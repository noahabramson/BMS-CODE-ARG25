# Copyright (c) 2023 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.BMS import BMS
from Engine.Interfaces.NoCon import NoCon
from jinja2 import Template
import math

class ArduinoConverter:
    """
    Object that can be used for converting command list to arduino. You make it ones, and then you can
    call it multiple times for different command_lists. The object will keep track of everything. After that,
    you give the convert command and everything should be converted as expected to Arduino Code.
    """
    def __init__(self):
        # list of the names of the command_lists that have been converted
        self.cmd_list_names = []
        #  Counter for the command_lists. This makes sure they all have a unique name
        self.cmd_list_cnt = 0
        # list of dicts that contain the replacement data for the template. Basicly the input for jinja2
        self.replace_dicts = []
        # Counter for functions. This makes sure they all have a unique name
        self.func_cnt = 0
        self.func_dicts = []
        self.jp_list_cnt = 0

    def __convert_to_c_code(self, python_lst):
        """
        :method: convert_to_c_code replaces [ with { and ] with }
        :param python_lst: The list of ints that has to be converted to a c-style array
        :type python_lst: required, list of ints
        """

        # If the list is 2d, convert it to 1d to make it C-compatible
        if isinstance(python_lst[0], list):
            python_lst = [item for sublist in python_lst for item in sublist]

        # Convert to str and replace the square brackets by curely brackets
        temp = str(python_lst)
        temp = temp.replace("[", "{")
        temp = temp.replace("]", "}")
        return temp

    def __create_c_function(self, cmd, bms, rx_cnt, list_name):
        """
        This function creates a c-function. If map_key="$ACCI==3;jp list3", there will be a check on ACCI being three.
        If this is not the case, it should jump to list3. However, this part has not been implemented yet. At the moment
        it will increase the err counter. If the err counter is nonzero, it will print this.

        The idea is, that it will jump to list3 or increase the err counter. These are future idea.
        :param cmd: cmd object
        :param bms: bms object
        :param rx_cnt: rx cnt, counter of recieved bytes
        :param list_name: name of the command where this function should be checking
        :return: lut with information for jinja2 to create the functions for arduino
        """
        # Check if it's a branch command in the map_key
        # TODO: use kwargs instead of abusing map_key
        # TODO: Add jp list3, err, print commands

        if cmd.map_key and cmd.map_key[0] == '$' and cmd.map_key[-1] == '$':
            ################################## Process command
            # Remove dollar signs
            branch = cmd.map_key.replace("$", "")

            # Decompose command in different sections
            target_bitfield, target_value = branch.split("==")
            target_value, target_op = target_value.split(";")

            # Convert target_value to bit list
            target_value = bms.convert_byte_list_to_bit_list([int(target_value)])

            ########### Preparing the mask ###########################
            target_position = []
            target_byte = []
            # Find the bitfield information to create the mask
            for bitfield in cmd.variable_bitfields[0]:
                if target_bitfield == bitfield.NAME:
                    target_position.extend(bitfield.bit_list_index)
                    # Convert bits to byte position
                    temp = [math.floor((bf - 32) / 8) for bf in bitfield.bit_list_index]
                    target_byte.extend(temp)

            # Trow errors in case of: wrong bitfield, bitfield for multi bytes
            if not target_position:
                raise ValueError(
                    f"Bitfield {target_bitfield} used in branch map_key is not found in {cmd.NAME}")
            elif len(set(target_byte)) > 1:
                raise ValueError(
                    f"Bitfield {target_bitfield} is spread over different bytes. This function can only cover single byte verification")

            # Create mask
            bit_mask = [0] * 8
            # Fill the mask
            for index, bit in enumerate(sorted(target_position)):
                # print(f"bit {bit}")
                # print(f"index {index}")
                # print(f"bit_pos {7-(bit % 8)}")
                # print(f"target_value[index] {target_value[7-index]}")
                bit_mask[(bit % 8)] = target_value[7 - index]
            # Create byte of mask instead of list of bits

            ###### Prepare all the variables for Jinja
            mask = bms.convert_bit_list_to_byte(bit_mask)
            # Because of the verification that all bits are in the same byte, it is possible to simply select a random (or the first) value from the list
            position_ptr = rx_cnt + target_byte[0]
            function_name = f"{cmd.NAME}{self.func_cnt}"

            # Prepare function replace table
            func_list = {
                'position': self.__convert_to_c_code([position_ptr]),
                'mask': self.__convert_to_c_code([mask]),
                'len': 1, # Keep 1 untill multi byte value are allowed
                'result': self.__convert_to_c_code([mask]),
                'func_name': function_name,
                'rx_buffer': f"rx_buffer_ptr{list_name}",
            }

            # In case the operation is jump instead of err, it will jump to the given command_list
            target_lst_name = target_op.split(" ")[1]
            # Prepare the jinja2 dict
            if 'jp' in target_op:
                jump_list = {
                    "jp": True,
                    "VAL_RX_BUFFER_LEN": str(int(rx_cnt)),
                    "NAME_RX_BUFFER_LEN": "RX_BUFFER_LEN" + target_lst_name.upper(),
                    "NAME_TX_DATA_LEN": "TX_DATA_LEN" + target_lst_name.upper(),
                    "NAME_TX_DATA_PTR": "TX_DATA_PTR" + target_lst_name.upper(),
                    "NAME_TX_INFO_PTR": "TX_INFO_PTR" + target_lst_name.upper(),
                    "NAME_TX_INFO_LEN": "TX_INFO_LEN" + target_lst_name.upper(),
                    "NAME_PRINT2SERIAL": "PRINT2SERIAL" + target_lst_name.upper(),
                    "NAME_LIST": str(target_lst_name),
                    "name_tx_data_ptr": "tx_data_ptr" + target_lst_name,
                    "name_tx_info_ptr": "tx_info_ptr" + target_lst_name,
                    "name_rx_buffer_ptr": "rx_buffer_ptr" + target_lst_name,
                }
                func_list.update(jump_list)

            # Make sure to increase the func counter
            self.func_cnt +=1

            return func_list
        else:
            return 0



    def convert_command_list(self,command_list, board_list, init_list=False, jp_list=False,list_name='auto_gen', print2serial=0):
        """
        This will convert a command list to arduino code. It also has the possibilty to create branches.
        :param command_list: The command_list that you want to convert.
        :param board_list: Board list like you are used to. List of devices.
        :param init_list: If it's an init list or not. If it is, it only runs one time
        :param list_name: Name of the list you want to convert. For example command_list
        :param print2serial: If you want the data on the serial bus on the arduino
        :return: nothing, it will create an arduino script
        """
        # Generate name if name is auto_gen
        if list_name=='auto_gen':
            if init_list:
                list_name = f"init{self.cmd_list_cnt}"
            elif jp_list:
                list_name = f"jp{self.cmd_list_cnt}"
            else:
                list_name = f"loop{self.cmd_list_cnt}"
        self.cmd_list_names.append(list_name)
        self.cmd_list_cnt +=1


        # Create the BMS Object with NoCon
        interface = NoCon()
        bms = BMS(interface=interface)
        compiled = bms.translate_command_list_to_compiled_commands(command_list, board_list)

        # Create transmit data and transmit info lists
        # Create counters for rx and tx
        transmit_data = []
        transmit_info = []
        rx_cnt = 0
        tx_cnt = 0

        # Go over command list to convert data to arduino compatible code
        for index, cmd in enumerate(compiled):
            # SDP-K1 command
            if '$' == cmd.NAME[0] and '$' == cmd.NAME[-1]:
                if cmd.NAME == '$DELAY_US$':
                    transmit_info.append([0, 0, interface.interface.COMMAND_TYPES["delay_us"], cmd.bytes[-1]])
                elif cmd.NAME == '$DELAY_MS$':
                    transmit_info.append([0, 0, interface.COMMAND_TYPES["delay_ms"], cmd.bytes[-1]])
                # Set wake_up time in us
                elif cmd.NAME == '$SPI_WAKEUP$':
                    transmit_info.append([1, 0, interface.COMMAND_TYPES["spi_wakeup"], cmd.bytes[-2]])
                    transmit_data.extend([0xFF])
                    # rx_cnt += cmd.bytes[-1]
                tx_cnt += 1

            # If not SDP commands, but normal BMS Commands
            else:
                transmit_info.append([int(cmd.tx_length/8), int(cmd.rx_length/8), 0, 0])
                transmit_data.extend(cmd.bytes)

                # Check if there are functions defined. If not, keep zero.
                func = self.__create_c_function(cmd, bms, rx_cnt, list_name)
                if func:
                    self.func_dicts.append(func)

                # Increment the counters
                rx_cnt += int(cmd.rx_length/8)
                tx_cnt += 1

        # Convert list to C-code array
        c_transmit_info = self.__convert_to_c_code(transmit_info)
        c_transmit_data = self.__convert_to_c_code(transmit_data)

        # The big replacement table for the commands. The Function LUT is already made
        replace_dict = {
            "VAL_RX_BUFFER_LEN": str(int(rx_cnt)),
            "NAME_RX_BUFFER_LEN": "RX_BUFFER_LEN" + list_name.upper(),
            "VAL_TX_DATA_LEN": str(len(transmit_data)),
            "NAME_TX_DATA_LEN": "TX_DATA_LEN" + list_name.upper(),
            "VAL_TX_DATA_PTR": str(c_transmit_data),
            "NAME_TX_DATA_PTR": "TX_DATA_PTR" + list_name.upper(),
            "VAL_TX_INFO_PTR": str(c_transmit_info),
            "NAME_TX_INFO_PTR": "TX_INFO_PTR" + list_name.upper(),
            "VAL_TX_INFO_LEN": str(tx_cnt),
            "NAME_TX_INFO_LEN": "TX_INFO_LEN" + list_name.upper(),
            "VAL_PRINT2SERIAL": str(print2serial),
            "NAME_PRINT2SERIAL": "PRINT2SERIAL" + list_name.upper(),
            "NAME_LIST": str(list_name),
            "init": init_list,
            "name_tx_data_ptr": "tx_data_ptr" + list_name,
            "name_tx_info_ptr": "tx_info_ptr" + list_name,
            "name_rx_buffer_ptr": "rx_buffer_ptr" + list_name,
        }

        # Create lut and save it in the object
        self.replace_dicts.append(replace_dict)

    def compile_template(self, template_in, path_out):
        """
        :method: Creates file from template based on Jinja2.
        Works just according to Jinja2 documentation.
        This method reads the template, create the file and writes the generated file

        :param template_in: path of the template file
        :type template_in: str, required
        :param path_out: path of where the result should go
        :type path_out: str, required
        """
        # Open template file, remove new lines and tabs from the code in the template
        with open(template_in, 'r') as file_:
            template = Template(file_.read(), trim_blocks=True, lstrip_blocks=True)

        # Render file
        # compiled_file = template.render(func_list=self.func_list, data_list=self.data_list)
        compiled_file = template.render(data_list=self.replace_dicts,func_list=self.func_dicts)

        # Write result to path out
        with open(path_out, 'w') as f:
            f.write(compiled_file)
            print("Creation of file from template success")

