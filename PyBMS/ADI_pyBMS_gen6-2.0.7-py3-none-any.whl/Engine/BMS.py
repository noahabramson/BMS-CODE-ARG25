# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import os
from importlib import import_module
from Engine.Devices.BMS_Config import Bitfield, MATH_EVAL
from Engine.setup_logger import init_logger


class BMS(object):
    logger = init_logger()


    def __init__(self, interface, bms_config_dir='Devices'):
        """
        Class containing methods to create/parse SPI strings for interfacing with BMS ICs. Also contains helper
        functions to help automate certain common tasks

        :param interface: Object to handle physical connection to devices
        :type interface: Interface object, Required
        :param bms_config_dir: Directory pointing to memory maps of BMS ICs
        :type bms_config_dir: str, optional, default='Devices'
        """

        # Interfaces and devies
        self.interface = interface
        self.BMS_CONFIGS = BMS.import_bms_configs(bms_config_dir)
        # Make preparations to save the board_list
        self.saved_board_list = []

    @staticmethod
    def import_bms_configs(bms_dir):
        """
        Imports BMS memory maps and command lists

        :param bms_dir: Directory containing BMS configs
        :type bms_dir: Str, Required
        :return: BMS Configs Objects in a dict
        :rtype: dict
        """

        bms_configs = {}
        path = os.path.join(os.path.dirname(__file__), bms_dir)
        for config in os.listdir(path):
            try:
                if '__' in config:
                    continue
                if not config.endswith(".py"):
                    continue
                if config == 'BMS_Config.py':
                    continue
                config = config[:-3]
                s = "{:s}.{:s}.{:s}".format(__package__, bms_dir.replace('/', '.'), config)
                bmsclass = getattr(import_module(s), config)
                bms_configs[config.split('.')[0]] = bmsclass
            except Exception:
                BMS.logger.warning("Could not import BMS Config [%s]" % config)
        return bms_configs

    @staticmethod
    def convert_byte_list_to_bit_list(data_bytes):
        """
        Converts bytes to a list of bits

        :param data_bytes: List of bytes that has to be converted to a bit list
        :type data_bytes: List, Required
        :return: List of bits
        """
        bit_list = []
        for byte in data_bytes:
            # Give a warning in case there is an out of range value
            if byte < 0 or byte > 255:
                BMS.logger.error("Byte in %s is out of range" %str(data_bytes))
            for i in [7, 6, 5, 4, 3, 2, 1, 0]:
                bit_list.append((byte >> i) & 0x01)
        return bit_list

    @staticmethod
    def convert_bit_list_to_byte(bit_list):
        """
        Inverse of bytes to a bit_list. Namely, bit_list to a byte
        :param bit_list: list of bits
        :return: byte
        """
        out = 0
        for bit in bit_list:
            out = (out << 1) | bit
        return out

    def translate_command_list_to_compiled_commands(self, command_list, board_list, spi_bus=0, spi_cs=0, loop=None, **kwargs):
        """
        Processes the command_list to a single format. This takes care of all the actions of the arguments in the command.

        :param command_list: The list of commands in the scratchpads. For example: [{"command": "ADI1", "arguments": {"OPT": 8}]
        :param board_list: The dict that contains device objects. For example: [{'Device': ADBMS2950}]
        :param spi_bus: Which IsoSPI Bus (0 or 1). With the parameter you can globally set the bus for that run_command_list
        :param spi_cs: Which IsoSPI CS (0 or 1). With the parameter you can globally set the bus for that run_command_list
        :param loop: If the loop functionality it used. If none, just run once. Otherwise, run multiples
        :param kwargs:
        :return: command
        """

        compiled_list = []
        kwargs.update({'Num Boards': len(board_list)})

        # Save the board_list in the bms object if the board_list is not populated
        if len(self.saved_board_list) == 0:
            self.saved_board_list = board_list
        # If CCNT is not in board_list, add it. In this way, we can keep track of the CCNT per device
        for index, device_dict in enumerate(self.saved_board_list):
            if not 'CCNT' in device_dict:
                self.saved_board_list[index].update({'CCNT': 0})

        # It's not the most amazing solution there is, but it does make sure loop and non loop work the same way
        def process_command_vars(cmd):
            # Create command
            temp_kwargs = {}
            temp_kwargs.update(kwargs)
            temp_spi_bus = spi_bus
            temp_spi_cs = spi_cs

            if 'map_key' not in cmd:
                cmd['map_key'] = None
            if 'board_list' in cmd:
                temp_boardlist = []
                for j, board in enumerate(board_list):
                    temp_boardlist.append({})
                    temp_boardlist[-1].update(board)
                    temp_boardlist[-1].update(cmd['board_list'][j])
            else:
                temp_boardlist = board_list
            if 'arguments' in cmd:
                temp_kwargs.update(cmd['arguments'])
                # Check for save state
                for arg in cmd['arguments']:
                    for j, board in enumerate(temp_boardlist):
                        if arg in board['Device'].BITFIELDS:
                            if board['Device'].BITFIELDS[arg].SAVE_STATE:
                                board[arg] = cmd['arguments'][arg]
            if 'spi_bus' in cmd:
                temp_spi_bus = cmd['spi_bus']
            if 'spi_cs' in cmd:
                temp_spi_cs = cmd['spi_cs']


            # This finds the command (since it's always at the same place) and loads the object. Currently, it only processes device 0
            # TODO: Add spi_bus, spi_cs to kwargs. That makes it easier to keep track of everything
            command = board_list[0]['Device'].COMMANDS[cmd['command']](spi_cs=temp_spi_cs, spi_bus=temp_spi_bus, map_key=cmd['map_key'], **temp_kwargs)
            command.compile_command(temp_boardlist, **temp_kwargs)
            return command

        # If loop is define, create a loop
        # Else, process as single list
        if loop:
            for i in range(loop):
                temp_list = []
                for cmd in command_list:
                    # process commands
                    command = process_command_vars(cmd)
                    temp_list.append(command)
                compiled_list.append(temp_list)
        else:
            for cmd in command_list:
                # process commands
                command = process_command_vars(cmd)
                compiled_list.append(command)
        return compiled_list

    def run_compiled_list(self, compiled_list, repeated_run=False, clear_buffer=True, loop=None, timeout=50):
        """
        Function that runs the compiled list

        :param compiled_list:
        :param repeated_run:
        :param clear_buffer:
        :param loop:
        :param timeout:
        :return:
        """
        BMS.logger.info("--- Start Running Command List ---")
        if not repeated_run:
            # Add commands to interface board
            if loop:
                for command in compiled_list[0]:
                    self.interface.add_command_to_buffer(command)
            else:
                for command in compiled_list:
                    self.interface.add_command_to_buffer(command)
        if loop:
            data = self.interface.loop_commands_in_buffer(loop, timeout=timeout)
            if clear_buffer:
                self.interface.clear_commands_in_buffer(timeout=timeout)
        else:
            self.interface.run_commands_in_buffer(timeout=timeout)
            if clear_buffer:
                data = self.interface.get_commands(timeout=timeout)
            else:
                data = self.interface.raw_commands(timeout=timeout)
        return data

    @staticmethod
    def parse_command_list(raw_data, compiled_commands, board_list, loop=None):
        if loop:
            for i in range(loop):
                j=0
                index = 0
                while j < len(compiled_commands[i]):
                    if isinstance(compiled_commands[i][j], MATH_EVAL):
                        j += 1
                        continue
                    compiled_commands[i][j].parse_bitfields(BMS.convert_byte_list_to_bit_list(raw_data[i][index]), board_list)
                    j += 1
                    index += 1
        else:
            j = 0
            index = 0
            while j < len(compiled_commands):
                if isinstance(compiled_commands[j], MATH_EVAL):
                    j += 1
                    continue
                compiled_commands[j].parse_bitfields(BMS.convert_byte_list_to_bit_list(raw_data[index]), board_list)
                j += 1
                index += 1
        return compiled_commands


    def parsed_command_list_to_dict(self,compiled_command_list, board_list, include_raw=True, include_cmd_objects=False, loop=None):
        """
        Function that parses the raw spi data to readable data based on the command_list
        :param compiled_command_list: The compiled command list with the method translate_command_list_to_compiled_commands
        :param board_list: The board_list
        :param include_raw: Boolean if you want to include raw values or not
        :param include_cmd_objects: Boolean if you want to include the cmd objects
        :param loop: Boolean if it was ran in loop mode or bot
        :return:
        """

        # Set all PEC Status to True. First for loop then for normal mode
        if loop:
            results = []
            for i in range(loop):
                results.append({'All': [], 'Total_PEC_Status': True, 'Total_CCNT_Status': True})
        else:
            results = {'All': [], 'Total_PEC_Status': True, 'Total_CCNT_Status': True}

        # Process commands when in loop mode
        if loop:
            for i in range(loop):
                for command in compiled_command_list[i]:
                    # Process the CCNT in the loop
                    for index, device_dict in enumerate(self.saved_board_list):
                        if command.TYPE == 'spi_write':
                            self.saved_board_list[index]['CCNT'] += 1
                            # Reset command counter with softreset or reset command counter
                            if command.NAME == 'SRST' or command.NAME == 'RSTCC':
                                self.saved_board_list[index]['CCNT'] = 0
                            # Roll over to 1
                            if self.saved_board_list[index]['CCNT'] > 63:
                                self.saved_board_list[index]['CCNT'] = 0
                    results[i]['All'].append(command)
                    if command.total_pec_status is False:
                        results[i]['Total_PEC_Status'] = False
                    if command.map_key:
                        if command.map_key not in results[i]:
                            results[i][command.map_key] = []
                            results[i]['%s_RAW' % command.map_key] = []
                            for _ in board_list:
                                results[i][command.map_key].append({'Total_PEC_Status': True})
                                results[i]['%s_RAW' % command.map_key].append({'Total_PEC_Status': None})
                        for index, board in enumerate(board_list):
                            if isinstance(command, MATH_EVAL):
                                try:
                                    results[i][command.map_key][index][command.result] = eval(command.function.format(**results[i][command.map_key][index]))
                                except:
                                    results[i][command.map_key][index][command.result_name] = None
                            else:
                                # Update PEC
                                if not command.device_total_pec_status[index]:
                                    results[i][command.map_key][index]['Total_PEC_Status'] = False
                                # Static
                                for bitfield in command.static_bitfields:
                                    results[i][command.map_key][index][bitfield.NAME] = bitfield.value
                                    results[i]['%s_RAW' % command.map_key][index][bitfield.NAME] = bitfield.raw_val
                                # Variable
                                for bitfield in command.variable_bitfields[index]:
                                    results[i][command.map_key][index][bitfield.NAME] = bitfield.value
                                    results[i]['%s_RAW' % command.map_key][index][bitfield.NAME] = bitfield.raw_val
                                    if bitfield.NAME == 'CCNT':
                                        if self.saved_board_list[index]['CCNT'] != bitfield.value:
                                            results[i][command.map_key][index]['Total_CCNT_Status'] = False
                                        else:
                                            results[i][command.map_key][index]['Total_CCNT_Status'] = True

                if include_raw is False:
                    for command in compiled_command_list[i]:
                        results[i].pop('%s_RAW' % command.map_key, None)
        # Process commands in normal mode
        else:
            for command in compiled_command_list:
                # Increase Command counter for write commands
                for index, device_dict in enumerate(self.saved_board_list):
                    if command.TYPE == 'spi_write':
                        self.saved_board_list[index]['CCNT'] += 1
                        # Reset command counter with softreset or reset command counter
                        if command.NAME == 'SRST' or command.NAME == 'RSTCC':
                            self.saved_board_list[index]['CCNT'] = 0
                        # Roll over to 1
                        if self.saved_board_list[index]['CCNT'] > 63:
                            self.saved_board_list[index]['CCNT'] = 0

                # If it is desired to show the command objects, it shows them. Otherwise, it will not append them to the results
                if include_cmd_objects:
                    results['All'].append(command)
                # If the total pec status is False, make the status false
                if command.total_pec_status is False:
                    results['Total_PEC_Status'] = False

                if command.map_key:
                    if command.map_key not in results:
                        results[command.map_key] = []
                        results['%s_RAW' % command.map_key] = []
                        for _ in board_list:
                            results[command.map_key].append({'Total_PEC_Status': True})
                            results['%s_RAW' % command.map_key].append({'Total_PEC_Status': None})
                    for index, board in enumerate(board_list):
                        if isinstance(command, MATH_EVAL):
                            try:
                                results[command.map_key][index][command.result_name] = eval(command.function.format(**results[command.map_key][index]))
                            except:
                                results[command.map_key][index][command.result_name] = None
                        else:
                            # Update PEC
                            if not command.device_total_pec_status[index]:
                                results[command.map_key][index]['Total_PEC_Status'] = False
                            # Static
                            for bitfield in command.static_bitfields:
                                results[command.map_key][index][bitfield.NAME] = bitfield.value
                                results['%s_RAW' % command.map_key][index][bitfield.NAME] = bitfield.raw_val
                            # Variable
                            for bitfield in command.variable_bitfields[index]:
                                results[command.map_key][index][bitfield.NAME] = bitfield.value
                                results['%s_RAW' % command.map_key][index][bitfield.NAME] = bitfield.raw_val
                                # Process the command counter
                                if bitfield.NAME == 'CCNT':
                                    if self.saved_board_list[index]['CCNT'] != bitfield.value:
                                        results[command.map_key][index]['Total_CCNT_Status'] = False
                                    else:
                                        results[command.map_key][index]['Total_CCNT_Status'] = True

            if include_raw is False:
                for command in compiled_command_list:
                    results.pop('%s_RAW' % command.map_key, None)
        # BMS.logger.info(results)
        return results

    def run_generic_command_list(self, command_list, board_list, repeated_run=False,
                                 clear_buffer=True, spi_bus=0, spi_cs=0, loop=None, timeout=50, include_raw=True, include_cmd_objects=False,
                                 **kwargs):
        """
        This is the top level function for running command lists.
        This function that takes a generic list of commands with arguments, runs the commands, and then parses the results.
        At this time, all arguments are global for devices in the daisy chain.

        :param command_list: List of dictionaries containing commands and any associated arguments
        :param board_list: List of boards as definied by BMS Configs
        :param repeated_run: Boolean indicating that this is a repeated run and it is not necessary to add commands
        :param clear_buffer: Boolean to clear out the interface buffer once the results have been read back
        :param spi_bus: SPI bus number on the interface
        :param spi_cs: SPI CS number on the interface
        :param loop: None for no looping, otherwise indicates how many command loops should be run
        :param timeout: Timeout for looping/printing results
        :param include_raw: Include raw versions of data
        :param kwargs: Arguments to be passed to parse/create commands functions
        :return: List of dictionaries containing commands results and board info
        """
        # Compile command list
        compiled_command_list = self.translate_command_list_to_compiled_commands(command_list, board_list, spi_bus=spi_bus, spi_cs=spi_cs, loop=loop, **kwargs)

        # Run list
        data = self.run_compiled_list(compiled_command_list, repeated_run=repeated_run, clear_buffer=clear_buffer, loop=loop, timeout=timeout)

        # Parse Results
        compiled_command_list = self.parse_command_list(data, compiled_command_list, board_list, loop=loop)

        # Get results ready to return
        return self.parsed_command_list_to_dict(compiled_command_list, board_list, include_raw=include_raw, loop=loop,
                                                include_cmd_objects=include_cmd_objects)


    def safety_loop(self, board_list, variant='Broadcast', safety_metric='Loop', limit_override=None, command_override=None, spi_bus=0, spi_cs=0, **kwargs):
        # Build safety command list, run list, using device functions to parse results
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        command_set = []
        for device in board_list_copy:
            if safety_metric in device['Device'].SAFETY_COMMAND_LISTS:
                if device['Device'].SAFETY_COMMAND_LISTS[safety_metric] not in command_set:
                    command_set.append(deepcopy(device['Device'].SAFETY_COMMAND_LISTS[safety_metric]))
        for item in command_set:
            for command in item:
                if command_override:
                    if 'override' in command:
                        for override in command['override']:
                            command['arguments'][override] = command_override[override]
                command_list.append(command)
        # Run command list
        results = self.run_generic_command_list(command_list, board_list_copy, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            if limit_override:
                board_list_copy[i]['Device'].decode_safety_loop(results, i, safety_metric=safety_metric, limit_override=limit_override[i])
            else:
                board_list_copy[i]['Device'].decode_safety_loop(results, i, safety_metric=safety_metric)
        return results


    def execute_commands_in_loop(self, board_list, variant='Broadcast', delay=None, loop=1, spi_bus=0, spi_cs=0, timeout=None,loop_commmands_list= [], **kwargs):
        # Check if board list is empty or None
        results = ""
        if len(board_list) == 0:
            BMS.logger.error("Board list empty")
            raise ValueError("Board list can't be empty")

        # Check if there are commands to be looped
        if len(loop_commmands_list) == 0:
            BMS.logger.error("Command list empty")
            raise ValueError("Command list can't be empty")

        # Check if loop variable is actually loopable
        if loop > 1:
            # Run and parse commands
            results = self.run_generic_command_list(loop_commmands_list, board_list, loop=loop, variant=variant,
                                                    spi_bus=spi_bus, spi_cs=spi_cs, timeout=timeout, **kwargs) # executes in loop
        else:
            # Throw critical when not enough loops are indicated
            BMS.logger.critical("Invalid command list. Not enough loops. Loops=<1")
            return 0
        return results

    def wakeup(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        # Create and run command list
        output = self.run_generic_command_list(wakeup_cmds, board_list_copy, variant=variant, spi_bus=spi_bus,
                                               spi_cs=spi_cs, **kwargs)
        return output

    def write_configs(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Create set of write config commands needed
        cfg_set = []
        for device in board_list_copy:
            if device['Device'].CFG_WRITE_CMDS not in cfg_set:
                cfg_set.append(device['Device'].CFG_WRITE_CMDS)
        cfg_cmds = []
        for cmd_set in cfg_set:
            cfg_cmds += cmd_set
        command_list += cfg_cmds
        # Run and parse commands
        self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs,
                                      **kwargs)

    def read_configs(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Create set of read config commands needed
        cfg_set = []
        for device in board_list_copy:
            if device['Device'].CFG_READ_CMDS not in cfg_set:
                cfg_set.append(device['Device'].CFG_READ_CMDS)
        cfg_cmds = []
        for cmd_set in cfg_set:
            cfg_cmds += cmd_set
        command_list += cfg_cmds
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['CONFIG'][i]
            board_list_copy[i]['Config'] = []
        for device in board_list_copy:
            for cfg in device['Device'].CFG:
                device['Config'].append(device['Data'][cfg])
        return board_list_copy

    def read_sid(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Create set of read config commands needed
        sid_set = []
        for device in board_list_copy:
            if device['Device'].SID_READ_CMDS not in sid_set:
                sid_set.append(device['Device'].SID_READ_CMDS)
        sid_cmds = []
        for cmd_set in sid_set:
            sid_cmds += cmd_set
        command_list += sid_cmds
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['SID'][i]
        return board_list_copy

    def measure_leakage(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed

        conversion_set = []
        for device in board_list_copy:
            if device['Device'].LEAKAGE_CMDS not in conversion_set:
                conversion_set.append(device['Device'].LEAKAGE_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds

        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['SPINS'][i]
            board_list_copy[i]['Leakage'] = []
        for device in board_list_copy:
            for cell in device['Device'].SPINS:
                device['Leakage'].append(device['Data'][cell])
        return board_list_copy

    def measure_cells(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].CELL_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].CELL_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CELL_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['CELLS'][i]
            board_list_copy[i]['Cells'] = []
        for device in board_list_copy:
            for cell in device['Device'].CELLS:
                device['Cells'].append(device['Data'][cell])
        return board_list_copy

    def measure_cells_with_sample_rate(self, board_list, variant='Broadcast', delay=5, sameple_rate=50, samples=20,
                                       sample_rate_skew=1, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        # Either poll or time delay
        adc_delay_cmds = [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
        sample_rate_delay = int((1.0 / sameple_rate) * 1000) - delay + sample_rate_skew
        sample_rate_delay_cmds = [{'command': "$DELAY_MS$", 'arguments': {"Delay": sample_rate_delay}}]
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CELL_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        for i in range(samples):
            command_list += wakeup_cmds
            command_list += conversion_cmds
            command_list += adc_delay_cmds
            command_list += wakeup_cmds
            for command in read_set:
                command.update({'map_key': str(i)})
                command_list.append(deepcopy(command))
            command_list += sample_rate_delay_cmds
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = []
            board_list_copy[i]['Cells'] = []
            for j in range(samples):
                board_list_copy[i]['Data'].append(results[str(j)][i])
        for device in board_list_copy:
            for i in range(len(device['Device'].CELLS)):
                device['Cells'].append([])
                for j in range(samples):
                    device['Cells'][i].append(device['Data'][j][device['Device'].CELLS[i]])
        return board_list_copy

    def measure_cells_filtered(self, board_list, variant='Broadcast', delay=None, filter_time_offset=None,
                               start_conversion=True, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        if start_conversion:
            # Run conversion for all boards
            # Create set of conversion commands needed
            conversion_set = []
            for device in board_list_copy:
                if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                    conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
            conversion_cmds = []
            for cmd_set in conversion_set:
                conversion_cmds += cmd_set
            command_list += conversion_cmds
        if filter_time_offset:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": filter_time_offset}}]
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].CELL_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].CELL_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].FILTERED_CELL_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['FCELLS'][i]
            board_list_copy[i]['FCells'] = []
        for device in board_list_copy:
            for cell in device['Device'].FILTERED_CELLS:
                device['FCells'].append(device['Data'][cell])
        return board_list_copy

    def measure_cells_averaged(self, board_list, variant='Broadcast', delay=50, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].CELL_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].CELL_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].AVERAGED_CELL_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, CONT=True, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['ACELLS'][i]
            board_list_copy[i]['ACells'] = []
        for device in board_list_copy:
            for cell in device['Device'].AVERAGED_CELLS:
                device['ACells'].append(device['Data'][cell])
        return board_list_copy

    def measure_cells_with_repeat_first_conv(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0,
                                             **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].CELL_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].CELL_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
        # Repeat for second conversion
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CELL_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].CELL_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].CELL_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].CELL_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CELL_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['CELLS'][i]
            board_list_copy[i]['Cells'] = []
        for device in board_list_copy:
            for cell in device['Device'].CELLS:
                device['Cells'].append(device['Data'][cell])
        return board_list_copy

    def measure_aux(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].AUX_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].AUX_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].AUX_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].AUX_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].AUX_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['AUX'][i]
            board_list_copy[i]['Aux'] = []
        for device in board_list_copy:
            for aux in device['Device'].AUX:
                device['Aux'].append(device['Data'][aux])
        return board_list_copy

    def measure_stat(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].STAT_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].STAT_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].STAT_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].STAT_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].STAT_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['STAT'][i]
            board_list_copy[i]['Stat'] = []
        for device in board_list_copy:
            for stat in device['Device'].STAT:
                device['Stat'].append(device['Data'][stat])
        return board_list_copy

    def measure_cell_impedance(self, board_list, spi_bus=0, spi_cs=0, cyc=10, measure_time=1.0, shunt=0.05, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].EIS_START_COMMANDS not in conversion_set:
                conversion_set.append(device['Device'].EIS_START_COMMANDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if hasattr(board_list_copy[0]['Device'], 'EIS_POLL_COMMANDS'):
            command_list += board_list_copy[0]['Device'].EIS_POLL_COMMANDS
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": (measure_time*1000)+10}}]
        command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].EIS_READ_COMMANDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list_copy, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['EIS_SAMPLE'][i]
            board_list_copy[i]['impedance_i'] = []
            board_list_copy[i]['impedance_q'] = []
            board_list_copy[i]['impedance_cell'] = []

        for device in board_list_copy:
            for cell in device['Device'].EISREAL:
                device['impedance_i'].append(device['Data'][cell])
            for cell in device['Device'].EISIMAG:
                device['impedance_q'].append(device['Data'][cell])
        for device in board_list_copy:
            if device['Device'].__name__ == 'ADBMS6830Z':
                i_comp = -1*device['impedance_i'][5] + -1j*device['impedance_q'][5]
            else:
                i_comp = -1*device['impedance_i'][len(device['Device'].EISREAL)-2] + -1j*device['impedance_q'][len(device['Device'].EISREAL)-2]
            for celln in range(len(device['Device'].CELLS)):
                v_comp = device['impedance_i'][celln] + 1j*device['impedance_q'][celln]
                if device['Device'].__name__ == 'ADBMS6830Z':
                    device['impedance_cell'].append(-1*v_comp / i_comp * shunt)
                else:
                    device['impedance_cell'].append(v_comp/i_comp*shunt)

        return board_list_copy

    def start_cell_impedance_measurement(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0,
                               cyc=10, shunt=0.05, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].EIS_START_COMMANDS not in conversion_set:
                conversion_set.append(device['Device'].EIS_START_COMMANDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        for device in board_list_copy:
            device['EFRQE']=cyc
        # Run and parse commands
        return self.run_generic_command_list(command_list, board_list_copy, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)

    def clear_cells(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Add clear cell command
        command_list += [{'command': 'CLRCELL'}]
        # Run and parse commands
        return self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs,
                                             **kwargs)

    def clear_aux(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Add clear aux command
        command_list += [{'command': 'CLRAUX'}]
        # Run and parse commands
        return self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs,
                                             **kwargs)

    def clear_stat(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Add clear stat command
        command_list += [{'command': 'CLRSTAT'}]
        # Run and parse commands
        return self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs,
                                             **kwargs)

    def measure_spins(self, board_list, variant='Broadcast', delay=None, spi_bus=0, spi_cs=0, **kwargs):
        """

        :param board_list:
        :param variant:
        :param delay:
        :param spi_bus:
        :param spi_cs:
        :param kwargs:
        :return:
        """
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].SPIN_CONVERSION_CMDS not in conversion_set:
                conversion_set.append(device['Device'].SPIN_CONVERSION_CMDS)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].SPIN_ADC_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].SPIN_ADC_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].SPIN_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, **kwargs)
        for i in range(len(board_list_copy)):
            board_list_copy[i]['Data'] = results['SPINS'][i]
            board_list_copy[i]['Spins'] = []
        for device in board_list_copy:
            for cell in device['Device'].SPINS:
                device['Spins'].append(device['Data'][cell])
        return board_list_copy

    def bci_communication_loop(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, loops=300,
                               timeout=5, **kwargs):
        com_set = []
        wakeup_set = []
        command_list = []
        pecs = []
        for device in board_list:
            pecs.append({'Errors': 0, 'Total': 0})
        # Create set of wakeup commands needed
        for device in board_list:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Add BCI commands
        for device in board_list:
            if device['Device'].BCI_COM_CMD_LIST not in com_set:
                com_set.append(device['Device'].BCI_COM_CMD_LIST)
        for com_command_set in com_set:
            command_list += com_command_set
        # Run commands
        result_maps = self.run_generic_command_list(command_list, board_list, variant=variant, loop=loops,
                                                    timeout=timeout, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)
        # Clear buffer
        self.interface.get_commands()
        # Parse results and count PEC errors as well as total possible PECs
        for result_map in result_maps:
            for i in range(len(board_list)):
                data = result_map[board_list[i]['Device'].BCI_COM_MAP_KEY][i]
                for pec in data['pec_match']:
                    pecs[i]['Total'] += 1
                    if not pec:
                        pecs[i]['Errors'] += 1
        return pecs

    def bci_analog_measurement_loop(self, board_list, suppress_com_errors, variant='Broadcast', spi_bus=0,
                                    spi_cs=0, loops=100, timeout=15, **kwargs):
        com_set = []
        wakeup_set = []
        command_list = []
        result_maps = []
        data = []
        # Initialize data array
        for device in board_list:
            data.append([])
        # Create set of wakeup commands needed
        for device in board_list:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Add BCI commands
        for device in board_list:
            if device['Device'].BCI_ANALOG_CMD_LIST not in com_set:
                com_set.append(device['Device'].BCI_ANALOG_CMD_LIST)
        for com_command_set in com_set:
            command_list += com_command_set
        # Run initialization script if present
        for device in board_list:
            if hasattr(device['Device'], 'BCI_ANALOG_INIT_CMD_LIST'):
                self.run_generic_command_list(device['Device'].WAKEUP_CMDS + device['Device'].BCI_ANALOG_INIT_CMD_LIST,
                                              board_list, variant=variant, spi_bus=spi_bus, spi_cs=spi_cs,
                                              timeout=timeout, **kwargs)
        # Run commands
        if hasattr(board_list[0]['Device'], 'BCI_ANALOG_LOOP_LIST'):
            command_list = board_list[0]['Device'].BCI_ANALOG_INIT_CMD_LIST + board_list[0]['Device'].BCI_ANALOG_CMD_LIST
            for i in range(loops):
                for cmd in board_list[0]['Device'].BCI_ANALOG_LOOP_LIST:
                    temp = cmd.copy()
                    if 'map_key' in cmd:
                        temp['map_key'] = temp['map_key'].format(i)
                    command_list.append(temp)
            raw_data = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                     spi_cs=spi_cs, timeout=timeout, **kwargs)
            result_maps = []
            for i in range(loops):
                key = board_list[0]['Device'].BCI_ANALOG_MAP_KEY + '_{}'
                key = key.format(i)
                result_maps.append({board_list[0]['Device'].BCI_ANALOG_MAP_KEY: raw_data[key], 'Total_PEC_Status': raw_data['Total_PEC_Status']})
        else:
            result_maps = self.run_generic_command_list(command_list, board_list, variant=variant, spi_bus=spi_bus,
                                                        spi_cs=spi_cs, loop=loops, timeout=timeout, **kwargs)
        # Clear buffer
        self.interface.get_commands()
        # Parse results and group data into arrays for easy manipulation
        for result_map in result_maps:
            # Check for com error suppression
            if suppress_com_errors and not result_map['Total_PEC_Status']:
                continue
            for i in range(len(board_list)):
                data_entry = []
                # Add metrics according to device configuration
                for metric in board_list[i]['Device'].BCI_ANALOG_METRICS:
                    # Boolean Check
                    if issubclass(board_list[i]['Device'].BITFIELDS[metric], BitfieldBool):
                        if result_map[board_list[i]['Device'].BCI_ANALOG_MAP_KEY][i][metric]:
                            data_entry.append(1)
                        else:
                            data_entry.append(0)
                    else:
                        data_entry.append(result_map[board_list[i]['Device'].BCI_ANALOG_MAP_KEY][i][metric])
                data[i].append(data_entry)
        return data

    def measure_stackvoltage(self, board_list, variant='Broadcast', delay=None, loop=1, spi_bus=0, spi_cs=0, timeout=10,
                             **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        command_list = []
        # Wake up all boards
        # Create set of wakeup commands needed
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            if device['Device'].CURRENT_CONVERSION_CMD1 not in conversion_set:
                conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        command_list += conversion_cmds
        # Either poll or time delay
        if not delay:
            # Create set of poll commands needed
            poll_set = []
            for device in board_list_copy:
                if device['Device'].I_VBat_POLL_CMDS not in poll_set:
                    poll_set.append(device['Device'].I_VBat_POLL_CMDS)
            poll_cmds = []
            for cmd_set in poll_set:
                poll_cmds += cmd_set
            command_list += poll_cmds
        else:
            command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
            command_list += wakeup_cmds
        # Read back all cell data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].VBAT_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(command_list, board_list, loop=loop, variant=variant, spi_bus=spi_bus,
                                                spi_cs=spi_cs, timeout=timeout, **kwargs)
        for liter in range(loop):
            key = 'Data' + str(liter)
            for i in range(len(board_list_copy)):
                board_list_copy[i][key] = results[liter]['VBAT']
        return board_list_copy

    def measure_current(self, board_list, variant='Broadcast', delay=None, loop=1, spi_bus=0, spi_cs=0, timeout=None,
                        **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        init_command_list = []
        # Wake up all boards
        # Create set of wakeup commands need
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        init_command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        ########
        for device in board_list_copy:
            if device['Device'].CURRENT_CONVERSION_CMD1 not in conversion_set:
                conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1)
        #######
        conversion_set += [[{'command': "$DELAY_MS$", 'arguments': {"Delay": 32}}]]  # Static delay for calibration

        for device in board_list_copy:
            # if device['Device'].CURRENT_CONVERSION_CMD1 not in conversion_set:
            conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1)
            conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD2)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        init_command_list += conversion_cmds

        # self.run_generic_command_list(init_command_list, board_list, variant=variant, spi_bus=spi_bus,
        #                              spi_cs=spi_cs, **kwargs)

        init_command_list += [{'command': "$DELAY_MS$", 'arguments': {"Delay": delay}}]
        init_command_list += wakeup_cmds
        # Read back all data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CURRENT_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        init_command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(init_command_list, board_list, loop=loop, variant=variant,
                                                spi_bus=spi_bus, spi_cs=spi_cs, timeout=timeout, **kwargs)
        for liter in range(loop):
            key = 'Data' + str(liter)
            for i in range(len(board_list_copy)):
                board_list_copy[i][key] = results[liter]['CURRENT']
        return board_list_copy

        # min value of loop set to 1, for atleast 1 value

    def measure_current_OC_Avg(self, board_list, variant='Broadcast', delay=None, loop=1, spi_bus=0, spi_cs=0,
                               timeout=None, **kwargs):
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        board_list_copy_raw = []
        for device in board_list:
            board_list_copy.append(device.copy())
            board_list_copy_raw.append(device.copy())
        init_command_list = []
        read_command_list = []
        # Wake up all boards
        # Create set of wakeup commands need
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        init_command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        ########
        for device in board_list_copy:
            if device['Device'].CURRENT_CONVERSION_CMD1 not in conversion_set:
                conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1)
        #######
        conversion_set += [[{'command': "$DELAY_MS$", 'arguments': {"Delay": 32}}]]  # Static delay for calibration

        for device in board_list_copy:
            # if device['Device'].CURRENT_CONVERSION_CMD1 not in conversion_set:
            conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1_CONT_RD)
            # conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD2)
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        init_command_list += conversion_cmds

        # self.run_generic_command_list(init_command_list, board_list, variant=variant, spi_bus=spi_bus,
        #                              spi_cs=spi_cs, **kwargs)

        init_command_list += [{'command': 'delay_ms', 'arguments': {"Delay": delay}}]
        init_command_list += wakeup_cmds
        # Read back all data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CURRENT_READ_CMDS_2:
                if cmd not in read_set:
                    read_set.append(cmd)
        init_command_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(init_command_list, board_list, loop=loop, variant=variant,
                                                spi_bus=spi_bus, spi_cs=spi_cs, timeout=timeout, **kwargs)
        return results

    def measure_current_continuously_init(self, board_list, variant='Broadcast', spi_bus=0, spi_cs=0, **kwargs):
        """ Function to measuere I1 and I2 continuously"""
        # Wakeup
        # ADI1- RD=1, CONT=1
        # Delay 600ms
        # RDI - in loop
        # Create new list of dictionaries to prevent data corruption of parameter dict
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())
        init_command_list = []
        # Wake up all boards
        # Create set of wakeup commands need
        wakeup_set = []
        for device in board_list_copy:
            if device['Device'].WAKEUP_CMDS not in wakeup_set:
                wakeup_set.append(device['Device'].WAKEUP_CMDS)  # WAKEUP 400us
        wakeup_cmds = []
        for cmd_set in wakeup_set:
            wakeup_cmds += cmd_set
        init_command_list += wakeup_cmds
        # Run conversion for all boards
        # Create set of conversion commands needed
        conversion_set = []
        for device in board_list_copy:
            conversion_set.append(device['Device'].CURRENT_CONVERSION_CMD1_CONT_RD)  # ADI1- RD=1,CONT=1
        conversion_set += [[{'command': 'delay_ms', 'arguments': {"Delay": 512}}]]  # Static delay for calibration
        conversion_cmds = []
        for cmd_set in conversion_set:
            conversion_cmds += cmd_set
        init_command_list += conversion_cmds

        # executes only once
        self.run_generic_command_list(init_command_list, board_list, variant=variant, spi_bus=spi_bus, loop=1,
                                      spi_cs=spi_cs, **kwargs)

    def measure_current_continuously_read(self, board_list, variant='Broadcast', delay=None, loop=1, spi_bus=0,
                                          spi_cs=0, timeout=None, **kwargs):
        """ Function to measuere I1 and I2 continuously"""
        board_list_copy = []
        for device in board_list:
            board_list_copy.append(device.copy())

        loop_commmads_list = []
        # Read back all data
        # Create set of read commands needed, this should not be additive like the other commands
        read_set = []
        for device in board_list_copy:
            for cmd in device['Device'].CURRENT_READ_CMDS:
                if cmd not in read_set:
                    read_set.append(cmd)
        for device in board_list_copy:
            for cmd in device['Device'].RDSTATC_READ_CMD:
                if cmd not in read_set:
                    read_set.append(cmd)
        loop_commmads_list += read_set
        # Run and parse commands
        results = self.run_generic_command_list(loop_commmads_list, board_list, loop=loop, variant=variant,
                                                spi_bus=spi_bus, spi_cs=spi_cs, timeout=timeout,
                                                **kwargs)  # executes in loop
        return results