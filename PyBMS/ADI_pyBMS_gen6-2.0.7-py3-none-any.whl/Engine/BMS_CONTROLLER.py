# Copyright (c) 2023 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.BMS import BMS

class BMS_CONTROLLER:
    def __init__(self, interface,  bms_config_dir='DUTs/BMS_Configs'):
        self.interface = interface
        self.TestCase = 0
        self.BMS_CONFIGS = BMS.import_bms_configs(bms_config_dir)

    def write(self,data):
        len = self.interface.write(data)
        return len
        #return #self.interface.read()

    def read(self, timeout):
        return  self.interface.read(timeout = timeout, include_termination = False)
        #return self.get_and_parse_data(testID, board_list)

    def get_and_parse_data(self, controller_comand, board_list, timeout=5):
        self.interface.write(controller_comand)
        output = self.interface.read(timeout=timeout)
        command_list = []
        result = []
        for line in output.splitlines():
            parts = line.split(':')
            if len(parts) == 3:
                command_list.append({'command': parts[0], 'variant': parts[1], 'data': []})
                for item in parts[2].split(','):
                    command_list[-1]['data'].append(int(item))
        for command in command_list:
            result.append(BMS.parse_spi_command_string(BMS.convert_byte_list_to_bit_list(command['data']), command['command'], command['variant'], board_list))
        return result