# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import Engine.Devices.BMS_Config as bmsbase
import Engine.Devices.ADBMS_GEN6 as gen6base
from copy import deepcopy
import math

# ===================================================== Bitfields =====================================================
# ===================================================== Registers =====================================================
class CFD0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD0'

    def __init__(self):
        super(CFD0, self).__init__([[gen6base.I1D, 0], [gen6base.V1D, 0], [gen6base.VDRUV, 0], [gen6base.OCMM, 0], [gen6base.OC3L, 0], [gen6base.OCAGD, 0], [gen6base.OCAL, 0], [gen6base.OC1L, 0]])


class CFD1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD1'

    def __init__(self):
        super(CFD1, self).__init__([[gen6base.I2D, 0], [gen6base.V2D, 0], [gen6base.VDDUV, 0], [gen6base.NOCLK, 0], [gen6base.REFFLT, 0], [gen6base.OCBGD, 0], [gen6base.OCBL, 0], [gen6base.OC2L, 0]])


class CFD2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD2'

    def __init__(self):
        super(CFD2, self).__init__([[gen6base.I2CNT, 2], [gen6base.I2CNT, 1], [gen6base.I2CNT, 0], [gen6base.I1CNT, 10], [gen6base.I1CNT, 9], [gen6base.I1CNT, 8], [gen6base.I1CNT, 7], [gen6base.I1CNT, 6]])


class CFD3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD3'

    def __init__(self):
        super(CFD3, self).__init__([[gen6base.I1CNT, 5], [gen6base.I1CNT, 4], [gen6base.I1CNT, 3], [gen6base.I1CNT, 2], [gen6base.I1CNT, 1], [gen6base.I1CNT, 0], [gen6base.I1PHA, 1], [gen6base.I1PHA, 0]])


class CFD4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD4'

    def __init__(self):
        super(CFD4, self).__init__([[gen6base.VREGOV, 0], [gen6base.VREGUV, 0], [gen6base.VDIGOV, 0], [gen6base.VDIGUV, 0], [gen6base.SED1, 0], [gen6base.MED1, 0], [gen6base.SED2, 0], [gen6base.MED2, 0]])


class CFD5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFD5'

    def __init__(self):
        super(CFD5, self).__init__([[gen6base.VDEL, 0], [gen6base.VDE, 0], [bmsbase.RSVD0, 0], [gen6base.SPIFLT, 0], [gen6base.RESET, 0], [gen6base.THSD, 0], [gen6base.TMODE, 0], [gen6base.OSCFLT, 0]])


class CFGAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR0'

    def __init__(self):
        super(CFGAR0, self).__init__([[gen6base.OCEN, 0], [gen6base.VS5, 0], [gen6base.VS4, 0], [gen6base.VS3, 0], [gen6base.VS2, 1], [gen6base.VS2, 0], [gen6base.VS1, 1], [gen6base.VS1, 0]])


class CFGAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR1'

    def __init__(self):
        super(CFGAR1, self).__init__([[gen6base.INJTM, 0], [gen6base.INJECC, 0], [bmsbase.RSVD0, 0], [gen6base.INJTS, 0], [gen6base.INJMON, 1], [gen6base.INJMON, 0], [gen6base.INJOSC, 1], [gen6base.INJOSC, 0]])


class CFGAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR2'

    def __init__(self):
        super(CFGAR2, self).__init__([[gen6base.SOAK, 2], [gen6base.SOAK, 1], [gen6base.SOAK, 0], [gen6base.VS10, 0], [gen6base.VS9, 0], [gen6base.VS8, 0], [gen6base.VS7, 0], [gen6base.VS6, 0]])


class CFGAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR3'

    def __init__(self):
        super(CFGAR3, self).__init__([[bmsbase.RSVD0, 0], [gen6base.GPO6C, 1], [gen6base.GPO6C, 0], [gen6base.GPO5C, 0], [gen6base.GPO4C, 0], [gen6base.GPO3C, 0], [gen6base.GPO2C, 0], [gen6base.GPO1C, 0]])


class CFGAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR4'

    def __init__(self):
        super(CFGAR4, self).__init__([[gen6base.SPI3W, 0], [gen6base.GPIO1FE, 0], [gen6base.GPO6OD, 0], [gen6base.GPO5OD, 0], [gen6base.GPO4OD, 0], [gen6base.GPO3OD, 0], [gen6base.GPO2OD, 0], [gen6base.GPO1OD, 0]])


class CFGAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR5'

    def __init__(self):
        super(CFGAR5, self).__init__([[gen6base.VB2MUX, 0], [gen6base.VB1MUX, 0], [gen6base.SNAPST, 0], [gen6base.REFUP, 0], [gen6base.COMMBK, 0], [gen6base.ACCI, 2], [gen6base.ACCI, 1], [gen6base.ACCI, 0]])


class CFGBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR0'

    def __init__(self):
        super(CFGBR0, self).__init__([[gen6base.OC1TEN, 0], [gen6base.OC1TH, 6], [gen6base.OC1TH, 5], [gen6base.OC1TH, 4], [gen6base.OC1TH, 3], [gen6base.OC1TH, 2], [gen6base.OC1TH, 1], [gen6base.OC1TH, 0]])


class CFGBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR1'

    def __init__(self):
        super(CFGBR1, self).__init__([[gen6base.OC2TEN, 0], [gen6base.OC2TH, 6], [gen6base.OC2TH, 5], [gen6base.OC2TH, 4], [gen6base.OC2TH, 3], [gen6base.OC2TH, 2], [gen6base.OC2TH, 1], [gen6base.OC2TH, 0]])


class CFGBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR2'

    def __init__(self):
        super(CFGBR2, self).__init__([[gen6base.OC3TEN, 0], [gen6base.OC3TH, 6], [gen6base.OC3TH, 5], [gen6base.OC3TH, 4], [gen6base.OC3TH, 3], [gen6base.OC3TH, 2], [gen6base.OC3TH, 1], [gen6base.OC3TH, 0]])


class CFGBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR3'

    def __init__(self):
        super(CFGBR3, self).__init__([[gen6base.OCTSEL, 1], [gen6base.OCTSEL, 0], [gen6base.REFTEN, 0], [bmsbase.RSVD0, 0], [gen6base.OCDP, 0], [bmsbase.RSVD0, 0], [gen6base.OCDGT, 1], [gen6base.OCDGT, 0]])


class CFGBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR4'

    def __init__(self):
        super(CFGBR4, self).__init__([[gen6base.OCBX, 0], [gen6base.OCAX, 0], [gen6base.OCMODE, 1], [gen6base.OCMODE, 0], [gen6base.OC3GC, 0], [gen6base.OC2GC, 0], [gen6base.OC1GC, 0], [gen6base.OCOD, 0]])


class CFGBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR5'

    def __init__(self):
        super(CFGBR5, self).__init__([[gen6base.GPIO4C, 0], [gen6base.GPIO3C, 0], [gen6base.GPIO2C, 0], [gen6base.GPIO1C, 0], [gen6base.GPIO2EOC, 0], [gen6base.DIAGSEL, 2], [gen6base.DIAGSEL, 1], [gen6base.DIAGSEL, 0]])


# ===================================================== Commands =====================================================
class WRCFGA(gen6base.WRCFGA):
    VARIABLE = [[CFGAR0(), False], [CFGAR1(), False], [CFGAR2(), False], [CFGAR3(), False], [CFGAR4(), False], [CFGAR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]

    def __init__(self, **kwargs):
        super(WRCFGA, self).__init__(**kwargs)


class WRCFGB(gen6base.WRCFGB):
    VARIABLE = [[CFGBR0(), False], [CFGBR1(), False], [CFGBR2(), False], [CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]

    def __init__(self, **kwargs):
        super(WRCFGB, self).__init__(**kwargs)


class RDCFGA(gen6base.RDCFGA):
    VARIABLE = [[CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDCFGA, self).__init__(**kwargs)


class RDCFGB(gen6base.RDCFGB):
    VARIABLE = [[CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDCFGB, self).__init__(**kwargs)


class RDALLA(gen6base.RDALLA):
    STATIC = [[gen6base.CMD_REGISTER(), False], [gen6base.CMD_PEC_REGISTER(), False],
              [gen6base.IAR0(), True], [gen6base.IAR1(), True], [gen6base.IAR2(), True], [gen6base.IAR3(), True], [gen6base.IAR4(), True], [gen6base.IAR5(), True],
              [gen6base.VBAR0(), True], [gen6base.VBAR1(), True], [gen6base.VBAR2(), True], [gen6base.VBAR3(), True], [gen6base.VBAR4(), True], [gen6base.VBAR5(), True],
              [gen6base.STR3(), True], [gen6base.STR4(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDALLA, self).__init__(**kwargs)


class RDALLC(gen6base.RDALLC):
    STATIC = [[gen6base.CMD_REGISTER(), False], [gen6base.CMD_PEC_REGISTER(), False],
              [CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True],
              [CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True],
              [gen6base.STR3(), True], [gen6base.STR4(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDALLC, self).__init__(**kwargs)


class RDALLI(gen6base.RDALLI):
    STATIC = [[gen6base.CMD_REGISTER(), False], [gen6base.CMD_PEC_REGISTER(), False],
              [gen6base.IR0(), True], [gen6base.IR1(), True], [gen6base.IR2(), True], [gen6base.IR3(), True], [gen6base.IR4(), True], [gen6base.IR5(), True],
              [gen6base.VBR2(), True], [gen6base.VBR3(), True], [gen6base.VBR4(), True], [gen6base.VBR5(), True],
              [gen6base.OVRIR0(), True], [gen6base.OVRIR1(), True], [gen6base.OVRIR2(), True],
              [gen6base.STR3(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDALLI, self).__init__(**kwargs)


class RDCVA(gen6base.RDI):
    NAME = 'RDCVA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVA, self).__init__(**kwargs)


class RDCVB(gen6base.RDVB):
    NAME = 'RDCVB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVB, self).__init__(**kwargs)


class RDCVC(gen6base.RDIVB1):
    NAME = 'RDCVC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVC, self).__init__(**kwargs)


class RDCVD(gen6base.RDV1A):
    NAME = 'RDCVD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVD, self).__init__(**kwargs)


class RDCVE(gen6base.RDV1B):
    NAME = 'RDCVE'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVE, self).__init__(**kwargs)


class RDCVF(gen6base.RDOC):
    NAME = 'RDCVF'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCVF, self).__init__(**kwargs)


class RDACA(gen6base.RDIACC):
    NAME = 'RDACA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACA, self).__init__(**kwargs)


class RDACB(gen6base.RDVBACC):
    NAME = 'RDACB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACB, self).__init__(**kwargs)


class RDACC(gen6base.RDIVB1ACC):
    NAME = 'RDACC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACC, self).__init__(**kwargs)


class RDACD(gen6base.RDV1A):
    NAME = 'RDACD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACD, self).__init__(**kwargs)


class RDACE(gen6base.RDV1B):
    NAME = 'RDACE'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACE, self).__init__(**kwargs)


class RDACF(gen6base.RDACF):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDACF, self).__init__(**kwargs)


class RDSVA(gen6base.RDV1C):
    NAME = 'RDSVA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVA, self).__init__(**kwargs)


class RDSVB(gen6base.RDV2C):
    NAME = 'RDSVB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVB, self).__init__(**kwargs)


class RDSVC(gen6base.RDV2A):
    NAME = 'RDSVC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVC, self).__init__(**kwargs)


class RDSVD(gen6base.RDV2B):
    NAME = 'RDSVD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVD, self).__init__(**kwargs)


class RDSVE(gen6base.RDSVE):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVE, self).__init__(**kwargs)


class RDSVF(gen6base.RDSVF):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSVF, self).__init__(**kwargs)


class RDFCA(gen6base.RDI):
    NAME = 'RDFCA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCA, self).__init__(**kwargs)


class RDFCB(gen6base.RDVB):
    NAME = 'RDFCB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCB, self).__init__(**kwargs)


class RDFCC(gen6base.RDIVB1):
    NAME = 'RDFCC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCC, self).__init__(**kwargs)


class RDFCD(gen6base.RDV1A):
    NAME = 'RDFCD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCD, self).__init__(**kwargs)


class RDFCE(gen6base.RDV1B):
    NAME = 'RDFCE'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCE, self).__init__(**kwargs)


class RDFCF(gen6base.RDOC):
    NAME = 'RDFCF'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFCF, self).__init__(**kwargs)


class RDAUXA(gen6base.RDV1A):
    NAME = 'RDAUXA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDAUXA, self).__init__(**kwargs)


class RDAUXB(gen6base.RDV1B):
    NAME = 'RDAUXB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDAUXB, self).__init__(**kwargs)


class RDAUXC(gen6base.RDV1D):
    NAME = 'RDAUXC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDAUXC, self).__init__(**kwargs)


class RDAUXD(gen6base.RDV2D):
    NAME = 'RDAUXD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDAUXD, self).__init__(**kwargs)


class RDAUXE(gen6base.RDAUXE):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDAUXE, self).__init__(**kwargs)


class RDRAXA(gen6base.RDV2A):
    NAME = 'RDRAXA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDRAXA, self).__init__(**kwargs)


class RDRAXB(gen6base.RDV2B):
    NAME = 'RDRAXB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDRAXB, self).__init__(**kwargs)


class RDRAXC(gen6base.RDRAXC):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDRAXC, self).__init__(**kwargs)


class RDRAXD(gen6base.RDV2E):
    NAME = 'RDRAXD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDRAXD, self).__init__(**kwargs)


class RDSTATA(gen6base.RDXA):
    NAME = 'RDSTATA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTATA, self).__init__(**kwargs)


class RDSTATB(gen6base.RDXB):
    NAME = 'RDSTATB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTATB, self).__init__(**kwargs)


class RDFLAG(gen6base.RDFLAG):
    VARIABLE = [[CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]

    def __init__(self, **kwargs):
        super(RDFLAG, self).__init__(**kwargs)


class RDSTATC(RDFLAG):
    NAME = 'RDSTATC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTATC, self).__init__(**kwargs)


class RDSTATD(gen6base.RDXC):
    NAME = 'RDSTATD'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTATD, self).__init__(**kwargs)


class RDSTATE(gen6base.RDSTAT):
    NAME = 'RDSTATE'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTATE, self).__init__(**kwargs)


class WRPWMA(gen6base.WRPWMA):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRPWMA, self).__init__(**kwargs)


class RDPWMA(gen6base.RDPWMA):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDPWMA, self).__init__(**kwargs)


class WRPWMB(gen6base.WRPWMB):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRPWMB, self).__init__(**kwargs)


class RDPWMB(gen6base.RDPWMB):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDPWMB, self).__init__(**kwargs)


class CMDIS(gen6base.CMDIS):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CMDIS, self).__init__(**kwargs)


class CMEN(gen6base.CMEN):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CMEN, self).__init__(**kwargs)


class CMHB(gen6base.CMHB):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CMHB, self).__init__(**kwargs)


class WRCMCFG(gen6base.WRCMCFG):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRCMCFG, self).__init__(**kwargs)


class RDCMCFG(gen6base.RDCMCFG):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCMCFG, self).__init__(**kwargs)


class WRCMCELLT(gen6base.WRCMCELLT):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRCMCELLT, self).__init__(**kwargs)


class RDCMCELLT(gen6base.RDCMCELLT):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCMCELLT, self).__init__(**kwargs)


class WRCMGPIOT(gen6base.WRCMGPIOT):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRCMGPIOT, self).__init__(**kwargs)


class RDCMGPIOT(gen6base.RDCMGPIOT):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCMGPIOT, self).__init__(**kwargs)


class CLRCMFLAG(gen6base.CLRCMFLAG):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRCMFLAG, self).__init__(**kwargs)


class RDCMFLAG(gen6base.RDCMFLAG):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDCMFLAG, self).__init__(**kwargs)


class ADCV(gen6base.ADCV):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADCV, self).__init__(**kwargs)


class ADSV(gen6base.ADSV):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADSV, self).__init__(**kwargs)


class ADAX(gen6base.ADAX):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADAX, self).__init__(**kwargs)


class ADAX2(gen6base.ADAX2):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADAX2, self).__init__(**kwargs)


class CLRCELL(gen6base.CLRI):
    NAME = 'CLRCELL'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRCELL, self).__init__(**kwargs)


class CLRFC(gen6base.CLRA):
    NAME = 'CLRFC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRFC, self).__init__(**kwargs)


class CLRAUX(gen6base.CLRVX):
    NAME = 'CLRAUX'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRAUX, self).__init__(**kwargs)


class CLRSPIN(gen6base.CLRSPIN):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRSPIN, self).__init__(**kwargs)


class CLRFLAG(gen6base.CLRFLAG):
    VARIABLE = [[CFD0(), False], [CFD1(), False], [CFD2(), False], [CFD3(), False], [CFD4(), False], [CFD5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]

    def __init__(self, **kwargs):
        super(CLRFLAG, self).__init__(**kwargs)


class CLOVUV(gen6base.CLOVUV):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLOVUV, self).__init__(**kwargs)


class PLCADC(gen6base.PLI1):
    NAME = 'PLCADC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLCADC, self).__init__(**kwargs)


class PLSADC(gen6base.PLI2):
    NAME = 'PLSADC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLSADC, self).__init__(**kwargs)


class PLAUX(gen6base.PLV):
    NAME = 'PLAUX'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLAUX, self).__init__(**kwargs)


class PLAUX2(gen6base.PLX):
    NAME = 'PLAUX2'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLAUX2, self).__init__(**kwargs)


class MUTE(gen6base.MUTE):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(MUTE, self).__init__(**kwargs)


class UNMUTE(gen6base.UNMUTE):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(UNMUTE, self).__init__(**kwargs)


class ULRR(gen6base.ULRR):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ULRR, self).__init__(**kwargs)


class WRRR(gen6base.WRRR):
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [gen6base.CCNT_REGISTER(), False], [gen6base.DATA_PEC_REGISTER(), False]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(WRRR, self).__init__(**kwargs)


class RDRR(gen6base.RDRR):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen6base.CCNT_REGISTER(), True], [gen6base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDRR, self).__init__(**kwargs)


class ADBMS2950(gen6base.ADBMS_GEN6):
    MEMORY_MAP = {
        **gen6base.ADBMS_GEN6.MEMORY_MAP,
        CFGAR0.NAME: CFGAR0,
        CFGAR1.NAME: CFGAR1,
        CFGAR2.NAME: CFGAR2,
        CFGAR3.NAME: CFGAR3,
        CFGAR4.NAME: CFGAR4,
        CFGAR5.NAME: CFGAR5,
        CFGBR0.NAME: CFGBR0,
        CFGBR1.NAME: CFGBR1,
        CFGBR2.NAME: CFGBR2,
        CFGBR3.NAME: CFGBR3,
        CFGBR4.NAME: CFGBR4,
        CFGBR5.NAME: CFGBR5,
        CFD0.NAME: CFD0,
        CFD1.NAME: CFD1,
        CFD2.NAME: CFD2,
        CFD3.NAME: CFD3,
        CFD4.NAME: CFD4,
        CFD5.NAME: CFD5,
    }
    BITFIELDS = {
        **gen6base.ADBMS_GEN6.BITFIELDS,
        gen6base.ACCI.NAME: gen6base.ACCI,
        gen6base.COMMBK.NAME: gen6base.COMMBK,
        gen6base.CONT.NAME: gen6base.CONT,
        gen6base.DER.NAME: gen6base.DER,
        gen6base.DIAGSEL.NAME: gen6base.DIAGSEL,
        gen6base.EPAD.NAME: gen6base.EPAD,
        gen6base.GPIO1C.NAME: gen6base.GPIO1C,
        gen6base.GPIO1FE.NAME: gen6base.GPIO1FE,
        gen6base.GPIO1L.NAME: gen6base.GPIO1L,
        gen6base.GPIO2C.NAME: gen6base.GPIO2C,
        gen6base.GPIO2EOC.NAME: gen6base.GPIO2EOC,
        gen6base.GPIO2L.NAME: gen6base.GPIO2L,
        gen6base.GPIO3C.NAME: gen6base.GPIO3C,
        gen6base.GPIO3L.NAME: gen6base.GPIO3L,
        gen6base.GPIO4C.NAME: gen6base.GPIO4C,
        gen6base.GPIO4L.NAME: gen6base.GPIO4L,
        gen6base.GPO1C.NAME: gen6base.GPO1C,
        gen6base.GPO1H.NAME: gen6base.GPO1H,
        gen6base.GPO1L.NAME: gen6base.GPO1L,
        gen6base.GPO1OD.NAME: gen6base.GPO1OD,
        gen6base.GPO2C.NAME: gen6base.GPO2C,
        gen6base.GPO2H.NAME: gen6base.GPO2H,
        gen6base.GPO2L.NAME: gen6base.GPO2L,
        gen6base.GPO2OD.NAME: gen6base.GPO2OD,
        gen6base.GPO3C.NAME: gen6base.GPO3C,
        gen6base.GPO3H.NAME: gen6base.GPO3H,
        gen6base.GPO3L.NAME: gen6base.GPO3L,
        gen6base.GPO3OD.NAME: gen6base.GPO3OD,
        gen6base.GPO4C.NAME: gen6base.GPO4C,
        gen6base.GPO4H.NAME: gen6base.GPO4H,
        gen6base.GPO4L.NAME: gen6base.GPO4L,
        gen6base.GPO4OD.NAME: gen6base.GPO4OD,
        gen6base.GPO5C.NAME: gen6base.GPO5C,
        gen6base.GPO5H.NAME: gen6base.GPO5H,
        gen6base.GPO5L.NAME: gen6base.GPO5L,
        gen6base.GPO5OD.NAME: gen6base.GPO5OD,
        gen6base.GPO6C.NAME: gen6base.GPO6C,
        gen6base.GPO6H.NAME: gen6base.GPO6H,
        gen6base.GPO6L.NAME: gen6base.GPO6L,
        gen6base.GPO6OD.NAME: gen6base.GPO6OD,
        gen6base.I1.NAME: gen6base.I1,
        gen6base.I1ACC.NAME: gen6base.I1ACC,
        gen6base.I1CAL.NAME: gen6base.I1CAL,
        gen6base.I1CNT.NAME: gen6base.I1CNT,
        gen6base.I1D.NAME: gen6base.I1D,
        gen6base.I1PHA.NAME: gen6base.I1PHA,
        gen6base.OPT.NAME: gen6base.OPT,
        gen6base.RD.NAME: gen6base.RD,
        gen6base.I2.NAME: gen6base.I2,
        gen6base.I2ACC.NAME: gen6base.I2ACC,
        gen6base.I2CAL.NAME: gen6base.I2CAL,
        gen6base.I2CNT.NAME: gen6base.I2CNT,
        gen6base.I2D.NAME: gen6base.I2D,
        gen6base.INJECC.NAME: gen6base.INJECC,
        gen6base.INJMON.NAME: gen6base.INJMON,
        gen6base.INJOSC.NAME: gen6base.INJOSC,
        gen6base.INJTM.NAME: gen6base.INJTM,
        gen6base.INJTS.NAME: gen6base.INJTS,
        gen6base.MED1.NAME: gen6base.MED1,
        gen6base.MED2.NAME: gen6base.MED2,
        gen6base.NOCLK.NAME: gen6base.NOCLK,
        gen6base.OC1GC.NAME: gen6base.OC1GC,
        gen6base.OC1L.NAME: gen6base.OC1L,
        gen6base.OC1R.NAME: gen6base.OC1R,
        gen6base.OC1TEN.NAME: gen6base.OC1TEN,
        gen6base.OC1TH.NAME: gen6base.OC1TH,
        gen6base.OC2GC.NAME: gen6base.OC2GC,
        gen6base.OC2L.NAME: gen6base.OC2L,
        gen6base.OC2R.NAME: gen6base.OC2R,
        gen6base.OC2TEN.NAME: gen6base.OC2TEN,
        gen6base.OC2TH.NAME: gen6base.OC2TH,
        gen6base.OC3GC.NAME: gen6base.OC3GC,
        gen6base.OC3L.NAME: gen6base.OC3L,
        gen6base.OC3MAX.NAME: gen6base.OC3MAX,
        gen6base.OC3MIN.NAME: gen6base.OC3MIN,
        gen6base.OC3R.NAME: gen6base.OC3R,
        gen6base.OC3TEN.NAME: gen6base.OC3TEN,
        gen6base.OC3TH.NAME: gen6base.OC3TH,
        gen6base.OCAGD.NAME: gen6base.OCAGD,
        gen6base.OCAL.NAME: gen6base.OCAL,
        gen6base.OCAP.NAME: gen6base.OCAP,
        gen6base.OCAX.NAME: gen6base.OCAX,
        gen6base.OCBGD.NAME: gen6base.OCBGD,
        gen6base.OCBL.NAME: gen6base.OCBL,
        gen6base.OCBP.NAME: gen6base.OCBP,
        gen6base.OCBX.NAME: gen6base.OCBX,
        gen6base.OCDGT.NAME: gen6base.OCDGT,
        gen6base.OCDP.NAME: gen6base.OCDP,
        gen6base.OCEN.NAME: gen6base.OCEN,
        gen6base.OCMM.NAME: gen6base.OCMM,
        gen6base.OCMODE.NAME: gen6base.OCMODE,
        gen6base.OCOD.NAME: gen6base.OCOD,
        gen6base.OCTSEL.NAME: gen6base.OCTSEL,
        gen6base.OSCCNT.NAME: gen6base.OSCCNT,
        gen6base.OSCFLT.NAME: gen6base.OSCFLT,
        gen6base.REFFLT.NAME: gen6base.REFFLT,
        gen6base.REFR.NAME: gen6base.REFR,
        gen6base.REFTEN.NAME: gen6base.REFTEN,
        gen6base.REFUP.NAME: gen6base.REFUP,
        gen6base.RESET.NAME: gen6base.RESET,
        gen6base.REVID.NAME: gen6base.REVID,
        gen6base.SED1.NAME: gen6base.SED1,
        gen6base.SED2.NAME: gen6base.SED2,
        gen6base.SNAPST.NAME: gen6base.SNAPST,
        gen6base.SOAK.NAME: gen6base.SOAK,
        gen6base.SPI3W.NAME: gen6base.SPI3W,
        gen6base.TMODE.NAME: gen6base.TMODE,
        gen6base.TMP1.NAME: gen6base.TMP1,
        gen6base.TMP2.NAME: gen6base.TMP2,
        gen6base.V1A.NAME: gen6base.V1A,
        gen6base.V1B.NAME: gen6base.V1B,
        gen6base.V1D.NAME: gen6base.V1D,
        gen6base.V2A.NAME: gen6base.V2A,
        gen6base.V2B.NAME: gen6base.V2B,
        gen6base.V2D.NAME: gen6base.V2D,
        gen6base.V3A.NAME: gen6base.V3A,
        gen6base.V3B.NAME: gen6base.V3B,
        gen6base.V4A.NAME: gen6base.V4A,
        gen6base.V4B.NAME: gen6base.V4B,
        gen6base.V5A.NAME: gen6base.V5A,
        gen6base.V5B.NAME: gen6base.V5B,
        gen6base.V6A.NAME: gen6base.V6A,
        gen6base.V6B.NAME: gen6base.V6B,
        gen6base.V7A.NAME: gen6base.V7A,
        gen6base.V8A.NAME: gen6base.V8A,
        gen6base.V9B.NAME: gen6base.V9B,
        gen6base.VB1.NAME: gen6base.VB1,
        gen6base.V10B.NAME: gen6base.V10B,
        gen6base.VB1ACC.NAME: gen6base.VB1ACC,
        gen6base.VB1MUX.NAME: gen6base.VB1MUX,
        gen6base.VB2.NAME: gen6base.VB2,
        gen6base.VB2ACC.NAME: gen6base.VB2ACC,
        gen6base.VB2MUX.NAME: gen6base.VB2MUX,
        gen6base.VCH.NAME: gen6base.VCH,
        gen6base.VDD.NAME: gen6base.VDD,
        gen6base.VDDUV.NAME: gen6base.VDDUV,
        gen6base.VDIG.NAME: gen6base.VDIG,
        gen6base.VDIGOV.NAME: gen6base.VDIGOV,
        gen6base.VDIGUV.NAME: gen6base.VDIGUV,
        gen6base.VDIV.NAME: gen6base.VDIV,
        gen6base.VDRUV.NAME: gen6base.VDRUV,
        gen6base.VREF1P25.NAME: gen6base.VREF1P25,
        gen6base.VREF2A.NAME: gen6base.VREF2A,
        gen6base.VREF2B.NAME: gen6base.VREF2B,
        gen6base.VREG.NAME: gen6base.VREG,
        gen6base.VREGOV.NAME: gen6base.VREGOV,
        gen6base.VREGUV.NAME: gen6base.VREGUV,
        gen6base.VS1.NAME: gen6base.VS1,
        gen6base.VS2.NAME: gen6base.VS2,
        gen6base.VS3.NAME: gen6base.VS3,
        gen6base.VS4.NAME: gen6base.VS4,
        gen6base.VS5.NAME: gen6base.VS5,
        gen6base.VS6.NAME: gen6base.VS6,
        gen6base.VS7.NAME: gen6base.VS7,
        gen6base.VS8.NAME: gen6base.VS8,
        gen6base.VS9.NAME: gen6base.VS9,
        gen6base.VS10.NAME: gen6base.VS10,
        gen6base.ERR.NAME: gen6base.ERR,
        gen6base.VDE.NAME: gen6base.VDE,
        gen6base.VDEL.NAME: gen6base.VDEL,
        gen6base.SPIFLT.NAME: gen6base.SPIFLT,
        gen6base.THSD.NAME: gen6base.THSD,
        gen6base.RSTF.NAME: gen6base.RSTF,
        gen6base.OW_AUX.NAME: gen6base.OW_AUX,
        gen6base.PUP.NAME: gen6base.PUP,
        gen6base.CH.NAME: gen6base.CH,
        gen6base.CH_AUX2.NAME: gen6base.CH_AUX2,
        gen6base.ICOM0.NAME: gen6base.ICOM0,
        gen6base.ICOM1.NAME: gen6base.ICOM1,
        gen6base.ICOM2.NAME: gen6base.ICOM2,
        gen6base.FCOM0.NAME: gen6base.FCOM0,
        gen6base.FCOM1.NAME: gen6base.FCOM1,
        gen6base.FCOM2.NAME: gen6base.FCOM2,
        gen6base.D0.NAME: gen6base.D0,
        gen6base.D1.NAME: gen6base.D1,
        gen6base.D2.NAME: gen6base.D2,
        gen6base.DCP.NAME: gen6base.DCP,
        gen6base.DTYPE.NAME: gen6base.DTYPE,
        gen6base.OW.NAME: gen6base.OW,
        gen6base.CMC_BTM.NAME: gen6base.CMC_BTM,
        gen6base.CMC_DIR.NAME: gen6base.CMC_DIR,
        gen6base.CMC_EN.NAME: gen6base.CMC_EN,
        gen6base.CMC_GOE.NAME: gen6base.CMC_GOE,
        gen6base.CMC_MAN.NAME: gen6base.CMC_MAN,
        gen6base.CMC_MPER.NAME: gen6base.CMC_MPER,
        gen6base.CMC_NDEV.NAME: gen6base.CMC_NDEV,
        gen6base.CMC_TPER.NAME: gen6base.CMC_TPER,
        gen6base.CMF_BTMCMP.NAME: gen6base.CMF_BTMCMP,
        gen6base.CMF_BTMWD.NAME: gen6base.CMF_BTMWD,
        gen6base.CMF_CDVN.NAME: gen6base.CMF_CDVN,
        gen6base.CMF_CDVP.NAME: gen6base.CMF_CDVP,
        gen6base.CMF_COV.NAME: gen6base.CMF_COV,
        gen6base.CMF_CUV.NAME: gen6base.CMF_CUV,
        gen6base.CMF_GDVN.NAME: gen6base.CMF_GDVN,
        gen6base.CMF_GDVP.NAME: gen6base.CMF_GDVP,
        gen6base.CMF_GOV.NAME: gen6base.CMF_GOV,
        gen6base.CMF_GUV.NAME: gen6base.CMF_GUV,
        gen6base.CMM_C.NAME: gen6base.CMM_C,
        gen6base.CMM_G.NAME: gen6base.CMM_G,
        gen6base.CMT_CDV.NAME: gen6base.CMT_CDV,
        gen6base.CMT_COV.NAME: gen6base.CMT_COV,
        gen6base.CMT_CUV.NAME: gen6base.CMT_CUV,
        gen6base.CMT_GDV.NAME: gen6base.CMT_GDV,
        gen6base.CMT_GOV.NAME: gen6base.CMT_GOV,
        gen6base.CMT_GUV.NAME: gen6base.CMT_GUV,

    }
    COMMANDS = {
        **gen6base.ADBMS_GEN6.COMMANDS,
        RDALLA.NAME: RDALLA,
        RDALLC.NAME: RDALLC,
        RDALLI.NAME: RDALLI,
        gen6base.RDALLR.NAME: gen6base.RDALLR,
        gen6base.RDALLV.NAME: gen6base.RDALLV,
        gen6base.RDALLX.NAME: gen6base.RDALLX,
        CLRFLAG.NAME: CLRFLAG,
        RDFLAG.NAME: RDFLAG,
        WRCFGA.NAME: WRCFGA,
        WRCFGB.NAME: WRCFGB,
        RDCFGA.NAME: RDCFGA,
        RDCFGB.NAME: RDCFGB,
        RDCVA.NAME: RDCVA,
        RDCVB.NAME: RDCVB,
        RDCVC.NAME: RDCVC,
        RDCVD.NAME: RDCVD,
        RDCVE.NAME: RDCVE,
        RDCVF.NAME: RDCVF,
        RDACA.NAME: RDACA,
        RDACB.NAME: RDACB,
        RDACC.NAME: RDACC,
        RDACD.NAME: RDACD,
        RDACE.NAME: RDACE,
        RDACF.NAME: RDACF,
        RDSVA.NAME: RDSVA,
        RDSVB.NAME: RDSVB,
        RDSVC.NAME: RDSVC,
        RDSVD.NAME: RDSVD,
        RDSVE.NAME: RDSVE,
        RDSVF.NAME: RDSVF,
        RDFCA.NAME: RDFCA,
        RDFCB.NAME: RDFCB,
        RDFCC.NAME: RDFCC,
        RDFCD.NAME: RDFCD,
        RDFCE.NAME: RDFCE,
        RDFCF.NAME: RDFCF,
        RDAUXA.NAME: RDAUXA,
        RDAUXB.NAME: RDAUXB,
        RDAUXC.NAME: RDAUXC,
        RDAUXD.NAME: RDAUXD,
        RDAUXE.NAME: RDAUXE,
        RDRAXA.NAME: RDRAXA,
        RDRAXB.NAME: RDRAXB,
        RDRAXC.NAME: RDRAXC,
        RDRAXD.NAME: RDRAXD,
        RDSTATA.NAME: RDSTATA,
        RDSTATB.NAME: RDSTATB,
        RDSTATC.NAME: RDSTATC,
        RDSTATD.NAME: RDSTATD,
        RDSTATE.NAME: RDSTATE,
        WRPWMA.NAME: WRPWMA,
        RDPWMA.NAME: RDPWMA,
        WRPWMB.NAME: WRPWMB,
        RDPWMB.NAME: RDPWMB,
        CMDIS.NAME: CMDIS,
        CMEN.NAME: CMEN,
        CMHB.NAME: CMHB,
        WRCMCFG.NAME: WRCMCFG,
        RDCMCFG.NAME: RDCMCFG,
        WRCMCELLT.NAME: WRCMCELLT,
        RDCMCELLT.NAME: RDCMCELLT,
        WRCMGPIOT.NAME: WRCMGPIOT,
        RDCMGPIOT.NAME: RDCMGPIOT,
        CLRCMFLAG.NAME: CLRCMFLAG,
        RDCMFLAG.NAME: RDCMFLAG,
        ADCV.NAME: ADCV,
        ADSV.NAME: ADSV,
        ADAX.NAME: ADAX,
        ADAX2.NAME: ADAX2,
        CLRCELL.NAME: CLRCELL,
        CLRFC.NAME: CLRFC,
        CLRAUX.NAME: CLRAUX,
        CLRSPIN.NAME: CLRSPIN,
        CLOVUV.NAME: CLOVUV,
        PLCADC.NAME: PLCADC,
        PLSADC.NAME: PLSADC,
        PLAUX.NAME: PLAUX,
        PLAUX2.NAME: PLAUX2,
        MUTE.NAME: MUTE,
        UNMUTE.NAME: UNMUTE,
        ULRR.NAME: ULRR,
        WRRR.NAME: WRRR,
        RDRR.NAME: RDRR,
    }

    Voltages = ['V1A', 'V1B', 'V2A', 'V2B', 'V3A', 'V3B', 'V4A', 'V4B', 'V5A', 'V5B', 'V6A', 'V6B', 'V7A', 'V8A', 'V9B', 'V10B', 'VREF2A', 'VREF2B', 'VREF1P25', 'VDIV', 'VREG', 'VDD', 'VDIG', 'EPAD', 'TMP1', 'TMP2']
    Currents = ['I1', 'I2']
    Avg_Currents = ['I1ACC', 'I2ACC']
    Avg_BAT = ['VB1ACC', 'VB2ACC']
    VBAT = ['VB1', 'VB2']
    GPIOS = ['ITMP', 'REF2', 'VREG']
    STAT = ['OCBP', 'OCAP', 'I2CAL', 'I1CAL', 'DER', 'GPO6H', 'GPO5H', 'GPO4H', 'GPO3H', 'GPO2H', 'GPO1H', 'GPO6L',
            'GPO5L', 'GPO4L', 'GPO3L', 'GPO2L', 'GPO1L', 'GPIO4L', 'GPIO3L', 'GPIO2L', 'GPIO1L', 'REVID', 'I1D', 'V1D',
            'VDRUV', 'OCMM', 'OC3L', 'OCAGD', 'OCAL', 'OC1L', 'I2D', 'V2D', 'VDDUV', 'NOCLK', 'REFFLT', 'OCBGD', 'OCBL',
            'OC2L', 'I2CNT', 'I1CNT', 'VDIGOV', 'VDIGUV', 'SED1', 'MED1', 'SED2', 'MED2', 'VDEL', 'VDE', 'SPIFLT',
            'RESET', 'THSD', 'TMODE', 'OSCFLT']
    CFG = ['OCEN', 'VS5', 'VS4', 'VS3', 'VS2', 'VS1', 'INJTM', 'INJECC', 'INJTS', 'INJMON', 'INJOSC', 'SOAK', 'VS10',
           'VS9', 'VS8', 'VS7', 'VS6', 'GPO6C', 'GPO5C', 'GPO4C', 'GPO3C', 'GPO2C', 'GPO1C', 'SPI3W', 'GPIO1FE',
           'GPO6OD', 'GPO5OD', 'GPO4OD', 'GPO3OD', 'GPO2OD', 'GPO1OD', 'VB2MUX', 'VB1MUX', 'SNAPST', 'REFUP', 'COMMBK',
           'ACCI', 'OC1TEN', 'OC1TH', 'OC2TEN', 'OC2TH', 'OC3TEN', 'OC3TH', 'OCTSEL', 'REFTEN', 'OCDP', 'OCDGT', 'OCBX', 'OCAX', 'OCMODE', 'OC3GC', 'OC2GC', 'OC1GC', 'OCOD', 'GPIO4C', 'GPIO3C', 'GPIO2C', 'GPIO1C', 'GPIO2EOC', 'DIAGSEL']

    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
    ]
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    CURRENT_CONVERSION_CMD1 = [
        {'command': 'ADI1'},
    ]
    CURRENT_CONVERSION_CMD1_CONT_RD = [
        {'command': 'ADI1','arguments': {'CONT': True, 'RD':True}},
    ]
    CURRENT_CONVERSION_CMD2 = [
        {'command': 'ADI2'},
    ]
    VOLTAGE_CONVERSION_CMD = [
        {'command': 'ADV'},
    ]
    AUX_CONVERSION_CMD = [
        {'command': 'ADAX'},
        {'command': 'ADAX2'},
    ]

    CURRENT_READ_CMDS = [
        {'command': 'RDI', 'map_key': 'CURRENT'},
    ]
    CURRENT_AVG_CURRENT_READ_CMDS = [
        {'command': 'RDIACC', 'map_key': 'CURRENT'},
    ]

    CURRENT_READ_CMDS_2 = [
        {'command': 'RDI', 'map_key': 'CURRENT'},
        {'command': 'RDOC', 'map_key': 'CURRENT'},
    ]

    VOLTAGE_READ_CMDS = [
        {'command': 'RDV1A', 'map_key': 'V_CHAN'},
        {'command': 'RDV1B', 'map_key': 'V_CHAN'},
        {'command': 'RDV1C', 'map_key': 'V_CHAN'},
        {'command': 'RDV1D', 'map_key': 'V_CHAN'},
        {'command': 'RDV2A', 'map_key': 'V_CHAN'},
        {'command': 'RDV2B', 'map_key': 'V_CHAN'},
        {'command': 'RDV2C', 'map_key': 'V_CHAN'},
        {'command': 'RDV2D', 'map_key': 'V_CHAN'}
    ]
    VBAT_READ_CMDS = [
        {'command': 'RDVBACC', 'map_key': 'VBAT'},
    ]

    ADC_POLL_CMDS = [
        {'command': 'PLADC'},
    ]

    I_VBat_POLL_CMDS = [
        {'command': 'PLIADC'},
    ]

    VADC_POLL_CMDS = [
        {'command': 'PLVADC'},
    ]

    PLAUX_POLL_CMDS = [
        {'command': 'PLAUX'},
    ]
    RDSTATC_READ_CMD = [
        {'command': 'RDSTATC', 'map_key': 'STATC'},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]
    BCI_ANALOG_INIT_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
        {"command": "SRST", "arguments": {}},
        {"command": "WRCFGA", "arguments": {}},
        {"command": "WRCFGB", "arguments": {}},
        {'command': 'RDCFGA', "arguments": {}},
        {'command': 'RDCFGB', "arguments": {}},
        {"command": "ADI1", "arguments": {"CONT": True, "RD": True}},
        {'command': "$DELAY_MS$", 'arguments': {"Delay": 500}},  # see Tiger errata A.IADCOFFS
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
        # {"command": "RDIAV", "map_key": "BCI_ANALOG"},
        {"command": "RDIAV"},
    ]
    BCI_ANALOG_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
        {"command": "ADI1", "arguments": {"CONT": True, "RD": True}},
    ]
    BCI_ANALOG_LOOP_LIST = [
        {'command': "$DELAY_US$", 'arguments': {"Delay": 6000}},  # minimum time 8ms
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
        {"command": "RDSTATC", "map_key": "BCI_ANALOG_{}"},  # to read CT,CTS
        {'command': 'loop',
         'arguments': {'loops': 0x00FF, 'mask': [0x00, 0x00, 0x1F, 0xFC, 0x00, 0x00, 0x00, 0x00], 'counter': 1}},
        # RDSTAC with STCR2/3 (CT) being monitored
        {"command": "RDIAV", "map_key": "BCI_ANALOG_{}"},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['I1ACC', 'I2ACC', 'CT', 'CTS']
    GUI_LOOP_CMD_LIST = [
        {"command": "$SPI_WAKEUP$", "arguments": {'Wakeup Time': 400}},
        {"command": "CLRFLAG", "arguments": {}},
        {"command": "WRCFGA", "arguments": {'ACCI': 7}},
        {"command": "WRCFGB", "arguments": {}},
        {"command": "RDCFGA", "arguments": {}, "map_key": "GUI"},
        {"command": "RDCFGB", "arguments": {}, "map_key": "GUI"},
        {"command": "ADI1", "arguments": {'RD': True, 'OPT': 8}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {'Wakeup Time': 10}},
        {"command": "RDI", "map_key": "GUI"},
        {"command": "RDVB", "map_key": "GUI"},
        {"command": "RDIACC", "map_key": "GUI"},
        {"command": "RDVBACC", "map_key": "GUI"},
        {"command": "RDOC", "map_key": "GUI"},
        {"command": "ADV", "arguments": {"VCH": 9}},
        {"command": "ADX", "arguments": {"ACH": 0}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {'Wakeup Time': 10}},
        {"command": "RDV1A", "map_key": "GUI"},
        {"command": "RDV1B", "map_key": "GUI"},
        {"command": "RDV1C", "map_key": "GUI"},
        {"command": "RDV1D", "map_key": "GUI"},
        {"command": "RDV2A", "map_key": "GUI"},
        {"command": "RDV2B", "map_key": "GUI"},
        {"command": "RDV2C", "map_key": "GUI"},
        {"command": "RDV2D", "map_key": "GUI"},
        {"command": "RDXA", "map_key": "GUI"},
        {"command": "RDXB", "map_key": "GUI"},
        {"command": "RDXC", "map_key": "GUI"},
        {"command": "RDSTAT", "map_key": "GUI"},
        {"command": "RDFLAG", "map_key": "GUI"},
    ]
    GUI_CFG = ['OCEN', 'VS5', 'VS4', 'VS3', 'VS2', 'VS1', 'INJTM', 'INJECC', 'INJTS', 'INJMON', 'INJOSC', 'SOAK', 'VS10',
           'VS9', 'VS8', 'VS7', 'VS6', 'GPO6C', 'GPO5C', 'GPO4C', 'GPO3C', 'GPO2C', 'GPO1C', 'SPI3W', 'GPIO1FE',
           'GPO6OD', 'GPO5OD', 'GPO4OD', 'GPO3OD', 'GPO2OD', 'GPO1OD', 'VB2MUX', 'VB1MUX', 'SNAPST', 'REFUP', 'COMMBK',
           'ACCI', 'OC1TEN', 'OC1TH', 'OC2TEN', 'OC2TH', 'OC3TEN', 'OC3TH', 'OCTSEL', 'REFTEN', 'OCDP', 'OCDGT', 'OCBX',
           'OCAX', 'OCMODE', 'OC3GC', 'OC2GC', 'OC1GC', 'OCOD', 'GPIO4C', 'GPIO3C', 'GPIO2C', 'GPIO1C', 'GPIO2EOC',
           'DIAGSEL']
    GUI_METRICS = ['I1', 'I2', 'I1ACC', 'I2ACC', 'VB1', 'VB2', 'VB1ACC', 'VB2ACC', 'V1A', 'V1B', 'V2A', 'V2B', 'V3A', 'V3B', 'V4A', 'V4B', 'V5A', 'V5B', 'V6A', 'V6B', 'V7A', 'V8A', 'V9B', 'V10B', 'VREF2A', 'VREF2B', 'VREF1P25', 'VDIV', 'VREG', 'VDD', 'VDIG', 'EPAD', 'TMP1', 'TMP2']
    STAT_READ_CMDS = [
        {"command": "$SPI_WAKEUP$", "arguments": {'Wakeup Time': 400}},
        {"command": "CLRFLAG", "arguments": {"VCH": 9}},
        {"command": "ADV", "arguments": {"VCH": 9}},
        {"command": "ADAX", "arguments": {"ACH": 0}},
        {"command": "ADAX2", "arguments": {"ACH": 0}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {'Wakeup Time': 10}},
        {"command": "RDCFGA", "arguments": {}, "map_key": "STAT"},
        {"command": "RDCFGB", "arguments": {}, "map_key": "STAT"},
        {"command": "RDSTAT", "map_key": "STAT"},
        {"command": "RDFLAG", "map_key": "STAT"},
    ]

    SAFETY_COMMAND_LISTS = {
        "SM_CLOCK_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG", "arguments": {"OSCFLT": 1, "NOCLK": 1}},  # 1
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 1}},  # 2+3
            {"command": "$DELAY_US$", "arguments": {"Delay": 167}},
            {"command": "RDFLAG", "map_key": "CLOCK_DIAG_4"},  # 4
            {"command": "RDSTAT", "map_key": "CLOCK_DIAG_5"},  # 5
            {"command": "RDXC", "map_key": "CLOCK_DIAG_6"},  # 6
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 0}},  # 7
            {"command": "CLRFLAG", "arguments": {"OSCFLT": 1, "NOCLK": 1}},  # 8
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 3}},  # 9
            {"command": "$DELAY_US$", "arguments": {"Delay": 60}},
            {"command": "RDFLAG", "map_key": "CLOCK_DIAG_10"},  # 10
            {"command": "RDSTAT", "map_key": "CLOCK_DIAG_11"},  # 11
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 0}},  # 12
            {"command": "CLRFLAG", "arguments": {"NOCLK": 1, "OSCFLT": 0}},  # 13
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 2}},  # 14
            {"command": "$DELAY_US$", "arguments": {"Delay": 167}},
            {"command": "RDFLAG", "map_key": "CLOCK_DIAG_15"},  # 15
            {"command": "RDSTAT", "map_key": "CLOCK_DIAG_16"},  # 16
            {"command": "RDXC", "map_key": "CLOCK_DIAG_17"},  # 17
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJOSC": 0}},  # 18
            {"command": "CLRFLAG", "arguments": {"NOCLK": 1, "OSCFLT": 1}},  # 19
            {"command": "$DELAY_US$", "arguments": {"Delay": 167}},
            {"command": "RDFLAG", "map_key": "CLOCK_DIAG_20"},  # 20
            {"command": "RDSTAT", "map_key": "CLOCK_DIAG_21"},  # 21
            {"command": "RDXC", "map_key": "CLOCK_DIAG_22"},  # 22
        ],
        "SM_CLOCK_MON": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "RDFLAG", "map_key": "CLOCK_MON"},
            {"command": "RDXC", "map_key": "CLOCK_MON"},
        ],
        "SM_CLOCK_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'SRST'},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADI1", 'arguments': {'OPT': 8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDFLAG", "map_key": "SM_CLOCK_OOR1"},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 100}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDFLAG", "map_key": "SM_CLOCK_OOR2"},
        ],
        "SM_FLAG_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'SRST'},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "RDFLAG", "map_key": "FLAG_DIAG_1"},  # 1
            {"command": "RDOC", "map_key": "REGS_DIAG_OC_1"},  # 1
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},  # 2
            {"command": "RDFLAG", "map_key": "FLAG_DIAG_3"},  # 3
            {"command": "WRCFGA", "arguments": {"INJTS": 1, "INJTM": 1}},  # 4
            {"command": "RDFLAG", "map_key": "FLAG_DIAG_5"},  # 5
            {"command": "WRCFGA", "arguments": {"INJTS": 0, "INJTM": 0}},  # 6
            {"command": "CLRFLAG",
             "arguments": {"TMODE": 1, "THSD": 1}},  # 7
            {"command": "RDFLAG", "map_key": "FLAG_DIAG_8"},  # 8

        ],
        "SM_FLAG_IND": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDFLAG", "map_key": "SM_FLAG_IND"},
        ],
        "SM_FREEZE_SEQ": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "ADI1", "arguments": {'OPT': 8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "SNAP"},
            {"command": "CLRI"},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDVB", "map_key": "SM_FREEZE_SEQ1"},
            {"command": "UNSNAP"},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDVB", "map_key": "SM_FREEZE_SEQ2"},
        ],
        "SM_GPO_CMP": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "WRCFGA", "arguments": {'GPO1OD': False, 'GPO2OD': False, 'GPO3OD': False, 'GPO4OD': False, 'GPO5OD': False, 'GPO6OD': False, 'GPO1C': False, 'GPO2C': False, 'GPO3C': False, 'GPO4C': False, 'GPO5C': False, 'GPO6C': False}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 1}},
            {"command": "RDSTAT", "map_key": "SM_GPO_CMP1"},
            {"command": "WRCFGA", "arguments": {'GPO1OD': False, 'GPO2OD': False, 'GPO3OD': False, 'GPO4OD': False, 'GPO5OD': False, 'GPO6OD': False, 'GPO1C': True, 'GPO2C': True, 'GPO3C': True, 'GPO4C': True, 'GPO5C': True, 'GPO6C': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 1}},
            {"command": "RDSTAT", "map_key": "SM_GPO_CMP2"},
        ],
        "SM_JTMP_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADX"},
            {"command": "PLX"},
            {"command": "RDXA", "map_key": "SM_JTMP_OOR"},
            {"command": "RDXC", "map_key": "SM_JTMP_OOR"},
        ],
        "SM_NVMECC_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG", "arguments": {"SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1}},
            {"command": "WRCFGA", "arguments": {"INJECC": 1}},
            {"command": "RDFLAG", "map_key": "SM_NVMECC_DIAG1"},
            {"command": "WRCFGA", "arguments": {"INJECC": 0}},
            {"command": "CLRFLAG", "arguments": {"SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1}},
            {"command": "RDFLAG", "map_key": "SM_NVMECC_DIAG2"},
        ],
        "SM_OCMJV_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "ADI1", "arguments": {'OPT': 8}},
            {"command": "ADI2", "arguments": {'OPT': 8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", "arguments": {"OC1TH": 0x00, "OC2TH": 0x40, "OC3TH": 0x40, "OCAX": 0, "OCBX": 0,
                                                "OCDP": 1, "OCMODE": 3, "OCOD": True}},  # a1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # a2
            {"command": "$DELAY_US$", "arguments": {"Delay": 400}},  # a3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_a4"},  # a4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # a5
            {"command": "WRCFGA", "arguments": {"OCEN": 0}},  # a6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # a7

            {"command": "WRCFGB", "arguments": {"OC1TH": 0x40, "OC2TH": 0x00, "OC3TH": 0x40, "OCAX": 1, "OCBX": 0,
                                                "OCDP": 0, "OCMODE": 3, "OCOD": True}},  # b1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # b2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1000}},  # b3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_b4"},  # b4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # b5
            {"command": "WRCFGA", "arguments": {"OCEN": 0, "GPO2OD": 0, "GPO2C": 1, "GPO1OD": 0, "GPO1C": 1}},  # b6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # b7

            {"command": "WRCFGB", "arguments": {"OC1TH": 0x40, "OC2TH": 0x40, "OC3TH": 0x00, "OCAX": 0, "OCBX": 1,
                                                "OCDP": 0, "OCMODE": 3, "OCOD": True}},  # c1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # c2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1000}},  # c3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_c4"},  # c4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # c5
            {"command": "WRCFGA", "arguments": {"OCEN": 0}},  # c6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # c7

            {"command": "WRCFGB", "arguments": {"OC1TH": 0x00, "OC2TH": 0x00, "OC3TH": 0x40, "OCAX": 0, "OCBX": 0,
                                                "OCDP": 0, "OCMODE": 3, "OCOD": True}},  # d1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # d2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1000}},  # d3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_d4"},  # d4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # d5
            {"command": "WRCFGA", "arguments": {"OCEN": 0}},  # d6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # d7

            {"command": "WRCFGB", "arguments": {"OC1TH": 0x00, "OC2TH": 0x40, "OC3TH": 0x00, "OCAX": 1, "OCBX": 0,
                                                "OCDP": 0, "OCMODE": 3, "OCOD": True}},  # e1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # e2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1000}},  # e3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_e4"},  # e4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # e5
            {"command": "WRCFGA", "arguments": {"OCEN": 0}},  # e6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # e7

            {"command": "WRCFGB", "arguments": {"OC1TH": 0x40, "OC2TH": 0x00, "OC3TH": 0x00, "OCAX": 0, "OCBX": 0,
                                                "OCDP": 0, "OCMODE": 3, "OCOD": True}},  # f1
            {"command": "WRCFGA", "arguments": {"OCEN": 1}},  # f2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1000}},  # f3
            {"command": "RDFLAG", "map_key": "OCMJV_DIAG_f4"},  # f4
            {"command": "$DELAY_US$", "arguments": {"Delay": 100}},  # f5
            {"command": "WRCFGA", "arguments": {"OCEN": 0}},  # f6
            {"command": "CLRFLAG", "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "OCAL": 1, "OCBL": 1}},  # e7
        ],
        "SM_POWER_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0b1000}},
            {"command": "$DELAY_MS$", "arguments": {"Delay": 2}},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1}},  # 1
            {"command": "RDSTAT", "map_key": "POWER_DIAG_1"},  #
            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJMON": 1}},  # 3
            {"command": "$DELAY_US$", "arguments": {"Delay": 50}},  # 3
            {"command": "RDFLAG", "map_key": "POWER_DIAG_4"},  # 4
            {"command": "RDSTAT", "map_key": "POWER_DIAG_5"},  # 5

            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJMON": 2}},  # 6
            {"command": "CLRFLAG", "arguments": {"OCMM": 1}},  # 7
            {"command": "RDFLAG", "map_key": "POWER_DIAG_8"},  # 8
            {"command": "RDSTAT", "map_key": "POWER_DIAG_9"},  # 9

            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJMON": 3}},  # 10
            {"command": "CLRFLAG", "arguments": {"OCMM": 1}},  # 11
            {"command": "RDFLAG", "map_key": "POWER_DIAG_12"},  # 12
            {"command": "RDSTAT", "map_key": "POWER_DIAG_13"},  # 13

            {"command": "WRCFGA", "arguments": {"GPIO1FE": 1, "INJMON": 0}},  # 14
            {"command": "CLRFLAG", "arguments": {"VREGOV": 1, "VDIGOV": 1, "VDE": 1, "VDEL": 1}},  # 15
            {"command": "RDSTAT", "map_key": "POWER_DIAG_16"},  # 16
            {"command": "WRCFGB", "arguments": {"DIAGSEL": 5}},  # 17

            {"command": "ADI1", "arguments": {"OPT": 0xE, "RD": 1}},  # 18a1
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},  # a3
            {"command": "RDALLI", "map_key": "POWER_DIAG_18b1"},  # 18b1
            {"command": "ADI1", "arguments": {"OPT": 0xE, "RD": 1}},  # 18a2
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},  # a3
            {"command": "RDALLI", "map_key": "POWER_DIAG_18b2"},  # 18b2
            {"command": "ADI1", "arguments": {"OPT": 0xE, "RD": 1}},  # 18a3
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},  # a3
            {"command": "RDALLI", "map_key": "POWER_DIAG_18b3"},  # 18b3
            {"command": "ADI1", "arguments": {"OPT": 0xE, "RD": 1}},  # 18b4
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},  # a3
            {"command": "RDALLI", "map_key": "POWER_DIAG_18b4"},  # 18b4
        ],
        "SM_POWER_MON": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "RDFLAG", "map_key": "SM_POWER_MON"}
        ],
        "SM_POWER_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADX"},
            {"command": "PLX"},
            {"command": "RDXA", "map_key": "SM_POWER_OOR"},
            {"command": "RDXB", "map_key": "SM_POWER_OOR"},
            {"command": "RDXC", "map_key": "SM_POWER_OOR"},
        ],
        "SM_REGS_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'RDALLI', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'RDALLA', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'RDALLV', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'RDALLR', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'RDALLX', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'RDOC', 'map_key': 'SM_REGS_DIAG1'},
            {'command': 'CLRI'},
            {'command': 'CLRA'},
            {'command': 'CLRVX'},
            {'command': 'CLRO'},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {'command': 'RDALLI', 'map_key': 'SM_REGS_DIAG2'},
            {'command': 'RDALLA', 'map_key': 'SM_REGS_DIAG2'},
            {'command': 'RDALLV', 'map_key': 'SM_REGS_DIAG2'},
            {'command': 'RDALLR', 'map_key': 'SM_REGS_DIAG2'},
            {'command': 'RDALLX', 'map_key': 'SM_REGS_DIAG2'},
            {'command': 'RDOC', 'map_key': 'SM_REGS_DIAG2'},
        ],
        "SM_REGS_RED": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {'command': 'ADI1'},
            {'command': 'ADI2'},
            {'command': 'ADV'},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDCFGA'},
            {'command': 'RDCFGB'},
            {'command': 'RDFLAG', 'map_key': 'SM_REGS_RED'},
        ],
        'SM_SPI_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {'command': 'RSTCC'},
            {'command': 'WRCOMM', 'arguments': {'D0': 0x3}},
            {'command': 'RDCOMM', 'map_key': 'SM_SPI_PEC_DIAG1'},
            {'command': 'WRCOMM', 'arguments': {'D0': 0x3, 'CMD PEC': gen6base.CMD_PEC(pec_size=1)}},
            {'command': 'RDCOMM', 'map_key': 'SM_SPI_PEC_DIAG2'},
            {'command': 'WRCOMM', 'arguments': {'D0': 0x3, 'DATA PEC': gen6base.DATA_PEC(pec_size=1)}},
            {'command': 'RDCOMM', 'map_key': 'SM_SPI_PEC_DIAG3'},
            {'command': 'RDFLAG', 'map_key': 'SM_SPI_PEC_DIAG4'},
            {'command': 'RDFLAG', 'map_key': 'SM_SPI_PEC_DIAG5', 'arguments': {'ERR': True}},
        ],
        'SM_SPI_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "CLRFLAG",
             "arguments": {"OC1L": 1, "OC2L": 1, "OC3L": 1, "REFFLT": 1, "OCAL": 1, "OCBL": 1, "OCAGD": 1, "OCBGD": 1,
                           "OCMM": 1, "I1PHA": 0, "I1CNT": 0, "I2CNT": 0, "SED1": 1, "SED2": 1, "MED1": 1, "MED2": 1,
                           "VREGUV": 1, "VREGOV": 1, "VDDUV": 1, "VDRUV": 1, "VDIGUV": 1, "VDIGOV": 1, "VDE": 1,
                           "VDEL": 1,
                           "OSCFLT": 1, "NOCLK": 1, "SPIFLT": 1, "TMODE": 1, "RESET": 1, "THSD": 0}},
            {'command': 'RDFLAG', 'map_key': 'SM_SPI_RED'},
        ],
        "SM_VBAT_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "WRCFGA", "arguments": {'GPO2OD': False, 'GPO2C': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},  # 1
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_1"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 2}},  # 2
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_3"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 1}},  # 3
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_2"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 3}},  # 4
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_4"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 4}},  # 5
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_5_AVG1"},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_5_AVG2"},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_5_AVG3"},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_5_AVG4"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 5}},  # 6
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_6"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 6}},  # 7
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_7"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 7}},  # 8
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDVB", "map_key": "VBAT_DIAG_8"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},  # 9
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x0}},
        ],
        "SM_VBAT_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "WRCFGA", "arguments": {'GPO2OD': False, 'GPO2C': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDVB", "map_key": "SM_VBAT_OOR"},
        ],
        "SM_VBAT_RED": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "WRCFGA", "arguments": {'GPO2OD': False, 'GPO2C': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDVB", "map_key": "SM_VBAT_RED"},
        ],
        "SM_VLINK_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADX"},
            {"command": "PLX"},
            {"command": "RDXA", "map_key": "SM_VLINK_DIAG"},
            {"command": "RDXB", "map_key": "SM_VLINK_DIAG"},
            {"command": "RDXC", "map_key": "SM_VLINK_DIAG"},
            {"command": "WRCFGA", "arguments": {'GPO5OD': True, 'GPO5C': True, 'VS5': True}},
            {"command": "ADV", "arguments": {'VCH': 4}},
            {"command": "PLV"},
            {"command": "RDV1B", "map_key": "SM_VLINK_DIAG1"},
            {"command": "RDV2B", "map_key": "SM_VLINK_DIAG1"},
            {"command": "WRCFGA", "arguments": {'GPO5OD': True, 'GPO5C': True, 'VS5': False}},
            {"command": "ADV", "arguments": {'VCH': 4}},
            {"command": "PLV"},
            {"command": "RDV1B", "map_key": "SM_VLINK_DIAG2"},
            {"command": "RDV2B", "map_key": "SM_VLINK_DIAG2"},
        ],
        "SM_VLINK_OWD": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 9, "OW": 0}},
            {"command": "PLV"},
            {"command": "RDV1A", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV1B", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV1C", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV1D", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV2A", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV2B", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV2C", "map_key": "SM_VLINK_OWD1"},
            {"command": "RDV2D", "map_key": "SM_VLINK_OWD1"},
            {"command": "ADV", "arguments": {'VCH': 9, "OW": 1}},
            {"command": "PLV"},
            {"command": "RDV1A", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV1B", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV1C", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV1D", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV2A", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV2B", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV2C", "map_key": "SM_VLINK_OWD2"},
            {"command": "RDV2D", "map_key": "SM_VLINK_OWD2"},
        ],
        "SM_VLINK_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 9}},
            {"command": "PLV"},
            {"command": "RDV1A", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV1B", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV1C", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV1D", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV2A", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV2B", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV2C", "map_key": "SM_VLINK_OOR"},
            {"command": "RDV2D", "map_key": "SM_VLINK_OOR"},
        ],
        "SM_VLINK_RED": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 9}},
            {"command": "PLV"},
            {"command": "RDV1A", "map_key": "SM_VLINK_RED"},
            {"command": "RDV1B", "map_key": "SM_VLINK_RED"},
            {"command": "RDV1C", "map_key": "SM_VLINK_RED"},
            {"command": "RDV1D", "map_key": "SM_VLINK_RED"},
            {"command": "RDV2A", "map_key": "SM_VLINK_RED"},
            {"command": "RDV2B", "map_key": "SM_VLINK_RED"},
            {"command": "RDV2C", "map_key": "SM_VLINK_RED"},
            {"command": "RDV2D", "map_key": "SM_VLINK_RED"},
        ],
        "SM_VNTC_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADX"},
            {"command": "PLX"},
            {"command": "RDXA", "map_key": "SM_VNTC_DIAG0"},
            {"command": "RDXB", "map_key": "SM_VNTC_DIAG0"},
            {"command": "RDXC", "map_key": "SM_VNTC_DIAG0"},
            {"command": "WRCFGA", "arguments": {'VS7': 1, 'VS8': 1, 'VS9': 1, 'VS10': 1}},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 0}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 0}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_DIAG1"},
            {"command": "RDV2C", "map_key": "SM_VNTC_DIAG1"},
            {"command": "WRCFGA", "arguments": {'VS7': 0, 'VS8': 0, 'VS9': 0, 'VS10': 0}},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 2}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 2}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_DIAG2"},
            {"command": "RDV2C", "map_key": "SM_VNTC_DIAG2"},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 1}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 1}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_DIAG3"},
            {"command": "RDV2C", "map_key": "SM_VNTC_DIAG3"},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 0}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 0}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_DIAG4"},
            {"command": "RDV2C", "map_key": "SM_VNTC_DIAG4"},
        ],
        "SM_VNTC_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 0}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 0}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_OOR"},
            {"command": "RDV2C", "map_key": "SM_VNTC_OOR"},
        ],
        "SM_VNTC_RED": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 6, "OW": 0}},
            {"command": "PLV"},
            {"command": "ADV", "arguments": {'VCH': 7, "OW": 0}},
            {"command": "PLV"},
            {"command": "RDV1D", "map_key": "SM_VNTC_RED"},
            {"command": "RDV2C", "map_key": "SM_VNTC_RED"},
        ],
        "SM_VOC3_OWD": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", 'arguments': {'OC1GC': False, 'OC2GC': False, 'OC3GC': False}},
            {"command": "WRCFGA", "arguments": {'OCEN': False}},
            {"command": "WRCFGA", "arguments": {'OCEN': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDOC', 'map_key': 'SM_VOC3_OWD'},
        ],
        "SM_VOC_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'CLRO'},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1, 'OCAGD': 1}},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "WRCFGB", 'arguments': {'OC1TEN': 0, 'OC2TEN': 0, 'OC3TEN': 0, 'REFTEN': 0, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0, 'OCTSEL': 0, 'OC1TH': 0x1E, 'OC2TH': 0x1E, 'OC3TH': 0x1E, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG1'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG1'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 1, 'OC2TEN': 1, 'OC3TEN': 1, 'REFTEN': 1, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 2, 'OC1TH': 0x1E, 'OC2TH': 0x1E, 'OC3TH': 0x1E, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG2'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG2'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 1, 'OC2TEN': 1, 'OC3TEN': 1, 'REFTEN': 1, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 0, 'OC1TH': 0x1E, 'OC2TH': 0x1E, 'OC3TH': 0x1E, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG3'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG3'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 1, 'OC2TEN': 1, 'OC3TEN': 1, 'REFTEN': 1, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 3, 'OC1TH': 0x38, 'OC2TH': 0x38, 'OC3TH': 0x38, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG4'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG4'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 1, 'OC2TEN': 1, 'OC3TEN': 1, 'REFTEN': 1, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 1, 'OC1TH': 0x38, 'OC2TH': 0x38, 'OC3TH': 0x38, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG5'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG5'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 1, 'OC2TEN': 1, 'OC3TEN': 1, 'REFTEN': 1, 'OC1GC': 1, 'OC2GC': 1, 'OC3GC': 1,
                           'OCTSEL': 2, 'OC1TH': 0x1E, 'OC2TH': 0x1E, 'OC3TH': 0x1E, 'OCDP': 0}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VOC_DIAG6'},
            {'command': 'RDFLAG', 'map_key': 'SM_VOC_DIAG6'},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 0, 'OC2TEN': 0, 'OC3TEN': 0, 'REFTEN': 0, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 0, 'OC1TH': 0x00, 'OC2TH': 0x00, 'OC3TH': 0x00, 'OCDP': 0}},
            {"command": "CLRO"},
            {"command": "CLRFLAG", "arguments": {'OCAGD': 1}},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
        ],
        "SM_VREF1P25_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2A", "map_key": "SM_VREF1P25_OOR"},
        ],
        "SM_VREF_MON": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "WRCFGA", "arguments": {'OCEN': 0}},
            {"command": "CLRFLAG", "arguments": {'OC1L': 1, 'OC2L': 1, 'OC3L': 1, 'REFFLT': 1}},
            {"command": "WRCFGB",
             'arguments': {'OC1TEN': 0, 'OC2TEN': 0, 'OC3TEN': 0, 'REFTEN': 0, 'OC1GC': 0, 'OC2GC': 0, 'OC3GC': 0,
                           'OCTSEL': 0, 'OC1TH': 0x00, 'OC2TH': 0x00, 'OC3TH': 0x00, 'OCDP': 0}},
            {"command": "CLRO"},
            {"command": "CLRFLAG", "arguments": {'OCAGD': 1}},
            {"command": "WRCFGA", "arguments": {'OCEN': 1}},
            {"command": "$DELAY_US$", 'arguments': {'Delay': 759}},
            {'command': 'RDOC', 'map_key': 'SM_VREF_MON'},
            {'command': 'RDFLAG', 'map_key': 'SM_VREF_MON'},
        ],
        "SM_VREF_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2D", "map_key": "SM_VREF_OOR0"},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2D", "map_key": "SM_VREF_OOR1"},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2D", "map_key": "SM_VREF_OOR2"},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2D", "map_key": "SM_VREF_OOR3"},
            {"command": "ADV", "arguments": {'VCH': 8}},
            {"command": "PLV"},
            {"command": "RDV2D", "map_key": "SM_VREF_OOR4"},
        ],
        "SM_VSHUNT_DIAG": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGA", "arguments": {'GPO2OD': False, 'GPO2C': True}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},  # 1
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG1"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 2}},  # 2
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG2"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 1}},  # 3
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1200}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG3"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 3}},  # 4
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG4"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 4}},  # 5
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG5"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 5}},  # 6
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG6"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 6}},  # 7
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG7"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 7}},  # 8
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x7}},
            {"command": "$DELAY_US$", "arguments": {"Delay": 1120}},
            {"command": "RDI", "map_key": "SM_VSHUNT_DIAG8"},

            {"command": "WRCFGB", "arguments": {"DIAGSEL": 0}},  # 9
            {"command": "ADI1", "arguments": {"RD": 1, "OPT": 0x0}},
        ],
        "SM_VSHUNT_OOR": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADI1', 'arguments': {'RD': True, 'OPT': 8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDI', 'map_key': 'SM_VSHUNT_OOR'},
        ],
        "SM_VSHUNT_RED": [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 500}},
            {'command': 'WRCFGA', 'arguments': {'ACCI': 7}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADI1', 'arguments': {'RD': True, 'OPT': 8}},
            {"command": "$DELAY_MS$", 'arguments': {'Delay': 100}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDIACC', 'map_key': 'SM_VSHUNT_RED'},
        ]
    }
    LIMITS = {
        'Safety': {
            'VB1': {
                'min': 0.756,
                'max': 1.0
            },
            'VB2': {
                'min': 0.756,
                'max': 1.0
            },
            "V1A": {
                'min': 0.01,
                'max': 2.5
            },
            "V1B": {
                'min': 0.01,
                'max': 2.5
            },
            "V2A": {
                'min': 0.01,
                'max': 2.5
            },
            "V2B": {
                'min': 0.01,
                'max': 2.5
            },
            "V3A": {
                'min': 0.01,
                'max': 2.5
            },
            "V3B": {
                'min': 0.01,
                'max': 2.5
            },
            "V4A": {
                'min': 0.01,
                'max': 2.5
            },
            "V4B": {
                'min': 0.01,
                'max': 2.5
            },
            "V5A": {
                'min': 0.01,
                'max': 2.5
            },
            "V5B": {
                'min': 0.01,
                'max': 2.5
            },
            "V6A": {
                'min': 0.01,
                'max': 2.5
            },
            "V6B": {
                'min': 0.01,
                'max': 2.5
            },
            "V7A": {
                'min': 0.01,
                'max': 2.5
            },
            "V8A": {
                'min': 0.01,
                'max': 2.5
            },
            "V9B": {
                'min': 0.01,
                'max': 2.5
            },
            "V10B": {
                'min': 0.01,
                'max': 2.5
            },
        }
    }


    @staticmethod
    def decode_safety_loop(result_dict, ic_num, safety_metric=None, limit_override=None):
        limits = deepcopy(ADBMS2950.LIMITS['Safety'])
        if limit_override:
            limits.update(limit_override)
        global_status = ADBMS2950.PASS
        safety_results = {}
        if 'Safety_Results' not in result_dict:
            result_dict['Safety_Results'] = []
        if safety_metric and safety_metric in ADBMS2950.SAFETY_COMMAND_LISTS:
            safety_results[safety_metric] = {'Result': None}
            safety_results[safety_metric]['Error Messages'] = []
            try:
                for map_key in result_dict:
                    if map_key in ['Total_PEC_Status', 'All', 'Safety_Results']:
                        continue
                    if map_key.endswith('_RAW'):
                        continue
                    if not result_dict[map_key][ic_num]['Total_PEC_Status']:
                        safety_results[safety_metric]['Error Messages'].append('PEC Error Detected')
            except:
                pass
            if safety_metric == 'SM_CLOCK_DIAG':
                if not result_dict['CLOCK_DIAG_4'][ic_num]['OSCFLT'] or result_dict['CLOCK_DIAG_4'][ic_num]['NOCLK'] or result_dict['CLOCK_DIAG_6'][ic_num]['OSCCNT'] <= 71:
                    safety_results[safety_metric]['Error Messages'].append('Could not Force Oscillator Fault with INJOSC = 1')
                if result_dict['CLOCK_DIAG_10'][ic_num]['OSCFLT'] or not result_dict['CLOCK_DIAG_10'][ic_num]['NOCLK'] or not result_dict['CLOCK_DIAG_11'][ic_num]['GPIO1L']:
                    safety_results[safety_metric]['Error Messages'].append('Could not Force Oscillator Fault with INJOSC = 3')
                if not result_dict['CLOCK_DIAG_15'][ic_num]['OSCFLT'] or not result_dict['CLOCK_DIAG_15'][ic_num]['NOCLK'] or result_dict['CLOCK_DIAG_17'][ic_num]['OSCCNT'] >= 52:
                    safety_results[safety_metric]['Error Messages'].append('Could not Force Oscillator Fault with INJOSC = 2')
                if result_dict['CLOCK_DIAG_20'][ic_num]['OSCFLT'] or result_dict['CLOCK_DIAG_20'][ic_num]['NOCLK'] or result_dict['CLOCK_DIAG_22'][ic_num]['OSCCNT'] < 52 or result_dict['CLOCK_DIAG_22'][ic_num]['OSCCNT'] > 71:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator Fault')
            elif safety_metric == 'SM_CLOCK_MON':
                if result_dict['CLOCK_MON'][ic_num]['OSCFLT'] or result_dict['CLOCK_MON'][ic_num]['NOCLK'] or result_dict['CLOCK_MON'][ic_num]['OSCCNT'] < 52 or result_dict['CLOCK_MON'][ic_num]['OSCCNT'] > 71:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator Fault')
            elif safety_metric == 'SM_CLOCK_OOR':
                if abs(result_dict['SM_CLOCK_OOR1'][ic_num]['I1CNT'] - result_dict['SM_CLOCK_OOR2'][ic_num]['I1CNT']) > 110 or abs(result_dict['SM_CLOCK_OOR1'][ic_num]['I1CNT'] - result_dict['SM_CLOCK_OOR2'][ic_num]['I1CNT']) < 90:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator OOR Fault')
            elif safety_metric == 'SM_FLAG_DIAG':
                for flag in ["OC1L", "OC2L", "OC3L", "REFFLT", "OCAL", "OCBL", "OCAGD", "OCBGD", "OCMM", "SED1", "SED2", "MED1", "MED2", "VREGUV", "VREGOV", "VDDUV", "VDRUV", "VDIGUV", "VDIGOV", "VDE", "VDEL", "OSCFLT", "NOCLK", "SPIFLT", "TMODE", "RESET"]:
                    if not result_dict['FLAG_DIAG_1'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after reset' % flag)
                    if result_dict['FLAG_DIAG_3'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after clear command' % flag)
                for flag in ["I1PHA", "I1CNT", "I2CNT", "THSD"]:
                    if result_dict['FLAG_DIAG_1'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after reset' % flag)
                    if result_dict['FLAG_DIAG_3'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after clear command' % flag)
                for flag in ["TMODE", "THSD"]:
                    if not result_dict['FLAG_DIAG_5'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after fault injection' % flag)
                    if result_dict['FLAG_DIAG_8'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s Flag was incorrect after clear command' % flag)
            elif safety_metric == 'SM_FLAG_IND':
                for flag in ["THSD", "MED1", "MED2","TMODE", "RESET"]:
                    if result_dict['SM_FLAG_IND'][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s flag is set' % flag)
            elif safety_metric == 'SM_FREEZE_SEQ':
                if result_dict['SM_FREEZE_SEQ1_RAW'][ic_num]['VB1'] != 0x8000:
                    safety_results[safety_metric]['Error Messages'].append('Result register did not freeze')
                if result_dict['SM_FREEZE_SEQ2_RAW'][ic_num]['VB1'] == 0x8000:
                    safety_results[safety_metric]['Error Messages'].append('Result register did not unfreeze')
            elif safety_metric == 'SM_GPO_CMP':
                for gpo in ['GPO1L', 'GPO1H', 'GPO2L', 'GPO2H', 'GPO3L', 'GPO3H', 'GPO4L', 'GPO4H', 'GPO5L', 'GPO5H', 'GPO6L', 'GPO6H']:
                    if result_dict['SM_GPO_CMP1'][ic_num][gpo]:
                        safety_results[safety_metric]['Error Messages'].append('%s output is out of range when pulled down' % gpo)
                    if not result_dict['SM_GPO_CMP2'][ic_num][gpo]:
                        safety_results[safety_metric]['Error Messages'].append('%s output is out of range when pulled up' % gpo)
            elif safety_metric == 'SM_JTMP_OOR':
                if result_dict['SM_JTMP_OOR'][ic_num]['TMP1'] > 120:
                    safety_results[safety_metric]['Error Messages'].append('Die temperature is over 120C Limit')
                if result_dict['SM_JTMP_OOR_RAW'][ic_num]['TMP1']/result_dict['SM_JTMP_OOR_RAW'][ic_num]['TMP2'] > 3.1 or result_dict['SM_JTMP_OOR_RAW'][ic_num]['TMP1']/result_dict['SM_JTMP_OOR_RAW'][ic_num]['TMP2'] < 2.5:
                    safety_results[safety_metric]['Error Messages'].append('TMP1/TMP2 ratio is out of range')
            elif safety_metric == 'SM_NVMECC_DIAG':
                if not result_dict['SM_NVMECC_DIAG1'][ic_num]['MED1'] or not result_dict['SM_NVMECC_DIAG1'][ic_num]['MED2']:
                    safety_results[safety_metric]['Error Messages'].append('MED1/2 did not set with fault injection active')
                if result_dict['SM_NVMECC_DIAG2'][ic_num]['MED1'] or result_dict['SM_NVMECC_DIAG2'][ic_num]['MED2']:
                    safety_results[safety_metric]['Error Messages'].append('MED1/2 did not reset')
            elif safety_metric == 'SM_OCMJV_DIAG':
                for map_key in ['OCMJV_DIAG_a4', 'OCMJV_DIAG_b4', 'OCMJV_DIAG_c4']:
                    if result_dict[map_key][ic_num]['OCAL'] or result_dict[map_key][ic_num]['OCBL'] or result_dict[map_key][ic_num]['OCAGD'] or result_dict[map_key][ic_num]['OCBGD']:
                        safety_results[safety_metric]['Error Messages'].append('OCAL/OCBL is set when it should be disabled')
                for map_key in ['OCMJV_DIAG_d4', 'OCMJV_DIAG_e4', 'OCMJV_DIAG_f4']:
                    if not result_dict[map_key][ic_num]['OCAL'] or not result_dict[map_key][ic_num]['OCBL'] or result_dict[map_key][ic_num]['OCAGD'] or result_dict[map_key][ic_num]['OCBGD']:
                        safety_results[safety_metric]['Error Messages'].append('OCAL/OCBL is not set when it should be active')
            elif safety_metric == 'SM_POWER_DIAG':
                if not result_dict["POWER_DIAG_4"][ic_num]['OCMM']:
                    safety_results[safety_metric]['Error Messages'].append('OCMM did not set with fault injection')
                for flag in ['VDDUV', 'VREGUV', 'VDIGUV']:
                    if not result_dict["POWER_DIAG_8"][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s did not set with fault injection' % flag)
                for flag in ['VDE', 'VDEL', 'VREGOV', 'VDIGOV']:
                    if not result_dict["POWER_DIAG_12"][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s did not set with fault injection' % flag)
                avgs = []
                for meas in ['I1', 'VB1', 'I2', 'VB2']:
                    avgs.append((result_dict['POWER_DIAG_18b1'][ic_num][meas] + result_dict['POWER_DIAG_18b1'][ic_num][meas] + result_dict['POWER_DIAG_18b1'][ic_num][meas] + result_dict['POWER_DIAG_18b1'][ic_num][meas])/4)
                if (avgs[1] - avgs[0]) < -0.0002 or (avgs[1] - avgs[0]) > 0.0008:
                    safety_results[safety_metric]['Error Messages'].append('VB1/I1 ground current measurement is out of range')
                if (avgs[3] - avgs[2]) < -0.0002 or (avgs[3] - avgs[2]) > 0.0008:
                    safety_results[safety_metric]['Error Messages'].append('VB2/I2 ground current measurement is out of range')
            elif safety_metric == 'SM_POWER_MON':
                for flag in ['VDDUV', 'VREGUV', 'VDIGUV', 'VDE', 'VDEL', 'VREGOV', 'VDIGOV']:
                    if result_dict["SM_POWER_MON"][ic_num][flag]:
                        safety_results[safety_metric]['Error Messages'].append('%s is set' % flag)
            elif safety_metric == 'SM_POWER_OOR':
                if result_dict["SM_POWER_OOR_RAW"][ic_num]['VDIV'] < 1068 or result_dict["SM_POWER_OOR_RAW"][ic_num]['VDIV'] > 1222:
                    safety_results[safety_metric]['Error Messages'].append('VDIV is out of range')
                if result_dict["SM_POWER_OOR"][ic_num]['EPAD'] < -0.05 or result_dict["SM_POWER_OOR"][ic_num]['EPAD'] > 0.05:
                    safety_results[safety_metric]['Error Messages'].append('EPAD is out of range')
                if result_dict["SM_POWER_OOR_RAW"][ic_num]['VREF1P25'] < 12000 or result_dict["SM_POWER_OOR_RAW"][ic_num]['VREF1P25'] > 13000:
                    safety_results[safety_metric]['Error Messages'].append('VREF1P25 is out of range')
                if result_dict["SM_POWER_OOR_RAW"][ic_num]['VDIG'] < 11250 or result_dict["SM_POWER_OOR_RAW"][ic_num]['VDIG'] > 13750:
                    safety_results[safety_metric]['Error Messages'].append('VDIG is out of range')
                if result_dict["SM_POWER_OOR_RAW"][ic_num]['VDD'] < 4500 or result_dict["SM_POWER_OOR_RAW"][ic_num]['VDD'] > 20000:
                    safety_results[safety_metric]['Error Messages'].append('VDD is out of range')
                if result_dict["SM_POWER_OOR_RAW"][ic_num]['VREG'] < 18750 or result_dict["SM_POWER_OOR_RAW"][ic_num]['VREG'] > 22917:
                    safety_results[safety_metric]['Error Messages'].append('VREG is out of range')
            elif safety_metric == 'SM_REGS_DIAG':
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['I1'] != 0x03FFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['I1'] != 0xFC0000:
                    safety_results[safety_metric]['Error Messages'].append('I1 failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['I2'] != 0x03FFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['I2'] != 0xFC0000:
                    safety_results[safety_metric]['Error Messages'].append('I2 failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['I1ACC'] != 0x7FFFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['I1ACC'] != 0x800000:
                    safety_results[safety_metric]['Error Messages'].append('I1ACC failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['I2ACC'] != 0x7FFFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['I2ACC'] != 0x800000:
                    safety_results[safety_metric]['Error Messages'].append('I2ACC failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['VB1ACC'] != 0x7FFFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['VB1ACC'] != 0x800000:
                    safety_results[safety_metric]['Error Messages'].append('VB1ACC failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['VB2ACC'] != 0x7FFFFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['VB2ACC'] != 0x800000:
                    safety_results[safety_metric]['Error Messages'].append('VB2ACC failed register diagnostic check')
                for item in ['V1A', 'V2A', 'V3A', 'V4A', 'V5A', 'V6A', 'V7A', 'V8A', 'V1B', 'V2B', 'V3B', 'V4B', 'V5B', 'V6B', 'V9B', 'V10B', 'VB1', 'VB2', 'VREF2A', 'VREF2B', 'VDIV', 'VREF1P25', 'VDD', 'VREG', 'VDIG', 'EPAD', 'TMP1', 'TMP2']:
                    if result_dict["SM_REGS_DIAG1_RAW"][ic_num][item] != 0x7FFF or result_dict["SM_REGS_DIAG2_RAW"][ic_num][item] != 0x8000:
                        safety_results[safety_metric]['Error Messages'].append('%s failed register diagnostic check' % item)
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['OC1R'] != 0x7F or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['OC1R'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('OC1R failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['OC2R'] != 0x7F or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['OC2R'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('OC2R failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['OC3R'] != 0x7F or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['OC3R'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('OC3R failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['REFR'] != 0x7F or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['REFR'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('REFR failed register diagnostic check')
                if result_dict["SM_REGS_DIAG1_RAW"][ic_num]['OC3MAX'] != 0x7F or result_dict["SM_REGS_DIAG2_RAW"][ic_num]['OC3MAX'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('OC3MAX failed register diagnostic check')
                if result_dict["SM_REGS_DIAG2_RAW"][ic_num]['OC3MIN'] != 0x7F or result_dict["SM_REGS_DIAG1_RAW"][ic_num]['OC3MIN'] != 0x80:
                    safety_results[safety_metric]['Error Messages'].append('OC3MIN failed register diagnostic check')
            elif safety_metric == 'SM_REGS_RED':
                if result_dict["SM_REGS_RED"][ic_num]['SPIFLT'] or result_dict["SM_REGS_RED"][ic_num]['OCMM']:
                    safety_results[safety_metric]['Error Messages'].append('Redundant register mismatch detected')
            elif safety_metric == 'SM_SPI_DIAG':
                safety_results[safety_metric]['Error Messages'] = []
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['CCNT'] != 0x1:
                    safety_results[safety_metric]['Error Messages'].append('CCNT did not increment')
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['D0'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value did not latch')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['CCNT'] != 0x1:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['D0'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['CCNT'] != 0x1:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['D0'] != 0x00:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG4'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
                if not result_dict['SM_SPI_PEC_DIAG5'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected with fault injection enabled')
            elif safety_metric == 'SM_SPI_RED':
                if result_dict['SM_SPI_RED'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
            elif safety_metric == 'SM_VBAT_DIAG':
                vina = result_dict['VBAT_DIAG_1'][ic_num]['VB1']
                vinb = result_dict['VBAT_DIAG_1'][ic_num]['VB2']
                # Open Wire P
                VBat1_eff_min = ADBMS2950.calc_adc_t_eff(1e-3, 8e-6, 1.84e3, 1e3 + 1/((1/9.1e3) + (1/3.6e6)), 33e-9)
                VBat1_eff_max = ADBMS2950.calc_adc_t_eff(1e-3, 12e-6, 2.76e3, 1e3 + 1/((1/9.1e3) + (1/3.6e6)), 33e-9)
                if result_dict['VBAT_DIAG_2'][ic_num]['VB1'] < vina + VBat1_eff_min or result_dict['VBAT_DIAG_2'][ic_num]['VB1'] > vina + VBat1_eff_max:
                    safety_results[safety_metric]['Error Messages'].append('VB1 Open Positive Connection Detected')
                if result_dict['VBAT_DIAG_2'][ic_num]['VB2'] < vinb + VBat1_eff_min or result_dict['VBAT_DIAG_2'][ic_num]['VB2'] > vinb + VBat1_eff_max:
                    safety_results[safety_metric]['Error Messages'].append('VB2 Open Positive Connection Detected')
                # Open Wire N
                if result_dict['VBAT_DIAG_3'][ic_num]['VB1'] < vina - 0.0331 or result_dict['VBAT_DIAG_3'][ic_num]['VB1'] > vina - 0.0147:
                    safety_results[safety_metric]['Error Messages'].append('VB1 Open Negative Connection Detected')
                if result_dict['VBAT_DIAG_3'][ic_num]['VB2'] < vinb - 0.0331 or result_dict['VBAT_DIAG_3'][ic_num]['VB2'] > vinb - 0.0147:
                    safety_results[safety_metric]['Error Messages'].append('VB2 Open Negative Connection Detected')
                avgvb1 = 0
                avgvb2 = 0
                for meas in range(1,5):
                    avgvb1 += result_dict['VBAT_DIAG_5_AVG%s'%meas][ic_num]['VB1']
                    avgvb2 += result_dict['VBAT_DIAG_5_AVG%s'%meas][ic_num]['VB2']
                avgvb1 = avgvb1/4
                avgvb2 = avgvb2/4
                if avgvb1 < -0.0002 or avgvb1 > 0.0002:
                    safety_results[safety_metric]['Error Messages'].append('VB1 Offset Error Detected')
                if avgvb2 < -0.0002 or avgvb2 > 0.0002:
                    safety_results[safety_metric]['Error Messages'].append('VB2 Offset Error Detected')
                if result_dict['VBAT_DIAG_6'][ic_num]['VB1'] < 0.1125 or result_dict['VBAT_DIAG_6'][ic_num]['VB1'] > 0.1213:
                    safety_results[safety_metric]['Error Messages'].append('VB1 VREF1 Measurement Error Detected')
                if result_dict['VBAT_DIAG_6'][ic_num]['VB2'] < 0.1125 or result_dict['VBAT_DIAG_6'][ic_num]['VB2'] > 0.1213:
                    safety_results[safety_metric]['Error Messages'].append('VB2 VREF1 Measurement Error Detected')
                if result_dict['VBAT_DIAG_7'][ic_num]['VB1'] < 2.327 or result_dict['VBAT_DIAG_7'][ic_num]['VB1'] > 2.422:
                    safety_results[safety_metric]['Error Messages'].append('VB1 VREF1 Measurement Error Detected')
                if result_dict['VBAT_DIAG_7'][ic_num]['VB2'] < 2.327 or result_dict['VBAT_DIAG_7'][ic_num]['VB2'] > 2.422:
                    safety_results[safety_metric]['Error Messages'].append('VB2 VREF1 Measurement Error Detected')
            elif safety_metric == 'SM_VBAT_OOR':
                if result_dict['SM_VBAT_OOR'][ic_num]['VB1'] < limits['VB1']['min'] or result_dict['SM_VBAT_OOR'][ic_num]['VB1'] > limits['VB1']['max']:
                    safety_results[safety_metric]['Error Messages'].append('VB1 is [%s] out of range [%s, %s]' % (result_dict['SM_VBAT_OOR'][ic_num]['VB1'],limits['VB1']['min'], limits['VB1']['max']))
                if result_dict['SM_VBAT_OOR'][ic_num]['VB2'] < limits['VB2']['min'] or result_dict['SM_VBAT_OOR'][ic_num]['VB2'] > limits['VB2']['max']:
                    safety_results[safety_metric]['Error Messages'].append('VB2 is [%s] out of range [%s, %s]' % (result_dict['SM_VBAT_OOR'][ic_num]['VB2'],limits['VB2']['min'], limits['VB2']['max']))
            elif safety_metric == 'SM_VBAT_RED':
                if abs(result_dict['SM_VBAT_RED'][ic_num]['VB1'] - result_dict['SM_VBAT_RED'][ic_num]['VB2']) > 0.0008:
                    safety_results[safety_metric]['Error Messages'].append('VB1 and VB2 mismatch is greater than 0.8mV')
            elif safety_metric == 'SM_VLINK_DIAG':
                if abs(result_dict['SM_VLINK_DIAG1'][ic_num]['V5A'] + result_dict['SM_VLINK_DIAG'][ic_num]['VREF1P25']) > 0.005:
                    safety_results[safety_metric]['Error Messages'].append('V5A GND measurement is out of spec with VS5=1')
                if abs(result_dict['SM_VLINK_DIAG1'][ic_num]['V5B'] + result_dict['SM_VLINK_DIAG'][ic_num]['VREF1P25']) > 0.001:
                    safety_results[safety_metric]['Error Messages'].append('V5B GND measurement is out of spec with VS5=1')
                if abs(result_dict['SM_VLINK_DIAG2'][ic_num]['V5A'] - 0) > 0.001:
                    safety_results[safety_metric]['Error Messages'].append('V5A GND measurement is out of spec with VS5=0')
                if abs(result_dict['SM_VLINK_DIAG2'][ic_num]['V5B'] - 0) > 0.001:
                    safety_results[safety_metric]['Error Messages'].append('V5B GND measurement is out of spec with VS5=0')
            elif safety_metric == 'SM_VLINK_OOR':
                for voltage in ['V1A', 'V1B', 'V2A', 'V2B', 'V3A', 'V3B', 'V4A', 'V4B', 'V5A', 'V5B', 'V6A', 'V6B', 'V7A', 'V8A', 'V9B', 'V10B']:
                    if result_dict['SM_VLINK_OOR'][ic_num][voltage] < limits[voltage]['min'] or result_dict['SM_VLINK_OOR'][ic_num][voltage] > limits[voltage]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is out of spec [%s,%s]' % (voltage, limits[voltage]['min'], limits[voltage]['max']))
            elif safety_metric == 'SM_VLINK_OWD':
                for item in range(1,7):
                    if result_dict['SM_VLINK_OWD2'][ic_num]['V%sA' % item] - result_dict['SM_VLINK_OWD2'][ic_num]['V%sB' % item] < 0.012:
                        safety_results[safety_metric]['Error Messages'].append('V%sA current source is not in range' % (item))
                for voltage in ['V1A', 'V1B', 'V2A', 'V2B', 'V3A', 'V3B', 'V4A', 'V4B', 'V5A', 'V5B', 'V6A', 'V6B']:
                    if result_dict['SM_VLINK_OWD2'][ic_num][voltage] < limits[voltage]['min'] or \
                            result_dict['SM_VLINK_OWD2'][ic_num][voltage] > limits[voltage]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is out of spec [%s,%s]' % (voltage, limits[voltage]['min'], limits[voltage]['max']))
            elif safety_metric == 'SM_VLINK_RED':
                for voltage in range(1,7):
                    if abs(result_dict['SM_VLINK_RED'][ic_num]['V%sA' % voltage] - result_dict['SM_VLINK_RED'][ic_num]['V%sB' % voltage]) > 0.001:
                        safety_results[safety_metric]['Error Messages'].append('V%sA/B mismatch is greater than 1mV' % (voltage))
            elif safety_metric == 'SM_VNTC_DIAG':
                ntc_eff_min = ADBMS2950.calc_adc_t_eff(265e-6, 8e-6, 1.84e3, 1e3 + 5e3, 100e-9)
                for item in ['V7A', 'V8A', 'V9B', 'V10B']:
                    if result_dict['SM_VNTC_DIAG0'][ic_num]['VREF1P25'] - 0.005 > (result_dict['SM_VNTC_DIAG4'][ic_num][item] - result_dict['SM_VNTC_DIAG1'][ic_num][item]) > result_dict['SM_VNTC_DIAG0'][ic_num]['VREF1P25'] + 0.005:
                        safety_results[safety_metric]['Error Messages'].append('%s VREF1P25 measurement is out of tolerance [-5mV,5mV]' % (item))
                    if abs(result_dict['SM_VNTC_DIAG4'][ic_num][item] - result_dict['SM_VNTC_DIAG2'][ic_num][item]) < 0.0147:
                        safety_results[safety_metric]['Error Messages'].append('%s open ground connection' % (item))
                    if abs(result_dict['SM_VNTC_DIAG4'][ic_num][item] - result_dict['SM_VNTC_DIAG3'][ic_num][item]) > ntc_eff_min:
                        safety_results[safety_metric]['Error Messages'].append('%s open positive connection' % (item))
            elif safety_metric == 'SM_VNTC_OOR':
                for item in ['V7A', 'V8A', 'V9B', 'V10B']:
                    if result_dict['SM_VNTC_OOR'][ic_num][item] <= 0 or result_dict['SM_VNTC_OOR'][ic_num][item] >= 1.25:
                        safety_results[safety_metric]['Error Messages'].append('%s measurement is out of tolerance [0,1.25]V' % (item))
            elif safety_metric == 'SM_VNTC_RED':
                if abs(result_dict['SM_VNTC_RED'][ic_num]['V7A'] - result_dict['SM_VNTC_RED'][ic_num]['V9B']) > 0.01:
                    safety_results[safety_metric]['Error Messages'].append('V7/V9 measurements are different by more than 10mV')
                if abs(result_dict['SM_VNTC_RED'][ic_num]['V8A'] - result_dict['SM_VNTC_RED'][ic_num]['V10B']) > 0.01:
                    safety_results[safety_metric]['Error Messages'].append('V8/V10 measurements are different by more than 10mV')
            elif safety_metric == 'SM_VOC3_OWD':
                if abs(result_dict['SM_VOC3_OWD'][ic_num]['OC3R'] - result_dict['SM_VOC3_OWD'][ic_num]['OC1R']) > 0.014:
                    safety_results[safety_metric]['Error Messages'].append('OC3R/OC1R measurements are different by more than 14mV')
                if abs(result_dict['SM_VOC3_OWD'][ic_num]['OC3R'] - result_dict['SM_VOC3_OWD'][ic_num]['OC2R']) > 0.014:
                    safety_results[safety_metric]['Error Messages'].append('OC3R/OC2R measurements are different by more than 14mV')
            elif safety_metric == 'SM_VOC_DIAG':
                for i in range(1,4):
                    if result_dict['SM_VOC_DIAG1_RAW'][ic_num]['OC%sR'%i] not in [0xFF, 0x00, 0x01]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR reported current when none was applied' % i)
                    if result_dict['SM_VOC_DIAG1'][ic_num]['OC%sL'%i]:
                        safety_results[safety_metric]['Error Messages'].append('OC%s fault latch present with no current applied' % i)

                    if result_dict['SM_VOC_DIAG2_RAW'][ic_num]['OC%sR'%i] not in [0xE4, 0xE5, 0xE3]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR out of range with -140mV test voltage' % i)
                    if result_dict['SM_VOC_DIAG2'][ic_num]['OC%sL'%i]:
                        safety_results[safety_metric]['Error Messages'].append('OC%s fault latch present during test' % i)

                    if result_dict['SM_VOC_DIAG3_RAW'][ic_num]['OC%sR' % i] not in [0x1B, 0x1C, 0x1D]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR out of range with +140mV test voltage' % i)
                    if result_dict['SM_VOC_DIAG3'][ic_num]['OC%sL' % i]:
                        safety_results[safety_metric]['Error Messages'].append('OC%s fault latch present with during test' % i)

                    if result_dict['SM_VOC_DIAG4_RAW'][ic_num]['OC%sR' % i] not in [0xC5, 0xC6, 0xC7]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR out of range with -293mV test voltage' % i)
                    if not result_dict['SM_VOC_DIAG4'][ic_num]['OC%sL' % i]:
                        safety_results[safety_metric]['Error Messages'].append('OC%s fault latch not present with during test' % i)

                    if result_dict['SM_VOC_DIAG5_RAW'][ic_num]['OC%sR' % i] not in [0x39, 0x3A, 0x3B]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR out of range with +293mV test voltage' % i)
                    if not result_dict['SM_VOC_DIAG5'][ic_num]['OC%sL' % i]:
                        safety_results[safety_metric]['Error Messages'].append('OC%s fault latch not present with during test' % i)

                    if result_dict['SM_VOC_DIAG6_RAW'][ic_num]['OC%sR' % i] not in [0xC7, 0xC8, 0xC9]:
                        safety_results[safety_metric]['Error Messages'].append('OC%sR out of range with -140mV test voltage with gain control activated' % i)
                if result_dict['SM_VOC_DIAG1_RAW'][ic_num]['OC3MAX'] not in [0xFF, 0x00, 0x01]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MAX reported current when none was applied')
                if result_dict['SM_VOC_DIAG1_RAW'][ic_num]['OC3MIN'] not in [0xFF, 0x00, 0x01]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MIN reported current when none was applied')
                # if result_dict['SM_VOC_DIAG2_RAW'][ic_num]['OC3MAX'] not in [0xFF, 0x00, 0x01]:
                #     safety_results[safety_metric]['Error Messages'].append('OC3MAX out of range with -140mV test voltage')
                if result_dict['SM_VOC_DIAG2_RAW'][ic_num]['OC3MIN'] not in [0xE4, 0xE5, 0xE3]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MIN out of range with -140mV test voltage')
                if result_dict['SM_VOC_DIAG3_RAW'][ic_num]['OC3MAX'] not in [0x1B, 0x1C, 0x1D]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MAX out of range with +140mV test voltage')
                # if result_dict['SM_VOC_DIAG3_RAW'][ic_num]['OC3MIN'] not in [0xE4, 0xE5, 0xE3]:
                #     safety_results[safety_metric]['Error Messages'].append('OC3MIN out of range with +140mV test voltage')
                # if result_dict['SM_VOC_DIAG4_RAW'][ic_num]['OC3MAX'] not in [0x1B, 0x1C, 0x1D]:
                #     safety_results[safety_metric]['Error Messages'].append('OC3MAX out of range with -293mV test voltage')
                if result_dict['SM_VOC_DIAG4_RAW'][ic_num]['OC3MIN'] not in [0xC5, 0xC6, 0xC7]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MIN out of range with -293mV test voltage')
                if result_dict['SM_VOC_DIAG5_RAW'][ic_num]['OC3MAX'] not in [0x39, 0x3A, 0x3B]:
                    safety_results[safety_metric]['Error Messages'].append('OC3MAX out of range with +293mV test voltage')
                # if result_dict['SM_VOC_DIAG5_RAW'][ic_num]['OC3MIN'] not in [0xC5, 0xC5, 0xC7]:
                #     safety_results[safety_metric]['Error Messages'].append('OC3MIN out of range with +293mV test voltage')


                if result_dict['SM_VOC_DIAG1'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('REF fault latch present with no current applied')
                if not result_dict['SM_VOC_DIAG2'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('REF fault latch not present with +40mV test voltage applied')
                if not result_dict['SM_VOC_DIAG3'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('REF fault latch not present with +40mV test voltage applied')
                if not result_dict['SM_VOC_DIAG4'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('REF fault latch not present with -40mV test voltage applied')
                if not result_dict['SM_VOC_DIAG5'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('REF fault latch not present with -40mV test voltage applied')
                if 10*0.005 < abs(result_dict['SM_VOC_DIAG2'][ic_num]['REFFLT'] - result_dict['SM_VOC_DIAG1'][ic_num]['REFFLT']) < 6*0.005:
                    safety_results[safety_metric]['Error Messages'].append('REFR did not deviate as expected with +40mV test voltage applied')
                if 10*0.005 < abs(result_dict['SM_VOC_DIAG3'][ic_num]['REFFLT'] - result_dict['SM_VOC_DIAG1'][ic_num]['REFFLT']) < 6*0.005:
                    safety_results[safety_metric]['Error Messages'].append('REFR did not deviate as expected with +40mV test voltage applied')
                if 10*0.005 < abs(result_dict['SM_VOC_DIAG4'][ic_num]['REFFLT'] - result_dict['SM_VOC_DIAG1'][ic_num]['REFFLT']) < 6*0.005:
                    safety_results[safety_metric]['Error Messages'].append('REFR did not deviate as expected with +40mV test voltage applied')
                if 10*0.005 < abs(result_dict['SM_VOC_DIAG5'][ic_num]['REFFLT'] - result_dict['SM_VOC_DIAG1'][ic_num]['REFFLT']) < 6*0.005:
                    safety_results[safety_metric]['Error Messages'].append('REFR did not deviate as expected with +40mV test voltage applied')
            elif safety_metric == 'SM_VREF1P25_OOR':
                if abs(result_dict['SM_VREF1P25_OOR'][ic_num]['V2B'] - 1.25) > 0.005:
                    safety_results[safety_metric]['Error Messages'].append('V1P25 measured via V2 is out of range')
            elif safety_metric == 'SM_VREF_MON':
                if result_dict['SM_VREF_MON'][ic_num]['REFFLT']:
                    safety_results[safety_metric]['Error Messages'].append('Reference fault detected')
            elif safety_metric == 'SM_VREF_OOR':
                if abs(result_dict['SM_VREF_OOR0'][ic_num]['VREF2A'] - 3.0) > 0.012:
                    safety_results[safety_metric]['Error Messages'].append('VREF2A is out of spec +/-12mV')
                if abs(result_dict['SM_VREF_OOR0'][ic_num]['VREF2B'] - 3.0) > 0.012:
                    safety_results[safety_metric]['Error Messages'].append('VREF2B is out of spec +/-12mV')
                avga = 0
                avgb = 0
                for i in range(1,5):
                    avga += result_dict['SM_VREF_OOR%s' % i][ic_num]['VREF2A']
                    avgb += result_dict['SM_VREF_OOR%s' % i][ic_num]['VREF2B']
                if abs(avga/4 - avgb/4) > 0.0012:
                    safety_results[safety_metric]['Error Messages'].append('VREF2A/B average difference is out of spec +/-1.2mV')
            elif safety_metric == 'SM_VSHUNT_DIAG':
                if -17*1e-6 > result_dict['SM_VSHUNT_DIAG1'][ic_num]['I1'] > 17*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 initial value out of range')
                if -17*1e-6 > result_dict['SM_VSHUNT_DIAG1'][ic_num]['I2'] > 17*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 initial value out of range')
                if -2730*1e-6 > result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] > -1340*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 with current injection on I1B value out of range')
                if 1340*1e-6 > result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] > 2730*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 with current injection on I2B value out of range')
                if -2730*1e-6 > result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] > -1340*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 with current injection on I2A value out of range')
                if 1340*1e-6 > result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] > 2730*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 with current injection on I1A value out of range')
                if -2730*1e-6 > result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1'] > -1340*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 with current injection on S1A value out of range')
                if 1340*1e-6 > result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2'] > 2730*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 with current injection on S2A value out of range')
                if -117*1e-6 > result_dict['SM_VSHUNT_DIAG5'][ic_num]['I1'] > 117*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 initial value out of range during offset compensation measurement')
                if -117*1e-6 > result_dict['SM_VSHUNT_DIAG5'][ic_num]['I2'] > 117*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 initial value out of range during offset compensation measurement')
                if 112850*1e-6 > result_dict['SM_VSHUNT_DIAG6'][ic_num]['I1'] > 121603*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 value out of range during VDIV conversion')
                if -121603*1e-6 > result_dict['SM_VSHUNT_DIAG6'][ic_num]['I2'] > -112850*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 value out of range during VDIV conversion')
                if -126426*1e-6 > result_dict['SM_VSHUNT_DIAG7'][ic_num]['I1'] > -121591*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 value out of range during scaled VREF conversion')
                if 121591*1e-6 > result_dict['SM_VSHUNT_DIAG7'][ic_num]['I2'] > 126426*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 value out of range during scaled VREF conversion')
                if -19*1e-6 > result_dict['SM_VSHUNT_DIAG1'][ic_num]['I1'] > 19*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I1 final value out of range')
                if -19*1e-6 > result_dict['SM_VSHUNT_DIAG1'][ic_num]['I2'] > 19*1e-6:
                    safety_results[safety_metric]['Error Messages'].append('I2 final value out of range')
                if 3*result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('I1A is open')
                if 3*result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('I2A is open')
                if -3*result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('I1B is open')
                if -3*result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('I2B is open')
                if -3*result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('S1A is open')
                if -3*result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) > 1.1:
                    safety_results[safety_metric]['Error Messages'].append('S2A is open')
                if 3*result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('I1A is shorted to GND')
                if 3*result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('I2A is shorted to GND')
                if -3*result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('I1B is shorted to GND')
                if -3*result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('I2B is shorted to GND')
                if -3*result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I1'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I1']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('S1A is shorted to GND')
                if -3*result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2'] / (result_dict['SM_VSHUNT_DIAG3'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG2'][ic_num]['I2'] - result_dict['SM_VSHUNT_DIAG4'][ic_num]['I2']) < 0.988:
                    safety_results[safety_metric]['Error Messages'].append('S2A is shorted to GND')
            elif safety_metric == 'SM_VSHUNT_OOR':
                if -0.135 > result_dict['SM_VSHUNT_OOR'][ic_num]['I1'] > 0.135:
                    safety_results[safety_metric]['Error Messages'].append('I1 is out of range [-0.135, 0.135]V')
                if -0.135 > result_dict['SM_VSHUNT_OOR'][ic_num]['I2'] > 0.135:
                    safety_results[safety_metric]['Error Messages'].append('I2 is out of range [-0.135, 0.135]V')
            elif safety_metric == 'SM_VSHUNT_RED':
                if abs(result_dict['SM_VSHUNT_RED'][ic_num]['I1ACC'] + result_dict['SM_VSHUNT_RED'][ic_num]['I2ACC']) > 2e-6 + (11e-6)/math.sqrt(32) + 0.0005*(result_dict['SM_VSHUNT_RED'][ic_num]['I1ACC'] + result_dict['SM_VSHUNT_RED'][ic_num]['I2ACC'])/32/2:
                    safety_results[safety_metric]['Error Messages'].append('I1/2ACC measurements are too far apart')
            if len(safety_results[safety_metric]['Error Messages']) != 0:
                safety_results[safety_metric]['Result'] = ADBMS2950.FAIL
                global_status = ADBMS2950.FAIL
            else:
                safety_results[safety_metric]['Result'] = ADBMS2950.PASS
        if len(result_dict['Safety_Results']) <= ic_num:
            result_dict['Safety_Results'].append(safety_results)
        else:
            result_dict['Safety_Results'][ic_num].update(safety_results)
        return global_status

    @staticmethod
    def calc_adc_t_eff(t_conv, I_ow, R_int, R_ext, C_ext):
        """
         Calculates expected voltage measurement during OW checks in case of RC circuit.
        """
        tau = R_ext * C_ext
        return I_ow * R_int + I_ow * R_ext * (t_conv + tau * math.exp(-t_conv / tau) - tau) / t_conv