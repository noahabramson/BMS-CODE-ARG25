# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import Engine.Devices.ADBMS_GEN5 as gen5base
from copy import deepcopy


# ===================================================== Bitfields =====================================================
# ===================================================== Registers =====================================================
# ===================================================== Commands =====================================================
class ADBMS6815(gen5base.ADBMS_GEN5):
    NAME = 'ADBMS6815'
    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V']
    SPINS = ['CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V', 'CD9V', 'CD10V', 'CD11V',
             'CD12V']
    OPEN_CELLS = ['CVS0V', 'CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V', 'CD9V', 'CD10V',
                  'CD11V', 'CD12V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V']
    STAT = ['SC', 'ITMP', 'VA', 'VD', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
            'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV', 'C11OV', 'C11UV', 'C12OV',
            'C12UV', 'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
            'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK', 'ADOL1',
            'ADOL2']
    CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
           'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPO7', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'GPI7', 'REV', 'VUV',
           'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9',
           'DCC10', 'DCC11', 'DCC12', 'MUTE_ST']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADLEAK'},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},
        {'command': 'RDCDC', 'map_key': 'SPINS'},
        {'command': 'RDCDD', 'map_key': 'SPINS'}
    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
        {'command': 'ADSTAT'}
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    STAT_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
        {'command': 'RDCVC', 'map_key': 'CELLS'},
        {'command': 'RDCVD', 'map_key': 'CELLS'}
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},
        {'command': 'RDCDC', 'map_key': 'SPINS'},
        {'command': 'RDCDD', 'map_key': 'SPINS'}
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]
    BCI_ANALOG_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA'},
        {'command': 'RDCFGB'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADOL'},
        {'command': 'PLADC'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'G1V',
                          'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'VA', 'VD', 'ITMP']
    GUI_CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
               'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPO7', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'GPI7', 'REV',
               'VUV',
               'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9',
               'DCC10', 'DCC11', 'DCC12', 'MUTE_ST']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'CD1V',
                   'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V', 'CD9V', 'CD10V', 'CD11V',
                   'CD12V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'ITMP', 'VA', 'VD',
                   'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
                   'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV', 'C11OV', 'C11UV',
                   'C12OV',
                   'C12UV', 'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
                   'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK', 'ADOL1',
                   'ADOL2']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'RDCVC', 'map_key': 'GUI'},
        {'command': 'RDCVD', 'map_key': 'GUI'},
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'GUI'},
        {'command': 'RDCDB', 'map_key': 'GUI'},
        {'command': 'RDCDC', 'map_key': 'GUI'},
        {'command': 'RDCDD', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'ADOL'},
        {'command': 'PLADC'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
    ]
    SAFETY_COMMAND_LISTS = {
        'SM1 MUX DECODER FAULT DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATC', 'map_key': 'SM1_CLEAR'},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM1_TEST'},
        ],
        'SM2 INTERNAL REFERENCE CROSSCHECK': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADAX', 'arguments': {'CHG': 8}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM2'},
        ],
        'SM4 CELL OPEN-WIRE DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'CVMIN': 1, "SOAKON": True, 'OWRNG': False, 'OWC': 7}},
            {'command': 'CVOW'},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM4'},
            {'command': 'RDCDB', 'map_key': 'SM4'},
            {'command': 'RDCDC', 'map_key': 'SM4'},
            {'command': 'RDCDD', 'map_key': 'SM4'},
        ],
        'SM5 CLEAR CELL VOLTAGE REGISTERS': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRCELL'},
            {'command': 'RDCVA', 'map_key': 'SM5'},
            {'command': 'RDCVB', 'map_key': 'SM5'},
            {'command': 'RDCVC', 'map_key': 'SM5'},
            {'command': 'RDCVD', 'map_key': 'SM5'},
        ],
        'SM6 CELL VOLTAGE REGISTER DIAGNOSTIC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD0_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD0_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD0_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD0_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD1_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD1_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD1_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD1_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD2_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD2_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD2_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD2_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD3_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD3_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD3_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD0_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD0_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD0_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD0_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD1_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD1_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD1_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD1_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD2_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD2_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD2_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD2_PG1'},
            {'command': 'CVPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD3_PG1'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD3_PG1'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD3_PG1'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD0_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD0_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD0_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD0_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD1_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD1_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD1_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD1_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD2_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD2_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD2_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD2_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT0_MD3_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT0_MD3_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT0_MD3_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT0_MD3_PG2'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD0_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD0_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD0_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD0_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD1_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD1_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD1_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD1_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD2_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD2_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD2_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD2_PG2'},
            {'command': 'CVPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM6_ADCOPT1_MD3_PG2'},
            {'command': 'RDCVB', 'map_key': 'SM6_ADCOPT1_MD3_PG2'},
            {'command': 'RDCVC', 'map_key': 'SM6_ADCOPT1_MD3_PG2'},
            {'command': 'RDCVD', 'map_key': 'SM6_ADCOPT1_MD3_PG2'},
        ],
        'SM7 INTERNAL SUPPLY VOLTAGE MONITORING': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADSTAT'},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM7'},
            {'command': 'RDSTATB', 'map_key': 'SM7'},
        ],
        'SM9 CELL OVERLAP MEASUREMENT': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADOL'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM9'},
        ],
        'SM10 CLEAR AUXILIARY REGISTERS': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRAUX'},
            {'command': 'RDAUXA', 'map_key': 'SM10'},
            {'command': 'RDAUXB', 'map_key': 'SM10'},
            {'command': 'RDAUXC', 'map_key': 'SM10'},
        ],
        'SM11 AUXILIARY CHANNEL VOLTAGE REGISTER DIAGNOSTIC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD0_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD0_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD0_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD1_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD1_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD1_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD2_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD2_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD2_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD3_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD3_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD0_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD0_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD0_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD1_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD1_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD1_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD2_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD2_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD2_PG1'},
            {'command': 'AXPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD3_PG1'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD3_PG1'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD0_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD0_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD0_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD1_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD1_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD1_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD2_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD2_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD2_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT0_MD3_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT0_MD3_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT0_MD3_PG2'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD0_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD0_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD0_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD1_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD1_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD1_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD2_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD2_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD2_PG2'},
            {'command': 'AXPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM11_ADCOPT1_MD3_PG2'},
            {'command': 'RDAUXB', 'map_key': 'SM11_ADCOPT1_MD3_PG2'},
            {'command': 'RDAUXC', 'map_key': 'SM11_ADCOPT1_MD3_PG2'},
        ],
        'SM12 CELL TEMPERATURE MEASUREMENT WITH REDUNDANCY': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM12'},
        ],
        'SM13 REDUNDANT DIGITAL FILTER': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATC', 'map_key': 'SM13_CLEAR'},
            {'command': 'WRCFGA', 'arguments': {'PS': 1}},
            {'command': 'ADOL'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM13_TEST1'},
            {'command': 'WRCFGA', 'arguments': {'PS': 2}},
            {'command': 'ADOL'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM13_TEST2'},
        ],
        'SM15 C PIN TO S PIN SHORT DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': False,
                'DCC3': False,
                'DCC4': False,
                'DCC5': False,
                'DCC6': False,
                'DCC7': False,
                'DCC8': False,
                'DCC9': False,
                'DCC10': False,
                'DCC11': False,
                'DCC12': False,
            }},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM15_BASE'},
            {'command': 'RDCVB', 'map_key': 'SM15_BASE'},
            {'command': 'RDCVC', 'map_key': 'SM15_BASE'},
            {'command': 'RDCVD', 'map_key': 'SM15_BASE'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': True,
                'DCC3': False,
                'DCC4': True,
                'DCC5': False,
                'DCC6': True,
                'DCC7': False,
                'DCC8': True,
                'DCC9': False,
                'DCC10': True,
                'DCC11': False,
                'DCC12': True,
            }},
            {'command': 'ADCV', 'arguments': {'CH': 1, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 2, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 3, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 4, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 5, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 6, 'DC': True}},
            {'command': 'RDCVA', 'map_key': 'SM15_EVEN'},
            {'command': 'RDCVB', 'map_key': 'SM15_EVEN'},
            {'command': 'RDCVC', 'map_key': 'SM15_EVEN'},
            {'command': 'RDCVD', 'map_key': 'SM15_EVEN'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': True,
                'DCC2': False,
                'DCC3': True,
                'DCC4': False,
                'DCC5': True,
                'DCC6': False,
                'DCC7': True,
                'DCC8': False,
                'DCC9': True,
                'DCC10': False,
                'DCC11': True,
                'DCC12': False,
            }},
            {'command': 'ADCV', 'arguments': {'CH': 1, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 2, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 3, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 4, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 5, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADCV', 'arguments': {'CH': 6, 'DC': True}},
            {'command': 'RDCVA', 'map_key': 'SM15_ODD'},
            {'command': 'RDCVB', 'map_key': 'SM15_ODD'},
            {'command': 'RDCVC', 'map_key': 'SM15_ODD'},
            {'command': 'RDCVD', 'map_key': 'SM15_ODD'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': False,
                'DCC3': False,
                'DCC4': False,
                'DCC5': False,
                'DCC6': False,
                'DCC7': False,
                'DCC8': False,
                'DCC9': False,
                'DCC10': False,
                'DCC11': False,
                'DCC12': False,
            }},
        ],
        'SM16 CELL INPUT BOARD LEAKAGE DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADLEAK'},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM16'},
            {'command': 'RDCDB', 'map_key': 'SM16'},
            {'command': 'RDCDC', 'map_key': 'SM16'},
            {'command': 'RDCDD', 'map_key': 'SM16'},
        ],
        'SM17 SENSE LINE FAULT DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': False,
                'DCC3': False,
                'DCC4': False,
                'DCC5': False,
                'DCC6': False,
                'DCC7': False,
                'DCC8': False,
                'DCC9': False,
                'DCC10': False,
                'DCC11': False,
                'DCC12': False,
            }},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM17_BASE'},
            {'command': 'RDCVB', 'map_key': 'SM17_BASE'},
            {'command': 'RDCVC', 'map_key': 'SM17_BASE'},
            {'command': 'RDCVD', 'map_key': 'SM17_BASE'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': True,
                'DCC3': False,
                'DCC4': True,
                'DCC5': False,
                'DCC6': True,
                'DCC7': False,
                'DCC8': True,
                'DCC9': False,
                'DCC10': True,
                'DCC11': False,
                'DCC12': True,
            }},
            {'command': 'ADSC', 'arguments': {'CH': 1, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 2, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 3, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 4, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 5, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 6, 'DC': True}},
            {'command': 'RDCDA', 'map_key': 'SM17_EVEN'},
            {'command': 'RDCDB', 'map_key': 'SM17_EVEN'},
            {'command': 'RDCDC', 'map_key': 'SM17_EVEN'},
            {'command': 'RDCDD', 'map_key': 'SM17_EVEN'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': True,
                'DCC2': False,
                'DCC3': True,
                'DCC4': False,
                'DCC5': True,
                'DCC6': False,
                'DCC7': True,
                'DCC8': False,
                'DCC9': True,
                'DCC10': False,
                'DCC11': True,
                'DCC12': False,
            }},
            {'command': 'ADSC', 'arguments': {'CH': 1, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 2, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 3, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 4, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 5, 'DC': True}},
            {'command': 'PLADC'},
            {'command': 'ADSC', 'arguments': {'CH': 6, 'DC': True}},
            {'command': 'RDCDA', 'map_key': 'SM17_ODD'},
            {'command': 'RDCDB', 'map_key': 'SM17_ODD'},
            {'command': 'RDCDC', 'map_key': 'SM17_ODD'},
            {'command': 'RDCDD', 'map_key': 'SM17_ODD'},
            {'command': 'WRCFGB', 'arguments': {
                'DCC1': False,
                'DCC2': False,
                'DCC3': False,
                'DCC4': False,
                'DCC5': False,
                'DCC6': False,
                'DCC7': False,
                'DCC8': False,
                'DCC9': False,
                'DCC10': False,
                'DCC11': False,
                'DCC12': False,
            }},
        ],
        'SM19 INTERNAL SUPPLY FAULT MONITORING': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDSTATC', 'map_key': 'SM19'},
        ],
        'SM22 REDUNDANT ADC CONTROLLER': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATC', 'map_key': 'SM22_CLEAR'},
            {'command': 'ADOL', 'arguments': {'PS': 0}},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM22_TEST'},
        ],
        'SM23 CLOCK MONITOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATB', 'map_key': 'SM23_CLEAR'},
            {'command': 'RDSTATC', 'map_key': 'SM23_CLEAR'},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATB', 'map_key': 'SM23_TEST'},
            {'command': 'RDSTATC', 'map_key': 'SM23_TEST'},
        ],
        'SM24 CELL-GPIO VOLTAGE RANGE CHECK': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM24'},
            {'command': 'RDCVB', 'map_key': 'SM24'},
            {'command': 'RDCVC', 'map_key': 'SM24'},
            {'command': 'RDCVD', 'map_key': 'SM24'},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM24'},
            {'command': 'RDAUXB', 'map_key': 'SM24'},
            {'command': 'RDAUXC', 'map_key': 'SM24'},
        ],
        'SM26 PEC DIAGNOSTIC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RSTCC'},
            {'command': 'MUTE'},
            {'command': 'WRPWM', 'arguments': {'PWM1': 0x3}},
            {'command': 'RDPWM', 'map_key': 'SM_SPI_PEC_DIAG1'},
            {'command': 'WRPWM', 'arguments': {'PWM1': 0x3, 'CMD PEC': gen5base.CMD_PEC(pec_size=1)}},
            {'command': 'RDPWM', 'map_key': 'SM_SPI_PEC_DIAG2'},
            {'command': 'WRPWM', 'arguments': {'PWM1': 0x3, 'DATA PEC': gen5base.DATA_PEC(pec_size=1)}},
            {'command': 'RDPWM', 'map_key': 'SM_SPI_PEC_DIAG3'},
            {'command': 'WRPWM', 'arguments': {'PWM1': 0x00}},
            {'command': 'UNMUTE'},
        ],
        'SM28 GPIO ADJACENT PIN-TO-PIN SHORT DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'GPO1': True, 'GPO2': True, 'GPO3': True, 'GPO4': True, 'GPO5': True, 'GPO6': True, 'GPO7': True}},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM28_BASE'},
            {'command': 'RDAUXB', 'map_key': 'SM28_BASE'},
            {'command': 'RDAUXC', 'map_key': 'SM28_BASE'},
            {'command': 'RDAUXD', 'map_key': 'SM28_BASE'},
            {'command': 'WRCFGA',
             'arguments': {'GPO1': True, 'GPO2': False, 'GPO3': True, 'GPO4': False, 'GPO5': True, 'GPO6': False,
                           'GPO7': True}},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM28_TEST'},
            {'command': 'RDAUXB', 'map_key': 'SM28_TEST'},
            {'command': 'RDAUXC', 'map_key': 'SM28_TEST'},
            {'command': 'RDAUXD', 'map_key': 'SM28_TEST'},
            {'command': 'WRCFGA',
             'arguments': {'GPO1': True, 'GPO2': True, 'GPO3': True, 'GPO4': True, 'GPO5': True, 'GPO6': True,
                           'GPO7': True}},
        ],
        'SM29 GPIO OPEN-WIRE DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA',
             'arguments': {'GPO1': True, 'GPO2': True, 'GPO3': True, 'GPO4': True, 'GPO5': True, 'GPO6': True,
                           'GPO7': True, 'OWA': 2, 'OWRNG': True}},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM29_BASE'},
            {'command': 'RDAUXB', 'map_key': 'SM29_BASE'},
            {'command': 'RDAUXC', 'map_key': 'SM29_BASE'},
            {'command': 'RDAUXD', 'map_key': 'SM29_BASE'},
            {'command': 'AXOW', 'arguments': {'PUP': False}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM29_TEST1'},
            {'command': 'RDAUXB', 'map_key': 'SM29_TEST1'},
            {'command': 'RDAUXC', 'map_key': 'SM29_TEST1'},
            {'command': 'RDAUXD', 'map_key': 'SM29_TEST1'},
            {'command': 'AXOW', 'arguments': {'PUP': True}},
            {'command': 'PLADC'},
            {'command': 'AXOW', 'arguments': {'PUP': True}},
            {'command': 'PLADC'},
            {'command': 'RDAUXA', 'map_key': 'SM29_TEST2'},
            {'command': 'RDAUXB', 'map_key': 'SM29_TEST2'},
            {'command': 'RDAUXC', 'map_key': 'SM29_TEST2'},
            {'command': 'RDAUXD', 'map_key': 'SM29_TEST2'},
        ],
        'SM30 MUX SWITCH BIAS COMPENSATION CURRENT FAULT DETECTION': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATC', 'map_key': 'SM30_CLEAR'},
            {'command': 'DIAGN'},
            {'command': '$DELAY_US$', 'arguments': {'Delay': 600}},
            {'command': 'RDSTATC', 'map_key': 'SM30_TEST'},
        ],
        'SM31 5V REFERENCE FOR DIAGNOSTIC ON THE UPPER ADC CHANNELS': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADAX', 'arguments': {'CHG': 8}},
            {'command': 'PLADC'},
            {'command': 'RDAUXC', 'map_key': 'SM31'},
        ],
        'SM33 CLEAR STATUS REGISTERS': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRSTAT'},
            {'command': 'RDSTATA', 'map_key': 'SM33'},
            {'command': 'RDSTATB', 'map_key': 'SM33'},
            {'command': 'RDSTATC', 'map_key': 'SM33'},
        ],
        'SM34 CHARGE PUMP FAULT MONITORING': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDSTATC', 'map_key': 'SM34'},
        ],
        'SM37 FACTORY TEST MODE INDICATOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDSTATC', 'map_key': 'SM37'},
        ],
        'SM38 DIE TEMPERATURE MEASUREMENT': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADSTAT'},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM38'},
        ],
        'SM41 DIAGNOSTIC TEST ON REDUNDANT DIGITAL FILTER': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRCELL'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x01<<5, 'PS': 1}},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDCVA', 'map_key': 'SM41_PS1'},
            {'command': 'RDCVB', 'map_key': 'SM41_PS1'},
            {'command': 'RDSTATC', 'map_key': 'SM41_PS1'},
            {'command': 'CLRCELL'},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x01 << 5, 'PS': 2}},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDCVC', 'map_key': 'SM41_PS2'},
            {'command': 'RDCVD', 'map_key': 'SM41_PS2'},
            {'command': 'RDSTATC', 'map_key': 'SM41_PS2'},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
        ],
        'SM42 DIAGNOSTIC TEST ON INTERNAL SUPPLY FAULT MONITOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x01 << 2}},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM42_UV'},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x03 << 2}},
            {'command': 'ADCV'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM42_OV'},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
        ],
        'SM43 DIAGNOSTIC TEST ON MUX DECODER FAULT DETECTION CIRCUITRY': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x01 << 4}},
            {'command': 'RDSTATC', 'map_key': 'SM43_CLEAR'},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM43_TEST'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'DIAGN'},
            {'command': '$DELAY_US$', 'arguments': {'Delay': 600}},
        ],
        'SM44 DIAGNOSTIC TEST ON CHARGE PUMP OUTPUT VOLTAGE MONITOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x01 << 2}},
            {'command': 'ADAX'},
            {'command': 'PLADC'},
            {'command': 'RDSTATC', 'map_key': 'SM44'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG'},
        ],
        'SM45 DIAGNOSTIC TEST ON CLOCK MONITOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATC', 'map_key': 'SM45_CLEAR'},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATB', 'map_key': 'SM45_CLEAR'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x03}},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATB', 'map_key': 'SM45_FAST'},
            {'command': 'RDSTATC', 'map_key': 'SM45_FAST'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x02}},
            {'command': 'CLRFLAG'},
            {'command': 'DIAGN'},
            {'command': 'PLADC'},
            {'command': 'RDSTATB', 'map_key': 'SM45_SLOW'},
            {'command': 'RDSTATC', 'map_key': 'SM45_SLOW'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG'},
        ],
        'SM46 CELL DIAGNOSTIC REGISTER DIAGNOSTIC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD0_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD0_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD0_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD0_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD1_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD1_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD1_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD1_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD2_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD2_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD2_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD2_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD3_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD3_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD3_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD0_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD0_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD0_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD0_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD1_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD1_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD1_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD1_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD2_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD2_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD2_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD2_PG1'},
            {'command': 'CDPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD3_PG1'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD3_PG1'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD3_PG1'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD0_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD0_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD0_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD0_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD1_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD1_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD1_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD1_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD2_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD2_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD2_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD2_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT0_MD3_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT0_MD3_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT0_MD3_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT0_MD3_PG2'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD0_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD0_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD0_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD0_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD1_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD1_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD1_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD1_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD2_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD2_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD2_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD2_PG2'},
            {'command': 'CDPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDCDA', 'map_key': 'SM46_ADCOPT1_MD3_PG2'},
            {'command': 'RDCDB', 'map_key': 'SM46_ADCOPT1_MD3_PG2'},
            {'command': 'RDCDC', 'map_key': 'SM46_ADCOPT1_MD3_PG2'},
            {'command': 'RDCDD', 'map_key': 'SM46_ADCOPT1_MD3_PG2'},
        ],
        'SM50 STATUS REGISTER DIAGNOSTIC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD0_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD0_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD0_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD1_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD1_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD1_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD2_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD2_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD2_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD3_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD3_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD0_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD0_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD0_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD1_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD1_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD1_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD2_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD2_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD2_PG1'},
            {'command': 'STATPG', 'arguments': {'PG': 1, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD3_PG1'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD3_PG1'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD3_PG1'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': False}},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD0_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD0_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD0_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD1_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD1_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD1_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD2_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD2_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD2_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT0_MD3_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT0_MD3_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT0_MD3_PG2'},
            {'command': 'WRCFGA', 'arguments': {'ADCOPT': True}},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 0}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD0_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD0_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD0_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 1}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD1_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD1_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD1_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 2}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD2_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD2_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD2_PG2'},
            {'command': 'STATPG', 'arguments': {'PG': 2, 'MD': 3}},
            {'command': 'PLADC'},
            {'command': 'RDSTATA', 'map_key': 'SM50_ADCOPT1_MD3_PG2'},
            {'command': 'RDSTATB', 'map_key': 'SM50_ADCOPT1_MD3_PG2'},
            {'command': 'RDSTATC', 'map_key': 'SM50_ADCOPT1_MD3_PG2'},
        ],
    }
    MEMORY_TEST_VALUES = {
        # Cell Memory
        'C1V': [0x00, 0x10],
        'C2V': [0x01, 0x11],
        'C3V': [0x02, 0x12],
        'C4V': [0x03, 0x13],
        'C5V': [0x04, 0x14],
        'C6V': [0x05, 0x15],
        'C7V': [0x06, 0x10],
        'C8V': [0x07, 0x11],
        'C9V': [0x08, 0x12],
        'C10V': [0x09, 0x13],
        'C11V': [0x0A, 0x14],
        'C12V': [0x0B, 0x15],
        # Spin memory
        'CD1V': [0x0C, 0x10],
        'CD2V': [0x0D, 0x11],
        'CD3V': [0x0E, 0x12],
        'CD4V': [0x0F, 0x13],
        'CD5V': [0x10, 0x14],
        'CD6V': [0x11, 0x15],
        'CD7V': [0x12, 0x10],
        'CD8V': [0x13, 0x11],
        'CD9V': [0x14, 0x12],
        'CD10V': [0x15, 0x13],
        'CD11V': [0x16, 0x14],
        'CD12V': [0x17, 0x15],
        # Aux Memory
        'REF2': [0x18, 0x07],
        'G1V': [0x19, 0x00],
        'G2V': [0x1A, 0x01],
        'G3V': [0x1B, 0x02],
        'G4V': [0x1C, 0x03],
        'G5V': [0x1D, 0x04],
        'G6V': [0x1E, 0x05],
        'G7V': [0x1F, 0x06],
        'REF3': [0x20, 0x07],
        # Stat Memory
        'SC': [0x21, 0x08],
        'ITMP': [0x22, 0x09],
        'VA': [0x23, 0x0A],
        'VD': [0x24, 0x0B],
        'ADOL1': [0x28, 0x16],
        'ADOL2': [0x29, 0x16],
        # Extra bits
        'OSR': [  # Index if ADCOPT, then MD
            [0x06, 0x00, 0x02, 0x0A],
            [0x05, 0x01, 0x03, 0x04]]
    }
    OPEN_WIRE_LIMIT = 0.720
    GPIO_OPEN_WIRE_LIMIT = 2.6
    ADC_OVERLAP_LIMIT = 0.0025
    ADC_LEAKAGE_LIMIT = 0.0015

    MEMORY_MAP = {
        **gen5base.ADBMS_GEN5.MEMORY_MAP,
    }
    BITFIELDS = {
        **gen5base.ADBMS_GEN5.BITFIELDS,
    }
    COMMANDS = {
        **gen5base.ADBMS_GEN5.COMMANDS,
    }
    LIMITS = {
        'Safety': {
            'C1V': {
                'min': 3.2,
                'max': 4.5
            },
            'C2V': {
                'min': 3.2,
                'max': 4.5
            },
            'C3V': {
                'min': 3.2,
                'max': 4.5
            },
            'C4V': {
                'min': 3.2,
                'max': 4.5
            },
            'C5V': {
                'min': 3.2,
                'max': 4.5
            },
            'C6V': {
                'min': 3.2,
                'max': 4.5
            },
            'C7V': {
                'min': 3.2,
                'max': 4.5
            },
            'C8V': {
                'min': 3.2,
                'max': 4.5
            },
            'C9V': {
                'min': 3.2,
                'max': 4.5
            },
            'C10V': {
                'min': 3.2,
                'max': 4.5
            },
            'C11V': {
                'min': 3.2,
                'max': 4.5
            },
            'C12V': {
                'min': 3.2,
                'max': 4.5
            },
            'G1V': {
                'min': 0.2,
                'max': 5.0
            },
            'G2V': {
                'min': 0.2,
                'max': 5.0
            },
            'G3V': {
                'min': 0.2,
                'max': 5.0
            },
            'G4V': {
                'min': 0.2,
                'max': 5.0
            },
            'G5V': {
                'min': 0.2,
                'max': 5.0
            },
            'G6V': {
                'min': 0.2,
                'max': 5.0
            },
            'G7V': {
                'min': 0.2,
                'max': 5.0
            },
        }
    }

    @staticmethod
    def decode_safety_loop(result_dict, ic_num, safety_metric=None, limit_override=None):
        limits = deepcopy(ADBMS6815.LIMITS['Safety'])
        if limit_override:
            limits.update(limit_override)
        global_status = ADBMS6815.PASS
        safety_results = {}
        if 'Safety_Results' not in result_dict:
            result_dict['Safety_Results'] = []
        if safety_metric and safety_metric in ADBMS6815.SAFETY_COMMAND_LISTS:
            safety_results[safety_metric] = {'Result': None}
            safety_results[safety_metric]['Error Messages'] = []
            try:
                for map_key in result_dict:
                    if map_key in ['Total_PEC_Status', 'All', 'Safety_Results']:
                        continue
                    if map_key.endswith('_RAW'):
                        continue
                    if not result_dict[map_key][ic_num]['Total_PEC_Status']:
                        safety_results[safety_metric]['Error Messages'].append('PEC Error Detected')
            except:
                pass
            if safety_metric == 'SM1 MUX DECODER FAULT DETECTION':
                if result_dict['SM1_CLEAR'][ic_num]['MUXFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('MUXFAIL incorrect POR reset value')
                if result_dict['SM1_TEST'][ic_num]['MUXFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('MUXFAIL incorrect test value')
            elif safety_metric == 'SM2 INTERNAL REFERENCE CROSSCHECK':
                if result_dict['SM2'][ic_num]['REF2'] > 3.007 or result_dict['SM2'][ic_num]['REF2'] < 2.993:
                    safety_results[safety_metric]['Error Messages'].append('Vref2 [%s] is Out of Range [2.993, 3.007]' % result_dict['SM2'][ic_num]['REF2'])
            elif safety_metric == 'SM4 CELL OPEN-WIRE DETECTION':
                for cell in ADBMS6815.SPINS:
                    if result_dict['SM4'][ic_num][cell] > ADBMS6815.OPEN_WIRE_LIMIT:
                        safety_results[safety_metric]['Error Messages'].append('%s [%s] is greater than open wire threshold [%s]' % (cell, result_dict['SM4'][ic_num][cell], ADBMS6815.OPEN_WIRE_LIMIT))
            elif safety_metric == 'SM5 CLEAR CELL VOLTAGE REGISTERS':
                for cell in ADBMS6815.CELLS:
                    if result_dict['SM5_RAW'][ic_num][cell] != 0xFFFF:
                        safety_results[safety_metric]['Error Messages'].append('%s [%s] did not reset' % (cell, hex(result_dict['SM5_RAW'][ic_num][cell])))
            elif safety_metric == 'SM6 CELL VOLTAGE REGISTER DIAGNOSTIC':
                for opt in [0, 1]:
                    for md in [0, 1, 2, 3]:
                        for cell in ADBMS6815.CELLS:
                            if result_dict['SM6_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell] != (ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM6_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell])))
                            if result_dict['SM6_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell] != (0xFFFF & ~(ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6)):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM6_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell])))
            elif safety_metric == 'SM7 INTERNAL SUPPLY VOLTAGE MONITORING':
                if result_dict['SM7'][ic_num]['VA'] > 5.5 or result_dict['SM7'][ic_num]['VA'] < 4.5:
                    safety_results[safety_metric]['Error Messages'].append('Vreg [%s] is Out of Range [4.5, 5.5]' % result_dict['SM7'][ic_num]['VA'])
                if result_dict['SM7'][ic_num]['VD'] > 3.6 or result_dict['SM7'][ic_num]['VD'] < 2.7:
                    safety_results[safety_metric]['Error Messages'].append('VD [%s] is Out of Range [2.7, 3.6]' % result_dict['SM7'][ic_num]['VD'])
            elif safety_metric == 'SM9 CELL OVERLAP MEASUREMENT':
                if abs(result_dict['SM9'][ic_num]['ADOL1']-result_dict['SM9'][ic_num]['ADOL2']) > 0.007:
                    safety_results[safety_metric]['Error Messages'].append('ADC Overlap Measurement is [%s] out of range +/-0.007V' % abs(result_dict['SM9'][ic_num]['ADOL1']-result_dict['SM9'][ic_num]['ADOL2']))
            elif safety_metric == 'SM10 CLEAR AUXILIARY REGISTERS':
                for cell in ADBMS6815.AUX:
                    if result_dict['SM10_RAW'][ic_num][cell] != 0xFFFF:
                        safety_results[safety_metric]['Error Messages'].append('%s [0x%s] did not reset' % (cell, hex(result_dict['SM10_RAW'][ic_num][cell])))
            elif safety_metric == 'SM11 AUXILIARY CHANNEL VOLTAGE REGISTER DIAGNOSTIC':
                for opt in [0, 1]:
                    for md in [0, 1, 2, 3]:
                        for cell in ADBMS6815.AUX:
                            if result_dict['SM11_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell] != (ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM11_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell])))
                            if result_dict['SM11_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell] != (0xFFFF & ~(ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6)):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM11_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell])))
            elif safety_metric == 'SM12 CELL TEMPERATURE MEASUREMENT WITH REDUNDANCY':
                if abs(result_dict['SM12'][ic_num]['G1V'] - result_dict['SM12'][ic_num]['G2V']) > 0.01:
                    safety_results[safety_metric]['Error Messages'].append('GPIO1/3 Redundant Measurements do not match')
            elif safety_metric == 'SM13 REDUNDANT DIGITAL FILTER':
                if result_dict['SM13_CLEAR'][ic_num]['REDFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('REDFAIL Bit Did Not Clear')
                if result_dict['SM13_TEST1'][ic_num]['REDFAIL'] or result_dict['SM13_TEST2'][ic_num]['REDFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('Redundant Filter Error Detected')
                if result_dict['SM13_TEST1_RAW'][ic_num]['ADOL1'] >= 0x7FA0 or result_dict['SM13_TEST2_RAW'][ic_num]['ADOL2'] >= 0x7FA0:
                    safety_results[safety_metric]['Error Messages'].append('ADC Result is Out of Range, Indicating Filter Failure')
            elif safety_metric == 'SM15 C PIN TO S PIN SHORT DETECTION':
                for index, cell in enumerate(ADBMS6815.CELLS):
                    if index % 2:
                        if result_dict['SM15_EVEN'][ic_num][cell]/result_dict['SM15_BASE'][ic_num][cell] < 0.75:
                            safety_results[safety_metric]['Error Messages'].append(
                                'C%s/S%s or C%s/S%s short detected' % (str(index+1), str(index+1), index, index))
                        elif result_dict['SM15_EVEN'][ic_num][cell]/result_dict['SM15_BASE'][ic_num][cell] > 1.25:
                            safety_results[safety_metric]['Error Messages'].append(
                                'C%s/S%s or C%s/S%s short detected' % (str(index+1), str(index+2), index, str(index+1)))
                    else:
                        if result_dict['SM15_ODD'][ic_num][cell]/result_dict['SM15_BASE'][ic_num][cell] < 0.75:
                            safety_results[safety_metric]['Error Messages'].append(
                                'C%s/S%s or C%s/S%s short detected' % (str(index+1), str(index+1), index, index))
                        elif result_dict['SM15_ODD'][ic_num][cell]/result_dict['SM15_BASE'][ic_num][cell] > 1.25:
                            safety_results[safety_metric]['Error Messages'].append(
                                'C%s/S%s or C%s/S%s short detected' % (str(index+1), str(index+2), index, str(index+1)))
            elif safety_metric == 'SM16 CELL INPUT BOARD LEAKAGE DETECTION':
                for index, cell in enumerate(ADBMS6815.SPINS):
                        if abs(result_dict['SM16'][ic_num][cell]) > 0.00105:
                            safety_results[safety_metric]['Error Messages'].append(
                                '%s Leakeage Detected' % (cell))
            elif safety_metric == 'SM17 SENSE LINE FAULT DETECTION':
                for index, cell in enumerate(ADBMS6815.SPINS):
                    if index % 2:
                        if result_dict['SM17_EVEN'][ic_num][cell]/result_dict['SM17_BASE'][ic_num][ADBMS6815.CELLS[index]] < 0.35 or result_dict['SM17_EVEN'][ic_num][cell]/result_dict['SM17_BASE'][ic_num][ADBMS6815.CELLS[index]] > 0.7:
                            safety_results[safety_metric]['Error Messages'].append('%s Sense Line Fault Detection' % (cell))
                    else:
                        if result_dict['SM17_ODD'][ic_num][cell]/result_dict['SM17_BASE'][ic_num][ADBMS6815.CELLS[index]] < 0.35 or result_dict['SM17_ODD'][ic_num][cell]/result_dict['SM17_BASE'][ic_num][ADBMS6815.CELLS[index]] > 0.7:
                            safety_results[safety_metric]['Error Messages'].append('%s Sense Line Fault Detection' % (cell))
            elif safety_metric == 'SM19 INTERNAL SUPPLY FAULT MONITORING':
                for metric in ['VD_OVHI', 'VD_UVLO', 'VA_OVHI', 'VA_UVLO']:
                    if result_dict['SM19'][ic_num][metric]:
                        safety_results[safety_metric]['Error Messages'].append('%s Fault Flag is Set' % metric)
            elif safety_metric == 'SM22 REDUNDANT ADC CONTROLLER':
                if result_dict['SM22_CLEAR'][ic_num]['REDFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('REDFAIL Bit Did Not Clear')
                if result_dict['SM22_TEST'][ic_num]['REDFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('Redundant Filter Error Detected')
            elif safety_metric == 'SM23 CLOCK MONITOR':
                if result_dict['SM23_CLEAR'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('OSCCHK Bit Did Not Clear')
                if result_dict['SM23_TEST'][ic_num]['OSCCHK'] and (result_dict['SM23_TEST'][ic_num]['OC_CNTR'] > 132 or result_dict['SM23_TEST'][ic_num]['OC_CNTR'] < 70):
                    safety_results[safety_metric]['Error Messages'].append('Oscillator Error Detected')
            elif safety_metric == 'SM24 CELL-GPIO VOLTAGE RANGE CHECK':
                for cell in ADBMS6815.CELLS:
                    if result_dict['SM24'][ic_num][cell] < limits[cell]['min'] or result_dict['SM24'][ic_num][cell] > limits[cell]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is out of limits [%s, %s]' % (cell, limits[cell]['min'], limits[cell]['max']))
                for cell in ADBMS6815.GPIOS:
                    if result_dict['SM24'][ic_num][cell] < limits[cell]['min'] or result_dict['SM24'][ic_num][cell] > limits[cell]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is out of limits [%s, %s]' % (cell, limits[cell]['min'], limits[cell]['max']))
            elif safety_metric == 'SM26 PEC DIAGNOSTIC':
                safety_results[safety_metric]['Error Messages'] = []
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT did not increment')
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['PWM1'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value did not latch')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['PWM1'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['PWM1'] != 0x00:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
            elif safety_metric == 'SM28 GPIO ADJACENT PIN-TO-PIN SHORT DETECTION':
                for index, gpio in enumerate(ADBMS6815.GPIOS):
                    if not (index % 2):
                        if result_dict['SM28_TEST'][ic_num][gpio]/result_dict['SM28_BASE'][ic_num][gpio] < 0.75:
                            safety_results[safety_metric]['Error Messages'].append('%s Has an Adjacent Pin Short' % gpio)
            elif safety_metric == 'SM29 GPIO OPEN-WIRE DETECTION':
                for index, gpio in enumerate(ADBMS6815.GPIOS):
                    if result_dict['SM29_BASE'][ic_num][gpio] >= 2.75:
                        delta = abs(result_dict['SM29_TEST1'][ic_num][gpio] - result_dict['SM29_BASE'][ic_num][gpio])
                    else:
                        delta = abs(result_dict['SM29_TEST2'][ic_num][gpio] - result_dict['SM29_BASE'][ic_num][gpio])
                    if delta > 2.6:
                        safety_results[safety_metric]['Error Messages'].append('%s Has an Open Pin/Cable' % gpio)
                    if delta < 0.03:
                        safety_results[safety_metric]['Error Messages'].append('%s Has a Stuck On/Off Current Source' % gpio)
                    if result_dict['SM29_BASE'][ic_num][gpio]/3.0 < 0.11:
                        safety_results[safety_metric]['Error Messages'].append('%s Has a Missing Pull Up Connection' % gpio)
                    if result_dict['SM29_BASE'][ic_num][gpio]/3.0 > 0.027:
                        safety_results[safety_metric]['Error Messages'].append('%s Has a Missing NTC Connection' % gpio)
            elif safety_metric == 'SM30 MUX SWITCH BIAS COMPENSATION CURRENT FAULT DETECTION':
                if result_dict['SM30_CLEAR'][ic_num]['COMPCHK']:
                    safety_results[safety_metric]['Error Messages'].append('COMPCHK incorrect POR reset value')
                if result_dict['SM30_TEST'][ic_num]['COMPCHK']:
                    safety_results[safety_metric]['Error Messages'].append('COMPCHK incorrect test value')
            elif safety_metric == 'SM31 5V REFERENCE FOR DIAGNOSTIC ON THE UPPER ADC CHANNELS':
                if result_dict['SM31'][ic_num]['REF3'] > 5.2 or result_dict['SM31'][ic_num]['REF3'] < 4.8:
                    safety_results[safety_metric]['Error Messages'].append('Vref3 [%s] is Out of Range [4.8, 5.2]' % result_dict['SM31'][ic_num]['REF3'])
            elif safety_metric == 'SM33 CLEAR STATUS REGISTERS':
                for cell in ['VD', 'VA', 'ITMP', 'SC', 'ADOL1', 'ADOL2']:
                    if result_dict['SM33_RAW'][ic_num][cell] != 0xFFFF:
                        safety_results[safety_metric]['Error Messages'].append('%s [%s] did not reset' % (cell, hex(result_dict['SM33_RAW'][ic_num][cell])))
            elif safety_metric == 'SM34 CHARGE PUMP FAULT MONITORING':
                if result_dict['SM34'][ic_num]['CPCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Charge Pump Error Indicated')
            elif safety_metric == 'SM37 FACTORY TEST MODE INDICATOR':
                if result_dict['SM37'][ic_num]['TMODECHK']:
                    safety_results[safety_metric]['Error Messages'].append('Test Mode Enable Indicated')
            elif safety_metric == 'SM38 DIE TEMPERATURE MEASUREMENT':
                if result_dict['SM38'][ic_num]['ITMP'] > 125:
                    safety_results[safety_metric]['Error Messages'].append('Die Temperature is Out of Range')
            elif safety_metric == 'SM41 DIAGNOSTIC TEST ON REDUNDANT DIGITAL FILTER':
                if not result_dict['SM41_PS1'][ic_num]['REDFAIL'] or not result_dict['SM41_PS2'][ic_num]['REDFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('REDFAIL Bit Did Not Set')
                for cell in ADBMS6815.CELLS:
                    if cell in result_dict['SM41_PS1_RAW'][ic_num]:
                        if result_dict['SM41_PS1_RAW'][ic_num][cell] < 0x7F00:
                            print(cell)
                            safety_results[safety_metric]['Error Messages'].append('ADC1 Result is Not Out of Range')
                    if cell in result_dict['SM41_PS2_RAW'][ic_num]:
                        if result_dict['SM41_PS2_RAW'][ic_num][cell] < 0x7F00:
                            print(cell)
                            safety_results[safety_metric]['Error Messages'].append('ADC2 Result is Not Out of Range')
            elif safety_metric == 'SM42 DIAGNOSTIC TEST ON INTERNAL SUPPLY FAULT MONITOR':
                if not result_dict['SM42_UV'][ic_num]['VA_UVLO'] or not result_dict['SM42_UV'][ic_num]['VD_UVLO']:
                    safety_results[safety_metric]['Error Messages'].append('VA_UVLO or VD_UVLO Did Not Set')
                if not result_dict['SM42_OV'][ic_num]['VA_OVHI'] or not result_dict['SM42_OV'][ic_num]['VD_OVHI']:
                    safety_results[safety_metric]['Error Messages'].append('VA_OVHI or VD_OVHI Did Not Set')
            elif safety_metric == 'SM43 DIAGNOSTIC TEST ON MUX DECODER FAULT DETECTION CIRCUITRY':
                if result_dict['SM43_CLEAR'][ic_num]['MUXFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('MUXFAIL incorrect POR reset value')
                if not result_dict['SM43_TEST'][ic_num]['MUXFAIL']:
                    safety_results[safety_metric]['Error Messages'].append('MUXFAIL incorrect test value')
            elif safety_metric == 'SM44 DIAGNOSTIC TEST ON CHARGE PUMP OUTPUT VOLTAGE MONITOR':
                if not result_dict['SM44'][ic_num]['CPCHK']:
                    safety_results[safety_metric]['Error Messages'].append('CPCHK incorrect test value')
            elif safety_metric == 'SM45 DIAGNOSTIC TEST ON CLOCK MONITOR':
                if result_dict['SM45_CLEAR'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('OSCCHK Bit Did Not Clear')
                if not result_dict['SM45_FAST'][ic_num]['OSCCHK'] or (
                        (result_dict['SM45_FAST'][ic_num]['OC_CNTR']/result_dict['SM45_CLEAR'][ic_num]['OC_CNTR']) > 2.4 or (result_dict['SM45_FAST'][ic_num]['OC_CNTR']/result_dict['SM45_CLEAR'][ic_num]['OC_CNTR']) < 1.6):
                    safety_results[safety_metric]['Error Messages'].append('Oscillator Fast Error Was not  Detected')
                if not result_dict['SM45_SLOW'][ic_num]['OSCCHK'] or (
                        (result_dict['SM45_SLOW'][ic_num]['OC_CNTR']/result_dict['SM45_CLEAR'][ic_num]['OC_CNTR']) > 0.8 or (result_dict['SM45_SLOW'][ic_num]['OC_CNTR']/result_dict['SM45_CLEAR'][ic_num]['OC_CNTR']) < 0.5):
                    safety_results[safety_metric]['Error Messages'].append('Oscillator Fast Error Was not  Detected')
            elif safety_metric == 'SM46 CELL DIAGNOSTIC REGISTER DIAGNOSTIC':
                for opt in [0, 1]:
                    for md in [0, 1, 2, 3]:
                        for cell in ADBMS6815.SPINS:
                            if result_dict['SM46_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell] != (ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM46_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell])))
                            if result_dict['SM46_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell] != (0xFFFF & ~(ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6)):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM46_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell])))
            elif safety_metric == 'SM50 STATUS REGISTER DIAGNOSTIC':
                for opt in [0, 1]:
                    for md in [0, 1, 2, 3]:
                        for cell in ['VD', 'VA', 'ITMP', 'SC', 'ADOL1', 'ADOL2']:
                            if result_dict['SM50_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell] != (ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM50_ADCOPT%s_MD%s_PG1_RAW' % (opt, md)][ic_num][cell])))
                            if result_dict['SM50_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell] != (0xFFFF & ~(ADBMS6815.MEMORY_TEST_VALUES[cell][0]<<10 | ADBMS6815.MEMORY_TEST_VALUES[cell][1] | ADBMS6815.MEMORY_TEST_VALUES['OSR'][opt][md]<<6)):
                                safety_results[safety_metric]['Error Messages'].append('%s [%s] failed memory test' % (cell, hex(result_dict['SM50_ADCOPT%s_MD%s_PG2_RAW' % (opt, md)][ic_num][cell])))
            if len(safety_results[safety_metric]['Error Messages']) != 0:
                safety_results[safety_metric]['Result'] = ADBMS6815.FAIL
                global_status = ADBMS6815.FAIL
            else:
                safety_results[safety_metric]['Result'] = ADBMS6815.PASS
        if len(result_dict['Safety_Results']) <= ic_num:
            result_dict['Safety_Results'].append(safety_results)
        else:
            result_dict['Safety_Results'][ic_num].update(safety_results)
        return global_status
