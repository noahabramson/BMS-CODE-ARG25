# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import Engine.Devices.ADBMS_GEN5 as gen5base
import Engine.Devices.BMS_Config as bmsbase


# ===================================================== Bitfields =====================================================
class SC(bmsbase.BitfieldAdc):
    NAME = 'SC'
    DESCRIPTION = 'Sum of All Cells Measurement'
    MEM_KEY = 'Status Register Group A'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SC, self).__init__(SC.LENGTH, value=value, raw_value=raw_value, lsb=0.0001*10, postpend=0, prepend=0)
        self.name = SC.NAME


# ===================================================== Registers =====================================================
class CFGAR0(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR0'

    def __init__(self):
        super(CFGAR0, self).__init__([[gen5base.REFON, 0], [gen5base.ADCOPT, 0], [bmsbase.RSVD0, 0], [gen5base.DIS_RED, 0], [gen5base.CVMIN, 1], [gen5base.CVMIN, 0], [gen5base.MCAL, 0], [gen5base.COMM_BK, 0]])


class CFGBR4(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR4'

    def __init__(self):
        super(CFGBR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [gen5base.DCC6, 0], [gen5base.DCC5, 0], [gen5base.DCC4, 0], [gen5base.DCC3, 0], [gen5base.DCC2, 0], [gen5base.DCC1, 0]])


class CFGBR5(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR5'

    def __init__(self):
        super(CFGBR5, self).__init__([[gen5base.MUTE_ST, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class STAR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR0'

    def __init__(self):
        super(STAR0, self).__init__([[SC, 7], [SC, 6], [SC, 5], [SC, 4], [SC, 3], [SC, 2], [SC, 1], [SC, 0]])


class STAR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR1'

    def __init__(self):
        super(STAR1, self).__init__([[SC, 15], [SC, 14], [SC, 13], [SC, 12], [SC, 11], [SC, 10], [SC, 9], [SC, 8]])


class STBR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR3'

    def __init__(self):
        super(STBR3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [gen5base.C6OV, 0], [gen5base.C6UV, 0], [gen5base.C5OV, 0], [gen5base.C5UV, 0]])


class STBR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR4'

    def __init__(self):
        super(STBR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class STCR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR2'

    def __init__(self):
        super(STCR2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class STCR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR3'

    def __init__(self):
        super(STCR3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class STCR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR4'

    def __init__(self):
        super(STCR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class STCR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR5'

    def __init__(self):
        super(STCR5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class PWMR3(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR3'

    def __init__(self):
        super(PWMR3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class PWMR4(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR4'

    def __init__(self):
        super(PWMR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class PWMR5(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR5'

    def __init__(self):
        super(PWMR5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


# ===================================================== Commands =====================================================
class WRCFGA(gen5base.WRCFGA):
    VARIABLE = [[CFGAR0(), False], [gen5base.CFGAR1(), False], [gen5base.CFGAR2(), False], [gen5base.CFGAR3(), False], [gen5base.CFGAR4(), False], [gen5base.CFGAR5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]


class WRCFGB(gen5base.WRCFGB):
    VARIABLE = [[gen5base.CFGBR0(), False], [gen5base.CFGBR1(), False], [gen5base.CFGBR2(), False], [gen5base.CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]


class RDCFGA(gen5base.RDCFGA):
    VARIABLE = [[CFGAR0(), True], [gen5base.CFGAR1(), True], [gen5base.CFGAR2(), True], [gen5base.CFGAR3(), True], [gen5base.CFGAR4(), True], [gen5base.CFGAR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class RDCFGB(gen5base.RDCFGB):
    VARIABLE = [[gen5base.CFGBR0(), True], [gen5base.CFGBR1(), True], [gen5base.CFGBR2(), True], [gen5base.CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class RDSTATA(gen5base.RDSTATA):
    VARIABLE = [[STAR0(), True], [STAR1(), True], [gen5base.STAR2(), True], [gen5base.STAR3(), True], [gen5base.STAR4(), True], [gen5base.STAR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class RDSTATB(gen5base.RDSTATB):
    VARIABLE = [[gen5base.STBR0(), True], [gen5base.STBR1(), True], [gen5base.STBR2(), True], [STBR3(), True], [STBR4(), True], [gen5base.STBR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class RDSTATC(gen5base.RDSTATC):
    VARIABLE = [[gen5base.STCR0(), True], [gen5base.STCR1(), True], [STCR2(), True], [STCR3(), True], [STCR4(), True], [STCR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class WRPWM(gen5base.WRPWM):
    VARIABLE = [[gen5base.PWMR0(), False], [gen5base.PWMR1(), False], [gen5base.PWMR2(), False], [PWMR3(), False], [PWMR4(), False], [PWMR5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]


class RDPWM(gen5base.RDPWM):
    VARIABLE = [[gen5base.PWMR0(), True], [gen5base.PWMR1(), True], [gen5base.PWMR2(), True], [PWMR3(), True], [PWMR4(), True], [PWMR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]


class RDCVC(gen5base.RDCVC):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True


class RDCVD(gen5base.RDCVD):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True


class RDCDC(gen5base.RDCDC):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True


class RDCDD(gen5base.RDCDD):
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    HIDDEN = True


class ADBMS6816(gen5base.ADBMS_GEN5):
    NAME = 'ADBMS6816'
    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V']
    SPINS = ['CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V']
    OPEN_CELLS = ['CVS0V', 'CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V']
    STAT = ['SC', 'ITMP', 'VA', 'VD', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
            'C6OV', 'C6UV', 'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
            'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK', 'ADOL1',
            'ADOL2']
    CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
           'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPO7', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'GPI7', 'REV', 'VUV',
           'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'MUTE_ST']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADLEAK'},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},

    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
        {'command': 'PLADC'},
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
        {'command': 'ADSTAT'}
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    STAT_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]
    BCI_ANALOG_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA'},
        {'command': 'RDCFGB'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADOL'},
        {'command': 'PLADC'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'G1V',
                          'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'VA', 'VD', 'ITMP']
    GUI_CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
               'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'REV',
               'VUV',
               'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'MUTE_ST']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'CD1V',
                   'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'ITMP', 'VA', 'VD',
                   'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
                   'C6OV', 'C6UV',
                   'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
                   'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'GUI'},
        {'command': 'RDCDB', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
    ]
    SAFETY_COMMAND_LISTS = {
    }
    MEMORY_TEST_VALUES = {
        # Cell Memory
        'C1V': [0x00, 0x10],
        'C2V': [0x01, 0x11],
        'C3V': [0x02, 0x12],
        'C4V': [0x03, 0x13],
        'C5V': [0x04, 0x14],
        'C6V': [0x05, 0x15],
        'C7V': [0x06, 0x10],
        'C8V': [0x07, 0x11],
        'C9V': [0x08, 0x12],
        'C10V': [0x09, 0x13],
        'C11V': [0x0A, 0x14],
        'C12V': [0x0B, 0x15],
        # Spin memory
        'CD1V': [0x0C, 0x10],
        'CD2V': [0x0D, 0x11],
        'CD3V': [0x0E, 0x12],
        'CD4V': [0x0F, 0x13],
        'CD5V': [0x10, 0x14],
        'CD6V': [0x11, 0x15],
        'CD7V': [0x12, 0x10],
        'CD8V': [0x13, 0x11],
        'CD9V': [0x14, 0x12],
        'CD10V': [0x15, 0x13],
        'CD11V': [0x16, 0x14],
        'CD12V': [0x17, 0x15],
        # Aux Memory
        'REF2': [0x18, 0x07],
        'G1V': [0x19, 0x00],
        'G2V': [0x1A, 0x01],
        'G3V': [0x1B, 0x02],
        'G4V': [0x1C, 0x03],
        'G5V': [0x1D, 0x04],
        'G6V': [0x1E, 0x05],
        'G7V': [0x1F, 0x06],
        'REF3': [0x20, 0x07],
        # Stat Memory
        'SC': [0x21, 0x08],
        'ITMP': [0x22, 0x09],
        'VA': [0x23, 0x0A],
        'VD': [0x24, 0x0B],
        'ADOL1': [0x28, 0x16],
        'ADOL2': [0x29, 0x16],
        # Extra bits
        'OSR': [  # Index if ADCOPT, then MD
            [0x06, 0x00, 0x02, 0x0A],
            [0x05, 0x01, 0x03, 0x04]]
    }
    OPEN_WIRE_LIMIT = 0.640
    GPIO_OPEN_WIRE_LIMIT = 2.6
    ADC_OVERLAP_LIMIT = 0.0025
    ADC_LEAKAGE_LIMIT = 0.0015

    MEMORY_MAP = {
        **gen5base.ADBMS_GEN5.MEMORY_MAP,
        CFGAR0.NAME: CFGAR0,
        CFGBR4.NAME: CFGBR4,
        CFGBR5.NAME: CFGBR5,
        STAR0.NAME: STAR0,
        STAR1.NAME: STAR1,
        STBR3.NAME: STBR3,
        STBR4.NAME: STBR4,
        STCR2.NAME: STCR2,
        STCR3.NAME: STCR3,
        STCR4.NAME: STCR4,
        STCR5.NAME: STCR5,
        PWMR3.NAME: PWMR3,
        PWMR4.NAME: PWMR4,
        PWMR5.NAME: PWMR5,
    }
    BITFIELDS = {
        **gen5base.ADBMS_GEN5.BITFIELDS,
        gen5base.DIS_RED.NAME: gen5base.DIS_RED,
        SC.NAME: SC
    }
    COMMANDS = {
        **gen5base.ADBMS_GEN5.COMMANDS,
        RDCFGA.NAME: RDCFGA,
        RDCFGB.NAME: RDCFGB,
        RDPWM.NAME: RDPWM,
        RDCDC.NAME: RDCDC,
        RDCDD.NAME: RDCDD,
        RDCVC.NAME: RDCVC,
        RDCVD.NAME: RDCVD,
        RDSTATA.NAME: RDSTATA,
        RDSTATB.NAME: RDSTATB,
        RDSTATC.NAME: RDSTATC,
        WRCFGA.NAME: WRCFGA,
        WRCFGB.NAME: WRCFGB,
        WRPWM.NAME: WRPWM,
    }
