# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Devices.ADBMS6815 import ADBMS6815


# ===================================================== Bitfields =====================================================
# ===================================================== Registers =====================================================
# ===================================================== Commands =====================================================
class ADBMS6817(ADBMS6815):
    NAME = 'ADBMS6817'
    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V']
    SPINS = ['CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V']
    OPEN_CELLS = ['CVS0V', 'CD1V', 'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V']
    STAT = ['SC', 'ITMP', 'VA', 'VD', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
            'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
            'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK', 'ADOL1',
            'ADOL2']
    CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
           'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPO7', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'GPI7', 'REV', 'VUV',
           'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'MUTE_ST']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADLEAK'},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},
        {'command': 'RDCDC', 'map_key': 'SPINS'},
    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
        {'command': 'PLADC'},
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
        {'command': 'ADSTAT'}
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    STAT_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
        {'command': 'RDCVC', 'map_key': 'CELLS'},
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDCDA', 'map_key': 'SPINS'},
        {'command': 'RDCDB', 'map_key': 'SPINS'},
        {'command': 'RDCDC', 'map_key': 'SPINS'},
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]
    BCI_ANALOG_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA'},
        {'command': 'RDCFGB'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADOL'},
        {'command': 'PLADC'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'G1V',
                          'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'VA', 'VD', 'ITMP']
    GUI_CFG = ['ADCOPT', 'REFON', 'PS', 'MCAL', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'OWC', 'GPO1', 'GPO2',
               'GPO3', 'GPO4', 'GPO5', 'GPO6', 'GPO7', 'GPI1', 'GPI2', 'GPI3', 'GPI4', 'GPI5', 'GPI6', 'GPI7', 'REV',
               'VUV',
               'VOV', 'DTMEN', 'DTRNG', 'DCTO', 'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'MUTE_ST']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'CD1V',
                   'CD2V', 'CD3V', 'CD4V', 'CD5V', 'CD6V', 'CD7V', 'CD8V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'REF2', 'REF3', 'SC', 'ITMP', 'VA', 'VD',
                   'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV', 'C5OV', 'C5UV',
                   'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'OC_CNTR', 'VA_OVHI', 'VA_UVLO', 'VD_OVHI', 'VD_UVLO', 'A_OTP_ED', 'A_OTP_MED', 'OTP_ED',
                   'OTP_MED', 'REDFAIL', 'COMPCHK', 'SLEEP', 'TMODECHK', 'MUXFAIL', 'THSD', 'CPCHK', 'OSCCHK', 'ADOL1',
                   'ADOL2']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV'},
        {'command': 'PLADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'RDCVC', 'map_key': 'GUI'},
        {'command': 'ADSC', 'arguments': {'CH': 1}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 2}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 3}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 4}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 5}},
        {'command': 'PLADC'},
        {'command': 'ADSC', 'arguments': {'CH': 6}},
        {'command': 'PLADC'},
        {'command': 'RDCDA', 'map_key': 'GUI'},
        {'command': 'RDCDB', 'map_key': 'GUI'},
        {'command': 'RDCDC', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLADC'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'ADOL'},
        {'command': 'PLADC'},
        {'command': 'ADSTAT'},
        {'command': 'PLADC'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
    ]


