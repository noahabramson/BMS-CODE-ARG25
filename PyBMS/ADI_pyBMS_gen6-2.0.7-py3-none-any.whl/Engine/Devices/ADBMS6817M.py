# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import Engine.Devices.BMS_Config as bmsbase
import Engine.Devices.ADBMS_GEN5 as gen5base
from Engine.Devices.ADBMS6817 import ADBMS6817


# ===================================================== Bitfields =====================================================

class CMC_NDEV(bmsbase.BitfieldInt):
    NAME = 'CMC_NDEV'
    DESCRIPTION = 'Number of Devices'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_NDEV, self).__init__(CMC_NDEV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_NDEV.NAME


class CMC_MAN(bmsbase.BitfieldBool):
    NAME = 'CMC_MAN'
    DESCRIPTION = 'Fault Monitoring Manager'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_MAN, self).__init__(CMC_MAN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_MAN.NAME


class CMC_MPER(bmsbase.BitfieldInt):
    NAME = 'CMC_MPER'
    DESCRIPTION = 'Fault Monitoring Measure Heartbeat Period'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_MPER, self).__init__(CMC_MPER.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_MPER.NAME


class CMC_BTM(bmsbase.BitfieldBool):
    NAME = 'CMC_BTM'
    DESCRIPTION = 'Fault Monitoring Bridgeless LPCM Timeout Monitor'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_BTM, self).__init__(CMC_BTM.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_BTM.NAME


class CMC_TPER(bmsbase.BitfieldInt):
    NAME = 'CMC_TPER'
    DESCRIPTION = 'Fault Monitoring Bridgeless Timeout Period'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_TPER, self).__init__(CMC_TPER.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_TPER.NAME


class CMC_DIR(bmsbase.BitfieldBool):
    NAME = 'CMC_DIR'
    DESCRIPTION = 'Manager Transmit Direction'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_DIR, self).__init__(CMC_DIR.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_DIR.NAME


class CMC_GOE(bmsbase.BitfieldInt):
    NAME = 'CMC_GOE'
    DESCRIPTION = 'LPCM Interrupt To GPIO'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_GOE, self).__init__(CMC_GOE.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_GOE.NAME


class CMT_CUV(bmsbase.BitfieldAdc):
    NAME = 'CMT_CUV'
    DESCRIPTION = 'Cell Under Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_CUV, self).__init__(CMT_CUV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_CUV.NAME


class CMT_COV(bmsbase.BitfieldAdc):
    NAME = 'CMT_COV'
    DESCRIPTION = 'Cell Over Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_COV, self).__init__(CMT_COV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_COV.NAME


class CMT_CDV(bmsbase.BitfieldAdc):
    NAME = 'CMT_CDV'
    DESCRIPTION = 'Cell Delta Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_CDV, self).__init__(CMT_CDV.LENGTH, value=value, raw_value=raw_value, lsb=0.0012, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_CDV.NAME


class CMT_GUV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GUV'
    DESCRIPTION = 'GPIO Under Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GUV, self).__init__(CMT_GUV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_GUV.NAME


class CMT_GOV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GOV'
    DESCRIPTION = 'GPIO Over Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GOV, self).__init__(CMT_GOV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_GOV.NAME


class CMT_GDV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GDV'
    DESCRIPTION = 'GPIO Delta Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GDV, self).__init__(CMT_GDV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_GDV.NAME


class CMC_EN(bmsbase.BitfieldBool):
    NAME = 'CMC_EN'
    DESCRIPTION = 'LPCM Enabled Status'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_EN, self).__init__(CMC_EN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_EN.NAME


class CMF_BTMWD(bmsbase.BitfieldBool):
    NAME = 'CMF_BTMWD'
    DESCRIPTION = 'Bridgeless Watchdog Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_BTMWD, self).__init__(CMF_BTMWD.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_BTMWD.NAME


class CMF_BTMCMP(bmsbase.BitfieldBool):
    NAME = 'CMF_BTMCMP'
    DESCRIPTION = 'Bridgeless Message Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_BTMCMP, self).__init__(CMF_BTMCMP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_BTMCMP.NAME


class CMF_CUV(bmsbase.BitfieldBool):
    NAME = 'CMF_CUV'
    DESCRIPTION = 'LPCM Cell Under Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CUV, self).__init__(CMF_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CUV.NAME


class CMF_COV(bmsbase.BitfieldBool):
    NAME = 'CMF_COV'
    DESCRIPTION = 'LPCM Cell Over Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_COV, self).__init__(CMF_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_COV.NAME


class CMF_CDVP(bmsbase.BitfieldBool):
    NAME = 'CMF_CDVP'
    DESCRIPTION = 'LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CDVP, self).__init__(CMF_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CDVP.NAME


class CMF_CDVN(bmsbase.BitfieldBool):
    NAME = 'CMF_CDVN'
    DESCRIPTION = 'LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CDVN, self).__init__(CMF_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CDVN.NAME


class CMF_GUV(bmsbase.BitfieldBool):
    NAME = 'CMF_GUV'
    DESCRIPTION = 'LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GUV, self).__init__(CMF_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GUV.NAME


class CMF_GOV(bmsbase.BitfieldBool):
    NAME = 'CMF_GOV'
    DESCRIPTION = 'LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GOV, self).__init__(CMF_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GOV.NAME


class CMF_GDVP(bmsbase.BitfieldBool):
    NAME = 'CMF_GDVP'
    DESCRIPTION = 'LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GDVP, self).__init__(CMF_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GDVP.NAME


class CMF_GDVN(bmsbase.BitfieldBool):
    NAME = 'CMF_GDVN'
    DESCRIPTION = 'LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GDVN, self).__init__(CMF_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GDVN.NAME


class CL_CUV(bmsbase.BitfieldBool):
    NAME = 'CL_CUV'
    DESCRIPTION = 'Clear LPCM Cell Under Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CUV, self).__init__(CL_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CUV.NAME


class CL_COV(bmsbase.BitfieldBool):
    NAME = 'CL_COV'
    DESCRIPTION = 'Clear LPCM Cell Over Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_COV, self).__init__(CL_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_COV.NAME


class CL_CDVP(bmsbase.BitfieldBool):
    NAME = 'CL_CDVP'
    DESCRIPTION = 'Clear LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CDVP, self).__init__(CL_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CDVP.NAME


class CL_CDVN(bmsbase.BitfieldBool):
    NAME = 'CL_CDVN'
    DESCRIPTION = 'Clear LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CDVN, self).__init__(CL_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CDVN.NAME


class CL_GUV(bmsbase.BitfieldBool):
    NAME = 'CL_GUV'
    DESCRIPTION = 'Clear LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GUV, self).__init__(CL_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GUV.NAME


class CL_GOV(bmsbase.BitfieldBool):
    NAME = 'CL_GOV'
    DESCRIPTION = 'Clear LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GOV, self).__init__(CL_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GOV.NAME


class CL_GDVP(bmsbase.BitfieldBool):
    NAME = 'CL_GDVP'
    DESCRIPTION = 'Clear LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GDVP, self).__init__(CL_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GDVP.NAME


class CL_GDVN(bmsbase.BitfieldBool):
    NAME = 'CL_GDVN'
    DESCRIPTION = 'Clear LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GDVN, self).__init__(CL_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GDVN.NAME


class HB_DCNT(bmsbase.BitfieldInt):
    NAME = 'HB_DCNT'
    DESCRIPTION = 'Heartbeat Message Device Count'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = 0x42
    MAX_VALUE = 0xFF
    MIN_VALUE = 0x42
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(HB_DCNT, self).__init__(HB_DCNT.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_DCNT.NAME


class HB_GDVP(bmsbase.BitfieldBool):
    NAME = 'HB_GDVP'
    DESCRIPTION = 'LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GDVP, self).__init__(HB_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GDVP.NAME


class HB_GDVN(bmsbase.BitfieldBool):
    NAME = 'HB_GDVN'
    DESCRIPTION = 'LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GDVN, self).__init__(HB_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GDVN.NAME


class HB_GOV(bmsbase.BitfieldBool):
    NAME = 'HB_GOV'
    DESCRIPTION = 'LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GOV, self).__init__(HB_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GOV.NAME


class HB_GUV(bmsbase.BitfieldBool):
    NAME = 'HB_GUV'
    DESCRIPTION = 'LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GUV, self).__init__(HB_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GUV.NAME


class HB_CDVP(bmsbase.BitfieldBool):
    NAME = 'HB_CDVP'
    DESCRIPTION = 'LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CDVP, self).__init__(HB_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CDVP.NAME


class HB_CDVN(bmsbase.BitfieldBool):
    NAME = 'HB_CDVN'
    DESCRIPTION = 'LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CDVN, self).__init__(HB_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CDVN.NAME


class HB_COV(bmsbase.BitfieldBool):
    NAME = 'HB_COV'
    DESCRIPTION = 'LPCM Cell Over Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_COV, self).__init__(HB_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_COV.NAME


class HB_CUV(bmsbase.BitfieldBool):
    NAME = 'HB_CUV'
    DESCRIPTION = 'LPCM Cell Under Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CUV, self).__init__(HB_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CUV.NAME


class CMM_C(bmsbase.BitfieldInt):
    NAME = 'CMM_C'
    DESCRIPTION = 'Cell Mask'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 2**12-1
    MIN_VALUE = 0
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMM_C, self).__init__(CMM_C.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMM_C.NAME


class CMM_G(bmsbase.BitfieldInt):
    NAME = 'CMM_G'
    DESCRIPTION = 'GPIO Mask'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 2**7-1
    MIN_VALUE = 0
    LENGTH = 7
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMM_G, self).__init__(CMM_G.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMM_G.NAME


# ===================================================== Registers =====================================================
class CMCF0(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF0'

    def __init__(self):
        super(CMCF0, self).__init__([[CMC_MAN, 0], [CMC_MPER, 2], [CMC_MPER, 1], [CMC_MPER, 0], [CMC_BTM, 0], [CMC_TPER, 2], [CMC_TPER, 1], [CMC_TPER, 0]])


class CMCF1(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF1'

    def __init__(self):
        super(CMCF1, self).__init__([[CMC_NDEV, 7], [CMC_NDEV, 6], [CMC_NDEV, 5], [CMC_NDEV, 4], [CMC_NDEV, 3], [CMC_NDEV, 2], [CMC_NDEV, 1], [CMC_NDEV, 0]])


class CMCF2(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF2'

    def __init__(self):
        super(CMCF2, self).__init__([[CMM_C, 7], [CMM_C, 6], [CMM_C, 5], [CMM_C, 4], [CMM_C, 3], [CMM_C, 2], [CMM_C, 1], [CMM_C, 0]])


class CMCF3(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF3'

    def __init__(self):
        super(CMCF3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMM_C, 11], [CMM_C, 10], [CMM_C, 9], [CMM_C, 8]])


class CMCF4(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF4'

    def __init__(self):
        super(CMCF4, self).__init__([[CMM_G, 1], [CMM_G, 0], [CMC_DIR, 0], [CMC_GOE, 2], [CMC_GOE, 1], [CMC_GOE, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMCF5(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF5'

    def __init__(self):
        super(CMCF5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMM_G, 6], [CMM_G, 5], [CMM_G, 4], [CMM_G, 3], [CMM_G, 2]])


class CMTC0(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC0'

    def __init__(self):
        super(CMTC0, self).__init__([[CMT_CUV, 7], [CMT_CUV, 6], [CMT_CUV, 5], [CMT_CUV, 4], [CMT_CUV, 3], [CMT_CUV, 2], [CMT_CUV, 1], [CMT_CUV, 0]])


class CMTC1(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC1'

    def __init__(self):
        super(CMTC1, self).__init__([[CMT_COV, 3], [CMT_COV, 2], [CMT_COV, 1], [CMT_COV, 0], [CMT_CUV, 11], [CMT_CUV, 10], [CMT_CUV, 9], [CMT_CUV, 8]])


class CMTC2(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC2'

    def __init__(self):
        super(CMTC2, self).__init__([[CMT_COV, 11], [CMT_COV, 10], [CMT_COV, 9], [CMT_COV, 8], [CMT_COV, 7], [CMT_COV, 6], [CMT_COV, 5], [CMT_COV, 4]])


class CMTC3(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC3'

    def __init__(self):
        super(CMTC3, self).__init__([[CMT_CDV, 7], [CMT_CDV, 6], [CMT_CDV, 5], [CMT_CDV, 4], [CMT_CDV, 3], [CMT_CDV, 2], [CMT_CDV, 1], [CMT_CDV, 0]])


class CMTC4(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC4'

    def __init__(self):
        super(CMTC4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMT_CDV, 11], [CMT_CDV, 10], [CMT_CDV, 9], [CMT_CDV, 8]])


class CMTC5(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC5'

    def __init__(self):
        super(CMTC5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMTG0(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG0'

    def __init__(self):
        super(CMTG0, self).__init__([[CMT_GUV, 7], [CMT_GUV, 6], [CMT_GUV, 5], [CMT_GUV, 4], [CMT_GUV, 3], [CMT_GUV, 2], [CMT_GUV, 1], [CMT_GUV, 0]])


class CMTG1(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG1'

    def __init__(self):
        super(CMTG1, self).__init__([[CMT_GOV, 3], [CMT_GOV, 2], [CMT_GOV, 1], [CMT_GOV, 0], [CMT_GUV, 11], [CMT_GUV, 10], [CMT_GUV, 9], [CMT_GUV, 8]])


class CMTG2(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG2'

    def __init__(self):
        super(CMTG2, self).__init__([[CMT_GOV, 11], [CMT_GOV, 10], [CMT_GOV, 9], [CMT_GOV, 8], [CMT_GOV, 7], [CMT_GOV, 6], [CMT_GOV, 5], [CMT_GOV, 4]])


class CMTG3(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG3'

    def __init__(self):
        super(CMTG3, self).__init__([[CMT_GDV, 7], [CMT_GDV, 6], [CMT_GDV, 5], [CMT_GDV, 4], [CMT_GDV, 3], [CMT_GDV, 2], [CMT_GDV, 1], [CMT_GDV, 0]])


class CMTG4(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG4'

    def __init__(self):
        super(CMTG4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMT_GDV, 11], [CMT_GDV, 10], [CMT_GDV, 9], [CMT_GDV, 8]])


class CMTG5(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG5'

    def __init__(self):
        super(CMTG5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF0(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF0'

    def __init__(self):
        super(CMF0, self).__init__([[CMF_GDVP, 0], [CMF_GDVN, 0], [CMF_GOV, 0], [CMF_GUV, 0], [CMF_CDVP, 0], [CMF_CDVN, 0], [CMF_COV, 0], [CMF_CUV, 0]])


class CMF1(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF1'

    def __init__(self):
        super(CMF1, self).__init__([[CMC_EN, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMF_BTMWD, 0], [CMF_BTMCMP, 0]])


class CCMFD0(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CCMFD0'

    def __init__(self):
        super(CCMFD0, self).__init__([[CL_GDVP, 0], [CL_GDVN, 0], [CL_GOV, 0], [CL_GUV, 0], [CL_CDVP, 0], [CL_CDVN, 0], [CL_COV, 0], [CL_CUV, 0]])


class CCMFD1(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CCMFD1'

    def __init__(self):
        super(CCMFD1, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF2(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF2'

    def __init__(self):
        super(CMF2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF3(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF3'

    def __init__(self):
        super(CMF3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF4(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF4'

    def __init__(self):
        super(CMF4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF5(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF5'

    def __init__(self):
        super(CMF5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class HBD0(bmsbase.Register):
    MEM_KEY = 'LPCM Heartbeat Group'
    NAME = 'HBD0'

    def __init__(self):
        super(HBD0, self).__init__([[HB_DCNT, 7], [HB_DCNT, 6], [HB_DCNT, 5], [HB_DCNT, 4], [HB_DCNT, 3], [HB_DCNT, 2], [HB_DCNT, 1], [HB_DCNT, 0]])


class HBD1(bmsbase.Register):
    MEM_KEY = 'LPCM Heartbeat Group'
    NAME = 'HBD1'

    def __init__(self):
        super(HBD1, self).__init__([[HB_GDVP, 0], [HB_GDVN, 0], [HB_GOV, 0], [HB_GUV, 0], [HB_CDVP, 0], [HB_CDVN, 0], [HB_COV, 0], [HB_CUV, 0]])


# ===================================================== Commands =====================================================
class CMDIS(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CMDIS'
    DESCRIPTION = 'LPCM Disable'


    def __init__(self, **kwargs):
        super(CMDIS, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x40)
        }


class CMEN(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CMEN'
    DESCRIPTION = 'LPCM Enable'


    def __init__(self, **kwargs):
        super(CMEN, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x41)
        }


class CMHB(bmsbase.SPIRead):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[HBD0(), True], [HBD1(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 4
    NAME = 'CMHB'
    DESCRIPTION = 'LPCM Heartbeat'


    def __init__(self, **kwargs):
        super(CMHB, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x43),
            gen5base.DATA_PEC.NAME: gen5base.DATA_PEC(pec_size=2 * 8 + 6)
        }


class WRCMCFG(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMCF0(), False], [CMCF1(), False], [CMCF2(), False], [CMCF3(), False], [CMCF4(), False], [CMCF5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMCFG'
    DESCRIPTION = 'Write LPCM Configuration Group'


    def __init__(self, **kwargs):
        super(WRCMCFG, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x48),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class RDCMCFG(bmsbase.SPIRead):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMCF0(), True], [CMCF1(), True], [CMCF2(), True], [CMCF3(), True], [CMCF4(), True], [CMCF5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMCFG'
    DESCRIPTION = 'Read LPCM Configuration Group'


    def __init__(self, **kwargs):
        super(RDCMCFG, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x49),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class WRCMCELLT(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTC0(), False], [CMTC1(), False], [CMTC2(), False], [CMTC3(), False], [CMTC4(), False], [CMTC5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMCELLT'
    DESCRIPTION = 'Write LPCM Cell Threshold Group'


    def __init__(self, **kwargs):
        super(WRCMCELLT, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4A),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class RDCMCELLT(bmsbase.SPIRead):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTC0(), True], [CMTC1(), True], [CMTC2(), True], [CMTC3(), True], [CMTC4(), True], [CMTC5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMCELLT'
    DESCRIPTION = 'Read LPCM Cell Threshold Group'


    def __init__(self, **kwargs):
        super(RDCMCELLT, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4B),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class WRCMGPIOT(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTG0(), False], [CMTG1(), False], [CMTG2(), False], [CMTG3(), False], [CMTG4(), False], [CMTG5(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMGPIOT'
    DESCRIPTION = 'Write LPCM GPIO Threshold Group'


    def __init__(self, **kwargs):
        super(WRCMGPIOT, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4C),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class RDCMGPIOT(bmsbase.SPIRead):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTG0(), True], [CMTG1(), True], [CMTG2(), True], [CMTG3(), True], [CMTG4(), True], [CMTG5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMGPIOT'
    DESCRIPTION = 'Read LPCM GPIO Threshold Group'


    def __init__(self, **kwargs):
        super(RDCMGPIOT, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4D),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00)
        }


class CLRCMFLAG(bmsbase.SPIWrite):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CCMFD0(), False], [CCMFD1(), False], [gen5base.CCNT_REGISTER(), False], [gen5base.DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 4
    NAME = 'CLRCMFLAG'
    DESCRIPTION = 'Clear LPCM Flags'


    def __init__(self, **kwargs):
        super(CLRCMFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4E),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00),
            gen5base.DATA_PEC.NAME: gen5base.DATA_PEC(pec_size=2 * 8 + 6)
        }


class RDCMFLAG(bmsbase.SPIRead):
    STATIC = [[gen5base.CMD_REGISTER(), False], [gen5base.CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMF0(), True], [CMF1(), True], [CMF2(), True], [CMF3(), True], [CMF4(), True], [CMF5(), True], [gen5base.CCNT_REGISTER(), True], [gen5base.DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMFLAG'
    DESCRIPTION = 'Read LPCM Flags'


    def __init__(self, **kwargs):
        super(RDCMFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            gen5base.CMD0.NAME: gen5base.CMD0(value=0x00),
            gen5base.CMD1.NAME: gen5base.CMD1(value=0x4F),
            gen5base.CCNT.NAME: gen5base.CCNT(value=0x00),
        }


class ADBMS6817M(ADBMS6817):

    MEMORY_MAP = dict(ADBMS6817.MEMORY_MAP, **{
        
    })
    BITFIELDS = dict(ADBMS6817.BITFIELDS, **{
        CMC_BTM.NAME: CMC_BTM,
        CMC_DIR.NAME: CMC_DIR,
        CMC_EN.NAME: CMC_EN,
        CMC_GOE.NAME: CMC_GOE,
        CMC_MAN.NAME: CMC_MAN,
        CMC_MPER.NAME: CMC_MPER,
        CMC_NDEV.NAME: CMC_NDEV,
        CMC_TPER.NAME: CMC_TPER,
        CMF_BTMCMP.NAME: CMF_BTMCMP,
        CMF_BTMWD.NAME: CMF_BTMWD,
        CMF_CDVN.NAME: CMF_CDVN,
        CMF_CDVP.NAME: CMF_CDVP,
        CMF_COV.NAME: CMF_COV,
        CMF_CUV.NAME: CMF_CUV,
        CMF_GDVN.NAME: CMF_GDVN,
        CMF_GDVP.NAME: CMF_GDVP,
        CMF_GOV.NAME: CMF_GOV,
        CMF_GUV.NAME: CMF_GUV,
        CL_CDVN.NAME: CL_CDVN,
        CL_CDVP.NAME: CL_CDVP,
        CL_COV.NAME: CL_COV,
        CL_CUV.NAME: CL_CUV,
        CL_GDVN.NAME: CL_GDVN,
        CL_GDVP.NAME: CL_GDVP,
        CL_GOV.NAME: CL_GOV,
        CL_GUV.NAME: CL_GUV,
        CMM_C.NAME: CMM_C,
        CMM_G.NAME: CMM_G,
        CMT_CDV.NAME: CMT_CDV,
        CMT_COV.NAME: CMT_COV,
        CMT_CUV.NAME: CMT_CUV,
        CMT_GDV.NAME: CMT_GDV,
        CMT_GOV.NAME: CMT_GOV,
        CMT_GUV.NAME: CMT_GUV,
        HB_DCNT.NAME: HB_DCNT,
        HB_GUV.NAME: HB_GUV,
        HB_GOV.NAME: HB_GOV,
        HB_GDVP.NAME: HB_GDVP,
        HB_GDVN.NAME: HB_GDVN,
        HB_CUV.NAME: HB_CUV,
        HB_COV.NAME: HB_COV,
        HB_CDVP.NAME: HB_CDVP,
        HB_CDVN.NAME: HB_CDVN
    })
    COMMANDS = dict(ADBMS6817.COMMANDS, **{
        CMDIS.NAME: CMDIS,
        CMEN.NAME: CMEN,
        CMHB.NAME: CMHB,
        WRCMCFG.NAME: WRCMCFG,
        RDCMCFG.NAME: RDCMCFG,
        WRCMCELLT.NAME: WRCMCELLT,
        RDCMCELLT.NAME: RDCMCELLT,
        WRCMGPIOT.NAME: WRCMGPIOT,
        RDCMGPIOT.NAME: RDCMGPIOT,
        CLRCMFLAG.NAME: CLRCMFLAG,
        RDCMFLAG.NAME: RDCMFLAG,
    })

