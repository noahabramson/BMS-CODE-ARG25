# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import Engine.Devices.BMS_Config as bmsbase
import Engine.Devices.ADBMS_GEN6 as gen6base
from copy import deepcopy


# ===================================================== Bitfields =====================================================
# ===================================================== Registers =====================================================
# ===================================================== Commands =====================================================
class ADI1(gen6base.ADI1):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADI1, self).__init__(**kwargs)


class ADI2(gen6base.ADI2):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADI2, self).__init__(**kwargs)


class ADV(gen6base.ADV):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADV, self).__init__(**kwargs)


class ADX(gen6base.ADX):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(ADX, self).__init__(**kwargs)


class CLRA(gen6base.CLRFC):
    NAME = 'CLRA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRA, self).__init__(**kwargs)


class CLRI(gen6base.CLRCELL):
    NAME = 'CLRI'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRI, self).__init__(**kwargs)


class CLRO(gen6base.CLRO):
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRO, self).__init__(**kwargs)


class CLRVX(gen6base.CLRAUX):
    NAME = 'CLRVX'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(CLRVX, self).__init__(**kwargs)


class PLI1(gen6base.PLCADC):
    NAME = 'PLI1'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLI1, self).__init__(**kwargs)


class PLI2(gen6base.PLSADC):
    NAME = 'PLI2'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLI2, self).__init__(**kwargs)


class PLV(gen6base.PLAUX):
    NAME = 'PLV'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLV, self).__init__(**kwargs)


class PLX(gen6base.PLAUX2):
    NAME = 'PLX'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(PLX, self).__init__(**kwargs)


class RDFLAG(gen6base.RDSTATC):
    NAME = 'RDFLAG'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDFLAG, self).__init__(**kwargs)


class RDI(gen6base.RDCVA):
    NAME = 'RDI'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDI, self).__init__(**kwargs)


class RDIACC(gen6base.RDACA):
    NAME = 'RDIACC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDIACC, self).__init__(**kwargs)


class RDIVB1(gen6base.RDCVC):
    NAME = 'RDIVB1'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDIVB1, self).__init__(**kwargs)


class RDIVB1ACC(gen6base.RDACC):
    NAME = 'RDIVB1ACC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDIVB1ACC, self).__init__(**kwargs)


class RDOC(gen6base.RDCVF):
    NAME = 'RDOC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDOC, self).__init__(**kwargs)


class RDSTAT(gen6base.RDSTATE):
    NAME = 'RDSTAT'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDSTAT, self).__init__(**kwargs)


class RDV1A(gen6base.RDCVD):
    NAME = 'RDV1A'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV1A, self).__init__(**kwargs)


class RDV1B(gen6base.RDCVE):
    NAME = 'RDV1B'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV1B, self).__init__(**kwargs)


class RDV1C(gen6base.RDSVA):
    NAME = 'RDV1C'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV1C, self).__init__(**kwargs)


class RDV1D(gen6base.RDAUXC):
    NAME = 'RDV1D'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV1D, self).__init__(**kwargs)


class RDV2A(gen6base.RDSVC):
    NAME = 'RDV2A'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV2A, self).__init__(**kwargs)


class RDV2B(gen6base.RDSVD):
    NAME = 'RDV2B'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV2B, self).__init__(**kwargs)


class RDV2C(gen6base.RDSVB):
    NAME = 'RDV2C'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV2C, self).__init__(**kwargs)


class RDV2D(gen6base.RDAUXD):
    NAME = 'RDV2D'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV2D, self).__init__(**kwargs)


class RDV2E(gen6base.RDRAXD):
    NAME = 'RDV2E'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDV2E, self).__init__(**kwargs)


class RDVB(gen6base.RDCVB):
    NAME = 'RDVB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDVB, self).__init__(**kwargs)


class RDVBACC(gen6base.RDACB):
    NAME = 'RDVBACC'

    def __init__(self, **kwargs):
        super(RDVBACC, self).__init__(**kwargs)


class RDXA(gen6base.RDSTATA):
    NAME = 'RDXA'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDXA, self).__init__(**kwargs)


class RDXB(gen6base.RDSTATB):
    NAME = 'RDXB'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDXB, self).__init__(**kwargs)


class RDXC(gen6base.RDSTATD):
    NAME = 'RDXC'
    HIDDEN = True

    def __init__(self, **kwargs):
        super(RDXC, self).__init__(**kwargs)


class ADBMS6830(gen6base.ADBMS_GEN6):
    NAME = 'ADBMS6830'
    MEMORY_MAP = {
        **gen6base.ADBMS_GEN6.MEMORY_MAP,
        gen6base.ACVAR0.NAME: gen6base.ACVAR0,
        gen6base.ACVAR1.NAME: gen6base.ACVAR1,
        gen6base.ACVAR2.NAME: gen6base.ACVAR2,
        gen6base.ACVAR3.NAME: gen6base.ACVAR3,
        gen6base.ACVAR4.NAME: gen6base.ACVAR4,
        gen6base.ACVAR5.NAME: gen6base.ACVAR5,
        gen6base.ACVBR0.NAME: gen6base.ACVBR0,
        gen6base.ACVBR1.NAME: gen6base.ACVBR1,
        gen6base.ACVBR2.NAME: gen6base.ACVBR2,
        gen6base.ACVBR3.NAME: gen6base.ACVBR3,
        gen6base.ACVBR4.NAME: gen6base.ACVBR4,
        gen6base.ACVBR5.NAME: gen6base.ACVBR5,
        gen6base.ACVCR0.NAME: gen6base.ACVCR0,
        gen6base.ACVCR1.NAME: gen6base.ACVCR1,
        gen6base.ACVCR2.NAME: gen6base.ACVCR2,
        gen6base.ACVCR3.NAME: gen6base.ACVCR3,
        gen6base.ACVCR4.NAME: gen6base.ACVCR4,
        gen6base.ACVCR5.NAME: gen6base.ACVCR5,
        gen6base.ACVDR0.NAME: gen6base.ACVDR0,
        gen6base.ACVDR1.NAME: gen6base.ACVDR1,
        gen6base.ACVDR2.NAME: gen6base.ACVDR2,
        gen6base.ACVDR3.NAME: gen6base.ACVDR3,
        gen6base.ACVDR4.NAME: gen6base.ACVDR4,
        gen6base.ACVDR5.NAME: gen6base.ACVDR5,
        gen6base.ACVER0.NAME: gen6base.ACVER0,
        gen6base.ACVER1.NAME: gen6base.ACVER1,
        gen6base.ACVER2.NAME: gen6base.ACVER2,
        gen6base.ACVER3.NAME: gen6base.ACVER3,
        gen6base.ACVER4.NAME: gen6base.ACVER4,
        gen6base.ACVER5.NAME: gen6base.ACVER5,
        gen6base.ACVFR0.NAME: gen6base.ACVFR0,
        gen6base.ACVFR1.NAME: gen6base.ACVFR1,
        gen6base.ACVFR2.NAME: gen6base.ACVFR2,
        gen6base.ACVFR3.NAME: gen6base.ACVFR3,
        gen6base.ACVFR4.NAME: gen6base.ACVFR4,
        gen6base.ACVFR5.NAME: gen6base.ACVFR5,
        gen6base.CCMFD0.NAME: gen6base.CCMFD0,
        gen6base.CCMFD1.NAME: gen6base.CCMFD1,
        gen6base.CCNT_REGISTER.NAME: gen6base.CCNT_REGISTER,
        gen6base.CFD0.NAME: gen6base.CFD0,
        gen6base.CFD1.NAME: gen6base.CFD1,
        gen6base.CFD2.NAME: gen6base.CFD2,
        gen6base.CFD3.NAME: gen6base.CFD3,
        gen6base.CFD4.NAME: gen6base.CFD4,
        gen6base.CFD5.NAME: gen6base.CFD5,
        gen6base.CFGAR0.NAME: gen6base.CFGAR0,
        gen6base.CFGAR1.NAME: gen6base.CFGAR1,
        gen6base.CFGAR2.NAME: gen6base.CFGAR2,
        gen6base.CFGAR3.NAME: gen6base.CFGAR3,
        gen6base.CFGAR4.NAME: gen6base.CFGAR4,
        gen6base.CFGAR5.NAME: gen6base.CFGAR5,
        gen6base.CFGBR0.NAME: gen6base.CFGBR0,
        gen6base.CFGBR1.NAME: gen6base.CFGBR1,
        gen6base.CFGBR2.NAME: gen6base.CFGBR2,
        gen6base.CFGBR3.NAME: gen6base.CFGBR3,
        gen6base.CFGBR4.NAME: gen6base.CFGBR4,
        gen6base.CFGBR5.NAME: gen6base.CFGBR5,
        gen6base.CL_STDR0.NAME: gen6base.CL_STDR0,
        gen6base.CL_STDR1.NAME: gen6base.CL_STDR1,
        gen6base.CL_STDR2.NAME: gen6base.CL_STDR2,
        gen6base.CL_STDR3.NAME: gen6base.CL_STDR3,
        gen6base.CL_STDR4.NAME: gen6base.CL_STDR4,
        gen6base.CL_STDR5.NAME: gen6base.CL_STDR5,
        gen6base.CMCF0.NAME: gen6base.CMCF0,
        gen6base.CMCF1.NAME: gen6base.CMCF1,
        gen6base.CMCF2.NAME: gen6base.CMCF2,
        gen6base.CMCF3.NAME: gen6base.CMCF3,
        gen6base.CMCF4.NAME: gen6base.CMCF4,
        gen6base.CMCF5.NAME: gen6base.CMCF5,
        gen6base.CMF0.NAME: gen6base.CMF0,
        gen6base.CMF1.NAME: gen6base.CMF1,
        gen6base.CMF2.NAME: gen6base.CMF2,
        gen6base.CMF3.NAME: gen6base.CMF3,
        gen6base.CMF4.NAME: gen6base.CMF4,
        gen6base.CMF5.NAME: gen6base.CMF5,
        gen6base.CMTC0.NAME: gen6base.CMTC0,
        gen6base.CMTC1.NAME: gen6base.CMTC1,
        gen6base.CMTC2.NAME: gen6base.CMTC2,
        gen6base.CMTC3.NAME: gen6base.CMTC3,
        gen6base.CMTC4.NAME: gen6base.CMTC4,
        gen6base.CMTC5.NAME: gen6base.CMTC5,
        gen6base.CMTG0.NAME: gen6base.CMTG0,
        gen6base.CMTG1.NAME: gen6base.CMTG1,
        gen6base.CMTG2.NAME: gen6base.CMTG2,
        gen6base.CMTG3.NAME: gen6base.CMTG3,
        gen6base.CMTG4.NAME: gen6base.CMTG4,
        gen6base.CMTG5.NAME: gen6base.CMTG5,
        gen6base.COMM0.NAME: gen6base.COMM0,
        gen6base.COMM1.NAME: gen6base.COMM1,
        gen6base.COMM2.NAME: gen6base.COMM2,
        gen6base.COMM3.NAME: gen6base.COMM3,
        gen6base.COMM4.NAME: gen6base.COMM4,
        gen6base.COMM5.NAME: gen6base.COMM5,
        gen6base.CVAR0.NAME: gen6base.CVAR0,
        gen6base.CVAR1.NAME: gen6base.CVAR1,
        gen6base.CVAR2.NAME: gen6base.CVAR2,
        gen6base.CVAR3.NAME: gen6base.CVAR3,
        gen6base.CVAR4.NAME: gen6base.CVAR4,
        gen6base.CVAR5.NAME: gen6base.CVAR5,
        gen6base.CVBR0.NAME: gen6base.CVBR0,
        gen6base.CVBR1.NAME: gen6base.CVBR1,
        gen6base.CVBR2.NAME: gen6base.CVBR2,
        gen6base.CVBR3.NAME: gen6base.CVBR3,
        gen6base.CVBR4.NAME: gen6base.CVBR4,
        gen6base.CVBR5.NAME: gen6base.CVBR5,
        gen6base.CVCR0.NAME: gen6base.CVCR0,
        gen6base.CVCR1.NAME: gen6base.CVCR1,
        gen6base.CVCR2.NAME: gen6base.CVCR2,
        gen6base.CVCR3.NAME: gen6base.CVCR3,
        gen6base.CVCR4.NAME: gen6base.CVCR4,
        gen6base.CVCR5.NAME: gen6base.CVCR5,
        gen6base.CVDR0.NAME: gen6base.CVDR0,
        gen6base.CVDR1.NAME: gen6base.CVDR1,
        gen6base.CVDR2.NAME: gen6base.CVDR2,
        gen6base.CVDR3.NAME: gen6base.CVDR3,
        gen6base.CVDR4.NAME: gen6base.CVDR4,
        gen6base.CVDR5.NAME: gen6base.CVDR5,
        gen6base.CVER0.NAME: gen6base.CVER0,
        gen6base.CVER1.NAME: gen6base.CVER1,
        gen6base.CVER2.NAME: gen6base.CVER2,
        gen6base.CVER3.NAME: gen6base.CVER3,
        gen6base.CVER4.NAME: gen6base.CVER4,
        gen6base.CVER5.NAME: gen6base.CVER5,
        gen6base.CVFR0.NAME: gen6base.CVFR0,
        gen6base.CVFR1.NAME: gen6base.CVFR1,
        gen6base.CVFR2.NAME: gen6base.CVFR2,
        gen6base.CVFR3.NAME: gen6base.CVFR3,
        gen6base.CVFR4.NAME: gen6base.CVFR4,
        gen6base.CVFR5.NAME: gen6base.CVFR5,
        gen6base.FCVAR0.NAME: gen6base.FCVAR0,
        gen6base.FCVAR1.NAME: gen6base.FCVAR1,
        gen6base.FCVAR2.NAME: gen6base.FCVAR2,
        gen6base.FCVAR3.NAME: gen6base.FCVAR3,
        gen6base.FCVAR4.NAME: gen6base.FCVAR4,
        gen6base.FCVAR5.NAME: gen6base.FCVAR5,
        gen6base.FCVBR0.NAME: gen6base.FCVBR0,
        gen6base.FCVBR1.NAME: gen6base.FCVBR1,
        gen6base.FCVBR2.NAME: gen6base.FCVBR2,
        gen6base.FCVBR3.NAME: gen6base.FCVBR3,
        gen6base.FCVBR4.NAME: gen6base.FCVBR4,
        gen6base.FCVBR5.NAME: gen6base.FCVBR5,
        gen6base.FCVCR0.NAME: gen6base.FCVCR0,
        gen6base.FCVCR1.NAME: gen6base.FCVCR1,
        gen6base.FCVCR2.NAME: gen6base.FCVCR2,
        gen6base.FCVCR3.NAME: gen6base.FCVCR3,
        gen6base.FCVCR4.NAME: gen6base.FCVCR4,
        gen6base.FCVCR5.NAME: gen6base.FCVCR5,
        gen6base.FCVDR0.NAME: gen6base.FCVDR0,
        gen6base.FCVDR1.NAME: gen6base.FCVDR1,
        gen6base.FCVDR2.NAME: gen6base.FCVDR2,
        gen6base.FCVDR3.NAME: gen6base.FCVDR3,
        gen6base.FCVDR4.NAME: gen6base.FCVDR4,
        gen6base.FCVDR5.NAME: gen6base.FCVDR5,
        gen6base.FCVER0.NAME: gen6base.FCVER0,
        gen6base.FCVER1.NAME: gen6base.FCVER1,
        gen6base.FCVER2.NAME: gen6base.FCVER2,
        gen6base.FCVER3.NAME: gen6base.FCVER3,
        gen6base.FCVER4.NAME: gen6base.FCVER4,
        gen6base.FCVER5.NAME: gen6base.FCVER5,
        gen6base.FCVFR0.NAME: gen6base.FCVFR0,
        gen6base.FCVFR1.NAME: gen6base.FCVFR1,
        gen6base.FCVFR2.NAME: gen6base.FCVFR2,
        gen6base.FCVFR3.NAME: gen6base.FCVFR3,
        gen6base.FCVFR4.NAME: gen6base.FCVFR4,
        gen6base.FCVFR5.NAME: gen6base.FCVFR5,
        gen6base.GPAR0.NAME: gen6base.GPAR0,
        gen6base.GPAR1.NAME: gen6base.GPAR1,
        gen6base.GPAR2.NAME: gen6base.GPAR2,
        gen6base.GPAR3.NAME: gen6base.GPAR3,
        gen6base.GPAR4.NAME: gen6base.GPAR4,
        gen6base.GPAR5.NAME: gen6base.GPAR5,
        gen6base.GPBR0.NAME: gen6base.GPBR0,
        gen6base.GPBR1.NAME: gen6base.GPBR1,
        gen6base.GPBR2.NAME: gen6base.GPBR2,
        gen6base.GPBR3.NAME: gen6base.GPBR3,
        gen6base.GPBR4.NAME: gen6base.GPBR4,
        gen6base.GPBR5.NAME: gen6base.GPBR5,
        gen6base.GPCR0.NAME: gen6base.GPCR0,
        gen6base.GPCR1.NAME: gen6base.GPCR1,
        gen6base.GPCR2.NAME: gen6base.GPCR2,
        gen6base.GPCR3.NAME: gen6base.GPCR3,
        gen6base.GPCR4.NAME: gen6base.GPCR4,
        gen6base.GPCR5.NAME: gen6base.GPCR5,
        gen6base.GPDR0.NAME: gen6base.GPDR0,
        gen6base.GPDR1.NAME: gen6base.GPDR1,
        gen6base.GPDR2.NAME: gen6base.GPDR2,
        gen6base.GPDR3.NAME: gen6base.GPDR3,
        gen6base.GPDR4.NAME: gen6base.GPDR4,
        gen6base.GPDR5.NAME: gen6base.GPDR5,
        gen6base.HBD0.NAME: gen6base.HBD0,
        gen6base.HBD1.NAME: gen6base.HBD1,
        gen6base.PSR0.NAME: gen6base.PSR0,
        gen6base.PSR1.NAME: gen6base.PSR1,
        gen6base.PSR2.NAME: gen6base.PSR2,
        gen6base.PSR3.NAME: gen6base.PSR3,
        gen6base.PSR4.NAME: gen6base.PSR4,
        gen6base.PSR5.NAME: gen6base.PSR5,
        gen6base.PWMR0.NAME: gen6base.PWMR0,
        gen6base.PWMR1.NAME: gen6base.PWMR1,
        gen6base.PWMR2.NAME: gen6base.PWMR2,
        gen6base.PWMR3.NAME: gen6base.PWMR3,
        gen6base.PWMR4.NAME: gen6base.PWMR4,
        gen6base.PWMR5.NAME: gen6base.PWMR5,
        gen6base.RGPAR0.NAME: gen6base.RGPAR0,
        gen6base.RGPAR1.NAME: gen6base.RGPAR1,
        gen6base.RGPAR2.NAME: gen6base.RGPAR2,
        gen6base.RGPAR3.NAME: gen6base.RGPAR3,
        gen6base.RGPAR4.NAME: gen6base.RGPAR4,
        gen6base.RGPAR5.NAME: gen6base.RGPAR5,
        gen6base.RGPBR0.NAME: gen6base.RGPBR0,
        gen6base.RGPBR1.NAME: gen6base.RGPBR1,
        gen6base.RGPBR2.NAME: gen6base.RGPBR2,
        gen6base.RGPBR3.NAME: gen6base.RGPBR3,
        gen6base.RGPBR4.NAME: gen6base.RGPBR4,
        gen6base.RGPBR5.NAME: gen6base.RGPBR5,
        gen6base.RGPCR0.NAME: gen6base.RGPCR0,
        gen6base.RGPCR1.NAME: gen6base.RGPCR1,
        gen6base.RGPCR2.NAME: gen6base.RGPCR2,
        gen6base.RGPCR3.NAME: gen6base.RGPCR3,
        gen6base.RGPCR4.NAME: gen6base.RGPCR4,
        gen6base.RGPCR5.NAME: gen6base.RGPCR5,
        gen6base.RGPDR0.NAME: gen6base.RGPDR0,
        gen6base.RGPDR1.NAME: gen6base.RGPDR1,
        gen6base.RGPDR2.NAME: gen6base.RGPDR2,
        gen6base.RGPDR3.NAME: gen6base.RGPDR3,
        gen6base.RGPDR4.NAME: gen6base.RGPDR4,
        gen6base.RGPDR5.NAME: gen6base.RGPDR5,
        gen6base.RRR0.NAME: gen6base.RRR0,
        gen6base.RRR1.NAME: gen6base.RRR1,
        gen6base.RRR2.NAME: gen6base.RRR2,
        gen6base.RRR3.NAME: gen6base.RRR3,
        gen6base.RRR4.NAME: gen6base.RRR4,
        gen6base.RRR5.NAME: gen6base.RRR5,
        gen6base.SIDR0.NAME: gen6base.SIDR0,
        gen6base.SIDR1.NAME: gen6base.SIDR1,
        gen6base.SIDR2.NAME: gen6base.SIDR2,
        gen6base.SIDR3.NAME: gen6base.SIDR3,
        gen6base.SIDR4.NAME: gen6base.SIDR4,
        gen6base.SIDR5.NAME: gen6base.SIDR5,
        gen6base.STAR0.NAME: gen6base.STAR0,
        gen6base.STAR1.NAME: gen6base.STAR1,
        gen6base.STAR2.NAME: gen6base.STAR2,
        gen6base.STAR3.NAME: gen6base.STAR3,
        gen6base.STAR4.NAME: gen6base.STAR4,
        gen6base.STAR5.NAME: gen6base.STAR5,
        gen6base.STBR0.NAME: gen6base.STBR0,
        gen6base.STBR1.NAME: gen6base.STBR1,
        gen6base.STBR2.NAME: gen6base.STBR2,
        gen6base.STBR3.NAME: gen6base.STBR3,
        gen6base.STBR4.NAME: gen6base.STBR4,
        gen6base.STBR5.NAME: gen6base.STBR5,
        gen6base.STCR0.NAME: gen6base.STCR0,
        gen6base.STCR1.NAME: gen6base.STCR1,
        gen6base.STCR2.NAME: gen6base.STCR2,
        gen6base.STCR3.NAME: gen6base.STCR3,
        gen6base.STCR4.NAME: gen6base.STCR4,
        gen6base.STCR5.NAME: gen6base.STCR5,
        gen6base.STDR0.NAME: gen6base.STDR0,
        gen6base.STDR1.NAME: gen6base.STDR1,
        gen6base.STDR2.NAME: gen6base.STDR2,
        gen6base.STDR3.NAME: gen6base.STDR3,
        gen6base.STDR4.NAME: gen6base.STDR4,
        gen6base.STDR5.NAME: gen6base.STDR5,
        gen6base.STER0.NAME: gen6base.STER0,
        gen6base.STER1.NAME: gen6base.STER1,
        gen6base.STER2.NAME: gen6base.STER2,
        gen6base.STER3.NAME: gen6base.STER3,
        gen6base.STER4.NAME: gen6base.STER4,
        gen6base.STER5.NAME: gen6base.STER5,
        gen6base.SVAR0.NAME: gen6base.SVAR0,
        gen6base.SVAR1.NAME: gen6base.SVAR1,
        gen6base.SVAR2.NAME: gen6base.SVAR2,
        gen6base.SVAR3.NAME: gen6base.SVAR3,
        gen6base.SVAR4.NAME: gen6base.SVAR4,
        gen6base.SVAR5.NAME: gen6base.SVAR5,
        gen6base.SVBR0.NAME: gen6base.SVBR0,
        gen6base.SVBR1.NAME: gen6base.SVBR1,
        gen6base.SVBR2.NAME: gen6base.SVBR2,
        gen6base.SVBR3.NAME: gen6base.SVBR3,
        gen6base.SVBR4.NAME: gen6base.SVBR4,
        gen6base.SVBR5.NAME: gen6base.SVBR5,
        gen6base.SVCR0.NAME: gen6base.SVCR0,
        gen6base.SVCR1.NAME: gen6base.SVCR1,
        gen6base.SVCR2.NAME: gen6base.SVCR2,
        gen6base.SVCR3.NAME: gen6base.SVCR3,
        gen6base.SVCR4.NAME: gen6base.SVCR4,
        gen6base.SVCR5.NAME: gen6base.SVCR5,
        gen6base.SVDR0.NAME: gen6base.SVDR0,
        gen6base.SVDR1.NAME: gen6base.SVDR1,
        gen6base.SVDR2.NAME: gen6base.SVDR2,
        gen6base.SVDR3.NAME: gen6base.SVDR3,
        gen6base.SVDR4.NAME: gen6base.SVDR4,
        gen6base.SVDR5.NAME: gen6base.SVDR5,
        gen6base.SVER0.NAME: gen6base.SVER0,
        gen6base.SVER1.NAME: gen6base.SVER1,
        gen6base.SVER2.NAME: gen6base.SVER2,
        gen6base.SVER3.NAME: gen6base.SVER3,
        gen6base.SVER4.NAME: gen6base.SVER4,
        gen6base.SVER5.NAME: gen6base.SVER5,
        gen6base.SVFR0.NAME: gen6base.SVFR0,
        gen6base.SVFR1.NAME: gen6base.SVFR1,
        gen6base.SVFR2.NAME: gen6base.SVFR2,
        gen6base.SVFR3.NAME: gen6base.SVFR3,
        gen6base.SVFR4.NAME: gen6base.SVFR4,
        gen6base.SVFR5.NAME: gen6base.SVFR5,
    }
    BITFIELDS = {
        **gen6base.ADBMS_GEN6.BITFIELDS,
        gen6base.AC1V.NAME: gen6base.AC1V,
        gen6base.AC2V.NAME: gen6base.AC2V,
        gen6base.AC3V.NAME: gen6base.AC3V,
        gen6base.AC4V.NAME: gen6base.AC4V,
        gen6base.AC5V.NAME: gen6base.AC5V,
        gen6base.AC6V.NAME: gen6base.AC6V,
        gen6base.AC7V.NAME: gen6base.AC7V,
        gen6base.AC8V.NAME: gen6base.AC8V,
        gen6base.AC9V.NAME: gen6base.AC9V,
        gen6base.AC10V.NAME: gen6base.AC10V,
        gen6base.AC11V.NAME: gen6base.AC11V,
        gen6base.AC12V.NAME: gen6base.AC12V,
        gen6base.AC13V.NAME: gen6base.AC13V,
        gen6base.AC14V.NAME: gen6base.AC14V,
        gen6base.AC15V.NAME: gen6base.AC15V,
        gen6base.AC16V.NAME: gen6base.AC16V,
        gen6base.C1OV.NAME: gen6base.C1OV,
        gen6base.C1UV.NAME: gen6base.C1UV,
        gen6base.C1V.NAME: gen6base.C1V,
        gen6base.C2OV.NAME: gen6base.C2OV,
        gen6base.C2UV.NAME: gen6base.C2UV,
        gen6base.C2V.NAME: gen6base.C2V,
        gen6base.C3OV.NAME: gen6base.C3OV,
        gen6base.C3UV.NAME: gen6base.C3UV,
        gen6base.C3V.NAME: gen6base.C3V,
        gen6base.C4OV.NAME: gen6base.C4OV,
        gen6base.C4UV.NAME: gen6base.C4UV,
        gen6base.C4V.NAME: gen6base.C4V,
        gen6base.C5OV.NAME: gen6base.C5OV,
        gen6base.C5UV.NAME: gen6base.C5UV,
        gen6base.C5V.NAME: gen6base.C5V,
        gen6base.C6OV.NAME: gen6base.C6OV,
        gen6base.C6UV.NAME: gen6base.C6UV,
        gen6base.C6V.NAME: gen6base.C6V,
        gen6base.C7OV.NAME: gen6base.C7OV,
        gen6base.C7UV.NAME: gen6base.C7UV,
        gen6base.C7V.NAME: gen6base.C7V,
        gen6base.C8OV.NAME: gen6base.C8OV,
        gen6base.C8UV.NAME: gen6base.C8UV,
        gen6base.C8V.NAME: gen6base.C8V,
        gen6base.C9OV.NAME: gen6base.C9OV,
        gen6base.C9UV.NAME: gen6base.C9UV,
        gen6base.C9V.NAME: gen6base.C9V,
        gen6base.C10OV.NAME: gen6base.C10OV,
        gen6base.C10UV.NAME: gen6base.C10UV,
        gen6base.C10V.NAME: gen6base.C10V,
        gen6base.C11OV.NAME: gen6base.C11OV,
        gen6base.C11UV.NAME: gen6base.C11UV,
        gen6base.C11V.NAME: gen6base.C11V,
        gen6base.C12OV.NAME: gen6base.C12OV,
        gen6base.C12UV.NAME: gen6base.C12UV,
        gen6base.C12V.NAME: gen6base.C12V,
        gen6base.C13OV.NAME: gen6base.C13OV,
        gen6base.C13UV.NAME: gen6base.C13UV,
        gen6base.C13V.NAME: gen6base.C13V,
        gen6base.C14OV.NAME: gen6base.C14OV,
        gen6base.C14UV.NAME: gen6base.C14UV,
        gen6base.C14V.NAME: gen6base.C14V,
        gen6base.C15OV.NAME: gen6base.C15OV,
        gen6base.C15UV.NAME: gen6base.C15UV,
        gen6base.C15V.NAME: gen6base.C15V,
        gen6base.C16OV.NAME: gen6base.C16OV,
        gen6base.C16UV.NAME: gen6base.C16UV,
        gen6base.C16V.NAME: gen6base.C16V,
        gen6base.CCNT.NAME: gen6base.CCNT,
        gen6base.CED.NAME: gen6base.CED,
        gen6base.CH.NAME: gen6base.CH,
        gen6base.CH_AUX2.NAME: gen6base.CH_AUX2,
        gen6base.CL_C1OV.NAME: gen6base.CL_C1OV,
        gen6base.CL_C1UV.NAME: gen6base.CL_C1UV,
        gen6base.CL_C2OV.NAME: gen6base.CL_C2OV,
        gen6base.CL_C2UV.NAME: gen6base.CL_C2UV,
        gen6base.CL_C3OV.NAME: gen6base.CL_C3OV,
        gen6base.CL_C3UV.NAME: gen6base.CL_C3UV,
        gen6base.CL_C4OV.NAME: gen6base.CL_C4OV,
        gen6base.CL_C4UV.NAME: gen6base.CL_C4UV,
        gen6base.CL_C5OV.NAME: gen6base.CL_C5OV,
        gen6base.CL_C5UV.NAME: gen6base.CL_C5UV,
        gen6base.CL_C6OV.NAME: gen6base.CL_C6OV,
        gen6base.CL_C6UV.NAME: gen6base.CL_C6UV,
        gen6base.CL_C7OV.NAME: gen6base.CL_C7OV,
        gen6base.CL_C7UV.NAME: gen6base.CL_C7UV,
        gen6base.CL_C8OV.NAME: gen6base.CL_C8OV,
        gen6base.CL_C8UV.NAME: gen6base.CL_C8UV,
        gen6base.CL_C9OV.NAME: gen6base.CL_C9OV,
        gen6base.CL_C9UV.NAME: gen6base.CL_C9UV,
        gen6base.CL_C10OV.NAME: gen6base.CL_C10OV,
        gen6base.CL_C10UV.NAME: gen6base.CL_C10UV,
        gen6base.CL_C11OV.NAME: gen6base.CL_C11OV,
        gen6base.CL_C11UV.NAME: gen6base.CL_C11UV,
        gen6base.CL_C12OV.NAME: gen6base.CL_C12OV,
        gen6base.CL_C12UV.NAME: gen6base.CL_C12UV,
        gen6base.CL_C13OV.NAME: gen6base.CL_C13OV,
        gen6base.CL_C13UV.NAME: gen6base.CL_C13UV,
        gen6base.CL_C14OV.NAME: gen6base.CL_C14OV,
        gen6base.CL_C14UV.NAME: gen6base.CL_C14UV,
        gen6base.CL_C15OV.NAME: gen6base.CL_C15OV,
        gen6base.CL_C15UV.NAME: gen6base.CL_C15UV,
        gen6base.CL_C16OV.NAME: gen6base.CL_C16OV,
        gen6base.CL_C16UV.NAME: gen6base.CL_C16UV,
        gen6base.CL_CDVN.NAME: gen6base.CL_CDVN,
        gen6base.CL_CDVP.NAME: gen6base.CL_CDVP,
        gen6base.CL_CED.NAME: gen6base.CL_CED,
        gen6base.CL_CMED.NAME: gen6base.CL_CMED,
        gen6base.CL_COV.NAME: gen6base.CL_COV,
        gen6base.CL_CS1FLT.NAME: gen6base.CL_CS1FLT,
        gen6base.CL_CS2FLT.NAME: gen6base.CL_CS2FLT,
        gen6base.CL_CS3FLT.NAME: gen6base.CL_CS3FLT,
        gen6base.CL_CS4FLT.NAME: gen6base.CL_CS4FLT,
        gen6base.CL_CS5FLT.NAME: gen6base.CL_CS5FLT,
        gen6base.CL_CS6FLT.NAME: gen6base.CL_CS6FLT,
        gen6base.CL_CS7FLT.NAME: gen6base.CL_CS7FLT,
        gen6base.CL_CS8FLT.NAME: gen6base.CL_CS8FLT,
        gen6base.CL_CS9FLT.NAME: gen6base.CL_CS9FLT,
        gen6base.CL_CS10FLT.NAME: gen6base.CL_CS10FLT,
        gen6base.CL_CS11FLT.NAME: gen6base.CL_CS11FLT,
        gen6base.CL_CS12FLT.NAME: gen6base.CL_CS12FLT,
        gen6base.CL_CS13FLT.NAME: gen6base.CL_CS13FLT,
        gen6base.CL_CS14FLT.NAME: gen6base.CL_CS14FLT,
        gen6base.CL_CS15FLT.NAME: gen6base.CL_CS15FLT,
        gen6base.CL_CS16FLT.NAME: gen6base.CL_CS16FLT,
        gen6base.CL_CUV.NAME: gen6base.CL_CUV,
        gen6base.CL_GDVN.NAME: gen6base.CL_GDVN,
        gen6base.CL_GDVP.NAME: gen6base.CL_GDVP,
        gen6base.CL_GOV.NAME: gen6base.CL_GOV,
        gen6base.CL_GUV.NAME: gen6base.CL_GUV,
        gen6base.CL_OSCCHK.NAME: gen6base.CL_OSCCHK,
        gen6base.CL_SED.NAME: gen6base.CL_SED,
        gen6base.CL_SLEEP.NAME: gen6base.CL_SLEEP,
        gen6base.CL_SMED.NAME: gen6base.CL_SMED,
        gen6base.CL_SPIFLT.NAME: gen6base.CL_SPIFLT,
        gen6base.CL_THSD.NAME: gen6base.CL_THSD,
        gen6base.CL_TMODCHK.NAME: gen6base.CL_TMODCHK,
        gen6base.CL_VA_OV.NAME: gen6base.CL_VA_OV,
        gen6base.CL_VA_UV.NAME: gen6base.CL_VA_UV,
        gen6base.CL_VDE.NAME: gen6base.CL_VDE,
        gen6base.CL_VDEL.NAME: gen6base.CL_VDEL,
        gen6base.CL_VD_OV.NAME: gen6base.CL_VD_OV,
        gen6base.CL_VD_UV.NAME: gen6base.CL_VD_UV,
        gen6base.CMC_BTM.NAME: gen6base.CMC_BTM,
        gen6base.CMC_DIR.NAME: gen6base.CMC_DIR,
        gen6base.CMC_EN.NAME: gen6base.CMC_EN,
        gen6base.CMC_GOE.NAME: gen6base.CMC_GOE,
        gen6base.CMC_MAN.NAME: gen6base.CMC_MAN,
        gen6base.CMC_MPER.NAME: gen6base.CMC_MPER,
        gen6base.CMC_NDEV.NAME: gen6base.CMC_NDEV,
        gen6base.CMC_TPER.NAME: gen6base.CMC_TPER,
        gen6base.CMED.NAME: gen6base.CMED,
        gen6base.CMF_BTMCMP.NAME: gen6base.CMF_BTMCMP,
        gen6base.CMF_BTMWD.NAME: gen6base.CMF_BTMWD,
        gen6base.CMF_CDVN.NAME: gen6base.CMF_CDVN,
        gen6base.CMF_CDVP.NAME: gen6base.CMF_CDVP,
        gen6base.CMF_COV.NAME: gen6base.CMF_COV,
        gen6base.CMF_CUV.NAME: gen6base.CMF_CUV,
        gen6base.CMF_GDVN.NAME: gen6base.CMF_GDVN,
        gen6base.CMF_GDVP.NAME: gen6base.CMF_GDVP,
        gen6base.CMF_GOV.NAME: gen6base.CMF_GOV,
        gen6base.CMF_GUV.NAME: gen6base.CMF_GUV,
        gen6base.CMM_C.NAME: gen6base.CMM_C,
        gen6base.CMM_G.NAME: gen6base.CMM_G,
        gen6base.CMT_CDV.NAME: gen6base.CMT_CDV,
        gen6base.CMT_COV.NAME: gen6base.CMT_COV,
        gen6base.CMT_CUV.NAME: gen6base.CMT_CUV,
        gen6base.CMT_GDV.NAME: gen6base.CMT_GDV,
        gen6base.CMT_GOV.NAME: gen6base.CMT_GOV,
        gen6base.CMT_GUV.NAME: gen6base.CMT_GUV,
        gen6base.COMM_BK.NAME: gen6base.COMM_BK,
        gen6base.COMP.NAME: gen6base.COMP,
        gen6base.CONT.NAME: gen6base.CONT,
        gen6base.CS1FLT.NAME: gen6base.CS1FLT,
        gen6base.CS2FLT.NAME: gen6base.CS2FLT,
        gen6base.CS3FLT.NAME: gen6base.CS3FLT,
        gen6base.CS4FLT.NAME: gen6base.CS4FLT,
        gen6base.CS5FLT.NAME: gen6base.CS5FLT,
        gen6base.CS6FLT.NAME: gen6base.CS6FLT,
        gen6base.CS7FLT.NAME: gen6base.CS7FLT,
        gen6base.CS8FLT.NAME: gen6base.CS8FLT,
        gen6base.CS9FLT.NAME: gen6base.CS9FLT,
        gen6base.CS10FLT.NAME: gen6base.CS10FLT,
        gen6base.CS11FLT.NAME: gen6base.CS11FLT,
        gen6base.CS12FLT.NAME: gen6base.CS12FLT,
        gen6base.CS13FLT.NAME: gen6base.CS13FLT,
        gen6base.CS14FLT.NAME: gen6base.CS14FLT,
        gen6base.CS15FLT.NAME: gen6base.CS15FLT,
        gen6base.CS16FLT.NAME: gen6base.CS16FLT,
        gen6base.CT.NAME: gen6base.CT,
        gen6base.CTH.NAME: gen6base.CTH,
        gen6base.CTS.NAME: gen6base.CTS,
        gen6base.D0.NAME: gen6base.D0,
        gen6base.D1.NAME: gen6base.D1,
        gen6base.D2.NAME: gen6base.D2,
        gen6base.DCC1.NAME: gen6base.DCC1,
        gen6base.DCC2.NAME: gen6base.DCC2,
        gen6base.DCC3.NAME: gen6base.DCC3,
        gen6base.DCC4.NAME: gen6base.DCC4,
        gen6base.DCC5.NAME: gen6base.DCC5,
        gen6base.DCC6.NAME: gen6base.DCC6,
        gen6base.DCC7.NAME: gen6base.DCC7,
        gen6base.DCC8.NAME: gen6base.DCC8,
        gen6base.DCC9.NAME: gen6base.DCC9,
        gen6base.DCC10.NAME: gen6base.DCC10,
        gen6base.DCC11.NAME: gen6base.DCC11,
        gen6base.DCC12.NAME: gen6base.DCC12,
        gen6base.DCC13.NAME: gen6base.DCC13,
        gen6base.DCC14.NAME: gen6base.DCC14,
        gen6base.DCC15.NAME: gen6base.DCC15,
        gen6base.DCC16.NAME: gen6base.DCC16,
        gen6base.DCP.NAME: gen6base.DCP,
        gen6base.DCTO.NAME: gen6base.DCTO,
        gen6base.DTMEN.NAME: gen6base.DTMEN,
        gen6base.DTRNG.NAME: gen6base.DTRNG,
        gen6base.DTYPE.NAME: gen6base.DTYPE,
        gen6base.ERR.NAME: gen6base.ERR,
        gen6base.FC.NAME: gen6base.FC,
        gen6base.FC1V.NAME: gen6base.FC1V,
        gen6base.FC2V.NAME: gen6base.FC2V,
        gen6base.FC3V.NAME: gen6base.FC3V,
        gen6base.FC4V.NAME: gen6base.FC4V,
        gen6base.FC5V.NAME: gen6base.FC5V,
        gen6base.FC6V.NAME: gen6base.FC6V,
        gen6base.FC7V.NAME: gen6base.FC7V,
        gen6base.FC8V.NAME: gen6base.FC8V,
        gen6base.FC9V.NAME: gen6base.FC9V,
        gen6base.FC10V.NAME: gen6base.FC10V,
        gen6base.FC11V.NAME: gen6base.FC11V,
        gen6base.FC12V.NAME: gen6base.FC12V,
        gen6base.FC13V.NAME: gen6base.FC13V,
        gen6base.FC14V.NAME: gen6base.FC14V,
        gen6base.FC15V.NAME: gen6base.FC15V,
        gen6base.FC16V.NAME: gen6base.FC16V,
        gen6base.FCOM0.NAME: gen6base.FCOM0,
        gen6base.FCOM1.NAME: gen6base.FCOM1,
        gen6base.FCOM2.NAME: gen6base.FCOM2,
        gen6base.FLAG_D.NAME: gen6base.FLAG_D,
        gen6base.G1V.NAME: gen6base.G1V,
        gen6base.G2V.NAME: gen6base.G2V,
        gen6base.G3V.NAME: gen6base.G3V,
        gen6base.G4V.NAME: gen6base.G4V,
        gen6base.G5V.NAME: gen6base.G5V,
        gen6base.G6V.NAME: gen6base.G6V,
        gen6base.G7V.NAME: gen6base.G7V,
        gen6base.G8V.NAME: gen6base.G8V,
        gen6base.G9V.NAME: gen6base.G9V,
        gen6base.G10V.NAME: gen6base.G10V,
        gen6base.GPI1.NAME: gen6base.GPI1,
        gen6base.GPI2.NAME: gen6base.GPI2,
        gen6base.GPI3.NAME: gen6base.GPI3,
        gen6base.GPI4.NAME: gen6base.GPI4,
        gen6base.GPI5.NAME: gen6base.GPI5,
        gen6base.GPI6.NAME: gen6base.GPI6,
        gen6base.GPI7.NAME: gen6base.GPI7,
        gen6base.GPI8.NAME: gen6base.GPI8,
        gen6base.GPI9.NAME: gen6base.GPI9,
        gen6base.GPI10.NAME: gen6base.GPI10,
        gen6base.GPO1.NAME: gen6base.GPO1,
        gen6base.GPO2.NAME: gen6base.GPO2,
        gen6base.GPO3.NAME: gen6base.GPO3,
        gen6base.GPO4.NAME: gen6base.GPO4,
        gen6base.GPO5.NAME: gen6base.GPO5,
        gen6base.GPO6.NAME: gen6base.GPO6,
        gen6base.GPO7.NAME: gen6base.GPO7,
        gen6base.GPO8.NAME: gen6base.GPO8,
        gen6base.GPO9.NAME: gen6base.GPO9,
        gen6base.GPO10.NAME: gen6base.GPO10,
        gen6base.HB_CDVN.NAME: gen6base.HB_CDVN,
        gen6base.HB_CDVP.NAME: gen6base.HB_CDVP,
        gen6base.HB_COV.NAME: gen6base.HB_COV,
        gen6base.HB_CUV.NAME: gen6base.HB_CUV,
        gen6base.HB_DCNT.NAME: gen6base.HB_DCNT,
        gen6base.HB_GDVN.NAME: gen6base.HB_GDVN,
        gen6base.HB_GDVP.NAME: gen6base.HB_GDVP,
        gen6base.HB_GOV.NAME: gen6base.HB_GOV,
        gen6base.HB_GUV.NAME: gen6base.HB_GUV,
        gen6base.ICOM0.NAME: gen6base.ICOM0,
        gen6base.ICOM1.NAME: gen6base.ICOM1,
        gen6base.ICOM2.NAME: gen6base.ICOM2,
        gen6base.ITMP.NAME: gen6base.ITMP,
        gen6base.MUTE_ST.NAME: gen6base.MUTE_ST,
        gen6base.OC_CNTR.NAME: gen6base.OC_CNTR,
        gen6base.OPT.NAME: gen6base.OPT,
        gen6base.OSCCHK.NAME: gen6base.OSCCHK,
        gen6base.OW.NAME: gen6base.OW,
        gen6base.OWA.NAME: gen6base.OWA,
        gen6base.OWRNG.NAME: gen6base.OWRNG,
        gen6base.OW_AUX.NAME: gen6base.OW_AUX,
        gen6base.PUP.NAME: gen6base.PUP,
        gen6base.PWM1.NAME: gen6base.PWM1,
        gen6base.PWM2.NAME: gen6base.PWM2,
        gen6base.PWM3.NAME: gen6base.PWM3,
        gen6base.PWM4.NAME: gen6base.PWM4,
        gen6base.PWM5.NAME: gen6base.PWM5,
        gen6base.PWM6.NAME: gen6base.PWM6,
        gen6base.PWM7.NAME: gen6base.PWM7,
        gen6base.PWM8.NAME: gen6base.PWM8,
        gen6base.PWM9.NAME: gen6base.PWM9,
        gen6base.PWM10.NAME: gen6base.PWM10,
        gen6base.PWM11.NAME: gen6base.PWM11,
        gen6base.PWM12.NAME: gen6base.PWM12,
        gen6base.PWM13.NAME: gen6base.PWM13,
        gen6base.PWM14.NAME: gen6base.PWM14,
        gen6base.PWM15.NAME: gen6base.PWM15,
        gen6base.PWM16.NAME: gen6base.PWM16,
        gen6base.RD.NAME: gen6base.RD,
        gen6base.REFON.NAME: gen6base.REFON,
        gen6base.REV.NAME: gen6base.REV,
        gen6base.RR.NAME: gen6base.RR,
        gen6base.RSTF.NAME: gen6base.RSTF,
        gen6base.R_G1V.NAME: gen6base.R_G1V,
        gen6base.R_G2V.NAME: gen6base.R_G2V,
        gen6base.R_G3V.NAME: gen6base.R_G3V,
        gen6base.R_G4V.NAME: gen6base.R_G4V,
        gen6base.R_G5V.NAME: gen6base.R_G5V,
        gen6base.R_G6V.NAME: gen6base.R_G6V,
        gen6base.R_G7V.NAME: gen6base.R_G7V,
        gen6base.R_G8V.NAME: gen6base.R_G8V,
        gen6base.R_G9V.NAME: gen6base.R_G9V,
        gen6base.R_G10V.NAME: gen6base.R_G10V,
        gen6base.S1V.NAME: gen6base.S1V,
        gen6base.S2V.NAME: gen6base.S2V,
        gen6base.S3V.NAME: gen6base.S3V,
        gen6base.S4V.NAME: gen6base.S4V,
        gen6base.S5V.NAME: gen6base.S5V,
        gen6base.S6V.NAME: gen6base.S6V,
        gen6base.S7V.NAME: gen6base.S7V,
        gen6base.S8V.NAME: gen6base.S8V,
        gen6base.S9V.NAME: gen6base.S9V,
        gen6base.S10V.NAME: gen6base.S10V,
        gen6base.S11V.NAME: gen6base.S11V,
        gen6base.S12V.NAME: gen6base.S12V,
        gen6base.S13V.NAME: gen6base.S13V,
        gen6base.S14V.NAME: gen6base.S14V,
        gen6base.S15V.NAME: gen6base.S15V,
        gen6base.S16V.NAME: gen6base.S16V,
        gen6base.SED.NAME: gen6base.SED,
        gen6base.SID.NAME: gen6base.SID,
        gen6base.SLEEP.NAME: gen6base.SLEEP,
        gen6base.SMED.NAME: gen6base.SMED,
        gen6base.SNAP_ST.NAME: gen6base.SNAP_ST,
        gen6base.SOAKON.NAME: gen6base.SOAKON,
        gen6base.SPIFLT.NAME: gen6base.SPIFLT,
        gen6base.TEST_DATA0.NAME: gen6base.TEST_DATA0,
        gen6base.TEST_DATA1.NAME: gen6base.TEST_DATA1,
        gen6base.THSD.NAME: gen6base.THSD,
        gen6base.TMODCHK.NAME: gen6base.TMODCHK,
        gen6base.VA.NAME: gen6base.VA,
        gen6base.VA_OV.NAME: gen6base.VA_OV,
        gen6base.VA_UV.NAME: gen6base.VA_UV,
        gen6base.VD.NAME: gen6base.VD,
        gen6base.VDE.NAME: gen6base.VDE,
        gen6base.VDEL.NAME: gen6base.VDEL,
        gen6base.VD_OV.NAME: gen6base.VD_OV,
        gen6base.VD_UV.NAME: gen6base.VD_UV,
        gen6base.VMV.NAME: gen6base.VMV,
        gen6base.VOV.NAME: gen6base.VOV,
        gen6base.VPV.NAME: gen6base.VPV,
        gen6base.VREF2.NAME: gen6base.VREF2,
        gen6base.VRES.NAME: gen6base.VRES,
        gen6base.VUV.NAME: gen6base.VUV,
        gen6base.VCH.NAME: gen6base.VCH,
    }
    COMMANDS = {
        **gen6base.ADBMS_GEN6.COMMANDS,
        RDI.NAME: RDI,
        gen6base.RDCVALL.NAME: gen6base.RDCVALL,
        gen6base.RDACALL.NAME: gen6base.RDACALL,
        gen6base.RDSALL.NAME: gen6base.RDSALL,
        gen6base.RDCSALL.NAME: gen6base.RDCSALL,
        gen6base.RDACSALL.NAME: gen6base.RDACSALL,
        gen6base.RDFCALL.NAME: gen6base.RDFCALL,
        gen6base.RDASALL.NAME: gen6base.RDASALL,
        ADI1.NAME: ADI1,
        ADI2.NAME: ADI2,
        ADV.NAME: ADV,
        ADX.NAME: ADX,
        CLRA.NAME: CLRA,
        CLRI.NAME: CLRI,
        CLRO.NAME: CLRO,
        CLRVX.NAME: CLRVX,
        PLI1.NAME: PLI1,
        PLI2.NAME: PLI2,
        PLV.NAME: PLV,
        PLX.NAME: PLX,
        RDFLAG.NAME: RDFLAG,
        RDIACC.NAME: RDIACC,
        RDIVB1.NAME: RDIVB1,
        RDIVB1ACC.NAME: RDIVB1ACC,
        RDOC.NAME: RDOC,
        RDSTAT.NAME: RDSTAT,
        RDV1A.NAME: RDV1A,
        RDV1B.NAME: RDV1B,
        RDV1C.NAME: RDV1C,
        RDV1D.NAME: RDV1D,
        RDV2A.NAME: RDV2A,
        RDV2B.NAME: RDV2B,
        RDV2C.NAME: RDV2C,
        RDV2D.NAME: RDV2D,
        RDV2E.NAME: RDV2E,
        RDVB.NAME: RDVB,
        RDVBACC.NAME: RDVBACC,
        RDXA.NAME: RDXA,
        RDXB.NAME: RDXB,
        RDXC.NAME: RDXC,
    }

    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V', 'C14V',
             'C15V', 'C16V']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V']
    FILTERED_CELLS = ['FC1V', 'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V',
                      'FC13V', 'FC14V', 'FC15V', 'FC16V']
    AVERAGED_CELLS = ['AC1V', 'AC2V', 'AC3V', 'AC4V', 'AC5V', 'AC6V', 'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V',
                      'AC13V', 'AC14V', 'AC15V', 'AC16V']
    OPEN_CELLS = ['S0V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V',
                  'S14V', 'S15V', 'S16V']
    SPINS = ['S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
             'S15V', 'S16V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V', 'VMV', 'VPV']
    STAT = ['VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV',
            'C4UV', 'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
            'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV', 'C16OV',
            'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT', 'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT', 'CS9FLT',
            'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'VA_OV', 'VA_UV',
            'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT',
            'SLEEP', 'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS']
    CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
           'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG', 'DCTO',
           'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12', 'DCC13',
           'DCC14', 'DCC15', 'DCC16']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    CONT_CELL_CONVERSION_CMDS = [
        {'command': 'WRCFGA', 'arguments': {'FC': 5}},
        {'command': 'WRCFGB', 'arguments': {'FC': 5}},
        {'command': 'ADCV', 'arguments': {'CONT': True}}
    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSV'}
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'SPINS'},
        {'command': 'RDCVB', 'map_key': 'SPINS'},
        {'command': 'RDCVC', 'map_key': 'SPINS'},
        {'command': 'RDCVD', 'map_key': 'SPINS'},
        {'command': 'RDCVE', 'map_key': 'SPINS'},
        {'command': 'RDCVF', 'map_key': 'SPINS'},
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S1V', 'function': '{C1V}-{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S2V', 'function': '{C2V}-{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S3V', 'function': '{C3V}-{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S4V', 'function': '{C4V}-{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S5V', 'function': '{C5V}-{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S6V', 'function': '{C6V}-{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S7V', 'function': '{C7V}-{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S8V', 'function': '{C8V}-{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S9V', 'function': '{C9V}-{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S10V', 'function': '{C10V}-{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S11V', 'function': '{C11V}-{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S12V', 'function': '{C12V}-{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S13V', 'function': '{C13V}-{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S14V', 'function': '{C14V}-{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S15V', 'function': '{C15V}-{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result': 'S16V', 'function': '{C16V}-{S16V}'}},
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLCADC'}
    ]
    CONT_CELL_ADC_POLL_CMDS = [
        {'command': 'RDSTATC', 'map_key': 'COUNTERS_{}'},
        {'command': '$LOOP_CMD$', 'arguments': {'loop_num': 0x00FF, 'mask': [0x00, 0x00, 0x1F, 0xFC, 0x00, 0x00, 0x00, 0x00], 'counter': 1}}  # RDSTAD with STDR4 (CT) being monitored
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLSADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'}
    ]
    STAT_ADC_POLL_CMDS = [
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
        {'command': 'RDCVC', 'map_key': 'CELLS'},
        {'command': 'RDCVD', 'map_key': 'CELLS'},
        {'command': 'RDCVE', 'map_key': 'CELLS'},
        {'command': 'RDCVF', 'map_key': 'CELLS'},
    ]
    CONT_CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVB', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVC', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVD', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVE', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVF', 'map_key': 'CELLS_{}'},
    ]
    FILTERED_CELL_READ_CMDS = [
        {'command': 'RDFCA', 'map_key': 'FCELLS'},
        {'command': 'RDFCB', 'map_key': 'FCELLS'},
        {'command': 'RDFCC', 'map_key': 'FCELLS'},
        {'command': 'RDFCD', 'map_key': 'FCELLS'},
        {'command': 'RDFCE', 'map_key': 'FCELLS'},
        {'command': 'RDFCF', 'map_key': 'FCELLS'},
    ]
    AVERAGED_CELL_READ_CMDS = [
        {'command': 'RDACA', 'map_key': 'ACELLS'},
        {'command': 'RDACB', 'map_key': 'ACELLS'},
        {'command': 'RDACC', 'map_key': 'ACELLS'},
        {'command': 'RDACD', 'map_key': 'ACELLS'},
        {'command': 'RDACE', 'map_key': 'ACELLS'},
        {'command': 'RDACF', 'map_key': 'ACELLS'},
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
        {'command': 'RDAUXD', 'map_key': 'AUX'},

    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
        {'command': 'RDSTATD', 'map_key': 'STAT'},
        {'command': 'RDSTATE', 'map_key': 'STAT'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]

    BCI_ANALOG_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'CLRFLAG'},
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'ADAX'},
        {'command': 'ADAX2'},
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'},
        {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATD', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED1', 'function': '{G1V}-{R_G1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED2', 'function': '{G2V}-{R_G2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED3', 'function': '{G3V}-{R_G3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED4', 'function': '{G4V}-{R_G4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED5', 'function': '{G5V}-{R_G5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED6', 'function': '{G6V}-{R_G6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED7', 'function': '{G7V}-{R_G7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED8', 'function': '{G8V}-{R_G8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED9', 'function': '{G9V}-{R_G9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'GPIO_RED10', 'function': '{G10V}-{R_G10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_BASE_S16', 'function': '{S16V}'}},
        {'command': 'ADSV', 'arguments': {'OW': 1}},
        {'command': 'PLSADC'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S16', 'function': '{S16V}'}},
        {'command': 'ADSV', 'arguments': {'OW': 2}},
        {'command': 'PLSADC'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S16', 'function': '{S16V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'OPEN1', 'function': '{ODD_S1}/{EVEN_S1}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'OPEN3', 'function': '{ODD_S3}/{EVEN_S3}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'OPEN5', 'function': '{ODD_S5}/{EVEN_S5}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'OPEN7', 'function': '{ODD_S7}/{EVEN_S7}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'OPEN9', 'function': '{ODD_S9}/{EVEN_S9}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN12', 'function': '{ODD_S11}/{EVEN_S11}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN13', 'function': '{ODD_S13}/{EVEN_S13}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN15', 'function': '{ODD_S15}/{EVEN_S15}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN2', 'function': '{EVEN_S2}/{EVEN_BASE_S2}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN4', 'function': '{EVEN_S4}/{EVEN_BASE_S4}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN6', 'function': '{EVEN_S6}/{EVEN_BASE_S6}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN8', 'function': '{EVEN_S8}/{EVEN_BASE_S8}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN10', 'function': '{EVEN_S10}/{EVEN_BASE_S10}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN12', 'function': '{EVEN_S12}/{EVEN_BASE_S12}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN14', 'function': '{EVEN_S14}/{EVEN_BASE_S14}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN16', 'function': '{EVEN_S16}/{EVEN_BASE_S16}'}},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                          'C14V', 'C15V', 'C16V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
                          'S15V', 'S16V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                          'VMV', 'VPV', 'VREF2', 'ITMP', 'VA', 'VD', 'VRES']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'RDCVC', 'map_key': 'GUI'},
        {'command': 'RDCVD', 'map_key': 'GUI'},
        {'command': 'RDCVE', 'map_key': 'GUI'},
        {'command': 'RDCVF', 'map_key': 'GUI'},
        {'command': 'RDSVA', 'map_key': 'GUI'},
        {'command': 'RDSVB', 'map_key': 'GUI'},
        {'command': 'RDSVC', 'map_key': 'GUI'},
        {'command': 'RDSVD', 'map_key': 'GUI'},
        {'command': 'RDSVE', 'map_key': 'GUI'},
        {'command': 'RDSVF', 'map_key': 'GUI'},
        {'command': 'RDACA', 'map_key': 'GUI'},
        {'command': 'RDACB', 'map_key': 'GUI'},
        {'command': 'RDACC', 'map_key': 'GUI'},
        {'command': 'RDACD', 'map_key': 'GUI'},
        {'command': 'RDACE', 'map_key': 'GUI'},
        {'command': 'RDACF', 'map_key': 'GUI'},
        {'command': 'RDFCA', 'map_key': 'GUI'},
        {'command': 'RDFCB', 'map_key': 'GUI'},
        {'command': 'RDFCC', 'map_key': 'GUI'},
        {'command': 'RDFCD', 'map_key': 'GUI'},
        {'command': 'RDFCE', 'map_key': 'GUI'},
        {'command': 'RDFCF', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'RDAUXD', 'map_key': 'GUI'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
        {'command': 'RDSTATD', 'map_key': 'GUI'},
        {'command': 'RDSTATE', 'map_key': 'GUI'},
    ]
    GUI_CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
               'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG', 'DCTO',
               'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12', 'DCC13',
               'DCC14', 'DCC15', 'DCC16']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                   'C14V', 'C15V', 'C16V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V',
                   'S11V', 'S12V', 'S13V', 'S14V','S15V', 'S16V', 'AC1V', 'AC2V', 'AC3V', 'AC4V', 'AC5V', 'AC6V',
                   'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V', 'AC13V', 'AC14V', 'AC15V', 'AC16V', 'FC1V',
                   'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V', 'FC13V',
                   'FC14V', 'FC15V', 'FC16V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                   'VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV',
                   'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
                   'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV',
                   'C16OV', 'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT', 'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT',
                   'CS9FLT', 'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'VA_OV',
                   'VA_UV', 'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT', 'SLEEP',
                   'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS'
                   ]
    SAFETY_COMMAND_LISTS = {
        'SM_AUXREGS_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': False}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATA', 'map_key': 'SM_AUXREGS_DIAG1'},
            {'command': 'RDSTATB', 'map_key': 'SM_AUXREGS_DIAG1'},
            {'command': 'CLRAUX'},
            {'command': 'RDSTATA', 'map_key': 'SM_AUXREGS_DIAG2'},
            {'command': 'RDSTATB', 'map_key': 'SM_AUXREGS_DIAG2'},
        ],
        'SM_CELL_OWD': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x0}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x1}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD3'},
        ],
        'SM_CELL_OWD_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
            }},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'CTH': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': False, 'OW': 0x0}},
            {'command': 'ADSV', 'arguments': {'CONT': True, 'OW': 0x1}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 16}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDACA', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACB', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACD', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACE', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACF', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
            }},
            {'command': 'ADSV', 'arguments': {'CONT': True, 'OW': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 16}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDACA', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACB', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACD', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACE', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACF', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
            }},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x0}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 8}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG3'},
        ],
        'SM_CLOCK_MON': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON'},
        ],
        'SM_CLOCK_MON_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x01}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG1'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x02}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG2'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG2'},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG3'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG3'},
        ],
        'SM_DIETEMP_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADAX', 'arguments': {'CH': 0x13}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATA', 'map_key': 'SM_DIETEMP_OOR'},
        ],
        'SM_FREEZE_SEQ': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': 'ADCV', 'arguments': {'CONT': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'CLRCELL'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
            }},
            {'command': 'RDCVA', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVB', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVC', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVD', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVE', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVF', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'UNSNAP'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 2}},
            {'command': 'RDCVA', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVB', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVC', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVD', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVE', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVF', 'map_key': 'SM_FREEZE_SEQ2'},

        ],
        'SM_IIR_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FC': 1}},
            {'command': 'ADCV', 'arguments': {'CONT': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_IIR_RED'}
        ],
        'SM_NVM_ECC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC'}
        ],
        'SM_NVM_ECC_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x60}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC_DIAG2'},
        ],
        'SM_POWER_MON': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON'}
        ],
        'SM_POWER_MON_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x04}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x0C}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG2'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG3'},
        ],
        'SM_POWER_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'GPO10': True}},
            {'command': 'ADAX'},
            {'command': 'ADAX2', 'arguments': {'CH_AUX2': 0xA}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 20}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATB', 'map_key': 'SM_POWER_OOR'},
            {'command': 'RDAUXD', 'map_key': 'SM_POWER_OOR'},
            {'command': 'RDRAXD', 'map_key': 'SM_POWER_OOR'},
        ],
        'SM_POWER_OOR_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'GPO10': True}},
            {'command': 'ADAX', 'arguments': {'CH': 0xA, 'PUP': True, 'OW_AUX': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXD', 'map_key': 'SM_POWER_OOR_DIAG'},
        ],
        'SM_SLEEP_IND': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDSTATC', 'map_key': 'SM_SLEEP_IND1'},
            {'command': 'CLRFLAG', 'arguments': {'CL_SLEEP': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SLEEP_IND2'},
        ],
        'SM_SPI_CNT': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RSTCC'},
            {'command': 'RDCFGA', 'map_key': 'SM_SPI_CNT1'},
            {'command': 'WRCFGA'},
            {'command': 'RDCFGA', 'map_key': 'SM_SPI_CNT2'},
        ],
        'SM_SPI_PEC_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RSTCC'},
            {'command': 'MUTE'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG1'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3, 'CMD PEC': gen6base.CMD_PEC(pec_size=1)}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG2'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3, 'DATA PEC': gen6base.DATA_PEC(pec_size=1)}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG3'},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_PEC_DIAG4'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x00}},
            {'command': 'UNMUTE'},
        ],
        'SM_SPI_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED'},
        ],
        'SM_SPI_RED_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED_DIAG1', 'arguments': {'ERR': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED_DIAG2', 'arguments': {'ERR': False}},
        ],
        'SM_THSD_IND_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_THSD': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x10}},
            {'command': 'RDSTATC', 'map_key': 'SM_THSD_IND_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_THSD': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_THSD_IND_DIAG2'},
        ],
        'SM_TMOD_IND': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND'},
        ],
        'SM_TMOD_IND_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x80}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND_DIAG2'},
        ],
        'SM_VCELL_CMP_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_CMP_DIAG1'},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_CMP_DIAG2'},

        ],
        'SM_VCELL_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDCVA', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVB', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVC', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVD', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVE', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVF', 'map_key': 'SM_VCELL_OOR'},
        ],
        'SM_VCELL_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
            }},
            {'command': 'WRCFGA', 'arguments': {'CTH': 0x2}},
            {'command': 'ADCV', 'arguments': {'CONT': False, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_RED'},
        ],
        'SM_VGPIO_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {
                'GPO1': True,
                'GPO2': True,
                'GPO3': True,
                'GPO4': True,
                'GPO5': True,
                'GPO6': True,
                'GPO7': True,
                'GPO8': True,
                'GPO9': True,
                'GPO10': True,
                'REFON': True
            }},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 25}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXA', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXB', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXC', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXD', 'map_key': 'SM_VGPIO_OOR'}
        ],
        'SM_VGPIO_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {
                'GPO1': True,
                'GPO2': True,
                'GPO3': True,
                'GPO4': True,
                'GPO5': True,
                'GPO6': True,
                'GPO7': True,
                'GPO8': True,
                'GPO9': True,
                'GPO10': True,
                'REFON': True
            }},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 15}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': 'ADAX2'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 25}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXA', 'map_key': 'SM_VGPIO_RED'},
            {'command': 'RDRAXA', 'map_key': 'SM_VGPIO_RED'},
        ],
        'SM_VREF2_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 20}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATB', 'map_key': 'SM_VREF2_OOR'},
        ],
    }
    LIMITS = {
        'Verification': {},
        'Safety': {
            'CELL_OPEN_WIRE_THRESHOLD': {
                'value': 0.85,
            },
            'CELL_OPEN_WIRE_DIAG_THRESHOLD': {
                'value': 0.95,
            },
            'AUX_OPEN_WIRE_THRESHOLD': {
                'value': 0.600,
            },
            'OSCCHK_OCCNTR': {
                'min': 52,
                'max': 70
            },
            'ITMP': {
                'max': 125
            },
            'VA': {
                'max': 5.486,
                'min': 4.512
            },
            'VD': {
                'max': 3.528,
                'min': 2.754
            },
            'VRES': {
                'max': 3.012,
                'min': 2.988
            },
            'G1V': {
                'max': 2.9,
                'min': 0.1
            },
            'G2V': {
                'max': 2.9,
                'min': 0.1
            },
            'G3V': {
                'max': 2.9,
                'min': 0.1
            },
            'G4V': {
                'max': 2.9,
                'min': 0.1
            },
            'G5V': {
                'max': 2.9,
                'min': 0.1
            },
            'G6V': {
                'max': 2.9,
                'min': 0.1
            },
            'G7V': {
                'max': 2.9,
                'min': 0.1
            },
            'G8V': {
                'max': 2.9,
                'min': 0.1
            },
            'G9V': {
                'max': 2.9,
                'min': 0.1
            },
            'G10V': {
                'max': 0.005,
                'min': -0.005
            },
            'G10V_OOR_DIAG': {
                'max': 0.5,
                'min': 0.05
            },
            'R_G10V': {
                'max': 0.005,
                'min': -0.005
            },
            'C1V': {
                'min': 0.1,
                'max': 4.5
            },
            'C2V': {
                'min': 0.1,
                'max': 4.5
            },
            'C3V': {
                'min': 0.1,
                'max': 4.5
            },
            'C4V': {
                'min': 0.1,
                'max': 4.5
            },
            'C5V': {
                'min': 0.1,
                'max': 4.5
            },
            'C6V': {
                'min': 0.1,
                'max': 4.5
            },
            'C7V': {
                'min': 0.1,
                'max': 4.5
            },
            'C8V': {
                'min': 0.1,
                'max': 4.5
            },
            'C9V': {
                'min': 0.1,
                'max': 4.5
            },
            'C10V': {
                'min': 0.1,
                'max': 4.5
            },
            'C11V': {
                'min': 0.1,
                'max': 4.5
            },
            'C12V': {
                'min': 0.1,
                'max': 4.5
            },
            'C13V': {
                'min': 0.1,
                'max': 4.5
            },
            'C14V': {
                'min': 0.1,
                'max': 4.5
            },
            'C15V': {
                'min': 0.1,
                'max': 4.5
            },
            'C16V': {
                'min': 0.1,
                'max': 4.5
            },
            'GPIO_RED_THRESHOLD': {
                'max': 0.01
            }
        },
        'Manufacturing': {},
        'Loose': {}
    }
    C_CODE_EXPORT = {
        'measure_cells': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'WRCFGA'},
                {'command': 'ADCV'},
                {'command': 'PLCADC'},
                {'command': 'RDCVA'},
                {'command': 'RDCVB'},
                {'command': 'RDCVC'},
                {'command': 'RDCVD'},
                {'command': 'RDCVE'},
                {'command': 'RDCVF'},
            ],
            'output': ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V', 'C14V', 'C15V', 'C16V']
        },
        'write_read_config': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'WRCFGA'},
                {'command': 'RDCFGA'},
            ],
            'output': ['REFON', 'FC', 'CCNT']
        },
        'lpcm': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'CMHB'},
                {'command': 'RDCFGA'},
            ],
            'output': ['REFON', 'FC', 'CCNT']
        },
        'start_adcs': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}}
            ],
        },
        'read_data': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'RDCVALL'},
            ],
        },
        'print_data': {
            'output': ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                       'C14V', 'C15V', 'C16V', 'pec_error']
        },

    }

    @staticmethod
    def decode_safety_loop(result_dict, ic_num, safety_metric=None, limit_override=None):
        limits = deepcopy(ADBMS6830.LIMITS['Safety'])
        if limit_override:
            limits.update(limit_override)
        global_status = ADBMS6830.PASS
        safety_results = {}
        if 'Safety_Results' not in result_dict:
            result_dict['Safety_Results'] = []
        if safety_metric and safety_metric in ADBMS6830.SAFETY_COMMAND_LISTS:
            safety_results[safety_metric] = {'Result': None}
            safety_results[safety_metric]['Error Messages'] = []
            try:
                for map_key in result_dict:
                    if map_key in ['Total_PEC_Status', 'All', 'Safety_Results']:
                        continue
                    if map_key.endswith('_RAW'):
                        continue
                    if not result_dict[map_key][ic_num]['Total_PEC_Status']:
                        safety_results[safety_metric]['Error Messages'].append('PEC Error Detected')
            except:
                pass
            if safety_metric == 'SM_AUXREGS_DIAG':
                for item in ['ITMP', 'VA', 'VD', 'VRES']:
                    if result_dict['SM_AUXREGS_DIAG1_RAW'][ic_num][item] != 0x7FFF:
                        safety_results[safety_metric]['Error Messages'].append('%s incorrect POR reset value' % item)
                    if result_dict['SM_AUXREGS_DIAG2_RAW'][ic_num][item] != 0x8000:
                        safety_results[safety_metric]['Error Messages'].append('%s incorrect CLRAUX value' % item)             
            elif safety_metric == 'SM_CELL_OWD':
                safety_results[safety_metric]['Opens'] = []
                safety_results[safety_metric]['Delta'] = []
                i = 0
                #  Gather open wire measurements into one array
                open_data = {}
                base_data = {}
                for spin in ['S2V', 'S4V', 'S6V', 'S8V', 'S10V', 'S12V', 'S14V', 'S16V']:
                    open_data[spin] = result_dict['SM_CELL_OWD2'][ic_num][spin]
                    base_data[spin] = result_dict['SM_CELL_OWD1'][ic_num][spin]
                for spin in ['S1V', 'S3V', 'S5V', 'S7V', 'S9V', 'S11V', 'S13V', 'S15V']:
                    open_data[spin] = result_dict['SM_CELL_OWD3'][ic_num][spin]
                    base_data[spin] = result_dict['SM_CELL_OWD2'][ic_num][spin]
                while i < len(ADBMS6830.SPINS):
                    spin = ADBMS6830.SPINS[i]
                    if i == 0:
                        safety_results[safety_metric]['Delta'].append(open_data[spin])  # Once for C0, once for C1
                        if open_data[spin] < 0.010:
                            safety_results[safety_metric]['Opens'].append('S0V')
                            safety_results[safety_metric]['Error Messages'].append(
                                'S0V open detected. S1V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[safety_metric]['Delta'].append(
                                (open_data[spin] / base_data[spin]) * 100)  # Once for C0, once for C1
                            i += 1
                            continue
                    if i == 15:
                        if open_data[spin] < 0.010:
                            safety_results[safety_metric]['Opens'].append('S16V')
                            safety_results[safety_metric]['Error Messages'].append(
                                'S16V open detected. S16V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[safety_metric]['Delta'].append(open_data[spin])
                            i += 1
                            continue
                    safety_results[safety_metric]['Delta'].append((open_data[spin] / base_data[spin]) * 100)
                    if base_data[spin] < 0:
                        if abs(open_data[spin]) < abs(base_data[spin]) * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                            safety_results[safety_metric]['Opens'].append(spin)
                            safety_results[safety_metric]['Error Messages'].append(
                                '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                                    spin, spin, open_data[spin], base_data[spin],
                                    limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                            if i < 15:
                                safety_results[safety_metric]['Delta'].append(
                                    (open_data[ADBMS6830.SPINS[i]] / base_data[ADBMS6830.SPINS[i]]) * 100)
                            i += 1
                    elif open_data[spin] < base_data[spin] * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                        safety_results[safety_metric]['Opens'].append(spin)
                        safety_results[safety_metric]['Error Messages'].append(
                            '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                            spin, spin, open_data[spin], base_data[spin], limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                        if i < 15:
                            safety_results[safety_metric]['Delta'].append(
                                (open_data[ADBMS6830.SPINS[i]] / base_data[ADBMS6830.SPINS[i]]) * 100)
                        i += 1

                    i += 1
                if len(safety_results[safety_metric]['Error Messages']) != 0:
                    safety_results[safety_metric]['Result'] = ADBMS6830.FAIL
                    global_status = ADBMS6830.FAIL
                else:
                    safety_results[safety_metric]['Result'] = ADBMS6830.PASS
            elif safety_metric == 'SM_CELL_OWD_DIAG':
                for i in range(len(ADBMS6830.SPINS)):
                    if i % 2:
                        # Evens
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['S%sV'%str(i+1)]/result_dict['SM_CELL_OWD_DIAG1'][ic_num]['AC%sV'%str(i+1)] > limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[safety_metric]['Error Messages'].append('S%s open wire switch not active' % str(i+1))
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['S%sV'%str(i+1)]/result_dict['SM_CELL_OWD_DIAG2'][ic_num]['AC%sV'%str(i+1)] < limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[safety_metric]['Error Messages'].append('S%s open wire switch incorrectly enabled' % str(i+1))
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['CS%sFLT' % str(i+1)]:
                            safety_results[safety_metric]['Error Messages'].append('S%s comparison flag incorrectly set' % str(i + 1))
                        if not result_dict['SM_CELL_OWD_DIAG1'][ic_num]['CS%sFLT' % str(i+1)]:
                            safety_results[safety_metric]['Error Messages'].append('S%s comparison flag not set' % str(i + 1))
                    else:
                        # Evens
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['S%sV' % str(i + 1)] / result_dict['SM_CELL_OWD_DIAG2'][ic_num]['AC%sV' % str(i + 1)] > limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[safety_metric]['Error Messages'].append('S%s open wire switch not active' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['S%sV' % str(i + 1)] / result_dict['SM_CELL_OWD_DIAG1'][ic_num]['AC%sV' % str(i + 1)] < limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[safety_metric]['Error Messages'].append('S%s open wire switch incorrectly enabled' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[safety_metric]['Error Messages'].append('S%s comparison flag incorrectly set' % str(i + 1))
                        if not result_dict['SM_CELL_OWD_DIAG2'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[safety_metric]['Error Messages'].append('S%s comparison flag not set' % str(i + 1))
                    if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['CS%sFLT' % str(i + 1)]:
                        safety_results[safety_metric]['Error Messages'].append('S%s comparison fault with switches disabled' % str(i + 1))
                if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['COMP']:
                    safety_results[safety_metric]['Error Messages'].append('COMP bit set with comparison disabled')
                if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
            elif safety_metric == 'SM_CLOCK_MON':
                if result_dict['SM_CLOCK_MON'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check failed')
            elif safety_metric == 'SM_CLOCK_MON_DIAG':
                if not result_dict['SM_CLOCK_MON_DIAG1'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check fast failed to set flag')
                if result_dict['SM_CLOCK_MON_DIAG1'][ic_num]['OC_CNTR'] <= limits['OSCCHK_OCCNTR']['max']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check fast counter too low')
                if not result_dict['SM_CLOCK_MON_DIAG2'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check slow failed to set flag')
                if result_dict['SM_CLOCK_MON_DIAG2'][ic_num]['OC_CNTR'] >= limits['OSCCHK_OCCNTR']['min']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check slow counter too high')
                if result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OSCCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check failed')
                if result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OC_CNTR'] < limits['OSCCHK_OCCNTR']['min'] or result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OC_CNTR'] > limits['OSCCHK_OCCNTR']['max']:
                    safety_results[safety_metric]['Error Messages'].append('Oscillator check counter out of range')
            elif safety_metric == 'SM_DIETEMP_OOR':
                if result_dict['SM_DIETEMP_OOR'][ic_num]['ITMP'] > limits['ITMP']['max']:
                    safety_results[safety_metric]['Error Messages'].append('Die temperature too high')
            elif safety_metric == 'SM_FREEZE_SEQ':
                for cell in ADBMS6830.CELLS:
                    if result_dict['SM_FREEZE_SEQ1_RAW'][ic_num][cell] != 0x8000:
                        safety_results[safety_metric]['Error Messages'].append('CLRCELL did not reset register')
                    if result_dict['SM_FREEZE_SEQ2_RAW'][ic_num][cell] == 0x8000:
                        safety_results[safety_metric]['Error Messages'].append('CVARx register did not update')
            elif safety_metric == 'SM_IIR_RED':
                if result_dict['SM_IIR_RED'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('IIR match failure')
            elif safety_metric == 'SM_NVM_ECC':
                if result_dict['SM_NVM_ECC'][ic_num]['CMED'] or result_dict['SM_NVM_ECC'][ic_num]['SMED']:
                    safety_results[safety_metric]['Error Messages'].append('NVM multiple errors detected')
            elif safety_metric == 'SM_NVM_ECC_DIAG':
                if not result_dict['SM_NVM_ECC_DIAG1'][ic_num]['CMED'] or not result_dict['SM_NVM_ECC_DIAG1'][ic_num]['SMED']:
                    safety_results[safety_metric]['Error Messages'].append('NVM multiple errors latch did not set')
                if result_dict['SM_NVM_ECC_DIAG2'][ic_num]['CMED'] or result_dict['SM_NVM_ECC_DIAG2'][ic_num]['SMED']:
                    safety_results[safety_metric]['Error Messages'].append('NVM multiple errors latch did not clear')
            elif safety_metric == 'SM_POWER_MON':
                for item in ['VA_OV', 'VA_UV', 'VD_OV', 'VD_UV', 'VDE']:
                    if result_dict['SM_POWER_MON'][ic_num][item]:
                        safety_results[safety_metric]['Error Messages'].append('%s power domain fault' % item)
            elif safety_metric == 'SM_POWER_MON_DIAG':
                for item in ['VA_UV', 'VD_UV']:
                    if not result_dict['SM_POWER_MON_DIAG1'][ic_num][item]:
                        safety_results[safety_metric]['Error Messages'].append('%s power domain fault did not set' % item)
                for item in ['VA_OV', 'VD_OV']:
                    if not result_dict['SM_POWER_MON_DIAG2'][ic_num][item]:
                        safety_results[safety_metric]['Error Messages'].append('%s power domain fault did not set' % item)
                for item in ['VA_OV', 'VA_UV', 'VD_OV', 'VD_UV', 'VDE']:
                    if result_dict['SM_POWER_MON_DIAG3'][ic_num][item]:
                        safety_results[safety_metric]['Error Messages'].append('%s power domain fault did not clear' % item)
            elif safety_metric == 'SM_POWER_OOR':
                for item in ['VA', 'VD', 'G10V', 'R_G10V']:
                    if result_dict['SM_POWER_OOR'][ic_num][item] < limits[item]['min'] or result_dict['SM_POWER_OOR'][ic_num][item] > limits[item]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % (item, result_dict['SM_POWER_OOR'][ic_num][item],  limits[item]['min'], limits[item]['max']))
            elif safety_metric == 'SM_POWER_OOR_DIAG':
                if result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'] < limits['G10V_OOR_DIAG']['min'] or result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'] > limits['G10V_OOR_DIAG']['max']:
                    safety_results[safety_metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % ('G10V', result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'], limits['G10V_OOR_DIAG']['min'], limits['G10V_OOR_DIAG']['max']))
            elif safety_metric == 'SM_SLEEP_IND':
                if not result_dict['SM_SLEEP_IND1'][ic_num]['SLEEP']:
                    safety_results[safety_metric]['Error Messages'].append('SLEEP bit did not set on reset')
                if result_dict['SM_SLEEP_IND2'][ic_num]['SLEEP']:
                    safety_results[safety_metric]['Error Messages'].append('SLEEP bit did not clear')
            elif safety_metric == 'SM_SPI_CNT':
                if result_dict['SM_SPI_CNT1'][ic_num]['CCNT']:
                    safety_results[safety_metric]['Error Messages'].append('CCNT did not reset')
                if result_dict['SM_SPI_CNT2'][ic_num]['CCNT'] != 1:
                    safety_results[safety_metric]['Error Messages'].append('CCNT did not increment')
            elif safety_metric == 'SM_SPI_PEC_DIAG':
                safety_results[safety_metric]['Error Messages'] = []
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT did not increment')
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['PWM1'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value did not latch')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['PWM1'] != 0x3:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['CCNT'] != 0x2:
                    safety_results[safety_metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['PWM1'] != 0x00:
                    safety_results[safety_metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG4'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
            elif safety_metric == 'SM_SPI_RED':
                if result_dict['SM_SPI_RED'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
            elif safety_metric == 'SM_SPI_RED_DIAG':
                if not result_dict['SM_SPI_RED_DIAG1'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected latch did not set')
                if result_dict['SM_SPI_RED_DIAG2'][ic_num]['SPIFLT']:
                    safety_results[safety_metric]['Error Messages'].append('SPI fault detected')
            elif safety_metric == 'SM_THSD_IND_DIAG':
                if not result_dict['SM_THSD_IND_DIAG1'][ic_num]['THSD']:
                    safety_results[safety_metric]['Error Messages'].append('Temperature shutdown latch did not set')
                if result_dict['SM_THSD_IND_DIAG2'][ic_num]['THSD']:
                    safety_results[safety_metric]['Error Messages'].append('Temperature shutdown detected')
            elif safety_metric == 'SM_TMOD_IND':
                if result_dict['SM_TMOD_IND'][ic_num]['TMODCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Test mode fault detected')
            elif safety_metric == 'SM_TMOD_IND_DIAG':
                if not result_dict['SM_TMOD_IND_DIAG1'][ic_num]['TMODCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Test mode activation latch did not set')
                if result_dict['SM_TMOD_IND_DIAG2'][ic_num]['TMODCHK']:
                    safety_results[safety_metric]['Error Messages'].append('Test mode fault detected')
            elif safety_metric == 'SM_VCELL_CMP_DIAG':
                if not result_dict['SM_VCELL_CMP_DIAG1'][ic_num]['COMP']:
                    safety_results[safety_metric]['Error Messages'].append('COMP bit not set')
                if result_dict['SM_VCELL_CMP_DIAG2'][ic_num]['COMP']:
                    safety_results[safety_metric]['Error Messages'].append('COMP bit set when comparison not enabled')
            elif safety_metric == 'SM_VCELL_OOR':
                for cell in ADBMS6830.CELLS:
                    if result_dict['SM_VCELL_OOR'][ic_num][cell] < limits[cell]['min'] or result_dict['SM_VCELL_OOR'][ic_num][cell] > limits[cell]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is %s out of spec [%s, %s]' % (cell, result_dict['SM_VCELL_OOR'][ic_num][cell], limits[cell]['min'], limits[cell]['max'] ))
            elif safety_metric == 'SM_VCELL_RED':
                for i in range(len(ADBMS6830.CELLS)):
                    if result_dict['SM_VCELL_RED'][ic_num]['CS%sFLT' % str(i+1)]:
                        safety_results[safety_metric]['Error Messages'].append('C%s-S%s comparison is out of range' % (str(i+1), str(i+1)))
            elif safety_metric == 'SM_VGPIO_OOR':
                for gpio in ADBMS6830.GPIOS:
                    if result_dict['SM_VGPIO_OOR'][ic_num][gpio] < limits[gpio]['min'] or result_dict['SM_VGPIO_OOR'][ic_num][gpio] > limits[gpio]['max']:
                        safety_results[safety_metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % (gpio, result_dict['SM_VGPIO_OOR'][ic_num][gpio], limits[gpio]['min'], limits[gpio]['max']))
            elif safety_metric == 'SM_VGPIO_RED':
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G1V']) > limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[safety_metric]['Error Messages'].append('G1V - R_G1V is %s out of spec %s' % (
                    str(abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V'])), limits['GPIO_RED_THRESHOLD']['max']))
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G3V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V']) > limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[safety_metric]['Error Messages'].append('G3V - R_G3V is %s out of spec %s' % (
                    str(abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['G3V'])), limits['GPIO_RED_THRESHOLD']['max']))
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['G3V']) > limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[safety_metric]['Error Messages'].append('G1V - G3V is %s out of spec %s' % (
                    str(abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V'])), limits['GPIO_RED_THRESHOLD']['max']))
            elif safety_metric == 'SM_VREF2_OOR':
                if result_dict['SM_VREF2_OOR'][ic_num]['VRES'] < limits['VRES']['min'] or result_dict['SM_VREF2_OOR'][ic_num]['VRES'] > limits['VRES']['max']:
                    safety_results[safety_metric]['Error Messages'].append('VRES is %s out of range [%s, %s]' % (result_dict['SM_VREF2_OOR'][ic_num]['VRES'], limits['VRES']['min'], limits['VRES']['max']))
            if len(safety_results[safety_metric]['Error Messages']) != 0:
                safety_results[safety_metric]['Result'] = ADBMS6830.FAIL
                global_status = ADBMS6830.FAIL
            else:
                safety_results[safety_metric]['Result'] = ADBMS6830.PASS
        if len(result_dict['Safety_Results']) <= ic_num:
            result_dict['Safety_Results'].append(safety_results)
        else:
            result_dict['Safety_Results'][ic_num].update(safety_results)
        return global_status
