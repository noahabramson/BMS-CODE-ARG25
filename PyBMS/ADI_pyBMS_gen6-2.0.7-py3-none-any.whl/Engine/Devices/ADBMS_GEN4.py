# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from abc import ABC
import Engine.Devices.BMS_Config as bmsbase

# ===================================================== Bitfields =====================================================
class ADCOPT(bmsbase.BitfieldBool):
    NAME = 'ADCOPT'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(ADCOPT, self).__init__(ADCOPT.LENGTH,  value=value, raw_value=raw_value)
        self.name = ADCOPT.NAME


class ADDR(bmsbase.BitfieldInt):
    NAME = 'ADDR'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ADDR, self).__init__(ADDR.LENGTH,  value=value, raw_value=raw_value)
        self.name = ADDR.NAME


class C10OV(bmsbase.BitfieldBool):
    NAME = 'C10OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10OV, self).__init__(C10OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10OV.NAME


class C10UV(bmsbase.BitfieldBool):
    NAME = 'C10UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10UV, self).__init__(C10UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10UV.NAME


class C10V(bmsbase.BitfieldAdc):
    NAME = 'C10V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C10V, self).__init__(C10V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C10V.NAME


class C11OV(bmsbase.BitfieldBool):
    NAME = 'C11OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11OV, self).__init__(C11OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11OV.NAME


class C11UV(bmsbase.BitfieldBool):
    NAME = 'C11UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11UV, self).__init__(C11UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11UV.NAME


class C11V(bmsbase.BitfieldAdc):
    NAME = 'C11V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C11V, self).__init__(C11V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C11V.NAME


class C12OV(bmsbase.BitfieldBool):
    NAME = 'C12OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12OV, self).__init__(C12OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12OV.NAME


class C12UV(bmsbase.BitfieldBool):
    NAME = 'C12UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12UV, self).__init__(C12UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12UV.NAME


class C12V(bmsbase.BitfieldAdc):
    NAME = 'C12V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C12V, self).__init__(C12V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C12V.NAME


class C13OV(bmsbase.BitfieldBool):
    NAME = 'C13OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C13OV, self).__init__(C13OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C13OV.NAME


class C13UV(bmsbase.BitfieldBool):
    NAME = 'C13UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C13UV, self).__init__(C13UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C13UV.NAME


class C13V(bmsbase.BitfieldAdc):
    NAME = 'C13V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C13V, self).__init__(C13V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C13V.NAME


class C14OV(bmsbase.BitfieldBool):
    NAME = 'C14OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C14OV, self).__init__(C14OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C14OV.NAME


class C14UV(bmsbase.BitfieldBool):
    NAME = 'C14UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C14UV, self).__init__(C14UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C14UV.NAME


class C14V(bmsbase.BitfieldAdc):
    NAME = 'C14V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C14V, self).__init__(C14V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C14V.NAME


class C15OV(bmsbase.BitfieldBool):
    NAME = 'C15OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C15OV, self).__init__(C15OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C15OV.NAME


class C15UV(bmsbase.BitfieldBool):
    NAME = 'C15UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C15UV, self).__init__(C15UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C15UV.NAME


class C15V(bmsbase.BitfieldAdc):
    NAME = 'C15V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C15V, self).__init__(C15V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C15V.NAME


class C16OV(bmsbase.BitfieldBool):
    NAME = 'C16OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C16OV, self).__init__(C16OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C16OV.NAME


class C16UV(bmsbase.BitfieldBool):
    NAME = 'C16UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C16UV, self).__init__(C16UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C16UV.NAME


class C16V(bmsbase.BitfieldAdc):
    NAME = 'C16V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C16V, self).__init__(C16V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C16V.NAME


class C17OV(bmsbase.BitfieldBool):
    NAME = 'C17OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C17OV, self).__init__(C17OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C17OV.NAME


class C17UV(bmsbase.BitfieldBool):
    NAME = 'C17UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C17UV, self).__init__(C17UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C17UV.NAME


class C17V(bmsbase.BitfieldAdc):
    NAME = 'C17V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C17V, self).__init__(C17V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C17V.NAME


class C18OV(bmsbase.BitfieldBool):
    NAME = 'C18OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C18OV, self).__init__(C18OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C18OV.NAME


class C18UV(bmsbase.BitfieldBool):
    NAME = 'C18UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C18UV, self).__init__(C18UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C18UV.NAME


class C18V(bmsbase.BitfieldAdc):
    NAME = 'C18V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C18V, self).__init__(C18V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C18V.NAME


class C1OV(bmsbase.BitfieldBool):
    NAME = 'C1OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1OV, self).__init__(C1OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1OV.NAME


class C1UV(bmsbase.BitfieldBool):
    NAME = 'C1UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1UV, self).__init__(C1UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1UV.NAME


class C1V(bmsbase.BitfieldAdc):
    NAME = 'C1V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C1V, self).__init__(C1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C1V.NAME


class C2OV(bmsbase.BitfieldBool):
    NAME = 'C2OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2OV, self).__init__(C2OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2OV.NAME


class C2UV(bmsbase.BitfieldBool):
    NAME = 'C2UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2UV, self).__init__(C2UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2UV.NAME


class C2V(bmsbase.BitfieldAdc):
    NAME = 'C2V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C2V, self).__init__(C2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C2V.NAME


class C3OV(bmsbase.BitfieldBool):
    NAME = 'C3OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3OV, self).__init__(C3OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3OV.NAME


class C3UV(bmsbase.BitfieldBool):
    NAME = 'C3UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3UV, self).__init__(C3UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3UV.NAME


class C3V(bmsbase.BitfieldAdc):
    NAME = 'C3V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C3V, self).__init__(C3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C3V.NAME


class C4OV(bmsbase.BitfieldBool):
    NAME = 'C4OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4OV, self).__init__(C4OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4OV.NAME


class C4UV(bmsbase.BitfieldBool):
    NAME = 'C4UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4UV, self).__init__(C4UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4UV.NAME


class C4V(bmsbase.BitfieldAdc):
    NAME = 'C4V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C4V, self).__init__(C4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C4V.NAME


class C5OV(bmsbase.BitfieldBool):
    NAME = 'C5OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5OV, self).__init__(C5OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5OV.NAME


class C5UV(bmsbase.BitfieldBool):
    NAME = 'C5UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5UV, self).__init__(C5UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5UV.NAME


class C5V(bmsbase.BitfieldAdc):
    NAME = 'C5V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C5V, self).__init__(C5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C5V.NAME


class C6OV(bmsbase.BitfieldBool):
    NAME = 'C6OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6OV, self).__init__(C6OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6OV.NAME


class C6UV(bmsbase.BitfieldBool):
    NAME = 'C6UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6UV, self).__init__(C6UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6UV.NAME


class C6V(bmsbase.BitfieldAdc):
    NAME = 'C6V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C6V, self).__init__(C6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C6V.NAME


class C7OV(bmsbase.BitfieldBool):
    NAME = 'C7OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7OV, self).__init__(C7OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7OV.NAME


class C7UV(bmsbase.BitfieldBool):
    NAME = 'C7UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7UV, self).__init__(C7UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7UV.NAME


class C7V(bmsbase.BitfieldAdc):
    NAME = 'C7V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C7V, self).__init__(C7V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C7V.NAME


class C8OV(bmsbase.BitfieldBool):
    NAME = 'C8OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8OV, self).__init__(C8OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8OV.NAME


class C8UV(bmsbase.BitfieldBool):
    NAME = 'C8UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8UV, self).__init__(C8UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8UV.NAME


class C8V(bmsbase.BitfieldAdc):
    NAME = 'C8V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C8V, self).__init__(C8V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C8V.NAME


class C9OV(bmsbase.BitfieldBool):
    NAME = 'C9OV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9OV, self).__init__(C9OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9OV.NAME


class C9UV(bmsbase.BitfieldBool):
    NAME = 'C9UV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9UV, self).__init__(C9UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9UV.NAME


class C9V(bmsbase.BitfieldAdc):
    NAME = 'C9V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C9V, self).__init__(C9V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = C9V.NAME


class CH(bmsbase.BitfieldInt):
    NAME = 'CH'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CH, self).__init__(CH.LENGTH,  value=value, raw_value=raw_value)
        self.name = CH.NAME


class CHG(bmsbase.BitfieldInt):
    NAME = 'CHG'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CHG, self).__init__(CHG.LENGTH,  value=value, raw_value=raw_value)
        self.name = CHG.NAME


class CHST(bmsbase.BitfieldInt):
    NAME = 'CHST'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CHST, self).__init__(CHST.LENGTH,  value=value, raw_value=raw_value)
        self.name = CHST.NAME


class CMD0(bmsbase.BitfieldInt):
    NAME = 'CMD0'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD0, self).__init__(CMD0.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMD0.NAME


class CMD1(bmsbase.BitfieldInt):
    NAME = 'CMD1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD1, self).__init__(CMD1.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMD1.NAME


class CMD_PEC(bmsbase.BitfieldPEC):
    NAME = 'CMD PEC'
    DESCRIPTION = 'Command PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=16):
        super(CMD_PEC, self).__init__(CMD_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = CMD_PEC.NAME
        self.crc_cal_func = self.calc_pec15


class D0(bmsbase.BitfieldInt):
    NAME = 'D0'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D0, self).__init__(D0.LENGTH,  value=value, raw_value=raw_value)
        self.name = D0.NAME


class D1(bmsbase.BitfieldInt):
    NAME = 'D1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D1, self).__init__(D1.LENGTH,  value=value, raw_value=raw_value)
        self.name = D1.NAME


class D2(bmsbase.BitfieldInt):
    NAME = 'D2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D2, self).__init__(D2.LENGTH,  value=value, raw_value=raw_value)
        self.name = D2.NAME


class DATA_PEC(bmsbase.BitfieldPEC):
    NAME = 'DATA_PEC'
    DESCRIPTION = 'Data PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=48):
        super(DATA_PEC, self).__init__(DATA_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = DATA_PEC.NAME
        self.crc_cal_func = self.calc_pec15


class DCC0(bmsbase.BitfieldBool):
    NAME = 'DCC0'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC0, self).__init__(DCC0.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC0.NAME


class DCC1(bmsbase.BitfieldBool):
    NAME = 'DCC1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC1, self).__init__(DCC1.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC1.NAME


class DCC10(bmsbase.BitfieldBool):
    NAME = 'DCC10'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC10, self).__init__(DCC10.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC10.NAME


class DCC11(bmsbase.BitfieldBool):
    NAME = 'DCC11'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC11, self).__init__(DCC11.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC11.NAME


class DCC12(bmsbase.BitfieldBool):
    NAME = 'DCC12'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC12, self).__init__(DCC12.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC12.NAME


class DCC13(bmsbase.BitfieldBool):
    NAME = 'DCC13'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC13, self).__init__(DCC13.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC13.NAME


class DCC14(bmsbase.BitfieldBool):
    NAME = 'DCC14'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC14, self).__init__(DCC14.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC14.NAME


class DCC15(bmsbase.BitfieldBool):
    NAME = 'DCC15'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC15, self).__init__(DCC15.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC15.NAME


class DCC16(bmsbase.BitfieldBool):
    NAME = 'DCC16'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC16, self).__init__(DCC16.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC16.NAME


class DCC17(bmsbase.BitfieldBool):
    NAME = 'DCC17'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC17, self).__init__(DCC17.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC17.NAME


class DCC18(bmsbase.BitfieldBool):
    NAME = 'DCC18'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC18, self).__init__(DCC18.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC18.NAME


class DCC2(bmsbase.BitfieldBool):
    NAME = 'DCC2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC2, self).__init__(DCC2.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC2.NAME


class DCC3(bmsbase.BitfieldBool):
    NAME = 'DCC3'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC3, self).__init__(DCC3.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC3.NAME


class DCC4(bmsbase.BitfieldBool):
    NAME = 'DCC4'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC4, self).__init__(DCC4.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC4.NAME


class DCC5(bmsbase.BitfieldBool):
    NAME = 'DCC5'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC5, self).__init__(DCC5.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC5.NAME


class DCC6(bmsbase.BitfieldBool):
    NAME = 'DCC6'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC6, self).__init__(DCC6.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC6.NAME


class DCC7(bmsbase.BitfieldBool):
    NAME = 'DCC7'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC7, self).__init__(DCC7.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC7.NAME


class DCC8(bmsbase.BitfieldBool):
    NAME = 'DCC8'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC8, self).__init__(DCC8.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC8.NAME


class DCC9(bmsbase.BitfieldBool):
    NAME = 'DCC9'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC9, self).__init__(DCC9.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC9.NAME


class DCP(bmsbase.BitfieldBool):
    NAME = 'DCP'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCP, self).__init__(DCP.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCP.NAME


class DCTO(bmsbase.BitfieldInt):
    NAME = 'DCTO'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DCTO, self).__init__(DCTO.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCTO.NAME


class DIS_RED(bmsbase.BitfieldBool):
    NAME = 'DIS_RED'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DIS_RED, self).__init__(DIS_RED.LENGTH,  value=value, raw_value=raw_value)
        self.name = DIS_RED.NAME


class DTEN(bmsbase.BitfieldBool):
    NAME = 'DTEN'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTEN, self).__init__(DTEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTEN.NAME


class DTMEN(bmsbase.BitfieldBool):
    NAME = 'DTMEN'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTMEN, self).__init__(DTMEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTMEN.NAME


class EN_DTMEN(bmsbase.BitfieldBool):
    NAME = 'EN_DTMEN'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(EN_DTMEN, self).__init__(EN_DTMEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = EN_DTMEN.NAME


class FCOM0(bmsbase.BitfieldInt):
    NAME = 'FCOM0'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM0, self).__init__(FCOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM0.NAME


class FCOM1(bmsbase.BitfieldInt):
    NAME = 'FCOM1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM1, self).__init__(FCOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM1.NAME


class FCOM2(bmsbase.BitfieldInt):
    NAME = 'FCOM2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM2, self).__init__(FCOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM2.NAME


class FDRF(bmsbase.BitfieldBool):
    NAME = 'FDRF'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(FDRF, self).__init__(FDRF.LENGTH,  value=value, raw_value=raw_value)
        self.name = FDRF.NAME


class G1V(bmsbase.BitfieldAdc):
    NAME = 'G1V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G1V, self).__init__(G1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G1V.NAME


class G2V(bmsbase.BitfieldAdc):
    NAME = 'G2V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G2V, self).__init__(G2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G2V.NAME


class G3V(bmsbase.BitfieldAdc):
    NAME = 'G3V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G3V, self).__init__(G3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G3V.NAME


class G4V(bmsbase.BitfieldAdc):
    NAME = 'G4V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G4V, self).__init__(G4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G4V.NAME


class G5V(bmsbase.BitfieldAdc):
    NAME = 'G5V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G5V, self).__init__(G5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G5V.NAME


class G6V(bmsbase.BitfieldAdc):
    NAME = 'G6V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G6V, self).__init__(G6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G6V.NAME


class G7V(bmsbase.BitfieldAdc):
    NAME = 'G7V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G7V, self).__init__(G7V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G7V.NAME


class G8V(bmsbase.BitfieldAdc):
    NAME = 'G8V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G8V, self).__init__(G8V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G8V.NAME


class G9V(bmsbase.BitfieldAdc):
    NAME = 'G9V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G9V, self).__init__(G9V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = G9V.NAME


class GPIO1(bmsbase.BitfieldBool):
    NAME = 'GPIO1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO1, self).__init__(GPIO1.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO1.NAME


class GPIO2(bmsbase.BitfieldBool):
    NAME = 'GPIO2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO2, self).__init__(GPIO2.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO2.NAME


class GPIO3(bmsbase.BitfieldBool):
    NAME = 'GPIO3'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO3, self).__init__(GPIO3.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO3.NAME


class GPIO4(bmsbase.BitfieldBool):
    NAME = 'GPIO4'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO4, self).__init__(GPIO4.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO4.NAME


class GPIO5(bmsbase.BitfieldBool):
    NAME = 'GPIO5'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO5, self).__init__(GPIO5.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO5.NAME


class GPIO6(bmsbase.BitfieldBool):
    NAME = 'GPIO6'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO6, self).__init__(GPIO6.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO6.NAME


class GPIO7(bmsbase.BitfieldBool):
    NAME = 'GPIO7'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO7, self).__init__(GPIO7.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO7.NAME


class GPIO8(bmsbase.BitfieldBool):
    NAME = 'GPIO8'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO8, self).__init__(GPIO8.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO8.NAME


class GPIO9(bmsbase.BitfieldBool):
    NAME = 'GPIO9'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO9, self).__init__(GPIO9.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO9.NAME


class ICOM0(bmsbase.BitfieldInt):
    NAME = 'ICOM0'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM0, self).__init__(ICOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM0.NAME


class ICOM1(bmsbase.BitfieldInt):
    NAME = 'ICOM1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM1, self).__init__(ICOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM1.NAME


class ICOM2(bmsbase.BitfieldInt):
    NAME = 'ICOM2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM2, self).__init__(ICOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM2.NAME


class ITMP(bmsbase.BitfieldAdc):
    NAME = 'ITMP'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 586.30232115
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ITMP, self).__init__(ITMP.LENGTH, value=value, raw_value=raw_value, lsb=0.01315789, postpend=-276, prepend=0, twos_complement=False)
        self.name = ITMP.NAME


class MCAL(bmsbase.BitfieldBool):
    NAME = 'MCAL'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MCAL, self).__init__(MCAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = MCAL.NAME


class MD(bmsbase.BitfieldInt):
    NAME = 'MD'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x2
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(MD, self).__init__(MD.LENGTH,  value=value, raw_value=raw_value)
        self.name = MD.NAME


class MUTE_ST(bmsbase.BitfieldBool):
    NAME = 'MUTE_ST'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MUTE_ST, self).__init__(MUTE_ST.LENGTH,  value=value, raw_value=raw_value)
        self.name = MUTE_ST.NAME


class MUXFAIL(bmsbase.BitfieldBool):
    NAME = 'MUXFAIL'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MUXFAIL, self).__init__(MUXFAIL.LENGTH,  value=value, raw_value=raw_value)
        self.name = MUXFAIL.NAME


class PS(bmsbase.BitfieldInt):
    NAME = 'PS'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PS, self).__init__(PS.LENGTH,  value=value, raw_value=raw_value)
        self.name = PS.NAME


class PUP(bmsbase.BitfieldBool):
    NAME = 'PUP'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(PUP, self).__init__(PUP.LENGTH,  value=value, raw_value=raw_value)
        self.name = PUP.NAME


class PWM1(bmsbase.BitfieldInt):
    NAME = 'PWM1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM1, self).__init__(PWM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM1.NAME


class PWM10(bmsbase.BitfieldInt):
    NAME = 'PWM10'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM10, self).__init__(PWM10.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM10.NAME


class PWM11(bmsbase.BitfieldInt):
    NAME = 'PWM11'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM11, self).__init__(PWM11.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM11.NAME


class PWM12(bmsbase.BitfieldInt):
    NAME = 'PWM12'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM12, self).__init__(PWM12.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM12.NAME


class PWM13(bmsbase.BitfieldInt):
    NAME = 'PWM13'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM13, self).__init__(PWM13.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM13.NAME


class PWM14(bmsbase.BitfieldInt):
    NAME = 'PWM14'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM14, self).__init__(PWM14.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM14.NAME


class PWM15(bmsbase.BitfieldInt):
    NAME = 'PWM15'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM15, self).__init__(PWM15.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM15.NAME


class PWM16(bmsbase.BitfieldInt):
    NAME = 'PWM16'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM16, self).__init__(PWM16.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM16.NAME


class PWM17(bmsbase.BitfieldInt):
    NAME = 'PWM17'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM17, self).__init__(PWM17.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM17.NAME


class PWM18(bmsbase.BitfieldInt):
    NAME = 'PWM18'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM18, self).__init__(PWM18.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM18.NAME


class PWM2(bmsbase.BitfieldInt):
    NAME = 'PWM2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM2, self).__init__(PWM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM2.NAME


class PWM3(bmsbase.BitfieldInt):
    NAME = 'PWM3'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM3, self).__init__(PWM3.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM3.NAME


class PWM4(bmsbase.BitfieldInt):
    NAME = 'PWM4'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM4, self).__init__(PWM4.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM4.NAME


class PWM5(bmsbase.BitfieldInt):
    NAME = 'PWM5'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM5, self).__init__(PWM5.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM5.NAME


class PWM6(bmsbase.BitfieldInt):
    NAME = 'PWM6'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM6, self).__init__(PWM6.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM6.NAME


class PWM7(bmsbase.BitfieldInt):
    NAME = 'PWM7'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM7, self).__init__(PWM7.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM7.NAME


class PWM8(bmsbase.BitfieldInt):
    NAME = 'PWM8'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM8, self).__init__(PWM8.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM8.NAME


class PWM9(bmsbase.BitfieldInt):
    NAME = 'PWM9'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM9, self).__init__(PWM9.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM9.NAME


class REF(bmsbase.BitfieldAdc):
    NAME = 'REF'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REF, self).__init__(REF.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = REF.NAME


class REFON(bmsbase.BitfieldBool):
    NAME = 'REFON'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(REFON, self).__init__(REFON.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFON.NAME


class REV(bmsbase.BitfieldInt):
    NAME = 'REV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REV, self).__init__(REV.LENGTH,  value=value, raw_value=raw_value)
        self.name = REV.NAME


class S0V(bmsbase.BitfieldAdc):
    NAME = 'S0V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S0V, self).__init__(S0V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0, twos_complement=True)
        self.name = S0V.NAME


class S1V(bmsbase.BitfieldAdc):
    NAME = 'S1V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S1V, self).__init__(S1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S1V.NAME


class S2V(bmsbase.BitfieldAdc):
    NAME = 'S2V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S2V, self).__init__(S2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S2V.NAME


class S3V(bmsbase.BitfieldAdc):
    NAME = 'S3V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S3V, self).__init__(S3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S3V.NAME


class S4V(bmsbase.BitfieldAdc):
    NAME = 'S4V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S4V, self).__init__(S4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S4V.NAME


class S5V(bmsbase.BitfieldAdc):
    NAME = 'S5V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S5V, self).__init__(S5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S5V.NAME


class S6V(bmsbase.BitfieldAdc):
    NAME = 'S6V'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S6V, self).__init__(S6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = S6V.NAME


class SC(bmsbase.BitfieldAdc):
    NAME = 'SC'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 196.60500000000002
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SC, self).__init__(SC.LENGTH, value=value, raw_value=raw_value, lsb=0.003, postpend=0, prepend=0, twos_complement=False)
        self.name = SC.NAME


class SCONV(bmsbase.BitfieldBool):
    NAME = 'SCONV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SCONV, self).__init__(SCONV.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCONV.NAME


class SCTL1(bmsbase.BitfieldInt):
    NAME = 'SCTL1'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL1, self).__init__(SCTL1.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL1.NAME


class SCTL10(bmsbase.BitfieldInt):
    NAME = 'SCTL10'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL10, self).__init__(SCTL10.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL10.NAME


class SCTL11(bmsbase.BitfieldInt):
    NAME = 'SCTL11'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL11, self).__init__(SCTL11.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL11.NAME


class SCTL12(bmsbase.BitfieldInt):
    NAME = 'SCTL12'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL12, self).__init__(SCTL12.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL12.NAME


class SCTL13(bmsbase.BitfieldInt):
    NAME = 'SCTL13'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL13, self).__init__(SCTL13.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL13.NAME


class SCTL14(bmsbase.BitfieldInt):
    NAME = 'SCTL14'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL14, self).__init__(SCTL14.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL14.NAME


class SCTL15(bmsbase.BitfieldInt):
    NAME = 'SCTL15'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL15, self).__init__(SCTL15.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL15.NAME


class SCTL16(bmsbase.BitfieldInt):
    NAME = 'SCTL16'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL16, self).__init__(SCTL16.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL16.NAME


class SCTL17(bmsbase.BitfieldInt):
    NAME = 'SCTL17'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL17, self).__init__(SCTL17.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL17.NAME


class SCTL18(bmsbase.BitfieldInt):
    NAME = 'SCTL18'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL18, self).__init__(SCTL18.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL18.NAME


class SCTL2(bmsbase.BitfieldInt):
    NAME = 'SCTL2'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL2, self).__init__(SCTL2.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL2.NAME


class SCTL3(bmsbase.BitfieldInt):
    NAME = 'SCTL3'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL3, self).__init__(SCTL3.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL3.NAME


class SCTL4(bmsbase.BitfieldInt):
    NAME = 'SCTL4'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL4, self).__init__(SCTL4.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL4.NAME


class SCTL5(bmsbase.BitfieldInt):
    NAME = 'SCTL5'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL5, self).__init__(SCTL5.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL5.NAME


class SCTL6(bmsbase.BitfieldInt):
    NAME = 'SCTL6'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL6, self).__init__(SCTL6.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL6.NAME


class SCTL7(bmsbase.BitfieldInt):
    NAME = 'SCTL7'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL7, self).__init__(SCTL7.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL7.NAME


class SCTL8(bmsbase.BitfieldInt):
    NAME = 'SCTL8'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL8, self).__init__(SCTL8.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL8.NAME


class SCTL9(bmsbase.BitfieldInt):
    NAME = 'SCTL9'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SCTL9, self).__init__(SCTL9.LENGTH,  value=value, raw_value=raw_value)
        self.name = SCTL9.NAME


class SID(bmsbase.BitfieldInt):
    NAME = 'SID'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xffffffffffff
    MIN_VALUE = 0x0
    LENGTH = 48
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SID, self).__init__(SID.LENGTH,  value=value, raw_value=raw_value)
        self.name = SID.NAME


class ST(bmsbase.BitfieldInt):
    NAME = 'ST'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x1
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ST, self).__init__(ST.LENGTH,  value=value, raw_value=raw_value)
        self.name = ST.NAME


class THSD(bmsbase.BitfieldBool):
    NAME = 'THSD'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(THSD, self).__init__(THSD.LENGTH,  value=value, raw_value=raw_value)
        self.name = THSD.NAME


class VA(bmsbase.BitfieldAdc):
    NAME = 'VA'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VA, self).__init__(VA.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = VA.NAME


class VD(bmsbase.BitfieldAdc):
    NAME = 'VD'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535000000000005
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VD, self).__init__(VD.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=False)
        self.name = VD.NAME


class VOV(bmsbase.BitfieldAdc):
    NAME = 'VOV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 6.5536
    MAX_VALUE = 6.5520000000000005
    MIN_VALUE = 0
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VOV, self).__init__(VOV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = VOV.NAME


class VUV(bmsbase.BitfieldAdc):
    NAME = 'VUV'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5520000000000005
    MIN_VALUE = 0
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VUV, self).__init__(VUV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0, twos_complement=False)
        self.name = VUV.NAME


class DATA0(bmsbase.BitfieldInt):
    NAME = 'DATA0'
    DESCRIPTION = 'Data Byte 0'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA0, self).__init__(DATA0.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA0.NAME


class DATA1(bmsbase.BitfieldInt):
    NAME = 'DATA1'
    DESCRIPTION = 'Data Byte 1'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA1, self).__init__(DATA1.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA1.NAME


class DATA2(bmsbase.BitfieldInt):
    NAME = 'DATA2'
    DESCRIPTION = 'Data Byte 2'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA2, self).__init__(DATA2.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA2.NAME


class DATA3(bmsbase.BitfieldInt):
    NAME = 'DATA3'
    DESCRIPTION = 'Data Byte 3'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA3, self).__init__(DATA3.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA3.NAME


class DATA4(bmsbase.BitfieldInt):
    NAME = 'DATA4'
    DESCRIPTION = 'Data Byte 4'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA4, self).__init__(DATA4.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA4.NAME


class DATA5(bmsbase.BitfieldInt):
    NAME = 'DATA5'
    DESCRIPTION = 'Data Byte 5'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA5, self).__init__(DATA5.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA5.NAME


# ===================================================== Registers =====================================================
class CMD_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command Bytes'
    NAME = 'Command Bytes'

    def __init__(self):
        super(CMD_REGISTER, self).__init__(
            [[CMD0, 7], [CMD0, 6], [CMD0, 5], [CMD0, 4], [CMD0, 3], [CMD0, 2], [CMD0, 1], [CMD0, 0],
             [CMD1, 7], [CMD1, 6], [CMD1, 5], [CMD1, 4], [CMD1, 3], [CMD1, 2], [CMD1, 1], [CMD1, 0]])


class CMD_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command PEC Bytes'
    NAME = 'Command PEC Bytes'

    def __init__(self):
        super(CMD_PEC_REGISTER, self).__init__(
            [[CMD_PEC, 15], [CMD_PEC, 14], [CMD_PEC, 13], [CMD_PEC, 12], [CMD_PEC, 11], [CMD_PEC, 10], [CMD_PEC, 9],
             [CMD_PEC, 8],
             [CMD_PEC, 7], [CMD_PEC, 6], [CMD_PEC, 5], [CMD_PEC, 4], [CMD_PEC, 3], [CMD_PEC, 2], [CMD_PEC, 1],
             [CMD_PEC, 0]])


class DATA_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Data PEC Bytes'
    NAME = 'Data PEC Bytes'

    def __init__(self):
        super(DATA_PEC_REGISTER, self).__init__(
            [[DATA_PEC, 15], [DATA_PEC, 14], [DATA_PEC, 13], [DATA_PEC, 12],
             [DATA_PEC, 11], [DATA_PEC, 10], [DATA_PEC, 9], [DATA_PEC, 8],
             [DATA_PEC, 7], [DATA_PEC, 6], [DATA_PEC, 5], [DATA_PEC, 4],
             [DATA_PEC, 3], [DATA_PEC, 2], [DATA_PEC, 1], [DATA_PEC, 0]])


class AVAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR0'

    def __init__(self):
        super(AVAR0, self).__init__([[G1V, 7], [G1V, 6], [G1V, 5], [G1V, 4], [G1V, 3], [G1V, 2], [G1V, 1], [G1V, 0]])


class AVAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR1'

    def __init__(self):
        super(AVAR1, self).__init__([[G1V, 15], [G1V, 14], [G1V, 13], [G1V, 12], [G1V, 11], [G1V, 10], [G1V, 9], [G1V, 8]])


class AVAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR2'

    def __init__(self):
        super(AVAR2, self).__init__([[G2V, 7], [G2V, 6], [G2V, 5], [G2V, 4], [G2V, 3], [G2V, 2], [G2V, 1], [G2V, 0]])


class AVAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR3'

    def __init__(self):
        super(AVAR3, self).__init__([[G2V, 15], [G2V, 14], [G2V, 13], [G2V, 12], [G2V, 11], [G2V, 10], [G2V, 9], [G2V, 8]])


class AVAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR4'

    def __init__(self):
        super(AVAR4, self).__init__([[G3V, 7], [G3V, 6], [G3V, 5], [G3V, 4], [G3V, 3], [G3V, 2], [G3V, 1], [G3V, 0]])


class AVAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVAR5'

    def __init__(self):
        super(AVAR5, self).__init__([[G3V, 15], [G3V, 14], [G3V, 13], [G3V, 12], [G3V, 11], [G3V, 10], [G3V, 9], [G3V, 8]])


class AVBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR0'

    def __init__(self):
        super(AVBR0, self).__init__([[G4V, 7], [G4V, 6], [G4V, 5], [G4V, 4], [G4V, 3], [G4V, 2], [G4V, 1], [G4V, 0]])


class AVBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR1'

    def __init__(self):
        super(AVBR1, self).__init__([[G4V, 15], [G4V, 14], [G4V, 13], [G4V, 12], [G4V, 11], [G4V, 10], [G4V, 9], [G4V, 8]])


class AVBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR2'

    def __init__(self):
        super(AVBR2, self).__init__([[G5V, 7], [G5V, 6], [G5V, 5], [G5V, 4], [G5V, 3], [G5V, 2], [G5V, 1], [G5V, 0]])


class AVBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR3'

    def __init__(self):
        super(AVBR3, self).__init__([[G5V, 15], [G5V, 14], [G5V, 13], [G5V, 12], [G5V, 11], [G5V, 10], [G5V, 9], [G5V, 8]])


class AVBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR4'

    def __init__(self):
        super(AVBR4, self).__init__([[REF, 7], [REF, 6], [REF, 5], [REF, 4], [REF, 3], [REF, 2], [REF, 1], [REF, 0]])


class AVBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVBR5'

    def __init__(self):
        super(AVBR5, self).__init__([[REF, 15], [REF, 14], [REF, 13], [REF, 12], [REF, 11], [REF, 10], [REF, 9], [REF, 8]])


class AVCR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR0'

    def __init__(self):
        super(AVCR0, self).__init__([[G6V, 7], [G6V, 6], [G6V, 5], [G6V, 4], [G6V, 3], [G6V, 2], [G6V, 1], [G6V, 0]])


class AVCR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR1'

    def __init__(self):
        super(AVCR1, self).__init__([[G6V, 15], [G6V, 14], [G6V, 13], [G6V, 12], [G6V, 11], [G6V, 10], [G6V, 9], [G6V, 8]])


class AVCR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR2'

    def __init__(self):
        super(AVCR2, self).__init__([[G7V, 7], [G7V, 6], [G7V, 5], [G7V, 4], [G7V, 3], [G7V, 2], [G7V, 1], [G7V, 0]])


class AVCR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR3'

    def __init__(self):
        super(AVCR3, self).__init__([[G7V, 15], [G7V, 14], [G7V, 13], [G7V, 12], [G7V, 11], [G7V, 10], [G7V, 9], [G7V, 8]])


class AVCR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR4'

    def __init__(self):
        super(AVCR4, self).__init__([[G8V, 7], [G8V, 6], [G8V, 5], [G8V, 4], [G8V, 3], [G8V, 2], [G8V, 1], [G8V, 0]])


class AVCR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVCR5'

    def __init__(self):
        super(AVCR5, self).__init__([[G8V, 15], [G8V, 14], [G8V, 13], [G8V, 12], [G8V, 11], [G8V, 10], [G8V, 9], [G8V, 8]])


class AVDR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR0'

    def __init__(self):
        super(AVDR0, self).__init__([[G9V, 7], [G9V, 6], [G9V, 5], [G9V, 4], [G9V, 3], [G9V, 2], [G9V, 1], [G9V, 0]])


class AVDR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR1'

    def __init__(self):
        super(AVDR1, self).__init__([[G9V, 15], [G9V, 14], [G9V, 13], [G9V, 12], [G9V, 11], [G9V, 10], [G9V, 9], [G9V, 8]])


class AVDR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR2'

    def __init__(self):
        super(AVDR2, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class AVDR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR3'

    def __init__(self):
        super(AVDR3, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class AVDR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR4'

    def __init__(self):
        super(AVDR4, self).__init__([[C16OV, 0], [C16UV, 0], [C15OV, 0], [C15UV, 0], [C14OV, 0], [C14UV, 0], [C13OV, 0], [C13UV, 0]])


class AVDR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AVDR5'

    def __init__(self):
        super(AVDR5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [C18OV, 0], [C18UV, 0], [C17OV, 0], [C17UV, 0]])


class CFGAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR0'

    def __init__(self):
        super(CFGAR0, self).__init__([[GPIO5, 0], [GPIO4, 0], [GPIO3, 0], [GPIO2, 0], [GPIO1, 0], [REFON, 0], [DTEN, 0], [ADCOPT, 0]])


class CFGAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR1'

    def __init__(self):
        super(CFGAR1, self).__init__([[VUV, 7], [VUV, 6], [VUV, 5], [VUV, 4], [VUV, 3], [VUV, 2], [VUV, 1], [VUV, 0]])


class CFGAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR2'

    def __init__(self):
        super(CFGAR2, self).__init__([[VOV, 3], [VOV, 2], [VOV, 1], [VOV, 0], [VUV, 11], [VUV, 10], [VUV, 9], [VUV, 8]])


class CFGAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR3'

    def __init__(self):
        super(CFGAR3, self).__init__([[VOV, 11], [VOV, 10], [VOV, 9], [VOV, 8], [VOV, 7], [VOV, 6], [VOV, 5], [VOV, 4]])


class CFGAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR4'

    def __init__(self):
        super(CFGAR4, self).__init__([[DCC8, 0], [DCC7, 0], [DCC6, 0], [DCC5, 0], [DCC4, 0], [DCC3, 0], [DCC2, 0], [DCC1, 0]])


class CFGAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGAR5'

    def __init__(self):
        super(CFGAR5, self).__init__([[DCTO, 3], [DCTO, 2], [DCTO, 1], [DCTO, 0], [DCC12, 0], [DCC11, 0], [DCC10, 0], [DCC9, 0]])


class CFGBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR0'

    def __init__(self):
        super(CFGBR0, self).__init__([[DCC16, 0], [DCC15, 0], [DCC14, 0], [DCC13, 0], [GPIO9, 0], [GPIO8, 0], [GPIO7, 0], [GPIO6, 0]])


class CFGBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR1'

    def __init__(self):
        super(CFGBR1, self).__init__([[MUTE_ST, 0], [FDRF, 0], [PS, 1], [PS, 0], [DTMEN, 0], [DCC0, 0], [DCC18, 0], [DCC17, 0]])


class CFGBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR2'

    def __init__(self):
        super(CFGBR2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFGBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR3'

    def __init__(self):
        super(CFGBR3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFGBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR4'

    def __init__(self):
        super(CFGBR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFGBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGBR5'

    def __init__(self):
        super(CFGBR5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFGR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR0'

    def __init__(self):
        super(CFGR0, self).__init__([[GPIO5, 0], [GPIO4, 0], [GPIO3, 0], [GPIO2, 0], [GPIO1, 0], [REFON, 0], [DTEN, 0], [ADCOPT, 0]])


class CFGR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR1'

    def __init__(self):
        super(CFGR1, self).__init__([[VUV, 7], [VUV, 6], [VUV, 5], [VUV, 4], [VUV, 3], [VUV, 2], [VUV, 1], [VUV, 0]])


class CFGR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR2'

    def __init__(self):
        super(CFGR2, self).__init__([[VOV, 3], [VOV, 2], [VOV, 1], [VOV, 0], [VUV, 11], [VUV, 10], [VUV, 9], [VUV, 8]])


class CFGR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR3'

    def __init__(self):
        super(CFGR3, self).__init__([[VOV, 11], [VOV, 10], [VOV, 9], [VOV, 8], [VOV, 7], [VOV, 6], [VOV, 5], [VOV, 4]])


class CFGR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR4'

    def __init__(self):
        super(CFGR4, self).__init__([[DCC8, 0], [DCC7, 0], [DCC6, 0], [DCC5, 0], [DCC4, 0], [DCC3, 0], [DCC2, 0], [DCC1, 0]])


class CFGR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CFGR5'

    def __init__(self):
        super(CFGR5, self).__init__([[DCTO, 3], [DCTO, 2], [DCTO, 1], [DCTO, 0], [DCC12, 0], [DCC11, 0], [DCC10, 0], [DCC9, 0]])


class COMM0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM0'

    def __init__(self):
        super(COMM0, self).__init__([[ICOM0, 3], [ICOM0, 2], [ICOM0, 1], [ICOM0, 0], [D0, 7], [D0, 6], [D0, 5], [D0, 4]])


class COMM1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM1'

    def __init__(self):
        super(COMM1, self).__init__([[D0, 3], [D0, 2], [D0, 1], [D0, 0], [FCOM0, 3], [FCOM0, 2], [FCOM0, 1], [FCOM0, 0]])


class COMM2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM2'

    def __init__(self):
        super(COMM2, self).__init__([[ICOM1, 3], [ICOM1, 2], [ICOM1, 1], [ICOM1, 0], [D1, 7], [D1, 6], [D1, 5], [D1, 4]])


class COMM3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM3'

    def __init__(self):
        super(COMM3, self).__init__([[D1, 3], [D1, 2], [D1, 1], [D1, 0], [FCOM1, 3], [FCOM1, 2], [FCOM1, 1], [FCOM1, 0]])


class COMM4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM4'

    def __init__(self):
        super(COMM4, self).__init__([[ICOM2, 3], [ICOM2, 2], [ICOM2, 1], [ICOM2, 0], [D2, 7], [D2, 6], [D2, 5], [D2, 4]])


class COMM5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'COMM5'

    def __init__(self):
        super(COMM5, self).__init__([[D2, 3], [D2, 2], [D2, 1], [D2, 0], [FCOM2, 3], [FCOM2, 2], [FCOM2, 1], [FCOM2, 0]])


class CVAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR0'

    def __init__(self):
        super(CVAR0, self).__init__([[C1V, 7], [C1V, 6], [C1V, 5], [C1V, 4], [C1V, 3], [C1V, 2], [C1V, 1], [C1V, 0]])


class CVAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR1'

    def __init__(self):
        super(CVAR1, self).__init__([[C1V, 15], [C1V, 14], [C1V, 13], [C1V, 12], [C1V, 11], [C1V, 10], [C1V, 9], [C1V, 8]])


class CVAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR2'

    def __init__(self):
        super(CVAR2, self).__init__([[C2V, 7], [C2V, 6], [C2V, 5], [C2V, 4], [C2V, 3], [C2V, 2], [C2V, 1], [C2V, 0]])


class CVAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR3'

    def __init__(self):
        super(CVAR3, self).__init__([[C2V, 15], [C2V, 14], [C2V, 13], [C2V, 12], [C2V, 11], [C2V, 10], [C2V, 9], [C2V, 8]])


class CVAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR4'

    def __init__(self):
        super(CVAR4, self).__init__([[C3V, 7], [C3V, 6], [C3V, 5], [C3V, 4], [C3V, 3], [C3V, 2], [C3V, 1], [C3V, 0]])


class CVAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVAR5'

    def __init__(self):
        super(CVAR5, self).__init__([[C3V, 15], [C3V, 14], [C3V, 13], [C3V, 12], [C3V, 11], [C3V, 10], [C3V, 9], [C3V, 8]])


class CVBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR0'

    def __init__(self):
        super(CVBR0, self).__init__([[C4V, 7], [C4V, 6], [C4V, 5], [C4V, 4], [C4V, 3], [C4V, 2], [C4V, 1], [C4V, 0]])


class CVBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR1'

    def __init__(self):
        super(CVBR1, self).__init__([[C4V, 15], [C4V, 14], [C4V, 13], [C4V, 12], [C4V, 11], [C4V, 10], [C4V, 9], [C4V, 8]])


class CVBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR2'

    def __init__(self):
        super(CVBR2, self).__init__([[C5V, 7], [C5V, 6], [C5V, 5], [C5V, 4], [C5V, 3], [C5V, 2], [C5V, 1], [C5V, 0]])


class CVBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR3'

    def __init__(self):
        super(CVBR3, self).__init__([[C5V, 15], [C5V, 14], [C5V, 13], [C5V, 12], [C5V, 11], [C5V, 10], [C5V, 9], [C5V, 8]])


class CVBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR4'

    def __init__(self):
        super(CVBR4, self).__init__([[C6V, 7], [C6V, 6], [C6V, 5], [C6V, 4], [C6V, 3], [C6V, 2], [C6V, 1], [C6V, 0]])


class CVBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVBR5'

    def __init__(self):
        super(CVBR5, self).__init__([[C6V, 15], [C6V, 14], [C6V, 13], [C6V, 12], [C6V, 11], [C6V, 10], [C6V, 9], [C6V, 8]])


class CVCR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR0'

    def __init__(self):
        super(CVCR0, self).__init__([[C7V, 7], [C7V, 6], [C7V, 5], [C7V, 4], [C7V, 3], [C7V, 2], [C7V, 1], [C7V, 0]])


class CVCR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR1'

    def __init__(self):
        super(CVCR1, self).__init__([[C7V, 15], [C7V, 14], [C7V, 13], [C7V, 12], [C7V, 11], [C7V, 10], [C7V, 9], [C7V, 8]])


class CVCR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR2'

    def __init__(self):
        super(CVCR2, self).__init__([[C8V, 7], [C8V, 6], [C8V, 5], [C8V, 4], [C8V, 3], [C8V, 2], [C8V, 1], [C8V, 0]])


class CVCR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR3'

    def __init__(self):
        super(CVCR3, self).__init__([[C8V, 15], [C8V, 14], [C8V, 13], [C8V, 12], [C8V, 11], [C8V, 10], [C8V, 9], [C8V, 8]])


class CVCR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR4'

    def __init__(self):
        super(CVCR4, self).__init__([[C9V, 7], [C9V, 6], [C9V, 5], [C9V, 4], [C9V, 3], [C9V, 2], [C9V, 1], [C9V, 0]])


class CVCR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVCR5'

    def __init__(self):
        super(CVCR5, self).__init__([[C9V, 15], [C9V, 14], [C9V, 13], [C9V, 12], [C9V, 11], [C9V, 10], [C9V, 9], [C9V, 8]])


class CVDR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR0'

    def __init__(self):
        super(CVDR0, self).__init__([[C10V, 7], [C10V, 6], [C10V, 5], [C10V, 4], [C10V, 3], [C10V, 2], [C10V, 1], [C10V, 0]])


class CVDR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR1'

    def __init__(self):
        super(CVDR1, self).__init__([[C10V, 15], [C10V, 14], [C10V, 13], [C10V, 12], [C10V, 11], [C10V, 10], [C10V, 9], [C10V, 8]])


class CVDR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR2'

    def __init__(self):
        super(CVDR2, self).__init__([[C11V, 7], [C11V, 6], [C11V, 5], [C11V, 4], [C11V, 3], [C11V, 2], [C11V, 1], [C11V, 0]])


class CVDR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR3'

    def __init__(self):
        super(CVDR3, self).__init__([[C11V, 15], [C11V, 14], [C11V, 13], [C11V, 12], [C11V, 11], [C11V, 10], [C11V, 9], [C11V, 8]])


class CVDR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR4'

    def __init__(self):
        super(CVDR4, self).__init__([[C12V, 7], [C12V, 6], [C12V, 5], [C12V, 4], [C12V, 3], [C12V, 2], [C12V, 1], [C12V, 0]])


class CVDR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVDR5'

    def __init__(self):
        super(CVDR5, self).__init__([[C12V, 15], [C12V, 14], [C12V, 13], [C12V, 12], [C12V, 11], [C12V, 10], [C12V, 9], [C12V, 8]])


class CVER0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER0'

    def __init__(self):
        super(CVER0, self).__init__([[C13V, 7], [C13V, 6], [C13V, 5], [C13V, 4], [C13V, 3], [C13V, 2], [C13V, 1], [C13V, 0]])


class CVER1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER1'

    def __init__(self):
        super(CVER1, self).__init__([[C13V, 15], [C13V, 14], [C13V, 13], [C13V, 12], [C13V, 11], [C13V, 10], [C13V, 9], [C13V, 8]])


class CVER2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER2'

    def __init__(self):
        super(CVER2, self).__init__([[C14V, 7], [C14V, 6], [C14V, 5], [C14V, 4], [C14V, 3], [C14V, 2], [C14V, 1], [C14V, 0]])


class CVER3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER3'

    def __init__(self):
        super(CVER3, self).__init__([[C14V, 15], [C14V, 14], [C14V, 13], [C14V, 12], [C14V, 11], [C14V, 10], [C14V, 9], [C14V, 8]])


class CVER4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER4'

    def __init__(self):
        super(CVER4, self).__init__([[C15V, 7], [C15V, 6], [C15V, 5], [C15V, 4], [C15V, 3], [C15V, 2], [C15V, 1], [C15V, 0]])


class CVER5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVER5'

    def __init__(self):
        super(CVER5, self).__init__([[C15V, 15], [C15V, 14], [C15V, 13], [C15V, 12], [C15V, 11], [C15V, 10], [C15V, 9], [C15V, 8]])


class CVFR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR0'

    def __init__(self):
        super(CVFR0, self).__init__([[C16V, 7], [C16V, 6], [C16V, 5], [C16V, 4], [C16V, 3], [C16V, 2], [C16V, 1], [C16V, 0]])


class CVFR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR1'

    def __init__(self):
        super(CVFR1, self).__init__([[C16V, 15], [C16V, 14], [C16V, 13], [C16V, 12], [C16V, 11], [C16V, 10], [C16V, 9], [C16V, 8]])


class CVFR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR2'

    def __init__(self):
        super(CVFR2, self).__init__([[C17V, 7], [C17V, 6], [C17V, 5], [C17V, 4], [C17V, 3], [C17V, 2], [C17V, 1], [C17V, 0]])


class CVFR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR3'

    def __init__(self):
        super(CVFR3, self).__init__([[C17V, 15], [C17V, 14], [C17V, 13], [C17V, 12], [C17V, 11], [C17V, 10], [C17V, 9], [C17V, 8]])


class CVFR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR4'

    def __init__(self):
        super(CVFR4, self).__init__([[C18V, 7], [C18V, 6], [C18V, 5], [C18V, 4], [C18V, 3], [C18V, 2], [C18V, 1], [C18V, 0]])


class CVFR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'CVFR5'

    def __init__(self):
        super(CVFR5, self).__init__([[C18V, 15], [C18V, 14], [C18V, 13], [C18V, 12], [C18V, 11], [C18V, 10], [C18V, 9], [C18V, 8]])


class PSR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR0'

    def __init__(self):
        super(PSR0, self).__init__([[PWM14, 3], [PWM14, 2], [PWM14, 1], [PWM14, 0], [PWM13, 3], [PWM13, 2], [PWM13, 1], [PWM13, 0]])


class PSR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR1'

    def __init__(self):
        super(PSR1, self).__init__([[PWM16, 3], [PWM16, 2], [PWM16, 1], [PWM16, 0], [PWM15, 3], [PWM15, 2], [PWM15, 1], [PWM15, 0]])


class PSR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR2'

    def __init__(self):
        super(PSR2, self).__init__([[PWM18, 3], [PWM18, 2], [PWM18, 1], [PWM18, 0], [PWM17, 3], [PWM17, 2], [PWM17, 1], [PWM17, 0]])


class PSR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR3'

    def __init__(self):
        super(PSR3, self).__init__([[SCTL14, 3], [SCTL14, 2], [SCTL14, 1], [SCTL14, 0], [SCTL13, 3], [SCTL13, 2], [SCTL13, 1], [SCTL13, 0]])


class PSR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR4'

    def __init__(self):
        super(PSR4, self).__init__([[SCTL16, 3], [SCTL16, 2], [SCTL16, 1], [SCTL16, 0], [SCTL15, 3], [SCTL15, 2], [SCTL15, 1], [SCTL15, 0]])


class PSR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PSR5'

    def __init__(self):
        super(PSR5, self).__init__([[SCTL18, 3], [SCTL18, 2], [SCTL18, 1], [SCTL18, 0], [SCTL17, 3], [SCTL17, 2], [SCTL17, 1], [SCTL17, 0]])


class PWMR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR0'

    def __init__(self):
        super(PWMR0, self).__init__([[PWM2, 3], [PWM2, 2], [PWM2, 1], [PWM2, 0], [PWM1, 3], [PWM1, 2], [PWM1, 1], [PWM1, 0]])


class PWMR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR1'

    def __init__(self):
        super(PWMR1, self).__init__([[PWM4, 3], [PWM4, 2], [PWM4, 1], [PWM4, 0], [PWM3, 3], [PWM3, 2], [PWM3, 1], [PWM3, 0]])


class PWMR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR2'

    def __init__(self):
        super(PWMR2, self).__init__([[PWM6, 3], [PWM6, 2], [PWM6, 1], [PWM6, 0], [PWM5, 3], [PWM5, 2], [PWM5, 1], [PWM5, 0]])


class PWMR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR3'

    def __init__(self):
        super(PWMR3, self).__init__([[PWM8, 3], [PWM8, 2], [PWM8, 1], [PWM8, 0], [PWM7, 3], [PWM7, 2], [PWM7, 1], [PWM7, 0]])


class PWMR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR4'

    def __init__(self):
        super(PWMR4, self).__init__([[PWM10, 3], [PWM10, 2], [PWM10, 1], [PWM10, 0], [PWM9, 3], [PWM9, 2], [PWM9, 1], [PWM9, 0]])


class PWMR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'PWMR5'

    def __init__(self):
        super(PWMR5, self).__init__([[PWM12, 3], [PWM12, 2], [PWM12, 1], [PWM12, 0], [PWM11, 3], [PWM11, 2], [PWM11, 1], [PWM11, 0]])


class SCTLR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR0'

    def __init__(self):
        super(SCTLR0, self).__init__([[SCTL2, 3], [SCTL2, 2], [SCTL2, 1], [SCTL2, 0], [SCTL1, 3], [SCTL1, 2], [SCTL1, 1], [SCTL1, 0]])


class SCTLR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR1'

    def __init__(self):
        super(SCTLR1, self).__init__([[SCTL4, 3], [SCTL4, 2], [SCTL4, 1], [SCTL4, 0], [SCTL3, 3], [SCTL3, 2], [SCTL3, 1], [SCTL3, 0]])


class SCTLR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR2'

    def __init__(self):
        super(SCTLR2, self).__init__([[SCTL6, 3], [SCTL6, 2], [SCTL6, 1], [SCTL6, 0], [SCTL5, 3], [SCTL5, 2], [SCTL5, 1], [SCTL5, 0]])


class SCTLR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR3'

    def __init__(self):
        super(SCTLR3, self).__init__([[SCTL8, 3], [SCTL8, 2], [SCTL8, 1], [SCTL8, 0], [SCTL7, 3], [SCTL7, 2], [SCTL7, 1], [SCTL7, 0]])


class SCTLR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR4'

    def __init__(self):
        super(SCTLR4, self).__init__([[SCTL10, 3], [SCTL10, 2], [SCTL10, 1], [SCTL10, 0], [SCTL9, 3], [SCTL9, 2], [SCTL9, 1], [SCTL9, 0]])


class SCTLR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SCTLR5'

    def __init__(self):
        super(SCTLR5, self).__init__([[SCTL12, 3], [SCTL12, 2], [SCTL12, 1], [SCTL12, 0], [SCTL11, 3], [SCTL11, 2], [SCTL11, 1], [SCTL11, 0]])


class SIDR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR0'

    def __init__(self):
        super(SIDR0, self).__init__([[SID, 7], [SID, 6], [SID, 5], [SID, 4], [SID, 3], [SID, 2], [SID, 1], [SID, 0]])


class SIDR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR1'

    def __init__(self):
        super(SIDR1, self).__init__([[SID, 15], [SID, 14], [SID, 13], [SID, 12], [SID, 11], [SID, 10], [SID, 9], [SID, 8]])


class SIDR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR2'

    def __init__(self):
        super(SIDR2, self).__init__([[SID, 23], [SID, 22], [SID, 21], [SID, 20], [SID, 19], [SID, 18], [SID, 17], [SID, 16]])


class SIDR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR3'

    def __init__(self):
        super(SIDR3, self).__init__([[SID, 31], [SID, 30], [SID, 29], [SID, 28], [SID, 27], [SID, 26], [SID, 25], [SID, 24]])


class SIDR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR4'

    def __init__(self):
        super(SIDR4, self).__init__([[SID, 39], [SID, 38], [SID, 37], [SID, 36], [SID, 35], [SID, 34], [SID, 33], [SID, 32]])


class SIDR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'SIDR5'

    def __init__(self):
        super(SIDR5, self).__init__([[SID, 47], [SID, 46], [SID, 45], [SID, 44], [SID, 43], [SID, 42], [SID, 41], [SID, 40]])


class STAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR0'

    def __init__(self):
        super(STAR0, self).__init__([[SC, 7], [SC, 6], [SC, 5], [SC, 4], [SC, 3], [SC, 2], [SC, 1], [SC, 0]])


class STAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR1'

    def __init__(self):
        super(STAR1, self).__init__([[SC, 15], [SC, 14], [SC, 13], [SC, 12], [SC, 11], [SC, 10], [SC, 9], [SC, 8]])


class STAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR2'

    def __init__(self):
        super(STAR2, self).__init__([[ITMP, 7], [ITMP, 6], [ITMP, 5], [ITMP, 4], [ITMP, 3], [ITMP, 2], [ITMP, 1], [ITMP, 0]])


class STAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR3'

    def __init__(self):
        super(STAR3, self).__init__([[ITMP, 15], [ITMP, 14], [ITMP, 13], [ITMP, 12], [ITMP, 11], [ITMP, 10], [ITMP, 9], [ITMP, 8]])


class STAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR4'

    def __init__(self):
        super(STAR4, self).__init__([[VA, 7], [VA, 6], [VA, 5], [VA, 4], [VA, 3], [VA, 2], [VA, 1], [VA, 0]])


class STAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STAR5'

    def __init__(self):
        super(STAR5, self).__init__([[VA, 15], [VA, 14], [VA, 13], [VA, 12], [VA, 11], [VA, 10], [VA, 9], [VA, 8]])


class STBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR0'

    def __init__(self):
        super(STBR0, self).__init__([[VD, 7], [VD, 6], [VD, 5], [VD, 4], [VD, 3], [VD, 2], [VD, 1], [VD, 0]])


class STBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR1'

    def __init__(self):
        super(STBR1, self).__init__([[VD, 15], [VD, 14], [VD, 13], [VD, 12], [VD, 11], [VD, 10], [VD, 9], [VD, 8]])


class STBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR2'

    def __init__(self):
        super(STBR2, self).__init__([[C4OV, 0], [C4UV, 0], [C3OV, 0], [C3UV, 0], [C2OV, 0], [C2UV, 0], [C1OV, 0], [C1UV, 0]])


class STBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR3'

    def __init__(self):
        super(STBR3, self).__init__([[C8OV, 0], [C8UV, 0], [C7OV, 0], [C7UV, 0], [C6OV, 0], [C6UV, 0], [C5OV, 0], [C5UV, 0]])


class STBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR4'

    def __init__(self):
        super(STBR4, self).__init__([[C12OV, 0], [C12UV, 0], [C11OV, 0], [C11UV, 0], [C10OV, 0], [C10UV, 0], [C9OV, 0], [C9UV, 0]])


class STBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STBR5'

    def __init__(self):
        super(STBR5, self).__init__([[REV, 3], [REV, 2], [REV, 1], [REV, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [MUXFAIL, 0], [THSD, 0]])


class WRITE_DATA_REGISTER(bmsbase.Register):
    MEM_KEY = 'Write Command Bytes'
    NAME = 'Write Command Bytes'

    def __init__(self):
        super(WRITE_DATA_REGISTER, self).__init__(
            [[DATA0, 7], [DATA0, 6], [DATA0, 5], [DATA0, 4], [DATA0, 3], [DATA0, 2], [DATA0, 1], [DATA0, 0],
             [DATA1, 7], [DATA1, 6], [DATA1, 5], [DATA1, 4], [DATA1, 3], [DATA1, 2], [DATA1, 1], [DATA1, 0],
             [DATA2, 7], [DATA2, 6], [DATA2, 5], [DATA2, 4], [DATA2, 3], [DATA2, 2], [DATA2, 1], [DATA2, 0],
             [DATA3, 7], [DATA3, 6], [DATA3, 5], [DATA3, 4], [DATA3, 3], [DATA3, 2], [DATA3, 1], [DATA3, 0],
             [DATA4, 7], [DATA4, 6], [DATA4, 5], [DATA4, 4], [DATA4, 3], [DATA4, 2], [DATA4, 1], [DATA4, 0],
             [DATA5, 7], [DATA5, 6], [DATA5, 5], [DATA5, 4], [DATA5, 3], [DATA5, 2], [DATA5, 1], [DATA5, 0]])

# ===================================================== Commands =====================================================

class ADAX(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAX'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADAX, self).__init__(**kwargs)


class ADAX_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAX Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADAX_Addressed, self).__init__(**kwargs)


class ADAXD(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAXD'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADAXD, self).__init__(**kwargs)


class ADAXD_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAXD Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADAXD_Addressed, self).__init__(**kwargs)


class ADCV(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [CH, 2], [CH, 1], [CH, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCV'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCV, self).__init__(**kwargs)


class ADCV_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [CH, 2], [CH, 1], [CH, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCV Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCV_Addressed, self).__init__(**kwargs)


class ADCVAX(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVAX'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVAX, self).__init__(**kwargs)


class ADCVAX_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVAX Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVAX_Addressed, self).__init__(**kwargs)


class ADCVSC(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVSC'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVSC, self).__init__(**kwargs)


class ADCVSC_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVSC Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVSC_Addressed, self).__init__(**kwargs)


class ADCVSOC(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVSOC'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVSOC, self).__init__(**kwargs)


class ADCVSOC_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVSOC Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADCVSOC_Addressed, self).__init__(**kwargs)


class ADOL(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADOL, self).__init__(**kwargs)


class ADOL_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [DCP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADOL_Addressed, self).__init__(**kwargs)


class ADOW(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [PUP, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit1, 0], [CH, 2], [CH, 1], [CH, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOW'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADOW, self).__init__(**kwargs)


class ADOW_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [PUP, 0], [bmsbase.Bit1, 0], [DCP, 0], [bmsbase.Bit1, 0], [CH, 2], [CH, 1], [CH, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOW Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADOW_Addressed, self).__init__(**kwargs)


class ADSTAT(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [CHST, 2], [CHST, 1], [CHST, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSTAT'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADSTAT, self).__init__(**kwargs)


class ADSTAT_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [CHST, 2], [CHST, 1], [CHST, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSTAT Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADSTAT_Addressed, self).__init__(**kwargs)


class ADSTATD(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [CHST, 2], [CHST, 1], [CHST, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSTATD'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADSTATD, self).__init__(**kwargs)


class ADSTATD_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [CHST, 2], [CHST, 1], [CHST, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSTATD Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(ADSTATD_Addressed, self).__init__(**kwargs)


class AXOW(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [PUP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXOW'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(AXOW, self).__init__(**kwargs)


class AXOW_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [PUP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [CHG, 2], [CHG, 1], [CHG, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXOW Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(AXOW_Addressed, self).__init__(**kwargs)


class AXST(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXST'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(AXST, self).__init__(**kwargs)


class AXST_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXST Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(AXST_Addressed, self).__init__(**kwargs)


class CLRAUX(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRAUX'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRAUX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x12)
        }


class CLRAUX_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRAUX Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRAUX_Addressed, self).__init__(**kwargs)


class CLRCELL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRCELL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRCELL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x11)
        }


class CLRCELL_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRCELL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRCELL_Addressed, self).__init__(**kwargs)


class CLRSCTRL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSCTRL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRSCTRL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x18)
        }


class CLRSCTRL_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSCTRL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRSCTRL_Addressed, self).__init__(**kwargs)


class CLRSTAT(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSTAT'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRSTAT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x13)
        }


class CLRSTAT_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSTAT Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CLRSTAT_Addressed, self).__init__(**kwargs)


class CVST(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CVST'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CVST, self).__init__(**kwargs)


class CVST_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CVST Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(CVST_Addressed, self).__init__(**kwargs)


class DIAGN(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'DIAGN'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(DIAGN, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x15)
        }


class DIAGN_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'DIAGN Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(DIAGN_Addressed, self).__init__(**kwargs)


class MUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'MUTE'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(MUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x28)
        }


class MUTE_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'MUTE Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(MUTE_Addressed, self).__init__(**kwargs)


class PLADC(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLADC'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(PLADC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x14)
        }


class PLADC_Addressed(bmsbase.SPIPoll):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLADC Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(PLADC_Addressed, self).__init__(**kwargs)


class RDAUXA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVAR0(), True], [AVAR1(), True], [AVAR2(), True], [AVAR3(), True], [AVAR4(), True], [AVAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xc)
        }


class RDAUXA_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVAR0(), True], [AVAR1(), True], [AVAR2(), True], [AVAR3(), True], [AVAR4(), True], [AVAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXA_Addressed, self).__init__(**kwargs)


class RDAUXB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVBR0(), True], [AVBR1(), True], [AVBR2(), True], [AVBR3(), True], [AVBR4(), True], [AVBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xe)
        }


class RDAUXB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVBR0(), True], [AVBR1(), True], [AVBR2(), True], [AVBR3(), True], [AVBR4(), True], [AVBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXB_Addressed, self).__init__(**kwargs)


class RDAUXC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVCR0(), True], [AVCR1(), True], [AVCR2(), True], [AVCR3(), True], [AVCR4(), True], [AVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXC'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xd)
        }


class RDAUXC_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVCR0(), True], [AVCR1(), True], [AVCR2(), True], [AVCR3(), True], [AVCR4(), True], [AVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXC Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXC_Addressed, self).__init__(**kwargs)


class RDAUXD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVDR0(), True], [AVDR1(), True], [AVDR2(), True], [AVDR3(), True], [AVDR4(), True], [AVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXD'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xf)
        }


class RDAUXD_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVDR0(), True], [AVDR1(), True], [AVDR2(), True], [AVDR3(), True], [AVDR4(), True], [AVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXD Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDAUXD_Addressed, self).__init__(**kwargs)


class RDCFGA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x2)
        }


class RDCFGA_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCFGA_Addressed, self).__init__(**kwargs)


class RDCFGB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x26)
        }


class RDCFGB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCFGB_Addressed, self).__init__(**kwargs)


class RDCOMM(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), True], [COMM1(), True], [COMM2(), True], [COMM3(), True], [COMM4(), True], [COMM5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCOMM'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x22)
        }


class RDCOMM_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), True], [COMM1(), True], [COMM2(), True], [COMM3(), True], [COMM4(), True], [COMM5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCOMM Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCOMM_Addressed, self).__init__(**kwargs)


class RDSA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSA, self).__init__(**kwargs)


class RDSA_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSA_Addressed, self).__init__(**kwargs)


class RDSB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSB, self).__init__(**kwargs)


class RDSB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSB_Addressed, self).__init__(**kwargs)


class RDCVA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x4)
        }


class RDCVA_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVA_Addressed, self).__init__(**kwargs)


class RDCVB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x6)
        }


class RDCVB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVB_Addressed, self).__init__(**kwargs)


class RDCVC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVC'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x8)
        }


class RDCVC_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVC Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVC_Addressed, self).__init__(**kwargs)


class RDCVD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVD'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xa)
        }


class RDCVD_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVD Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVD_Addressed, self).__init__(**kwargs)


class RDCVE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVER0(), True], [CVER1(), True], [CVER2(), True], [CVER3(), True], [CVER4(), True], [CVER5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVE'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x9)
        }


class RDCVE_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVER0(), True], [CVER1(), True], [CVER2(), True], [CVER3(), True], [CVER4(), True], [CVER5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVE Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVE_Addressed, self).__init__(**kwargs)


class RDCVF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVFR0(), True], [CVFR1(), True], [CVFR2(), True], [CVFR3(), True], [CVFR4(), True], [CVFR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVF'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xb)
        }


class RDCVF_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVFR0(), True], [CVFR1(), True], [CVFR2(), True], [CVFR3(), True], [CVFR4(), True], [CVFR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVF Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDCVF_Addressed, self).__init__(**kwargs)


class RDPSB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), True], [PSR1(), True], [PSR2(), True], [PSR3(), True], [PSR4(), True], [PSR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPSB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDPSB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x1e)
        }


class RDPSB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), True], [PSR1(), True], [PSR2(), True], [PSR3(), True], [PSR4(), True], [PSR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPSB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDPSB_Addressed, self).__init__(**kwargs)


class RDPWM(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), True], [PWMR1(), True], [PWMR2(), True], [PWMR3(), True], [PWMR4(), True], [PWMR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPWM'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDPWM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x22)
        }


class RDPWM_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), True], [PWMR1(), True], [PWMR2(), True], [PWMR3(), True], [PWMR4(), True], [PWMR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPWM Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDPWM_Addressed, self).__init__(**kwargs)


class RDSCTRL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SCTLR0(), True], [SCTLR1(), True], [SCTLR2(), True], [SCTLR3(), True], [SCTLR4(), True], [SCTLR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSCTRL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSCTRL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x16)
        }


class RDSCTRL_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SCTLR0(), True], [SCTLR1(), True], [SCTLR2(), True], [SCTLR3(), True], [SCTLR4(), True], [SCTLR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSCTRL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSCTRL_Addressed, self).__init__(**kwargs)


class RDSID(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SIDR0(), True], [SIDR1(), True], [SIDR2(), True], [SIDR3(), True], [SIDR4(), True], [SIDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSID'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSID, self).__init__(**kwargs)


class RDSID_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SIDR0(), True], [SIDR1(), True], [SIDR2(), True], [SIDR3(), True], [SIDR4(), True], [SIDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSID Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSID_Addressed, self).__init__(**kwargs)


class RDSTATA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSTATA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x10)
        }


class RDSTATA_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSTATA_Addressed, self).__init__(**kwargs)


class RDSTATB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSTATB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x12)
        }


class RDSTATB_Addressed(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(RDSTATB_Addressed, self).__init__(**kwargs)


class STATST(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STATST'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STATST, self).__init__(**kwargs)


class STATST_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1], [MD, 0], [ST, 1], [ST, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STATST Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STATST_Addressed, self).__init__(**kwargs)


class STCOMM(bmsbase.SPIWriteOpen):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STCOMM'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x23)
        }


class STCOMM_Addressed(bmsbase.SPIWriteOpen):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STCOMM Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STCOMM_Addressed, self).__init__(**kwargs)


class STSCTRL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STSCTRL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STSCTRL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x19)
        }


class STSCTRL_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STSCTRL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(STSCTRL_Addressed, self).__init__(**kwargs)


class UNMUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'UNMUTE'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(UNMUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x29)
        }


class UNMUTE_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'UNMUTE Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(UNMUTE_Addressed, self).__init__(**kwargs)


class WRCFGA(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), False], [CFGAR1(), False], [CFGAR2(), False], [CFGAR3(), False], [CFGAR4(), False], [CFGAR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGA'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x1)
        }


class WRCFGA_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), False], [CFGAR1(), False], [CFGAR2(), False], [CFGAR3(), False], [CFGAR4(), False], [CFGAR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGA Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCFGA_Addressed, self).__init__(**kwargs)


class WRCFGB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), False], [CFGBR1(), False], [CFGBR2(), False], [CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x24)
        }


class WRCFGB_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), False], [CFGBR1(), False], [CFGBR2(), False], [CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCFGB_Addressed, self).__init__(**kwargs)


class WRCOMM(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), False], [COMM1(), False], [COMM2(), False], [COMM3(), False], [COMM4(), False], [COMM5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCOMM'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x21)
        }


class WRCOMM_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), False], [COMM1(), False], [COMM2(), False], [COMM3(), False], [COMM4(), False], [COMM5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCOMM Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRCOMM_Addressed, self).__init__(**kwargs)


class WRPSB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), False], [PSR1(), False], [PSR2(), False], [PSR3(), False], [PSR4(), False], [PSR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPSB'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRPSB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x1c)
        }


class WRPSB_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), False], [PSR1(), False], [PSR2(), False], [PSR3(), False], [PSR4(), False], [PSR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPSB Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRPSB_Addressed, self).__init__(**kwargs)


class WRPWM(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), False], [PWMR1(), False], [PWMR2(), False], [PWMR3(), False], [PWMR4(), False], [PWMR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPWM'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRPWM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x20)
        }


class WRPWM_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), False], [PWMR1(), False], [PWMR2(), False], [PWMR3(), False], [PWMR4(), False], [PWMR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPWM Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRPWM_Addressed, self).__init__(**kwargs)


class WRSCTRL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SCTLR0(), False], [SCTLR1(), False], [SCTLR2(), False], [SCTLR3(), False], [SCTLR4(), False], [SCTLR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRSCTRL'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRSCTRL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x14)
        }


class WRSCTRL_Addressed(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit1, 0], [ADDR, 3], [ADDR, 2], [ADDR, 1], [ADDR, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SCTLR0(), False], [SCTLR1(), False], [SCTLR2(), False], [SCTLR3(), False], [SCTLR4(), False], [SCTLR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRSCTRL Addressed'
    DESCRIPTION = ''

    def __init__(self, **kwargs):
        super(WRSCTRL_Addressed, self).__init__(**kwargs)


class Broadcast_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'Broadcast Command'
    DESCRIPTION = 'Generic Broadcast Command'

    def __init__(self, **kwargs):
        super(Broadcast_Command, self).__init__(**kwargs)


class Write_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'Write Command'
    DESCRIPTION = 'Generic Write Command'

    def __init__(self, **kwargs):
        super(Write_Command, self).__init__(**kwargs)


class Read_Command(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'Read Command'
    DESCRIPTION = 'Generic Read Command'

    def __init__(self, **kwargs):
        super(Read_Command, self).__init__(**kwargs)


class Write_Reserved_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'Write Reserved Command'
    DESCRIPTION = 'Generic Write Command To Reserved Registers'

    def __init__(self, **kwargs):
        super(Write_Reserved_Command, self).__init__(**kwargs)


class Read_Reserved_Command(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'Read Reserved Command'
    DESCRIPTION = 'Generic Read Command Of Reserved Registers'

    def __init__(self, **kwargs):
        super(Read_Reserved_Command, self).__init__(**kwargs)



# ===================================================== DUT =====================================================
class ADBMS_GEN4(ABC):
    NAME = 'ADBMS_GEN4'
    PASS = 'Pass'
    FAIL = 'Fail'
    MEMORY_MAP = {
        **bmsbase.BMS_Config.MEMORY_MAP,
        CMD_REGISTER.NAME: CMD_REGISTER,
        CMD_PEC_REGISTER.NAME: CMD_PEC_REGISTER,
        DATA_PEC_REGISTER.NAME: DATA_PEC_REGISTER,
        # CVAR0.NAME: CVAR0,
        # CVAR1.NAME: CVAR1,
        # CVAR2.NAME: CVAR2,
        # CVAR3.NAME: CVAR3,
        # CVAR4.NAME: CVAR4,
        # CVAR5.NAME: CVAR5,
        # CVBR0.NAME: CVBR0,
        # CVBR1.NAME: CVBR1,
        # CVBR2.NAME: CVBR2,
        # CVBR3.NAME: CVBR3,
        # CVBR4.NAME: CVBR4,
        # CVBR5.NAME: CVBR5,
        # CVCR0.NAME: CVCR0,
        # CVCR1.NAME: CVCR1,
        # CVCR2.NAME: CVCR2,
        # CVCR3.NAME: CVCR3,
        # CVCR4.NAME: CVCR4,
        # CVCR5.NAME: CVCR5,
        # CVDR0.NAME: CVDR0,
        # CVDR1.NAME: CVDR1,
        # CVDR2.NAME: CVDR2,
        # CVDR3.NAME: CVDR3,
        # CVDR4.NAME: CVDR4,
        # CVDR5.NAME: CVDR5,
        # CDAR0.NAME: CDAR0,
        # CDAR1.NAME: CDAR1,
        # CDAR2.NAME: CDAR2,
        # CDAR3.NAME: CDAR3,
        # CDAR4.NAME: CDAR4,
        # CDAR5.NAME: CDAR5,
        # CDBR0.NAME: CDBR0,
        # CDBR1.NAME: CDBR1,
        # CDBR2.NAME: CDBR2,
        # CDBR3.NAME: CDBR3,
        # CDBR4.NAME: CDBR4,
        # CDBR5.NAME: CDBR5,
        # CDCR0.NAME: CDCR0,
        # CDCR1.NAME: CDCR1,
        # CDCR2.NAME: CDCR2,
        # CDCR3.NAME: CDCR3,
        # CDCR4.NAME: CDCR4,
        # CDCR5.NAME: CDCR5,
        # CDDR0.NAME: CDDR0,
        # CDDR1.NAME: CDDR1,
        # CDDR2.NAME: CDDR2,
        # CDDR3.NAME: CDDR3,
        # CDDR4.NAME: CDDR4,
        # CDDR5.NAME: CDDR5,
        # CFGAR0.NAME: CFGAR0,
        # CFGAR1.NAME: CFGAR1,
        # CFGAR2.NAME: CFGAR2,
        # CFGAR3.NAME: CFGAR3,
        # CFGAR4.NAME: CFGAR4,
        # CFGAR5.NAME: CFGAR5,
        # CFGBR0.NAME: CFGBR0,
        # CFGBR1.NAME: CFGBR1,
        # CFGBR2.NAME: CFGBR2,
        # CFGBR3.NAME: CFGBR3,
        # CFGBR4.NAME: CFGBR4,
        # CFGBR5.NAME: CFGBR5,
        # AVAR0.NAME: AVAR0,
        # AVAR1.NAME: AVAR1,
        # AVAR2.NAME: AVAR2,
        # AVAR3.NAME: AVAR3,
        # AVAR4.NAME: AVAR4,
        # AVAR5.NAME: AVAR5,
        # AVBR0.NAME: AVBR0,
        # AVBR1.NAME: AVBR1,
        # AVBR2.NAME: AVBR2,
        # AVBR3.NAME: AVBR3,
        # AVBR4.NAME: AVBR4,
        # AVBR5.NAME: AVBR5,
        # AVCR0.NAME: AVCR0,
        # AVCR1.NAME: AVCR1,
        # AVCR2.NAME: AVCR2,
        # AVCR3.NAME: AVCR3,
        # AVCR4.NAME: AVCR4,
        # AVCR5.NAME: AVCR5,
        # STAR0.NAME: STAR0,
        # STAR1.NAME: STAR1,
        # STAR2.NAME: STAR2,
        # STAR3.NAME: STAR3,
        # STAR4.NAME: STAR4,
        # STAR5.NAME: STAR5,
        # STBR0.NAME: STBR0,
        # STBR1.NAME: STBR1,
        # STBR2.NAME: STBR2,
        # STBR3.NAME: STBR3,
        # STBR4.NAME: STBR4,
        # STBR5.NAME: STBR5,
        # STCR0.NAME: STCR0,
        # STCR1.NAME: STCR1,
        # STCR2.NAME: STCR2,
        # STCR3.NAME: STCR3,
        # STCR4.NAME: STCR4,
        # STCR5.NAME: STCR5,
        # COMM0.NAME: COMM0,
        # COMM1.NAME: COMM1,
        # COMM2.NAME: COMM2,
        # COMM3.NAME: COMM3,
        # COMM4.NAME: COMM4,
        # COMM5.NAME: COMM5,
        # PWMR0.NAME: PWMR0,
        # PWMR1.NAME: PWMR1,
        # PWMR2.NAME: PWMR2,
        # PWMR3.NAME: PWMR3,
        # PWMR4.NAME: PWMR4,
        # PWMR5.NAME: PWMR5,
        # SIDR0.NAME: SIDR0,
        # SIDR1.NAME: SIDR1,
        # SIDR2.NAME: SIDR2,
        # SIDR3.NAME: SIDR3,
        # SIDR4.NAME: SIDR4,
        # SIDR5.NAME: SIDR5,
        # # CFD0.NAME: CFD0,
        # # CFD1.NAME: CFD1,
        # # WRITE_DATA_REGISTER.NAME: WRITE_DATA_REGISTER
    }
    BITFIELDS = {
        **bmsbase.BMS_Config.BITFIELDS,
        CMD0.NAME: CMD0,
        CMD1.NAME: CMD1,
        CMD_PEC.NAME: CMD_PEC,
        DATA_PEC.NAME: DATA_PEC,
        ADDR.NAME: ADDR,
        MD.NAME: MD,
        CH.NAME: CH,
        CHG.NAME: CHG,
        CHST.NAME: CHST,
        PUP.NAME: PUP,
        ST.NAME: ST,
        DCP.NAME: DCP,
        ICOM0.NAME: ICOM0,
        ICOM1.NAME: ICOM1,
        ICOM2.NAME: ICOM2,
        FCOM0.NAME: FCOM0,
        FCOM1.NAME: FCOM1,
        FCOM2.NAME: FCOM2,
        D0.NAME: D0,
        D1.NAME: D1,
        D2.NAME: D2,
        DATA0.NAME: DATA0,
        DATA1.NAME: DATA1,
        DATA2.NAME: DATA2,
        DATA3.NAME: DATA3,
        DATA4.NAME: DATA4,
        DATA5.NAME: DATA5,
    }
    COMMANDS = {
        **bmsbase.BMS_Config.COMMANDS,
        ADAX.NAME: ADAX,
        ADAXD.NAME: ADAXD,
        ADAXD_Addressed.NAME: ADAXD_Addressed,
        ADAX_Addressed.NAME: ADAX_Addressed,
        ADCV.NAME: ADCV,
        ADCVAX.NAME: ADCVAX,
        ADCVAX_Addressed.NAME: ADCVAX_Addressed,
        ADCVSC.NAME: ADCVSC,
        ADCVSC_Addressed.NAME: ADCVSC_Addressed,
        ADCVSOC.NAME: ADCVSOC,
        ADCVSOC_Addressed.NAME: ADCVSOC_Addressed,
        ADCV_Addressed.NAME: ADCV_Addressed,
        ADOL.NAME: ADOL,
        ADOL_Addressed.NAME: ADOL_Addressed,
        ADOW.NAME: ADOW,
        ADOW_Addressed.NAME: ADOW_Addressed,
        ADSTAT.NAME: ADSTAT,
        ADSTATD.NAME: ADSTATD,
        ADSTATD_Addressed.NAME: ADSTATD_Addressed,
        ADSTAT_Addressed.NAME: ADSTAT_Addressed,
        AXOW.NAME: AXOW,
        AXOW_Addressed.NAME: AXOW_Addressed,
        AXST.NAME: AXST,
        AXST_Addressed.NAME: AXST_Addressed,
        CLRAUX.NAME: CLRAUX,
        CLRAUX_Addressed.NAME: CLRAUX_Addressed,
        CLRCELL.NAME: CLRCELL,
        CLRCELL_Addressed.NAME: CLRCELL_Addressed,
        CLRSCTRL.NAME: CLRSCTRL,
        CLRSCTRL_Addressed.NAME: CLRSCTRL_Addressed,
        CLRSTAT.NAME: CLRSTAT,
        CLRSTAT_Addressed.NAME: CLRSTAT_Addressed,
        CVST.NAME: CVST,
        CVST_Addressed.NAME: CVST_Addressed,
        DIAGN.NAME: DIAGN,
        DIAGN_Addressed.NAME: DIAGN_Addressed,
        MUTE.NAME: MUTE,
        MUTE_Addressed.NAME: MUTE_Addressed,
        PLADC.NAME: PLADC,
        PLADC_Addressed.NAME: PLADC_Addressed,
        RDAUXA.NAME: RDAUXA,
        RDAUXA_Addressed.NAME: RDAUXA_Addressed,
        RDAUXB.NAME: RDAUXB,
        RDAUXB_Addressed.NAME: RDAUXB_Addressed,
        RDAUXC.NAME: RDAUXC,
        RDAUXC_Addressed.NAME: RDAUXC_Addressed,
        RDAUXD.NAME: RDAUXD,
        RDAUXD_Addressed.NAME: RDAUXD_Addressed,
        RDCFGA.NAME: RDCFGA,
        RDCFGA_Addressed.NAME: RDCFGA_Addressed,
        RDCFGB.NAME: RDCFGB,
        RDCFGB_Addressed.NAME: RDCFGB_Addressed,
        RDCOMM.NAME: RDCOMM,
        RDCOMM_Addressed.NAME: RDCOMM_Addressed,
        RDSA.NAME: RDSA,
        RDSA_Addressed.NAME: RDSA_Addressed,
        RDSB.NAME: RDSB,
        RDSB_Addressed.NAME: RDSB_Addressed,
        RDCVA.NAME: RDCVA,
        RDCVA_Addressed.NAME: RDCVA_Addressed,
        RDCVB.NAME: RDCVB,
        RDCVB_Addressed.NAME: RDCVB_Addressed,
        RDCVC.NAME: RDCVC,
        RDCVC_Addressed.NAME: RDCVC_Addressed,
        RDCVD.NAME: RDCVD,
        RDCVD_Addressed.NAME: RDCVD_Addressed,
        RDCVE.NAME: RDCVE,
        RDCVE_Addressed.NAME: RDCVE_Addressed,
        RDCVF.NAME: RDCVF,
        RDCVF_Addressed.NAME: RDCVF_Addressed,
        RDPSB.NAME: RDPSB,
        RDPSB_Addressed.NAME: RDPSB_Addressed,
        RDPWM.NAME: RDPWM,
        RDPWM_Addressed.NAME: RDPWM_Addressed,
        RDSCTRL.NAME: RDSCTRL,
        RDSCTRL_Addressed.NAME: RDSCTRL_Addressed,
        RDSTATA.NAME: RDSTATA,
        RDSTATA_Addressed.NAME: RDSTATA_Addressed,
        RDSTATB.NAME: RDSTATB,
        RDSTATB_Addressed.NAME: RDSTATB_Addressed,
        STATST.NAME: STATST,
        STATST_Addressed.NAME: STATST_Addressed,
        STCOMM.NAME: STCOMM,
        STCOMM_Addressed.NAME: STCOMM_Addressed,
        STSCTRL.NAME: STSCTRL,
        STSCTRL_Addressed.NAME: STSCTRL_Addressed,
        UNMUTE.NAME: UNMUTE,
        UNMUTE_Addressed.NAME: UNMUTE_Addressed,
        WRCFGA.NAME: WRCFGA,
        WRCFGA_Addressed.NAME: WRCFGA_Addressed,
        WRCFGB.NAME: WRCFGB,
        WRCFGB_Addressed.NAME: WRCFGB_Addressed,
        WRCOMM.NAME: WRCOMM,
        WRCOMM_Addressed.NAME: WRCOMM_Addressed,
        WRPSB.NAME: WRPSB,
        WRPSB_Addressed.NAME: WRPSB_Addressed,
        WRPWM.NAME: WRPWM,
        WRPWM_Addressed.NAME: WRPWM_Addressed,
        WRSCTRL.NAME: WRSCTRL,
        WRSCTRL_Addressed.NAME: WRSCTRL_Addressed,
        Broadcast_Command.NAME: Broadcast_Command,
        Read_Command.NAME: Read_Command,
        Write_Command.NAME: Write_Command
    }

    CELL_CONVERSION_CMDS = []
    SPIN_CONVERSION_CMDS = []
    AUX_CONVERSION_CMDS = []
    STAT_CONVERSION_CMDS = []
    CELL_ADC_POLL_CMDS = []
    AUX_ADC_POLL_CMDS = []
    STAT_ADC_POLL_CMDS = []
    ADC_POLL_CMDS = []
    SPIN_ADC_POLL_CMDS = []
    CELL_READ_CMDS = []
    SPIN_READ_CMDS = []
    AUX_READ_CMDS = []
    STAT_READ_CMDS = []
    WAKEUP_CMDS = []
    BCI_COM_CMD_LIST = []
    BCI_ANALOG_CMD_LIST = []
    GUI_LOOP_CMD_LIST = []
    SAFETY_COMMAND_LISTS = {}
    MAX_SPI_SPEED_CMDS = [
        {'command': '$SPI_SET_FREQUENCY_kHz$', 'arguments': {'Frequency': 1000}}
    ]
    GUI_CFG = []
    GUI_METRICS = []
