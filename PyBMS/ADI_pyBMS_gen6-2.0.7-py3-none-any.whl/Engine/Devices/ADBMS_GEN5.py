# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from abc import ABC
import Engine.Devices.BMS_Config as bmsbase


# ===================================================== Bitfields =====================================================
class CMD0(bmsbase.BitfieldInt):
    NAME = 'CMD0'
    DESCRIPTION = 'Command Byte 0'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD0, self).__init__(CMD0.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMD0.NAME


class CMD1(bmsbase.BitfieldInt):
    NAME = 'CMD1'
    DESCRIPTION = 'Command Byte 1'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD1, self).__init__(CMD1.LENGTH, value=value, raw_value=raw_value)
        self.name = CMD1.NAME


class CCNT(bmsbase.BitfieldInt):
    NAME = 'CCNT'
    DESCRIPTION = 'Command Counter'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 63
    MIN_VALUE = 0
    LENGTH = 6
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CCNT, self).__init__(CCNT.LENGTH, value=value, raw_value=raw_value)
        self.name = CCNT.NAME


class CMD_PEC(bmsbase.BitfieldPEC):
    NAME = 'CMD PEC'
    DESCRIPTION = 'Command PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=16):
        super(CMD_PEC, self).__init__(CMD_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = CMD_PEC.NAME
        self.crc_cal_func = self.calc_pec15


class DATA_PEC(bmsbase.BitfieldPEC):
    NAME = 'DATA PEC'
    DESCRIPTION = 'Data PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 10
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=54):
        super(DATA_PEC, self).__init__(DATA_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = DATA_PEC.NAME
        self.crc_cal_func = self.calc_pec10


class DATA0(bmsbase.BitfieldInt):
    NAME = 'DATA0'
    DESCRIPTION = 'Data Byte 0'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA0, self).__init__(DATA0.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA0.NAME


class DATA1(bmsbase.BitfieldInt):
    NAME = 'DATA1'
    DESCRIPTION = 'Data Byte 1'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA1, self).__init__(DATA1.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA1.NAME


class DATA2(bmsbase.BitfieldInt):
    NAME = 'DATA2'
    DESCRIPTION = 'Data Byte 2'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA2, self).__init__(DATA2.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA2.NAME


class DATA3(bmsbase.BitfieldInt):
    NAME = 'DATA3'
    DESCRIPTION = 'Data Byte 3'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA3, self).__init__(DATA3.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA3.NAME


class DATA4(bmsbase.BitfieldInt):
    NAME = 'DATA4'
    DESCRIPTION = 'Data Byte 4'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA4, self).__init__(DATA4.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA4.NAME


class DATA5(bmsbase.BitfieldInt):
    NAME = 'DATA5'
    DESCRIPTION = 'Data Byte 5'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA5, self).__init__(DATA5.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA5.NAME


class MD(bmsbase.BitfieldInt):
    NAME = 'MD'
    DESCRIPTION = 'Filter Mode'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 2
    MAX_VALUE = 3
    MIN_VALUE = 0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=2, raw_value=2):
        super(MD, self).__init__(MD.LENGTH,  value=value, raw_value=raw_value)
        self.name = MD.NAME


class CH(bmsbase.BitfieldInt):
    NAME = 'CH'
    DESCRIPTION = 'Cell Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CH, self).__init__(CH.LENGTH,  value=value, raw_value=raw_value)
        self.name = CH.NAME


class DC(bmsbase.BitfieldBool):
    NAME = 'DC'
    DESCRIPTION = 'Discharge During Conversion Enable'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DC, self).__init__(DC.LENGTH,  value=value, raw_value=raw_value)
        self.name = DC.NAME


class REFON(bmsbase.BitfieldBool):
    NAME = 'REFON'
    DESCRIPTION = 'Reference Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=True, raw_value=1):
        super(REFON, self).__init__(REFON.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFON.NAME


class DIS_RED(bmsbase.BitfieldBool):
    NAME = 'DIS_RED'
    DESCRIPTION = 'Disable Digital Redundancy'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=True, raw_value=1):
        super(DIS_RED, self).__init__(DIS_RED.LENGTH,  value=value, raw_value=raw_value)
        self.name = DIS_RED.NAME


class ADCOPT(bmsbase.BitfieldBool):
    NAME = 'ADCOPT'
    DESCRIPTION = 'ADC Filter Mode Option'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(ADCOPT, self).__init__(ADCOPT.LENGTH,  value=value, raw_value=raw_value)
        self.name = ADCOPT.NAME


class MCAL(bmsbase.BitfieldBool):
    NAME = 'MCAL'
    DESCRIPTION = 'ADC Multiple Calibration Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MCAL, self).__init__(MCAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = MCAL.NAME


class COMM_BK(bmsbase.BitfieldBool):
    NAME = 'COMM_BK'
    DESCRIPTION = 'Communication Break Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(COMM_BK, self).__init__(COMM_BK.LENGTH,  value=value, raw_value=raw_value)
        self.name = COMM_BK.NAME


class SOAKON(bmsbase.BitfieldBool):
    NAME = 'SOAKON'
    DESCRIPTION = 'ADC Soak Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SOAKON, self).__init__(SOAKON.LENGTH,  value=value, raw_value=raw_value)
        self.name = SOAKON.NAME


class OWRNG(bmsbase.BitfieldBool):
    NAME = 'OWRNG'
    DESCRIPTION = 'Open Wire Soak Range Option'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OWRNG, self).__init__(OWRNG.LENGTH,  value=value, raw_value=raw_value)
        self.name = OWRNG.NAME


class GPO1(bmsbase.BitfieldBool):
    NAME = 'GPO1'
    DESCRIPTION = 'GPIO 1 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1, self).__init__(GPO1.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1.NAME


class GPO2(bmsbase.BitfieldBool):
    NAME = 'GPO2'
    DESCRIPTION = 'GPIO 2 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2, self).__init__(GPO2.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2.NAME


class GPO3(bmsbase.BitfieldBool):
    NAME = 'GPO3'
    DESCRIPTION = 'GPIO 3 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3, self).__init__(GPO3.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3.NAME


class GPO4(bmsbase.BitfieldBool):
    NAME = 'GPO4'
    DESCRIPTION = 'GPIO 4 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4, self).__init__(GPO4.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4.NAME


class GPO5(bmsbase.BitfieldBool):
    NAME = 'GPO5'
    DESCRIPTION = 'GPIO 5 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5, self).__init__(GPO5.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5.NAME


class GPO6(bmsbase.BitfieldBool):
    NAME = 'GPO6'
    DESCRIPTION = 'GPIO 6 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO6, self).__init__(GPO6.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6.NAME


class GPO7(bmsbase.BitfieldBool):
    NAME = 'GPO7'
    DESCRIPTION = 'GPIO 7 output state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO7, self).__init__(GPO7.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO7.NAME


class GPI1(bmsbase.BitfieldBool):
    NAME = 'GPI1'
    DESCRIPTION = 'GPIO 1 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI1, self).__init__(GPI1.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI1.NAME


class GPI2(bmsbase.BitfieldBool):
    NAME = 'GPI2'
    DESCRIPTION = 'GPIO 2 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI2, self).__init__(GPI2.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI2.NAME


class GPI3(bmsbase.BitfieldBool):
    NAME = 'GPI3'
    DESCRIPTION = 'GPIO 3 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI3, self).__init__(GPI3.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI3.NAME


class GPI4(bmsbase.BitfieldBool):
    NAME = 'GPI4'
    DESCRIPTION = 'GPIO 4 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI4, self).__init__(GPI4.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI4.NAME


class GPI5(bmsbase.BitfieldBool):
    NAME = 'GPI5'
    DESCRIPTION = 'GPIO 5 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI5, self).__init__(GPI5.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI5.NAME


class GPI6(bmsbase.BitfieldBool):
    NAME = 'GPI6'
    DESCRIPTION = 'GPIO 6 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI6, self).__init__(GPI6.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI6.NAME


class GPI7(bmsbase.BitfieldBool):
    NAME = 'GPI7'
    DESCRIPTION = 'GPIO 7 input state'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI7, self).__init__(GPI7.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI7.NAME


class DTMEN(bmsbase.BitfieldBool):
    NAME = 'DTMEN'
    DESCRIPTION = 'Discharge Monitor Timer Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTMEN, self).__init__(DTMEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTMEN.NAME


class DTRNG(bmsbase.BitfieldBool):
    NAME = 'DTRNG'
    DESCRIPTION = 'Discharge Monitor Timer Range Option'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTRNG, self).__init__(DTRNG.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTRNG.NAME


class DCC1(bmsbase.BitfieldBool):
    NAME = 'DCC1'
    DESCRIPTION = 'Channel 1 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC1, self).__init__(DCC1.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC1.NAME


class DCC2(bmsbase.BitfieldBool):
    NAME = 'DCC2'
    DESCRIPTION = 'Channel 2 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC2, self).__init__(DCC2.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC2.NAME


class DCC3(bmsbase.BitfieldBool):
    NAME = 'DCC3'
    DESCRIPTION = 'Channel 3 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC3, self).__init__(DCC3.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC3.NAME


class DCC4(bmsbase.BitfieldBool):
    NAME = 'DCC4'
    DESCRIPTION = 'Channel 4 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC4, self).__init__(DCC4.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC4.NAME


class DCC5(bmsbase.BitfieldBool):
    NAME = 'DCC5'
    DESCRIPTION = 'Channel 5 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC5, self).__init__(DCC5.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC5.NAME


class DCC6(bmsbase.BitfieldBool):
    NAME = 'DCC6'
    DESCRIPTION = 'Channel 6 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC6, self).__init__(DCC6.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC6.NAME


class DCC7(bmsbase.BitfieldBool):
    NAME = 'DCC7'
    DESCRIPTION = 'Channel 7 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC7, self).__init__(DCC7.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC7.NAME


class DCC8(bmsbase.BitfieldBool):
    NAME = 'DCC8'
    DESCRIPTION = 'Channel 8 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC8, self).__init__(DCC8.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC8.NAME


class DCC9(bmsbase.BitfieldBool):
    NAME = 'DCC9'
    DESCRIPTION = 'Channel 9 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC9, self).__init__(DCC9.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC9.NAME


class DCC10(bmsbase.BitfieldBool):
    NAME = 'DCC10'
    DESCRIPTION = 'Channel 10 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC10, self).__init__(DCC10.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC10.NAME


class DCC11(bmsbase.BitfieldBool):
    NAME = 'DCC11'
    DESCRIPTION = 'Channel 11 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC11, self).__init__(DCC11.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC11.NAME


class DCC12(bmsbase.BitfieldBool):
    NAME = 'DCC12'
    DESCRIPTION = 'Channel 12 Discharge Switch Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC12, self).__init__(DCC12.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC12.NAME


class MUTE_ST(bmsbase.BitfieldBool):
    NAME = 'MUTE_ST'
    DESCRIPTION = 'Discharge Mute Status'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MUTE_ST, self).__init__(MUTE_ST.LENGTH,  value=value, raw_value=raw_value)
        self.name = MUTE_ST.NAME


class C1OV(bmsbase.BitfieldBool):
    NAME = 'C1OV'
    DESCRIPTION = 'Cell 1 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1OV, self).__init__(C1OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1OV.NAME


class C2OV(bmsbase.BitfieldBool):
    NAME = 'C2OV'
    DESCRIPTION = 'Cell 2 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2OV, self).__init__(C2OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2OV.NAME


class C3OV(bmsbase.BitfieldBool):
    NAME = 'C3OV'
    DESCRIPTION = 'Cell 3 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3OV, self).__init__(C3OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3OV.NAME


class C4OV(bmsbase.BitfieldBool):
    NAME = 'C4OV'
    DESCRIPTION = 'Cell 4 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4OV, self).__init__(C4OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4OV.NAME


class C5OV(bmsbase.BitfieldBool):
    NAME = 'C5OV'
    DESCRIPTION = 'Cell 5 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5OV, self).__init__(C5OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5OV.NAME


class C6OV(bmsbase.BitfieldBool):
    NAME = 'C6OV'
    DESCRIPTION = 'Cell 6 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6OV, self).__init__(C6OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6OV.NAME


class C7OV(bmsbase.BitfieldBool):
    NAME = 'C7OV'
    DESCRIPTION = 'Cell 7 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7OV, self).__init__(C7OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7OV.NAME


class C8OV(bmsbase.BitfieldBool):
    NAME = 'C8OV'
    DESCRIPTION = 'Cell 8 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8OV, self).__init__(C8OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8OV.NAME


class C9OV(bmsbase.BitfieldBool):
    NAME = 'C9OV'
    DESCRIPTION = 'Cell 9 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9OV, self).__init__(C9OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9OV.NAME


class C10OV(bmsbase.BitfieldBool):
    NAME = 'C10OV'
    DESCRIPTION = 'Cell 10 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10OV, self).__init__(C10OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10OV.NAME


class C11OV(bmsbase.BitfieldBool):
    NAME = 'C11OV'
    DESCRIPTION = 'Cell 11 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11OV, self).__init__(C11OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11OV.NAME


class C12OV(bmsbase.BitfieldBool):
    NAME = 'C12OV'
    DESCRIPTION = 'Cell 12 Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12OV, self).__init__(C12OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12OV.NAME


class C1UV(bmsbase.BitfieldBool):
    NAME = 'C1UV'
    DESCRIPTION = 'Cell 1 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1UV, self).__init__(C1UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1UV.NAME


class C2UV(bmsbase.BitfieldBool):
    NAME = 'C2UV'
    DESCRIPTION = 'Cell 2 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2UV, self).__init__(C2UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2UV.NAME


class C3UV(bmsbase.BitfieldBool):
    NAME = 'C3UV'
    DESCRIPTION = 'Cell 3 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3UV, self).__init__(C3UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3UV.NAME


class C4UV(bmsbase.BitfieldBool):
    NAME = 'C4UV'
    DESCRIPTION = 'Cell 4 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4UV, self).__init__(C4UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4UV.NAME


class C5UV(bmsbase.BitfieldBool):
    NAME = 'C5UV'
    DESCRIPTION = 'Cell 5 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5UV, self).__init__(C5UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5UV.NAME


class C6UV(bmsbase.BitfieldBool):
    NAME = 'C6UV'
    DESCRIPTION = 'Cell 6 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6UV, self).__init__(C6UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6UV.NAME


class C7UV(bmsbase.BitfieldBool):
    NAME = 'C7UV'
    DESCRIPTION = 'Cell 7 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7UV, self).__init__(C7UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7UV.NAME


class C8UV(bmsbase.BitfieldBool):
    NAME = 'C8UV'
    DESCRIPTION = 'Cell 8 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8UV, self).__init__(C8UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8UV.NAME


class C9UV(bmsbase.BitfieldBool):
    NAME = 'C9UV'
    DESCRIPTION = 'Cell 9 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9UV, self).__init__(C9UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9UV.NAME


class C10UV(bmsbase.BitfieldBool):
    NAME = 'C10UV'
    DESCRIPTION = 'Cell 10 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10UV, self).__init__(C10UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10UV.NAME


class C11UV(bmsbase.BitfieldBool):
    NAME = 'C11UV'
    DESCRIPTION = 'Cell 11 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11UV, self).__init__(C11UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11UV.NAME


class C12UV(bmsbase.BitfieldBool):
    NAME = 'C12UV'
    DESCRIPTION = 'Cell 12 Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12UV, self).__init__(C12UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12UV.NAME


class VA_OVHI(bmsbase.BitfieldBool):
    NAME = 'VA_OVHI'
    DESCRIPTION = 'Vreg Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VA_OVHI, self).__init__(VA_OVHI.LENGTH,  value=value, raw_value=raw_value)
        self.name = VA_OVHI.NAME


class VA_UVLO(bmsbase.BitfieldBool):
    NAME = 'VA_UVLO'
    DESCRIPTION = 'Vreg Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VA_UVLO, self).__init__(VA_UVLO.LENGTH,  value=value, raw_value=raw_value)
        self.name = VA_UVLO.NAME


class VD_OVHI(bmsbase.BitfieldBool):
    NAME = 'VD_OVHI'
    DESCRIPTION = 'Digital Voltage Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VD_OVHI, self).__init__(VD_OVHI.LENGTH,  value=value, raw_value=raw_value)
        self.name = VD_OVHI.NAME


class VD_UVLO(bmsbase.BitfieldBool):
    NAME = 'VD_UVLO'
    DESCRIPTION = 'Digital Voltage Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VD_UVLO, self).__init__(VD_UVLO.LENGTH,  value=value, raw_value=raw_value)
        self.name = VD_UVLO.NAME


class A_OTP_ED(bmsbase.BitfieldBool):
    NAME = 'A_OTP_ED'
    DESCRIPTION = 'ADC Trim OTP Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(A_OTP_ED, self).__init__(A_OTP_ED.LENGTH,  value=value, raw_value=raw_value)
        self.name = A_OTP_ED.NAME


class A_OTP_MED(bmsbase.BitfieldBool):
    NAME = 'A_OTP_MED'
    DESCRIPTION = 'ADC Trim OTP Multiple Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(A_OTP_MED, self).__init__(A_OTP_MED.LENGTH,  value=value, raw_value=raw_value)
        self.name = A_OTP_MED.NAME


class REDFAIL(bmsbase.BitfieldBool):
    NAME = 'REDFAIL'
    DESCRIPTION = 'Digital Redundancy Failure Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(REDFAIL, self).__init__(REDFAIL.LENGTH,  value=value, raw_value=raw_value)
        self.name = REDFAIL.NAME


class OTP_ED(bmsbase.BitfieldBool):
    NAME = 'OTP_ED'
    DESCRIPTION = 'Other Trim OTP Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OTP_ED, self).__init__(OTP_ED.LENGTH,  value=value, raw_value=raw_value)
        self.name = OTP_ED.NAME


class OTP_MED(bmsbase.BitfieldBool):
    NAME = 'OTP_MED'
    DESCRIPTION = 'Other Trim OTP Multiple Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OTP_MED, self).__init__(OTP_MED.LENGTH,  value=value, raw_value=raw_value)
        self.name = OTP_MED.NAME


class COMPCHK(bmsbase.BitfieldBool):
    NAME = 'COMPCHK'
    DESCRIPTION = 'ADC Current Compensation Logic Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(COMPCHK, self).__init__(COMPCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = COMPCHK.NAME


class SLEEP(bmsbase.BitfieldBool):
    NAME = 'SLEEP'
    DESCRIPTION = 'Sleep State Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SLEEP, self).__init__(SLEEP.LENGTH,  value=value, raw_value=raw_value)
        self.name = SLEEP.NAME


class TMODECHK(bmsbase.BitfieldBool):
    NAME = 'TMODECHK'
    DESCRIPTION = 'Test Mode Activation Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(TMODECHK, self).__init__(TMODECHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = TMODECHK.NAME


class MUXFAIL(bmsbase.BitfieldBool):
    NAME = 'MUXFAIL'
    DESCRIPTION = 'Multiplexer Self Test Result'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MUXFAIL, self).__init__(MUXFAIL.LENGTH,  value=value, raw_value=raw_value)
        self.name = MUXFAIL.NAME


class THSD(bmsbase.BitfieldBool):
    NAME = 'THSD'
    DESCRIPTION = 'Thermal Shutdown Status'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(THSD, self).__init__(THSD.LENGTH,  value=value, raw_value=raw_value)
        self.name = THSD.NAME


class CPCHK(bmsbase.BitfieldBool):
    NAME = 'CPCHK'
    DESCRIPTION = 'Charge Pump Check Status'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CPCHK, self).__init__(CPCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CPCHK.NAME


class OSCCHK(bmsbase.BitfieldBool):
    NAME = 'OSCCHK'
    DESCRIPTION = 'Oscillator Check Status'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OSCCHK, self).__init__(OSCCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = OSCCHK.NAME


class CL_VA_OVHI(bmsbase.BitfieldBool):
    NAME = 'CL_VA_OVHI'
    DESCRIPTION = 'Clear Vreg Over Voltage Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VA_OVHI, self).__init__(CL_VA_OVHI.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VA_OVHI.NAME


class CL_VA_UVLO(bmsbase.BitfieldBool):
    NAME = 'CL_VA_UVLO'
    DESCRIPTION = 'Clear Vreg Under Voltage Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VA_UVLO, self).__init__(CL_VA_UVLO.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VA_UVLO.NAME


class CL_VD_OVHI(bmsbase.BitfieldBool):
    NAME = 'CL_VD_OVHI'
    DESCRIPTION = 'Clear Digital Voltage Over Voltage Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VD_OVHI, self).__init__(CL_VD_OVHI.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VD_OVHI.NAME


class CL_VD_UVLO(bmsbase.BitfieldBool):
    NAME = 'CL_VD_UVLO'
    DESCRIPTION = 'Clear Digital Voltage Under Voltage Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VD_UVLO, self).__init__(CL_VD_UVLO.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VD_UVLO.NAME


class CL_A_OTP_ED(bmsbase.BitfieldBool):
    NAME = 'CL_A_OTP_ED'
    DESCRIPTION = 'Clear ADC Trim OTP Error Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_A_OTP_ED, self).__init__(CL_A_OTP_ED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_A_OTP_ED.NAME


class CL_A_OTP_MED(bmsbase.BitfieldBool):
    NAME = 'CL_A_OTP_MED'
    DESCRIPTION = 'Clear ADC Trim OTP Multiple Error Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_A_OTP_MED, self).__init__(CL_A_OTP_MED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_A_OTP_MED.NAME


class CL_REDFAIL(bmsbase.BitfieldBool):
    NAME = 'CL_REDFAIL'
    DESCRIPTION = 'Clear Digital Redundancy Failure Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_REDFAIL, self).__init__(CL_REDFAIL.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_REDFAIL.NAME


class CL_OTP_ED(bmsbase.BitfieldBool):
    NAME = 'CL_OTP_ED'
    DESCRIPTION = 'Clear Other Trim OTP Error Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_OTP_ED, self).__init__(CL_OTP_ED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_OTP_ED.NAME


class CL_OTP_MED(bmsbase.BitfieldBool):
    NAME = 'CL_OTP_MED'
    DESCRIPTION = 'Clear Other Trim OTP Multiple Error Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_OTP_MED, self).__init__(CL_OTP_MED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_OTP_MED.NAME


class CL_COMPCHK(bmsbase.BitfieldBool):
    NAME = 'CL_COMPCHK'
    DESCRIPTION = 'Clear ADC Current Compensation Logic Error Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_COMPCHK, self).__init__(CL_COMPCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_COMPCHK.NAME


class CL_SLEEP(bmsbase.BitfieldBool):
    NAME = 'CL_SLEEP'
    DESCRIPTION = 'Clear Sleep State Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_SLEEP, self).__init__(CL_SLEEP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_SLEEP.NAME


class CL_TMODECHK(bmsbase.BitfieldBool):
    NAME = 'CL_TMODECHK'
    DESCRIPTION = 'Clear Test Mode Activation Detection Flag'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_TMODECHK, self).__init__(CL_TMODECHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_TMODECHK.NAME


class CL_MUXFAIL(bmsbase.BitfieldBool):
    NAME = 'CL_MUXFAIL'
    DESCRIPTION = 'Clear Multiplexer Self Test Result'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_MUXFAIL, self).__init__(CL_MUXFAIL.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_MUXFAIL.NAME


class CL_THSD(bmsbase.BitfieldBool):
    NAME = 'CL_THSD'
    DESCRIPTION = 'Clear Thermal Shutdown Status'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_THSD, self).__init__(CL_THSD.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_THSD.NAME


class CL_CPCHK(bmsbase.BitfieldBool):
    NAME = 'CL_CPCHK'
    DESCRIPTION = 'Clear Charge Pump Check Status'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CPCHK, self).__init__(CL_CPCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CPCHK.NAME


class CL_OSCCHK(bmsbase.BitfieldBool):
    NAME = 'CL_OSCCHK'
    DESCRIPTION = 'Clear Oscillator Check Status'
    MEM_KEY = 'Clear Flag Register Group'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_OSCCHK, self).__init__(CL_OSCCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_OSCCHK.NAME


class PUP(bmsbase.BitfieldBool):
    NAME = 'PUP'
    DESCRIPTION = 'Pull Up/Down Current Source for Open Wire Detection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(PUP, self).__init__(PUP.LENGTH,  value=value, raw_value=raw_value)
        self.name = PUP.NAME


class STR(bmsbase.BitfieldBool):
    NAME = 'STR'
    DESCRIPTION = 'Stretch/Squeeze Current for Open Wire Detection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(STR, self).__init__(STR.LENGTH,  value=value, raw_value=raw_value)
        self.name = STR.NAME


class PS(bmsbase.BitfieldInt):
    NAME = 'PS'
    DESCRIPTION = 'Digital Redundancy Path Selection'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 3
    MIN_VALUE = 0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PS, self).__init__(PS.LENGTH,  value=value, raw_value=raw_value)
        self.name = PS.NAME


class CVMIN(bmsbase.BitfieldInt):
    NAME = 'CVMIN'
    DESCRIPTION = 'Minimum Cell Voltage for CVOW Operation'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 3
    MIN_VALUE = 0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CVMIN, self).__init__(CVMIN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CVMIN.NAME


class FLAG_D(bmsbase.BitfieldInt):
    NAME = 'FLAG_D'
    DESCRIPTION = 'Diagnostic Mode Selection'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FLAG_D, self).__init__(FLAG_D.LENGTH,  value=value, raw_value=raw_value)
        self.name = FLAG_D.NAME


class OWA(bmsbase.BitfieldInt):
    NAME = 'OWA'
    DESCRIPTION = 'Auxiliary Open Wire Soak Time'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OWA, self).__init__(OWA.LENGTH,  value=value, raw_value=raw_value)
        self.name = OWA.NAME


class OWC(bmsbase.BitfieldInt):
    NAME = 'OWC'
    DESCRIPTION = 'Open Wire Soak Time'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OWC, self).__init__(OWC.LENGTH,  value=value, raw_value=raw_value)
        self.name = OWC.NAME


class REV(bmsbase.BitfieldInt):
    NAME = 'REV'
    DESCRIPTION = 'Silicon Revision'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 15
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REV, self).__init__(REV.LENGTH,  value=value, raw_value=raw_value)
        self.name = REV.NAME


class DCTO(bmsbase.BitfieldInt):
    NAME = 'DCTO'
    DESCRIPTION = 'Discharge Timeout Setting'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x3F
    MIN_VALUE = 0
    LENGTH = 6
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DCTO, self).__init__(DCTO.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCTO.NAME


class OC_CNTR(bmsbase.BitfieldInt):
    NAME = 'OC_CNTR'
    DESCRIPTION = 'Oscillator Check Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC_CNTR, self).__init__(OC_CNTR.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC_CNTR.NAME


class ICOM0(bmsbase.BitfieldInt):
    NAME = 'ICOM0'
    DESCRIPTION = 'Initial Communication Control Setting Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM0, self).__init__(ICOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM0.NAME


class ICOM1(bmsbase.BitfieldInt):
    NAME = 'ICOM1'
    DESCRIPTION = 'Initial Communication Control Setting Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM1, self).__init__(ICOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM1.NAME


class ICOM2(bmsbase.BitfieldInt):
    NAME = 'ICOM2'
    DESCRIPTION = 'Initial Communication Control Setting Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ICOM2, self).__init__(ICOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM2.NAME


class D0(bmsbase.BitfieldInt):
    NAME = 'D0'
    DESCRIPTION = 'Communication Data Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D0, self).__init__(D0.LENGTH,  value=value, raw_value=raw_value)
        self.name = D0.NAME


class D1(bmsbase.BitfieldInt):
    NAME = 'D1'
    DESCRIPTION = 'Communication Data Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D1, self).__init__(D1.LENGTH,  value=value, raw_value=raw_value)
        self.name = D1.NAME


class D2(bmsbase.BitfieldInt):
    NAME = 'D2'
    DESCRIPTION = 'Communication Data Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D2, self).__init__(D2.LENGTH,  value=value, raw_value=raw_value)
        self.name = D2.NAME


class FCOM0(bmsbase.BitfieldInt):
    NAME = 'FCOM0'
    DESCRIPTION = 'Final Communication Control Setting Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM0, self).__init__(FCOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM0.NAME


class FCOM1(bmsbase.BitfieldInt):
    NAME = 'FCOM1'
    DESCRIPTION = 'Final Communication Control Setting Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM1, self).__init__(FCOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM1.NAME


class FCOM2(bmsbase.BitfieldInt):
    NAME = 'FCOM2'
    DESCRIPTION = 'Final Communication Control Setting Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FCOM2, self).__init__(FCOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM2.NAME


class PWM1(bmsbase.BitfieldInt):
    NAME = 'PWM1'
    DESCRIPTION = 'Cell 1 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM1, self).__init__(PWM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM1.NAME


class PWM2(bmsbase.BitfieldInt):
    NAME = 'PWM2'
    DESCRIPTION = 'Cell 2 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM2, self).__init__(PWM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM2.NAME


class PWM3(bmsbase.BitfieldInt):
    NAME = 'PWM3'
    DESCRIPTION = 'Cell 3 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM3, self).__init__(PWM3.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM3.NAME


class PWM4(bmsbase.BitfieldInt):
    NAME = 'PWM4'
    DESCRIPTION = 'Cell 4 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM4, self).__init__(PWM4.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM4.NAME


class PWM5(bmsbase.BitfieldInt):
    NAME = 'PWM5'
    DESCRIPTION = 'Cell 5 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM5, self).__init__(PWM5.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM5.NAME


class PWM6(bmsbase.BitfieldInt):
    NAME = 'PWM6'
    DESCRIPTION = 'Cell 6 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM6, self).__init__(PWM6.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM6.NAME


class PWM7(bmsbase.BitfieldInt):
    NAME = 'PWM7'
    DESCRIPTION = 'Cell 7 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM7, self).__init__(PWM7.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM7.NAME


class PWM8(bmsbase.BitfieldInt):
    NAME = 'PWM8'
    DESCRIPTION = 'Cell 8 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM8, self).__init__(PWM8.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM8.NAME


class PWM9(bmsbase.BitfieldInt):
    NAME = 'PWM9'
    DESCRIPTION = 'Cell 9 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM9, self).__init__(PWM9.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM9.NAME


class PWM10(bmsbase.BitfieldInt):
    NAME = 'PWM10'
    DESCRIPTION = 'Cell 10 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM10, self).__init__(PWM10.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM10.NAME


class PWM11(bmsbase.BitfieldInt):
    NAME = 'PWM11'
    DESCRIPTION = 'Cell 11 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM11, self).__init__(PWM11.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM11.NAME


class PWM12(bmsbase.BitfieldInt):
    NAME = 'PWM12'
    DESCRIPTION = 'Cell 12 PWM Discharge Configuration'
    MEM_KEY = 'PWM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(PWM12, self).__init__(PWM12.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM12.NAME


class SID(bmsbase.BitfieldInt):
    NAME = 'SID'
    DESCRIPTION = 'Serial ID'
    MEM_KEY = 'Serial ID Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = (2**6)-1
    MIN_VALUE = 0
    LENGTH = 48
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SID, self).__init__(SID.LENGTH,  value=value, raw_value=raw_value)
        self.name = SID.NAME


class CHG(bmsbase.BitfieldInt):
    NAME = 'CHG'
    DESCRIPTION = 'GPIO Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 8
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CHG, self).__init__(CHG.LENGTH,  value=value, raw_value=raw_value)
        self.name = CHG.NAME


class CHST(bmsbase.BitfieldInt):
    NAME = 'CHST'
    DESCRIPTION = 'Status Group Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 4
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CHST, self).__init__(CHST.LENGTH,  value=value, raw_value=raw_value)
        self.name = CHST.NAME


class PG(bmsbase.BitfieldInt):
    NAME = 'PG'
    DESCRIPTION = 'Memory Pattern Generation Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 1
    MAX_VALUE = 2
    MIN_VALUE = 1
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=1, raw_value=1):
        super(PG, self).__init__(PG.LENGTH,  value=value, raw_value=raw_value)
        self.name = PG.NAME


class TEST_DATA0(bmsbase.BitfieldInt):
    NAME = 'TEST_DATA0'
    DESCRIPTION = 'Test Mode Data Byte 0'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TEST_DATA0, self).__init__(TEST_DATA0.LENGTH,  value=value, raw_value=raw_value)
        self.name = TEST_DATA0.NAME


class TEST_DATA1(bmsbase.BitfieldInt):
    NAME = 'TEST_DATA1'
    DESCRIPTION = 'Test Mode Data Byte 1'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TEST_DATA1, self).__init__(TEST_DATA1.LENGTH,  value=value, raw_value=raw_value)
        self.name = TEST_DATA1.NAME


class DTYPE(bmsbase.BitfieldInt):
    NAME = 'DTYPE'
    DESCRIPTION = 'Device Type ID'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DTYPE, self).__init__(DTYPE.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTYPE.NAME


class C1V(bmsbase.BitfieldAdc):
    NAME = 'C1V'
    DESCRIPTION = 'Cell 1'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C1V, self).__init__(C1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C1V.NAME


class C2V(bmsbase.BitfieldAdc):
    NAME = 'C2V'
    DESCRIPTION = 'Cell 2'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C2V, self).__init__(C2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C2V.NAME


class C3V(bmsbase.BitfieldAdc):
    NAME = 'C3V'
    DESCRIPTION = 'Cell 3'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C3V, self).__init__(C3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C3V.NAME


class C4V(bmsbase.BitfieldAdc):
    NAME = 'C4V'
    DESCRIPTION = 'Cell 4'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C4V, self).__init__(C4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C4V.NAME


class C5V(bmsbase.BitfieldAdc):
    NAME = 'C5V'
    DESCRIPTION = 'Cell 5'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C5V, self).__init__(C5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C5V.NAME


class C6V(bmsbase.BitfieldAdc):
    NAME = 'C6V'
    DESCRIPTION = 'Cell 6'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C6V, self).__init__(C6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C6V.NAME


class C7V(bmsbase.BitfieldAdc):
    NAME = 'C7V'
    DESCRIPTION = 'Cell 7'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C7V, self).__init__(C7V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C7V.NAME


class C8V(bmsbase.BitfieldAdc):
    NAME = 'C8V'
    DESCRIPTION = 'Cell 8'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C8V, self).__init__(C8V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C8V.NAME


class C9V(bmsbase.BitfieldAdc):
    NAME = 'C9V'
    DESCRIPTION = 'Cell 9'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C9V, self).__init__(C9V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C9V.NAME


class C10V(bmsbase.BitfieldAdc):
    NAME = 'C10V'
    DESCRIPTION = 'Cell 10'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C10V, self).__init__(C10V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C10V.NAME


class C11V(bmsbase.BitfieldAdc):
    NAME = 'C11V'
    DESCRIPTION = 'Cell 11'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C11V, self).__init__(C11V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C11V.NAME


class C12V(bmsbase.BitfieldAdc):
    NAME = 'C12V'
    DESCRIPTION = 'Cell 12'
    MEM_KEY = 'Cell Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C12V, self).__init__(C12V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = C12V.NAME


class VUV(bmsbase.BitfieldAdc):
    NAME = 'VUV'
    DESCRIPTION = 'Under Voltage Comparison Voltage'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.552
    MIN_VALUE = 0
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VUV, self).__init__(VUV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0)
        self.name = VUV.NAME


class VOV(bmsbase.BitfieldAdc):
    NAME = 'VOV'
    DESCRIPTION = 'Over Voltage Comparison Voltage'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.552
    MIN_VALUE = 0
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VOV, self).__init__(VOV.LENGTH, value=value, raw_value=raw_value, lsb=0.0016, postpend=0, prepend=0)
        self.name = VOV.NAME


class CD1V(bmsbase.BitfieldAdc):
    NAME = 'CD1V'
    DESCRIPTION = 'Diagnostic Voltage Channel 1'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD1V, self).__init__(CD1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD1V.NAME


class CD2V(bmsbase.BitfieldAdc):
    NAME = 'CD2V'
    DESCRIPTION = 'Diagnostic Voltage Channel 2'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD2V, self).__init__(CD2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD2V.NAME


class CD3V(bmsbase.BitfieldAdc):
    NAME = 'CD3V'
    DESCRIPTION = 'Diagnostic Voltage Channel 3'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD3V, self).__init__(CD3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD3V.NAME


class CD4V(bmsbase.BitfieldAdc):
    NAME = 'CD4V'
    DESCRIPTION = 'Diagnostic Voltage Channel 4'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD4V, self).__init__(CD4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD4V.NAME


class CD5V(bmsbase.BitfieldAdc):
    NAME = 'CD5V'
    DESCRIPTION = 'Diagnostic Voltage Channel 5'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD5V, self).__init__(CD5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD5V.NAME


class CD6V(bmsbase.BitfieldAdc):
    NAME = 'CD6V'
    DESCRIPTION = 'Diagnostic Voltage Channel 6'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD6V, self).__init__(CD6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD6V.NAME


class CD7V(bmsbase.BitfieldAdc):
    NAME = 'CD7V'
    DESCRIPTION = 'Diagnostic Voltage Channel 7'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD7V, self).__init__(CD7V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD7V.NAME


class CD8V(bmsbase.BitfieldAdc):
    NAME = 'CD8V'
    DESCRIPTION = 'Diagnostic Voltage Channel 8'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD8V, self).__init__(CD8V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD8V.NAME


class CD9V(bmsbase.BitfieldAdc):
    NAME = 'CD9V'
    DESCRIPTION = 'Diagnostic Voltage Channel 9'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD9V, self).__init__(CD9V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                   twos_complement=True)
        self.name = CD9V.NAME


class CD10V(bmsbase.BitfieldAdc):
    NAME = 'CD10V'
    DESCRIPTION = 'Diagnostic Voltage Channel 10'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD10V, self).__init__(CD10V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                    twos_complement=True)
        self.name = CD10V.NAME


class CD11V(bmsbase.BitfieldAdc):
    NAME = 'CD11V'
    DESCRIPTION = 'Diagnostic Voltage Channel 11'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD11V, self).__init__(CD11V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                    twos_complement=True)
        self.name = CD11V.NAME


class CD12V(bmsbase.BitfieldAdc):
    NAME = 'CD12V'
    DESCRIPTION = 'Diagnostic Voltage Channel 12'
    MEM_KEY = 'Cell Diagnostic Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5534
    MIN_VALUE = -6.5536
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CD12V, self).__init__(CD12V.LENGTH, value=value, raw_value=raw_value, lsb=0.0002, postpend=0, prepend=0,
                                    twos_complement=True)
        self.name = CD12V.NAME


class G1V(bmsbase.BitfieldAdc):
    NAME = 'G1V'
    DESCRIPTION = 'Auxiliary Voltage Channel 1'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G1V, self).__init__(G1V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G1V.NAME


class G2V(bmsbase.BitfieldAdc):
    NAME = 'G2V'
    DESCRIPTION = 'Auxiliary Voltage Channel 2'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G2V, self).__init__(G2V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G2V.NAME


class G3V(bmsbase.BitfieldAdc):
    NAME = 'G3V'
    DESCRIPTION = 'Auxiliary Voltage Channel 3'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G3V, self).__init__(G3V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G3V.NAME


class G4V(bmsbase.BitfieldAdc):
    NAME = 'G4V'
    DESCRIPTION = 'Auxiliary Voltage Channel 4'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G4V, self).__init__(G4V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G4V.NAME


class G5V(bmsbase.BitfieldAdc):
    NAME = 'G5V'
    DESCRIPTION = 'Auxiliary Voltage Channel 5'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G5V, self).__init__(G5V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G5V.NAME


class G6V(bmsbase.BitfieldAdc):
    NAME = 'G6V'
    DESCRIPTION = 'Auxiliary Voltage Channel 6'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G6V, self).__init__(G6V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G6V.NAME


class G7V(bmsbase.BitfieldAdc):
    NAME = 'G7V'
    DESCRIPTION = 'Auxiliary Voltage Channel 7'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G7V, self).__init__(G7V.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = G7V.NAME


class REF2(bmsbase.BitfieldAdc):
    NAME = 'REF2'
    DESCRIPTION = 'Secondary Reference Internal Measurement'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REF2, self).__init__(REF2.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = REF2.NAME


class REF3(bmsbase.BitfieldAdc):
    NAME = 'REF3'
    DESCRIPTION = 'Third Reference Internal Measurement'
    MEM_KEY = 'Auxiliary Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REF3, self).__init__(REF3.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = REF3.NAME


class SC(bmsbase.BitfieldAdc):
    NAME = 'SC'
    DESCRIPTION = 'Sum of All Cells Measurement'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SC, self).__init__(SC.LENGTH, value=value, raw_value=raw_value, lsb=0.0001*20, postpend=0, prepend=0)
        self.name = SC.NAME


class ITMP(bmsbase.BitfieldAdc):
    NAME = 'ITMP'
    DESCRIPTION = 'Die Temperature Measurement'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ITMP, self).__init__(ITMP.LENGTH, value=value, raw_value=raw_value, lsb=0.0001/0.0075, postpend=-260,
                                   prepend=0)
        self.name = ITMP.NAME


class VA(bmsbase.BitfieldAdc):
    NAME = 'VA'
    DESCRIPTION = 'Vreg Internal Measurement'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VA, self).__init__(VA.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = VA.NAME


class VD(bmsbase.BitfieldAdc):
    NAME = 'VD'
    DESCRIPTION = 'Digital Voltage Regulator Internal Measurement'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VD, self).__init__(VD.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = VD.NAME


class ADOL1(bmsbase.BitfieldAdc):
    NAME = 'ADOL1'
    DESCRIPTION = 'ADC Overlap Measurement 1'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ADOL1, self).__init__(ADOL1.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = ADOL1.NAME


class ADOL2(bmsbase.BitfieldAdc):
    NAME = 'ADOL2'
    DESCRIPTION = 'ADC Overlap Measurement 2'
    MEM_KEY = 'Status Voltage'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.5535
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ADOL2, self).__init__(ADOL2.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0)
        self.name = ADOL2.NAME


# ===================================================== Registers =====================================================
class CMD_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command Bytes'
    NAME = 'Command Bytes'
    
    def __init__(self):
        super(CMD_REGISTER, self).__init__(
            [[CMD0, 7], [CMD0, 6], [CMD0, 5], [CMD0, 4], [CMD0, 3], [CMD0, 2], [CMD0, 1], [CMD0, 0],
             [CMD1, 7], [CMD1, 6], [CMD1, 5], [CMD1, 4], [CMD1, 3], [CMD1, 2], [CMD1, 1], [CMD1, 0]])


class CCNT_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command Counter'
    NAME = 'Command Counter'

    def __init__(self):
        super(CCNT_REGISTER, self).__init__(
            [[CCNT, 5], [CCNT, 4], [CCNT, 3], [CCNT, 2], [CCNT, 1], [CCNT, 0]])


class CMD_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command PEC Bytes'
    NAME = 'Command PEC Bytes'

    def __init__(self):
        super(CMD_PEC_REGISTER, self).__init__(
            [[CMD_PEC, 15], [CMD_PEC, 14], [CMD_PEC, 13], [CMD_PEC, 12], [CMD_PEC, 11], [CMD_PEC, 10], [CMD_PEC, 9], [CMD_PEC, 8],
             [CMD_PEC, 7], [CMD_PEC, 6], [CMD_PEC, 5], [CMD_PEC, 4], [CMD_PEC, 3], [CMD_PEC, 2], [CMD_PEC, 1], [CMD_PEC, 0]])


class DATA_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Data PEC Bytes'
    NAME = 'Data PEC Bytes'

    def __init__(self):
        super(DATA_PEC_REGISTER, self).__init__(
            [[DATA_PEC, 9], [DATA_PEC, 8],
             [DATA_PEC, 7], [DATA_PEC, 6], [DATA_PEC, 5], [DATA_PEC, 4], [DATA_PEC, 3], [DATA_PEC, 2], [DATA_PEC, 1], [DATA_PEC, 0]])


class WRITE_DATA_REGISTER(bmsbase.Register):
    MEM_KEY = 'Write Command Bytes'
    NAME = 'Write Command Bytes'

    def __init__(self):
        super(WRITE_DATA_REGISTER, self).__init__(
            [[DATA0, 7], [DATA0, 6], [DATA0, 5], [DATA0, 4], [DATA0, 3], [DATA0, 2], [DATA0, 1], [DATA0, 0],
             [DATA1, 7], [DATA1, 6], [DATA1, 5], [DATA1, 4], [DATA1, 3], [DATA1, 2], [DATA1, 1], [DATA1, 0],
             [DATA2, 7], [DATA2, 6], [DATA2, 5], [DATA2, 4], [DATA2, 3], [DATA2, 2], [DATA2, 1], [DATA2, 0],
             [DATA3, 7], [DATA3, 6], [DATA3, 5], [DATA3, 4], [DATA3, 3], [DATA3, 2], [DATA3, 1], [DATA3, 0],
             [DATA4, 7], [DATA4, 6], [DATA4, 5], [DATA4, 4], [DATA4, 3], [DATA4, 2], [DATA4, 1], [DATA4, 0],
             [DATA5, 7], [DATA5, 6], [DATA5, 5], [DATA5, 4], [DATA5, 3], [DATA5, 2], [DATA5, 1], [DATA5, 0]])


class CVAR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR0'

    def __init__(self):
        super(CVAR0, self).__init__([[C1V, 7], [C1V, 6], [C1V, 5], [C1V, 4], [C1V, 3], [C1V, 2], [C1V, 1], [C1V, 0]])


class CVAR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR1'

    def __init__(self):
        super(CVAR1, self).__init__([[C1V, 15], [C1V, 14], [C1V, 13], [C1V, 12], [C1V, 11], [C1V, 10], [C1V, 9], [C1V, 8]])


class CVAR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR2'

    def __init__(self):
        super(CVAR2, self).__init__([[C2V, 7], [C2V, 6], [C2V, 5], [C2V, 4], [C2V, 3], [C2V, 2], [C2V, 1], [C2V, 0]])


class CVAR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR3'

    def __init__(self):
        super(CVAR3, self).__init__([[C2V, 15], [C2V, 14], [C2V, 13], [C2V, 12], [C2V, 11], [C2V, 10], [C2V, 9], [C2V, 8]])


class CVAR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR4'

    def __init__(self):
        super(CVAR4, self).__init__([[C3V, 7], [C3V, 6], [C3V, 5], [C3V, 4], [C3V, 3], [C3V, 2], [C3V, 1], [C3V, 0]])


class CVAR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR5'

    def __init__(self):
        super(CVAR5, self).__init__([[C3V, 15], [C3V, 14], [C3V, 13], [C3V, 12], [C3V, 11], [C3V, 10], [C3V, 9], [C3V, 8]])


class CVBR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR0'

    def __init__(self):
        super(CVBR0, self).__init__([[C4V, 7], [C4V, 6], [C4V, 5], [C4V, 4], [C4V, 3], [C4V, 2], [C4V, 1], [C4V, 0]])


class CVBR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR1'

    def __init__(self):
        super(CVBR1, self).__init__([[C4V, 15], [C4V, 14], [C4V, 13], [C4V, 12], [C4V, 11], [C4V, 10], [C4V, 9], [C4V, 8]])


class CVBR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR2'

    def __init__(self):
        super(CVBR2, self).__init__([[C5V, 7], [C5V, 6], [C5V, 5], [C5V, 4], [C5V, 3], [C5V, 2], [C5V, 1], [C5V, 0]])


class CVBR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR3'

    def __init__(self):
        super(CVBR3, self).__init__([[C5V, 15], [C5V, 14], [C5V, 13], [C5V, 12], [C5V, 11], [C5V, 10], [C5V, 9], [C5V, 8]])


class CVBR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR4'

    def __init__(self):
        super(CVBR4, self).__init__([[C6V, 7], [C6V, 6], [C6V, 5], [C6V, 4], [C6V, 3], [C6V, 2], [C6V, 1], [C6V, 0]])


class CVBR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR5'

    def __init__(self):
        super(CVBR5, self).__init__([[C6V, 15], [C6V, 14], [C6V, 13], [C6V, 12], [C6V, 11], [C6V, 10], [C6V, 9], [C6V, 8]])


class CVCR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR0'

    def __init__(self):
        super(CVCR0, self).__init__([[C7V, 7], [C7V, 6], [C7V, 5], [C7V, 4], [C7V, 3], [C7V, 2], [C7V, 1], [C7V, 0]])


class CVCR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR1'

    def __init__(self):
        super(CVCR1, self).__init__([[C7V, 15], [C7V, 14], [C7V, 13], [C7V, 12], [C7V, 11], [C7V, 10], [C7V, 9], [C7V, 8]])


class CVCR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR2'

    def __init__(self):
        super(CVCR2, self).__init__([[C8V, 7], [C8V, 6], [C8V, 5], [C8V, 4], [C8V, 3], [C8V, 2], [C8V, 1], [C8V, 0]])


class CVCR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR3'

    def __init__(self):
        super(CVCR3, self).__init__([[C8V, 15], [C8V, 14], [C8V, 13], [C8V, 12], [C8V, 11], [C8V, 10], [C8V, 9], [C8V, 8]])


class CVCR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR4'

    def __init__(self):
        super(CVCR4, self).__init__([[C9V, 7], [C9V, 6], [C9V, 5], [C9V, 4], [C9V, 3], [C9V, 2], [C9V, 1], [C9V, 0]])


class CVCR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR5'

    def __init__(self):
        super(CVCR5, self).__init__([[C9V, 15], [C9V, 14], [C9V, 13], [C9V, 12], [C9V, 11], [C9V, 10], [C9V, 9], [C9V, 8]])


class CVDR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR0'

    def __init__(self):
        super(CVDR0, self).__init__([[C10V, 7], [C10V, 6], [C10V, 5], [C10V, 4], [C10V, 3], [C10V, 2], [C10V, 1], [C10V, 0]])


class CVDR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR1'

    def __init__(self):
        super(CVDR1, self).__init__([[C10V, 15], [C10V, 14], [C10V, 13], [C10V, 12], [C10V, 11], [C10V, 10], [C10V, 9], [C10V, 8]])


class CVDR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR2'

    def __init__(self):
        super(CVDR2, self).__init__([[C11V, 7], [C11V, 6], [C11V, 5], [C11V, 4], [C11V, 3], [C11V, 2], [C11V, 1], [C11V, 0]])


class CVDR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR3'

    def __init__(self):
        super(CVDR3, self).__init__([[C11V, 15], [C11V, 14], [C11V, 13], [C11V, 12], [C11V, 11], [C11V, 10], [C11V, 9], [C11V, 8]])


class CVDR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR4'

    def __init__(self):
        super(CVDR4, self).__init__([[C12V, 7], [C12V, 6], [C12V, 5], [C12V, 4], [C12V, 3], [C12V, 2], [C12V, 1], [C12V, 0]])


class CVDR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR5'

    def __init__(self):
        super(CVDR5, self).__init__([[C12V, 15], [C12V, 14], [C12V, 13], [C12V, 12], [C12V, 11], [C12V, 10], [C12V, 9], [C12V, 8]])


class CDAR0(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR0'

    def __init__(self):
        super(CDAR0, self).__init__([[CD1V, 7], [CD1V, 6], [CD1V, 5], [CD1V, 4], [CD1V, 3], [CD1V, 2], [CD1V, 1], [CD1V, 0]])


class CDAR1(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR1'

    def __init__(self):
        super(CDAR1, self).__init__([[CD1V, 15], [CD1V, 14], [CD1V, 13], [CD1V, 12], [CD1V, 11], [CD1V, 10], [CD1V, 9], [CD1V, 8]])


class CDAR2(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR2'

    def __init__(self):
        super(CDAR2, self).__init__([[CD2V, 7], [CD2V, 6], [CD2V, 5], [CD2V, 4], [CD2V, 3], [CD2V, 2], [CD2V, 1], [CD2V, 0]])


class CDAR3(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR3'

    def __init__(self):
        super(CDAR3, self).__init__([[CD2V, 15], [CD2V, 14], [CD2V, 13], [CD2V, 12], [CD2V, 11], [CD2V, 10], [CD2V, 9], [CD2V, 8]])


class CDAR4(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR4'

    def __init__(self):
        super(CDAR4, self).__init__([[CD3V, 7], [CD3V, 6], [CD3V, 5], [CD3V, 4], [CD3V, 3], [CD3V, 2], [CD3V, 1], [CD3V, 0]])


class CDAR5(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group A'
    NAME = 'CDAR5'

    def __init__(self):
        super(CDAR5, self).__init__([[CD3V, 15], [CD3V, 14], [CD3V, 13], [CD3V, 12], [CD3V, 11], [CD3V, 10], [CD3V, 9], [CD3V, 8]])


class CDBR0(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR0'

    def __init__(self):
        super(CDBR0, self).__init__([[CD4V, 7], [CD4V, 6], [CD4V, 5], [CD4V, 4], [CD4V, 3], [CD4V, 2], [CD4V, 1], [CD4V, 0]])


class CDBR1(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR1'

    def __init__(self):
        super(CDBR1, self).__init__([[CD4V, 15], [CD4V, 14], [CD4V, 13], [CD4V, 12], [CD4V, 11], [CD4V, 10], [CD4V, 9], [CD4V, 8]])


class CDBR2(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR2'

    def __init__(self):
        super(CDBR2, self).__init__([[CD5V, 7], [CD5V, 6], [CD5V, 5], [CD5V, 4], [CD5V, 3], [CD5V, 2], [CD5V, 1], [CD5V, 0]])


class CDBR3(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR3'

    def __init__(self):
        super(CDBR3, self).__init__([[CD5V, 15], [CD5V, 14], [CD5V, 13], [CD5V, 12], [CD5V, 11], [CD5V, 10], [CD5V, 9], [CD5V, 8]])


class CDBR4(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR4'

    def __init__(self):
        super(CDBR4, self).__init__([[CD6V, 7], [CD6V, 6], [CD6V, 5], [CD6V, 4], [CD6V, 3], [CD6V, 2], [CD6V, 1], [CD6V, 0]])


class CDBR5(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group B'
    NAME = 'CDBR5'

    def __init__(self):
        super(CDBR5, self).__init__([[CD6V, 15], [CD6V, 14], [CD6V, 13], [CD6V, 12], [CD6V, 11], [CD6V, 10], [CD6V, 9], [CD6V, 8]])


class CDCR0(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR0'

    def __init__(self):
        super(CDCR0, self).__init__([[CD7V, 7], [CD7V, 6], [CD7V, 5], [CD7V, 4], [CD7V, 3], [CD7V, 2], [CD7V, 1], [CD7V, 0]])


class CDCR1(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR1'

    def __init__(self):
        super(CDCR1, self).__init__([[CD7V, 15], [CD7V, 14], [CD7V, 13], [CD7V, 12], [CD7V, 11], [CD7V, 10], [CD7V, 9], [CD7V, 8]])


class CDCR2(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR2'

    def __init__(self):
        super(CDCR2, self).__init__([[CD8V, 7], [CD8V, 6], [CD8V, 5], [CD8V, 4], [CD8V, 3], [CD8V, 2], [CD8V, 1], [CD8V, 0]])


class CDCR3(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR3'

    def __init__(self):
        super(CDCR3, self).__init__([[CD8V, 15], [CD8V, 14], [CD8V, 13], [CD8V, 12], [CD8V, 11], [CD8V, 10], [CD8V, 9], [CD8V, 8]])


class CDCR4(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR4'

    def __init__(self):
        super(CDCR4, self).__init__([[CD9V, 7], [CD9V, 6], [CD9V, 5], [CD9V, 4], [CD9V, 3], [CD9V, 2], [CD9V, 1], [CD9V, 0]])


class CDCR5(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group C'
    NAME = 'CDCR5'

    def __init__(self):
        super(CDCR5, self).__init__([[CD9V, 15], [CD9V, 14], [CD9V, 13], [CD9V, 12], [CD9V, 11], [CD9V, 10], [CD9V, 9], [CD9V, 8]])


class CDDR0(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR0'

    def __init__(self):
        super(CDDR0, self).__init__([[CD10V, 7], [CD10V, 6], [CD10V, 5], [CD10V, 4], [CD10V, 3], [CD10V, 2], [CD10V, 1], [CD10V, 0]])


class CDDR1(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR1'

    def __init__(self):
        super(CDDR1, self).__init__([[CD10V, 15], [CD10V, 14], [CD10V, 13], [CD10V, 12], [CD10V, 11], [CD10V, 10], [CD10V, 9], [CD10V, 8]])


class CDDR2(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR2'

    def __init__(self):
        super(CDDR2, self).__init__([[CD11V, 7], [CD11V, 6], [CD11V, 5], [CD11V, 4], [CD11V, 3], [CD11V, 2], [CD11V, 1], [CD11V, 0]])


class CDDR3(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR3'

    def __init__(self):
        super(CDDR3, self).__init__([[CD11V, 15], [CD11V, 14], [CD11V, 13], [CD11V, 12], [CD11V, 11], [CD11V, 10], [CD11V, 9], [CD11V, 8]])


class CDDR4(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR4'

    def __init__(self):
        super(CDDR4, self).__init__([[CD12V, 7], [CD12V, 6], [CD12V, 5], [CD12V, 4], [CD12V, 3], [CD12V, 2], [CD12V, 1], [CD12V, 0]])


class CDDR5(bmsbase.Register):
    MEM_KEY = 'Cell Diagnostic Register Group D'
    NAME = 'CDDR5'

    def __init__(self):
        super(CDDR5, self).__init__([[CD12V, 15], [CD12V, 14], [CD12V, 13], [CD12V, 12], [CD12V, 11], [CD12V, 10], [CD12V, 9], [CD12V, 8]])


class CFGAR0(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR0'

    def __init__(self):
        super(CFGAR0, self).__init__([[REFON, 0], [ADCOPT, 0], [PS, 1], [PS, 0], [CVMIN, 1], [CVMIN, 0], [MCAL, 0], [COMM_BK, 0]])


class CFGAR1(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR1'

    def __init__(self):
        super(CFGAR1, self).__init__([[FLAG_D, 7], [FLAG_D, 6], [FLAG_D, 5], [FLAG_D, 4], [FLAG_D, 3], [FLAG_D, 2], [FLAG_D, 1], [FLAG_D, 0]])


class CFGAR2(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR2'

    def __init__(self):
        super(CFGAR2, self).__init__([[SOAKON, 0], [OWRNG, 0], [OWA, 2], [OWA, 1], [OWA, 0], [OWC, 2], [OWC, 1], [OWC, 0]])


class CFGAR3(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR3'

    def __init__(self):
        super(CFGAR3, self).__init__([[bmsbase.RSVD1, 0], [GPO7, 0], [GPO6, 0], [GPO5, 0], [GPO4, 0], [GPO3, 0], [GPO2, 0], [GPO1, 0]])


class CFGAR4(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR4'

    def __init__(self):
        super(CFGAR4, self).__init__([[bmsbase.RSVD0, 0], [GPI7, 0], [GPI6, 0], [GPI5, 0], [GPI4, 0], [GPI3, 0], [GPI2, 0], [GPI1, 0]])


class CFGAR5(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR5'

    def __init__(self):
        super(CFGAR5, self).__init__([[REV, 3], [REV, 2], [REV, 1], [REV, 0], [DTYPE, 3], [DTYPE, 2], [DTYPE, 1], [DTYPE, 0]])


class CFGBR0(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR0'

    def __init__(self):
        super(CFGBR0, self).__init__([[VUV, 7], [VUV, 6], [VUV, 5], [VUV, 4], [VUV, 3], [VUV, 2], [VUV, 1], [VUV, 0]])


class CFGBR1(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR1'

    def __init__(self):
        super(CFGBR1, self).__init__([[VOV, 3], [VOV, 2], [VOV, 1], [VOV, 0], [VUV, 11], [VUV, 10], [VUV, 9], [VUV, 8]])


class CFGBR2(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR2'

    def __init__(self):
        super(CFGBR2, self).__init__([[VOV, 11], [VOV, 10], [VOV, 9], [VOV, 8], [VOV, 7], [VOV, 6], [VOV, 5], [VOV, 4]])


class CFGBR3(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR3'

    def __init__(self):
        super(CFGBR3, self).__init__([[DTMEN, 0], [DTRNG, 0], [DCTO, 5], [DCTO, 4], [DCTO, 3], [DCTO, 2], [DCTO, 1], [DCTO, 0]])


class CFGBR4(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR4'

    def __init__(self):
        super(CFGBR4, self).__init__([[DCC8, 0], [DCC7, 0], [DCC6, 0], [DCC5, 0], [DCC4, 0], [DCC3, 0], [DCC2, 0], [DCC1, 0]])


class CFGBR5(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR5'

    def __init__(self):
        super(CFGBR5, self).__init__([[MUTE_ST, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [DCC12, 0], [DCC11, 0], [DCC10, 0], [DCC9, 0]])


class AVAR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR0'

    def __init__(self):
        super(AVAR0, self).__init__([[REF2, 7], [REF2, 6], [REF2, 5], [REF2, 4], [REF2, 3], [REF2, 2], [REF2, 1], [REF2, 0]])


class AVAR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR1'

    def __init__(self):
        super(AVAR1, self).__init__([[REF2, 15], [REF2, 14], [REF2, 13], [REF2, 12], [REF2, 11], [REF2, 10], [REF2, 9], [REF2, 8]])


class AVAR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR2'

    def __init__(self):
        super(AVAR2, self).__init__([[G1V, 7], [G1V, 6], [G1V, 5], [G1V, 4], [G1V, 3], [G1V, 2], [G1V, 1], [G1V, 0]])


class AVAR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR3'

    def __init__(self):
        super(AVAR3, self).__init__([[G1V, 15], [G1V, 14], [G1V, 13], [G1V, 12], [G1V, 11], [G1V, 10], [G1V, 9], [G1V, 8]])


class AVAR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR4'

    def __init__(self):
        super(AVAR4, self).__init__([[G2V, 7], [G2V, 6], [G2V, 5], [G2V, 4], [G2V, 3], [G2V, 2], [G2V, 1], [G2V, 0]])


class AVAR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'AVAR5'

    def __init__(self):
        super(AVAR5, self).__init__([[G2V, 15], [G2V, 14], [G2V, 13], [G2V, 12], [G2V, 11], [G2V, 10], [G2V, 9], [G2V, 8]])


class AVBR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR0'

    def __init__(self):
        super(AVBR0, self).__init__([[G3V, 7], [G3V, 6], [G3V, 5], [G3V, 4], [G3V, 3], [G3V, 2], [G3V, 1], [G3V, 0]])


class AVBR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR1'

    def __init__(self):
        super(AVBR1, self).__init__([[G3V, 15], [G3V, 14], [G3V, 13], [G3V, 12], [G3V, 11], [G3V, 10], [G3V, 9], [G3V, 8]])


class AVBR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR2'

    def __init__(self):
        super(AVBR2, self).__init__([[G4V, 7], [G4V, 6], [G4V, 5], [G4V, 4], [G4V, 3], [G4V, 2], [G4V, 1], [G4V, 0]])


class AVBR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR3'

    def __init__(self):
        super(AVBR3, self).__init__([[G4V, 15], [G4V, 14], [G4V, 13], [G4V, 12], [G4V, 11], [G4V, 10], [G4V, 9], [G4V, 8]])


class AVBR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR4'

    def __init__(self):
        super(AVBR4, self).__init__([[G5V, 7], [G5V, 6], [G5V, 5], [G5V, 4], [G5V, 3], [G5V, 2], [G5V, 1], [G5V, 0]])


class AVBR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'AVBR5'

    def __init__(self):
        super(AVBR5, self).__init__([[G5V, 15], [G5V, 14], [G5V, 13], [G5V, 12], [G5V, 11], [G5V, 10], [G5V, 9], [G5V, 8]])


class AVCR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR0'

    def __init__(self):
        super(AVCR0, self).__init__([[G6V, 7], [G6V, 6], [G6V, 5], [G6V, 4], [G6V, 3], [G6V, 2], [G6V, 1], [G6V, 0]])


class AVCR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR1'

    def __init__(self):
        super(AVCR1, self).__init__([[G6V, 15], [G6V, 14], [G6V, 13], [G6V, 12], [G6V, 11], [G6V, 10], [G6V, 9], [G6V, 8]])


class AVCR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR2'

    def __init__(self):
        super(AVCR2, self).__init__([[G7V, 7], [G7V, 6], [G7V, 5], [G7V, 4], [G7V, 3], [G7V, 2], [G7V, 1], [G7V, 0]])


class AVCR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR3'

    def __init__(self):
        super(AVCR3, self).__init__([[G7V, 15], [G7V, 14], [G7V, 13], [G7V, 12], [G7V, 11], [G7V, 10], [G7V, 9], [G7V, 8]])


class AVCR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR4'

    def __init__(self):
        super(AVCR4, self).__init__([[REF3, 7], [REF3, 6], [REF3, 5], [REF3, 4], [REF3, 3], [REF3, 2], [REF3, 1], [REF3, 0]])


class AVCR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'AVCR5'

    def __init__(self):
        super(AVCR5, self).__init__([[REF3, 15], [REF3, 14], [REF3, 13], [REF3, 12], [REF3, 11], [REF3, 10], [REF3, 9], [REF3, 8]])


class STAR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR0'

    def __init__(self):
        super(STAR0, self).__init__([[SC, 7], [SC, 6], [SC, 5], [SC, 4], [SC, 3], [SC, 2], [SC, 1], [SC, 0]])


class STAR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR1'

    def __init__(self):
        super(STAR1, self).__init__([[SC, 15], [SC, 14], [SC, 13], [SC, 12], [SC, 11], [SC, 10], [SC, 9], [SC, 8]])


class STAR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR2'

    def __init__(self):
        super(STAR2, self).__init__([[ITMP, 7], [ITMP, 6], [ITMP, 5], [ITMP, 4], [ITMP, 3], [ITMP, 2], [ITMP, 1], [ITMP, 0]])


class STAR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR3'

    def __init__(self):
        super(STAR3, self).__init__([[ITMP, 15], [ITMP, 14], [ITMP, 13], [ITMP, 12], [ITMP, 11], [ITMP, 10], [ITMP, 9], [ITMP, 8]])


class STAR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR4'

    def __init__(self):
        super(STAR4, self).__init__([[VA, 7], [VA, 6], [VA, 5], [VA, 4], [VA, 3], [VA, 2], [VA, 1], [VA, 0]])


class STAR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR5'

    def __init__(self):
        super(STAR5, self).__init__([[VA, 15], [VA, 14], [VA, 13], [VA, 12], [VA, 11], [VA, 10], [VA, 9], [VA, 8]])


class STBR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR0'

    def __init__(self):
        super(STBR0, self).__init__([[VD, 7], [VD, 6], [VD, 5], [VD, 4], [VD, 3], [VD, 2], [VD, 1], [VD, 0]])


class STBR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR1'

    def __init__(self):
        super(STBR1, self).__init__([[VD, 15], [VD, 14], [VD, 13], [VD, 12], [VD, 11], [VD, 10], [VD, 9], [VD, 8]])


class STBR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR2'

    def __init__(self):
        super(STBR2, self).__init__([[C4OV, 0], [C4UV, 0], [C3OV, 0], [C3UV, 0], [C2OV, 0], [C2UV, 0], [C1OV, 0], [C1UV, 0]])


class STBR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR3'

    def __init__(self):
        super(STBR3, self).__init__([[C8OV, 0], [C8UV, 0], [C7OV, 0], [C7UV, 0], [C6OV, 0], [C6UV, 0], [C5OV, 0], [C5UV, 0]])


class STBR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR4'

    def __init__(self):
        super(STBR4, self).__init__([[C12OV, 0], [C12UV, 0], [C11OV, 0], [C11UV, 0], [C10OV, 0], [C10UV, 0], [C9OV, 0], [C9UV, 0]])


class STBR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR5'

    def __init__(self):
        super(STBR5, self).__init__([[OC_CNTR, 7], [OC_CNTR, 6], [OC_CNTR, 5], [OC_CNTR, 4], [OC_CNTR, 3], [OC_CNTR, 2], [OC_CNTR, 1], [OC_CNTR, 0]])


class STCR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR0'

    def __init__(self):
        super(STCR0, self).__init__([[VA_OVHI, 0], [VA_UVLO, 0], [VD_OVHI, 0], [VD_UVLO, 0], [A_OTP_ED, 0], [A_OTP_MED, 0], [OTP_ED, 0], [OTP_MED, 0]])


class STCR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR1'

    def __init__(self):
        super(STCR1, self).__init__([[REDFAIL, 0], [COMPCHK, 0], [SLEEP, 0], [TMODECHK, 0], [MUXFAIL, 0], [THSD, 0], [CPCHK, 0], [OSCCHK, 0]])


class STCR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR2'

    def __init__(self):
        super(STCR2, self).__init__([[ADOL1, 7], [ADOL1, 6], [ADOL1, 5], [ADOL1, 4], [ADOL1, 3], [ADOL1, 2], [ADOL1, 1], [ADOL1, 0]])


class STCR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR3'

    def __init__(self):
        super(STCR3, self).__init__([[ADOL1, 15], [ADOL1, 14], [ADOL1, 13], [ADOL1, 12], [ADOL1, 11], [ADOL1, 10], [ADOL1, 9], [ADOL1, 8]])


class STCR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR4'

    def __init__(self):
        super(STCR4, self).__init__([[ADOL2, 7], [ADOL2, 6], [ADOL2, 5], [ADOL2, 4], [ADOL2, 3], [ADOL2, 2], [ADOL2, 1], [ADOL2, 0]])


class STCR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR5'

    def __init__(self):
        super(STCR5, self).__init__([[ADOL2, 15], [ADOL2, 14], [ADOL2, 13], [ADOL2, 12], [ADOL2, 11], [ADOL2, 10], [ADOL2, 9], [ADOL2, 8]])


class COMM0(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM0'

    def __init__(self):
        super(COMM0, self).__init__([[ICOM0, 3], [ICOM0, 2], [ICOM0, 1], [ICOM0, 0], [FCOM0, 3], [FCOM0, 2], [FCOM0, 1], [FCOM0, 0]])


class COMM1(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM1'

    def __init__(self):
        super(COMM1, self).__init__([[D0, 7], [D0, 6], [D0, 5], [D0, 4], [D0, 3], [D0, 2], [D0, 1], [D0, 0]])


class COMM2(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM2'

    def __init__(self):
        super(COMM2, self).__init__([[ICOM1, 3], [ICOM1, 2], [ICOM1, 1], [ICOM1, 0], [FCOM1, 3], [FCOM1, 2], [FCOM1, 1], [FCOM1, 0]])


class COMM3(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM3'

    def __init__(self):
        super(COMM3, self).__init__([[D1, 7], [D1, 6], [D1, 5], [D1, 4], [D1, 3], [D1, 2], [D1, 1], [D1, 0]])


class COMM4(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM4'

    def __init__(self):
        super(COMM4, self).__init__([[ICOM2, 3], [ICOM2, 2], [ICOM2, 1], [ICOM2, 0], [FCOM2, 3], [FCOM2, 2], [FCOM2, 1], [FCOM2, 0]])


class COMM5(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM5'

    def __init__(self):
        super(COMM5, self).__init__([[D2, 7], [D2, 6], [D2, 5], [D2, 4], [D2, 3], [D2, 2], [D2, 1], [D2, 0]])


class PWMR0(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR0'

    def __init__(self):
        super(PWMR0, self).__init__([[PWM2, 3], [PWM2, 2], [PWM2, 1], [PWM2, 0], [PWM1, 3], [PWM1, 2], [PWM1, 1], [PWM1, 0]])


class PWMR1(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR1'

    def __init__(self):
        super(PWMR1, self).__init__([[PWM4, 3], [PWM4, 2], [PWM4, 1], [PWM4, 0], [PWM3, 3], [PWM3, 2], [PWM3, 1], [PWM3, 0]])


class PWMR2(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR2'

    def __init__(self):
        super(PWMR2, self).__init__([[PWM6, 3], [PWM6, 2], [PWM6, 1], [PWM6, 0], [PWM5, 3], [PWM5, 2], [PWM5, 1], [PWM5, 0]])


class PWMR3(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR3'

    def __init__(self):
        super(PWMR3, self).__init__([[PWM8, 3], [PWM8, 2], [PWM8, 1], [PWM8, 0], [PWM7, 3], [PWM7, 2], [PWM7, 1], [PWM7, 0]])


class PWMR4(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR4'

    def __init__(self):
        super(PWMR4, self).__init__([[PWM10, 3], [PWM10, 2], [PWM10, 1], [PWM10, 0], [PWM9, 3], [PWM9, 2], [PWM9, 1], [PWM9, 0]])


class PWMR5(bmsbase.Register):
    MEM_KEY = 'PWM Register Group'
    NAME = 'PWMR5'

    def __init__(self):
        super(PWMR5, self).__init__([[PWM12, 3], [PWM12, 2], [PWM12, 1], [PWM12, 0], [PWM11, 3], [PWM11, 2], [PWM11, 1], [PWM11, 0]])


class SIDR0(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR0'

    def __init__(self):
        super(SIDR0, self).__init__([[SID, 7], [SID, 6], [SID, 5], [SID, 4], [SID, 3], [SID, 2], [SID, 1], [SID, 0]])


class SIDR1(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR1'

    def __init__(self):
        super(SIDR1, self).__init__([[SID, 15], [SID, 14], [SID, 13], [SID, 12], [SID, 11], [SID, 10], [SID, 9], [SID, 8]])


class SIDR2(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR2'

    def __init__(self):
        super(SIDR2, self).__init__([[SID, 23], [SID, 22], [SID, 21], [SID, 20], [SID, 19], [SID, 18], [SID, 17], [SID, 16]])


class SIDR3(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR3'

    def __init__(self):
        super(SIDR3, self).__init__([[SID, 31], [SID, 30], [SID, 29], [SID, 28], [SID, 27], [SID, 26], [SID, 25], [SID, 24]])


class SIDR4(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR4'

    def __init__(self):
        super(SIDR4, self).__init__([[SID, 39], [SID, 38], [SID, 37], [SID, 36], [SID, 35], [SID, 34], [SID, 33], [SID, 32]])


class SIDR5(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR5'

    def __init__(self):
        super(SIDR5, self).__init__([[SID, 47], [SID, 46], [SID, 45], [SID, 44], [SID, 43], [SID, 42], [SID, 41], [SID, 40]])


class CFD0(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD0'

    def __init__(self):
        super(CFD0, self).__init__([[CL_VA_OVHI, 0], [CL_VA_UVLO, 0], [CL_VD_OVHI, 0], [CL_VD_UVLO, 0], [CL_A_OTP_ED, 0], [CL_A_OTP_MED, 0], [CL_OTP_ED, 0], [CL_OTP_MED, 0]])


class CFD1(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD1'

    def __init__(self):
        super(CFD1, self).__init__([[CL_REDFAIL, 0], [CL_COMPCHK, 0], [CL_SLEEP, 0], [CL_TMODECHK, 0], [bmsbase.RSVD1, 0], [CL_THSD, 0], [CL_CPCHK, 0], [CL_OSCCHK, 0]])


# ===================================================== Commands =====================================================
class ADCV(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DC, 0],
        [bmsbase.Bit0, 0], [CH, 2], [CH, 1], [CH, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCV'
    DESCRIPTION = 'Start Cell Conversion'

    def __init__(self, **kwargs):
        super(ADCV, self).__init__(**kwargs)


class Broadcast_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'Broadcast Command'
    DESCRIPTION = 'Generic Broadcast Command'

    def __init__(self, **kwargs):
        super(Broadcast_Command, self).__init__(**kwargs)


class Write_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'Write Command'
    DESCRIPTION = 'Generic Write Command'

    def __init__(self, **kwargs):
        super(Write_Command, self).__init__(**kwargs)
        self.local_definitions = {
            CCNT.NAME: CCNT(value=0x00)
        }


class Read_Command(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'Read Command'
    DESCRIPTION = 'Generic Read Command'

    def __init__(self, **kwargs):
        super(Read_Command, self).__init__(**kwargs)


class WRCFGA(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), False], [CFGAR1(), False], [CFGAR2(), False], [CFGAR3(), False], [CFGAR4(), False], [CFGAR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGA'
    DESCRIPTION = 'Write Configuration Group A'

    def __init__(self, **kwargs):
        super(WRCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x01),
            CCNT.NAME: CCNT(value=0x00)
        }


class WRCFGB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), False], [CFGBR1(), False], [CFGBR2(), False], [CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGB'
    DESCRIPTION = 'Write Configuration Group B'


    def __init__(self, **kwargs):
        super(WRCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x24),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCFGA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGA'
    DESCRIPTION = 'Read Configuration Group A'


    def __init__(self, **kwargs):
        super(RDCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x02),
        }


class RDCFGB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGB'
    DESCRIPTION = 'Read Configuration Group B'


    def __init__(self, **kwargs):
        super(RDCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x26),
        }


class RDCVA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVA'
    DESCRIPTION = 'Readback Cell Voltage Register Group A'


    def __init__(self, **kwargs):
        super(RDCVA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x04)
        }


class RDCVB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVB'
    DESCRIPTION = 'Readback Cell Voltage Register Group B'


    def __init__(self, **kwargs):
        super(RDCVB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x06)
        }


class RDCVC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVC'
    DESCRIPTION = 'Readback Cell Voltage Register Group C'


    def __init__(self, **kwargs):
        super(RDCVC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x08)
        }


class RDCVD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVD'
    DESCRIPTION = 'Readback Cell Voltage Register Group D'


    def __init__(self, **kwargs):
        super(RDCVD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0A)
        }


class RDCVALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True],
              [CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True],
              [CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True],
              [CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 30
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDCVALL'
    DESCRIPTION = 'Readback Cell Voltage Register Groups A-D; 1 device only'


    def __init__(self, **kwargs):
        super(RDCVALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x38),
            DATA_PEC.NAME: DATA_PEC(pec_size=198)
        }


class RDCVE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVE'
    DESCRIPTION = 'Readback Cell Voltage Register Group E'


    def __init__(self, **kwargs):
        super(RDCVE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x09)
        }


class RDCVF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [bmsbase.TRASH_Register(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVF'
    DESCRIPTION = 'Readback Cell Voltage Register Group F'


    def __init__(self, **kwargs):
        super(RDCVF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0B)
        }


class RDCDA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CDAR0(), True], [CDAR1(), True], [CDAR2(), True], [CDAR3(), True], [CDAR4(), True], [CDAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCDA'
    DESCRIPTION = 'Readback Cell Diagnostic Register Group A'


    def __init__(self, **kwargs):
        super(RDCDA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x30)
        }


class RDCDB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CDBR0(), True], [CDBR1(), True], [CDBR2(), True], [CDBR3(), True], [CDBR4(), True], [CDBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCDB'
    DESCRIPTION = 'Readback Cell Diagnostic Register Group B'


    def __init__(self, **kwargs):
        super(RDCDB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x31)
        }


class RDCDC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CDCR0(), True], [CDCR1(), True], [CDCR2(), True], [CDCR3(), True], [CDCR4(), True], [CDCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCDC'
    DESCRIPTION = 'Readback Cell Diagnostic Register Group C'


    def __init__(self, **kwargs):
        super(RDCDC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x32)
        }


class RDCDD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CDDR0(), True], [CDDR1(), True], [CDDR2(), True], [CDDR3(), True], [CDDR4(), True], [CDDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCDD'
    DESCRIPTION = 'Readback Cell Diagnostic Register Group D'


    def __init__(self, **kwargs):
        super(RDCDD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x33)
        }


class RDCDALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [CDAR0(), True], [CDAR1(), True], [CDAR2(), True], [CDAR3(), True], [CDAR4(), True], [CDAR5(), True],
              [CDBR0(), True], [CDBR1(), True], [CDBR2(), True], [CDBR3(), True], [CDBR4(), True], [CDBR5(), True],
              [CDCR0(), True], [CDCR1(), True], [CDCR2(), True], [CDCR3(), True], [CDCR4(), True], [CDCR5(), True],
              [CDDR0(), True], [CDDR1(), True], [CDDR2(), True], [CDDR3(), True], [CDDR4(), True], [CDDR5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 30
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDCDALL'
    DESCRIPTION = 'Readback Cell Diagnostic Register Groups A-D; 1 device only'


    def __init__(self, **kwargs):
        super(RDCDALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x3A),
            DATA_PEC.NAME: DATA_PEC(pec_size=198)
        }


class RDAUXA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVAR0(), True], [AVAR1(), True], [AVAR2(), True], [AVAR3(), True], [AVAR4(), True], [AVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXA'
    DESCRIPTION = 'Readback Auxiliary Register Group A'


    def __init__(self, **kwargs):
        super(RDAUXA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0C)
        }


class RDAUXB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVBR0(), True], [AVBR1(), True], [AVBR2(), True], [AVBR3(), True], [AVBR4(), True], [AVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXB'
    DESCRIPTION = 'Readback Auxiliary Register Group B'


    def __init__(self, **kwargs):
        super(RDAUXB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0E)
        }


class RDAUXC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AVCR0(), True], [AVCR1(), True], [AVCR2(), True], [AVCR3(), True], [AVCR4(), True], [AVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXC'
    DESCRIPTION = 'Readback Auxiliary Register Group C'


    def __init__(self, **kwargs):
        super(RDAUXC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0D)
        }


class RDSTATA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATA'
    DESCRIPTION = 'Readback Status Register Group A'


    def __init__(self, **kwargs):
        super(RDSTATA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x10)
        }


class RDSTATB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATB'
    DESCRIPTION = 'Readback Status Register Group B'


    def __init__(self, **kwargs):
        super(RDSTATB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x12)
        }


class RDSTATC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STCR0(), True], [STCR1(), True], [STCR2(), True], [STCR3(), True], [STCR4(), True], [STCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATC'
    DESCRIPTION = 'Readback Status Register Group C'


    def __init__(self, **kwargs):
        super(RDSTATC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x13)
        }


class RDASALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [AVAR0(), True], [AVAR1(), True], [AVAR2(), True], [AVAR3(), True], [AVAR4(), True], [AVAR5(), True],
              [AVBR0(), True], [AVBR1(), True], [AVBR2(), True], [AVBR3(), True], [AVBR4(), True], [AVBR5(), True],
              [AVCR0(), True], [AVCR1(), True], [AVCR2(), True], [AVCR3(), True], [AVCR4(), True], [AVCR5(), True],
              [STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True],
              [STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True],
              [STCR0(), True], [STCR1(), True], [STCR2(), True], [STCR3(), True], [STCR4(), True], [STCR5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 42
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDASALL'
    DESCRIPTION = 'Readback All Status/Auxiliary Register Groups'


    def __init__(self, **kwargs):
        super(RDASALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x3C),
            DATA_PEC.NAME: DATA_PEC(pec_size=294)
        }


class WRPWM(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), False], [PWMR1(), False], [PWMR2(), False], [PWMR3(), False], [PWMR4(), False], [PWMR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPWM'
    DESCRIPTION = 'Write PWM Register Group'


    def __init__(self, **kwargs):
        super(WRPWM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x20),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDPWM(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), True], [PWMR1(), True], [PWMR2(), True], [PWMR3(), True], [PWMR4(), True], [PWMR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPWM'
    DESCRIPTION = 'Read PWM Register Group'


    def __init__(self, **kwargs):
        super(RDPWM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x22)
        }


class CVOW(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CVOW'
    DESCRIPTION = 'Start Cell Voltage Open Wire Conversion'


    def __init__(self, **kwargs):
        super(CVOW, self).__init__(**kwargs)


class ADOW(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [STR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit1, 0], [CH, 2], [CH, 1], [CH, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOW'
    DESCRIPTION = 'Start Legacy Cell Voltage Open Wire Conversion'


    def __init__(self, **kwargs):
        super(ADOW, self).__init__(**kwargs)


class CVPG(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [PG, 1], [PG, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CVPG'
    DESCRIPTION = 'Start Cell Voltage Pattern Generation'


    def __init__(self, **kwargs):
        super(CVPG, self).__init__(**kwargs)


class CDPG(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [PG, 1], [PG, 0], [bmsbase.Bit1, 0],
        [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CDPG'
    DESCRIPTION = 'Start Diagnostic Voltage Pattern Generation'


    def __init__(self, **kwargs):
        super(CDPG, self).__init__(**kwargs)


class ADOL(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADOL'
    DESCRIPTION = 'Start Overlap Measurement of Cell 7'


    def __init__(self, **kwargs):
        super(ADOL, self).__init__(**kwargs)


class ADLEAK(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DC, 0],
        [bmsbase.Bit0, 0], [CH, 2], [CH, 1], [CH, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADLEAK'
    DESCRIPTION = 'Start Pin Leakage Measurement (Cx-Sx)'


    def __init__(self, **kwargs):
        super(ADLEAK, self).__init__(**kwargs)


class ADSC(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DC, 0],
        [bmsbase.Bit1, 0], [CH, 2], [CH, 1], [CH, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSC'
    DESCRIPTION = 'Start Sx - C(x-1) Measurement'


    def __init__(self, **kwargs):
        super(ADSC, self).__init__(**kwargs)


class ADAX(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [CHG, 3], [CHG, 2], [CHG, 1], [CHG, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAX'
    DESCRIPTION = 'Start GPIOs ADC Conversion'


    def __init__(self, **kwargs):
        super(ADAX, self).__init__(**kwargs)


class AXOW(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [PUP, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0],
        [CHG, 3], [CHG, 2], [CHG, 1], [CHG, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXOW'
    DESCRIPTION = 'Start GPIOs Open Wire ADC Conversion'


    def __init__(self, **kwargs):
        super(AXOW, self).__init__(**kwargs)


class AXPG(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [PG, 1], [PG, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'AXPG'
    DESCRIPTION = 'Start Auxiliary Pattern Generation'


    def __init__(self, **kwargs):
        super(AXPG, self).__init__(**kwargs)


class ADSTAT(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit1, 0], [CHST, 2], [CHST, 1], [CHST, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSTAT'
    DESCRIPTION = 'Start Status Group ADC Conversion'


    def __init__(self, **kwargs):
        super(ADSTAT, self).__init__(**kwargs)


class STATPG(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [PG, 1], [PG, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STATPG'
    DESCRIPTION = 'Start Status Group Pattern Generation'


    def __init__(self, **kwargs):
        super(STATPG, self).__init__(**kwargs)


class ADCVAX(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVAX'
    DESCRIPTION = 'Start Combined Cell Voltage and GPIO1/2 Conversion'


    def __init__(self, **kwargs):
        super(ADCVAX, self).__init__(**kwargs)


class ADCVSC(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [MD, 1],
        [MD, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCVSC'
    DESCRIPTION = 'Start Combined Cell Voltage and SC Conversion'


    def __init__(self, **kwargs):
        super(ADCVSC, self).__init__(**kwargs)


class CLRCELL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRCELL'
    DESCRIPTION = 'Clear Cell Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRCELL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x11)
        }


class CLRAUX(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRAUX'
    DESCRIPTION = 'Clear Auxiliary Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRAUX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x12)
        }


class CLRSTAT(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSTAT'
    DESCRIPTION = 'Clear Status Register Groups'


    def __init__(self, **kwargs):
        super(CLRSTAT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x13)
        }


class CLRCD(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRCD'
    DESCRIPTION = 'Clear Cell Diagnostic Register Groups'


    def __init__(self, **kwargs):
        super(CLRCD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x16)
        }


class CLRFLAG(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFD0(), False], [CFD1(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 4
    NAME = 'CLRFLAG'
    DESCRIPTION = 'Clear Diagnostic Flags'


    def __init__(self, **kwargs):
        super(CLRFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x17),
            CCNT.NAME: CCNT(value=0x00),
            DATA_PEC.NAME: DATA_PEC(pec_size=22)
        }


class PLADC(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLADC'
    DESCRIPTION = 'Poll ADC Status'


    def __init__(self, **kwargs):
        super(PLADC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x14)
        }


class DIAGN(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'DIAGN'
    DESCRIPTION = 'Run Mux Diagnostic'


    def __init__(self, **kwargs):
        super(DIAGN, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x15)
        }


class WRCOMM(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), False], [COMM1(), False], [COMM2(), False], [COMM3(), False], [COMM4(), False], [COMM5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCOMM'
    DESCRIPTION = 'Write COMM Register Group'


    def __init__(self, **kwargs):
        super(WRCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x21),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCOMM(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), True], [COMM1(), True], [COMM2(), True], [COMM3(), True], [COMM4(), True], [COMM5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCOMM'
    DESCRIPTION = 'Read COMM Register Group'


    def __init__(self, **kwargs):
        super(RDCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x22),
            CCNT.NAME: CCNT(value=0x00)
        }


class STCOMM(bmsbase.SPIWriteOpen):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STCOMM'
    DESCRIPTION = 'Start I2C/SPI Communication'

    def __init__(self, **kwargs):
        super(STCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x23)
        }


class MUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'MUTE'
    DESCRIPTION = 'Mute Discharge'


    def __init__(self, **kwargs):
        super(MUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x28)
        }


class UNMUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'UNMUTE'
    DESCRIPTION = 'Unmute Discharge'


    def __init__(self, **kwargs):
        super(UNMUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x29)
        }


class RDSID(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SIDR0(), True], [SIDR1(), True], [SIDR2(), True], [SIDR3(), True], [SIDR4(), True], [SIDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSID'
    DESCRIPTION = 'Read Serial ID Register Group'


    def __init__(self, **kwargs):
        super(RDSID, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2C),
        }


class SRST(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'SRST'
    DESCRIPTION = 'Soft Reset'


    def __init__(self, **kwargs):
        super(SRST, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1F)
        }


class RSTCC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RSTCC'
    DESCRIPTION = 'Reset Command Counter'


    def __init__(self, **kwargs):
        super(RSTCC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2E)
        }


class RSVDW1(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDW1'
    DESCRIPTION = 'Reserved Write Command 1'


    def __init__(self, **kwargs):
        super(RSVDW1, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x25),
            CCNT.NAME: CCNT(value=0x00)
        }


class RSVDW2(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDW2'
    DESCRIPTION = 'Reserved Write Command 2'


    def __init__(self, **kwargs):
        super(RSVDW2, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1C),
            CCNT.NAME: CCNT(value=0x00)
        }


class WRPSB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), False], [bmsbase.RSVDR1(), False], [bmsbase.RSVDR2(), False], [bmsbase.RSVDR3(), False], [bmsbase.RSVDR4(), False], [bmsbase.RSVDR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPSB'
    DESCRIPTION = 'Reserved Write Command 2'


    def __init__(self, **kwargs):
        super(WRPSB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1C),
            CCNT.NAME: CCNT(value=0x00)
        }


class RSVDR1(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR1'
    DESCRIPTION = 'Reserved Read Command 1'


    def __init__(self, **kwargs):
        super(RSVDR1, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x27),
        }


class RSVDR2(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR2'
    DESCRIPTION = 'Reserved Read Command 2'


    def __init__(self, **kwargs):
        super(RSVDR2, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1E),
        }


class RDPSB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPSB'
    DESCRIPTION = 'Reserved Read Command 2'


    def __init__(self, **kwargs):
        super(RDPSB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1E),
        }


class RSVDR3(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR3'
    DESCRIPTION = 'Reserved Read Command 3'


    def __init__(self, **kwargs):
        super(RSVDR3, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x09),
        }


class RSVDR4(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR4'
    DESCRIPTION = 'Reserved Read Command 4'


    def __init__(self, **kwargs):
        super(RSVDR4, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0B),
        }


class RSVDR5(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR5'
    DESCRIPTION = 'Reserved Read Command 5'


    def __init__(self, **kwargs):
        super(RSVDR5, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x34),
        }


class RSVDR6(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR6'
    DESCRIPTION = 'Reserved Read Command 6'


    def __init__(self, **kwargs):
        super(RSVDR6, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x35),
        }


class RSVDR7(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR7'
    DESCRIPTION = 'Reserved Read Command 7'


    def __init__(self, **kwargs):
        super(RSVDR7, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0F),
        }


class RDAUXD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXD'
    DESCRIPTION = 'Reserved Read Command 7'


    def __init__(self, **kwargs):
        super(RDAUXD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0F),
        }


class RSVDR8(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [bmsbase.RSVDR4(), True], [bmsbase.RSVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RSVDR8'
    DESCRIPTION = 'Reserved Read Command 8'


    def __init__(self, **kwargs):
        super(RSVDR8, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x11),
        }


# ===================================================== DUT =====================================================
class ADBMS_GEN5(ABC):
    NAME = 'ADBMS_GEN5'
    PASS = 'Pass'
    FAIL = 'Fail'
    MEMORY_MAP = {
        **bmsbase.BMS_Config.MEMORY_MAP,
        CMD_REGISTER.NAME: CMD_REGISTER,
        CMD_PEC_REGISTER.NAME: CMD_PEC_REGISTER,
        DATA_PEC_REGISTER.NAME: DATA_PEC_REGISTER,
        CVAR0.NAME: CVAR0,
        CVAR1.NAME: CVAR1,
        CVAR2.NAME: CVAR2,
        CVAR3.NAME: CVAR3,
        CVAR4.NAME: CVAR4,
        CVAR5.NAME: CVAR5,
        CVBR0.NAME: CVBR0,
        CVBR1.NAME: CVBR1,
        CVBR2.NAME: CVBR2,
        CVBR3.NAME: CVBR3,
        CVBR4.NAME: CVBR4,
        CVBR5.NAME: CVBR5,
        CVCR0.NAME: CVCR0,
        CVCR1.NAME: CVCR1,
        CVCR2.NAME: CVCR2,
        CVCR3.NAME: CVCR3,
        CVCR4.NAME: CVCR4,
        CVCR5.NAME: CVCR5,
        CVDR0.NAME: CVDR0,
        CVDR1.NAME: CVDR1,
        CVDR2.NAME: CVDR2,
        CVDR3.NAME: CVDR3,
        CVDR4.NAME: CVDR4,
        CVDR5.NAME: CVDR5,
        CDAR0.NAME: CDAR0,
        CDAR1.NAME: CDAR1,
        CDAR2.NAME: CDAR2,
        CDAR3.NAME: CDAR3,
        CDAR4.NAME: CDAR4,
        CDAR5.NAME: CDAR5,
        CDBR0.NAME: CDBR0,
        CDBR1.NAME: CDBR1,
        CDBR2.NAME: CDBR2,
        CDBR3.NAME: CDBR3,
        CDBR4.NAME: CDBR4,
        CDBR5.NAME: CDBR5,
        CDCR0.NAME: CDCR0,
        CDCR1.NAME: CDCR1,
        CDCR2.NAME: CDCR2,
        CDCR3.NAME: CDCR3,
        CDCR4.NAME: CDCR4,
        CDCR5.NAME: CDCR5,
        CDDR0.NAME: CDDR0,
        CDDR1.NAME: CDDR1,
        CDDR2.NAME: CDDR2,
        CDDR3.NAME: CDDR3,
        CDDR4.NAME: CDDR4,
        CDDR5.NAME: CDDR5,
        CFGAR0.NAME: CFGAR0,
        CFGAR1.NAME: CFGAR1,
        CFGAR2.NAME: CFGAR2,
        CFGAR3.NAME: CFGAR3,
        CFGAR4.NAME: CFGAR4,
        CFGAR5.NAME: CFGAR5,
        CFGBR0.NAME: CFGBR0,
        CFGBR1.NAME: CFGBR1,
        CFGBR2.NAME: CFGBR2,
        CFGBR3.NAME: CFGBR3,
        CFGBR4.NAME: CFGBR4,
        CFGBR5.NAME: CFGBR5,
        AVAR0.NAME: AVAR0,
        AVAR1.NAME: AVAR1,
        AVAR2.NAME: AVAR2,
        AVAR3.NAME: AVAR3,
        AVAR4.NAME: AVAR4,
        AVAR5.NAME: AVAR5,
        AVBR0.NAME: AVBR0,
        AVBR1.NAME: AVBR1,
        AVBR2.NAME: AVBR2,
        AVBR3.NAME: AVBR3,
        AVBR4.NAME: AVBR4,
        AVBR5.NAME: AVBR5,
        AVCR0.NAME: AVCR0,
        AVCR1.NAME: AVCR1,
        AVCR2.NAME: AVCR2,
        AVCR3.NAME: AVCR3,
        AVCR4.NAME: AVCR4,
        AVCR5.NAME: AVCR5,
        STAR0.NAME: STAR0,
        STAR1.NAME: STAR1,
        STAR2.NAME: STAR2,
        STAR3.NAME: STAR3,
        STAR4.NAME: STAR4,
        STAR5.NAME: STAR5,
        STBR0.NAME: STBR0,
        STBR1.NAME: STBR1,
        STBR2.NAME: STBR2,
        STBR3.NAME: STBR3,
        STBR4.NAME: STBR4,
        STBR5.NAME: STBR5,
        STCR0.NAME: STCR0,
        STCR1.NAME: STCR1,
        STCR2.NAME: STCR2,
        STCR3.NAME: STCR3,
        STCR4.NAME: STCR4,
        STCR5.NAME: STCR5,
        COMM0.NAME: COMM0,
        COMM1.NAME: COMM1,
        COMM2.NAME: COMM2,
        COMM3.NAME: COMM3,
        COMM4.NAME: COMM4,
        COMM5.NAME: COMM5,
        PWMR0.NAME: PWMR0,
        PWMR1.NAME: PWMR1,
        PWMR2.NAME: PWMR2,
        PWMR3.NAME: PWMR3,
        PWMR4.NAME: PWMR4,
        PWMR5.NAME: PWMR5,
        SIDR0.NAME: SIDR0,
        SIDR1.NAME: SIDR1,
        SIDR2.NAME: SIDR2,
        SIDR3.NAME: SIDR3,
        SIDR4.NAME: SIDR4,
        SIDR5.NAME: SIDR5,
        CFD0.NAME: CFD0,
        CFD1.NAME: CFD1,
        WRITE_DATA_REGISTER.NAME: WRITE_DATA_REGISTER
    }
    BITFIELDS = {
        **bmsbase.BMS_Config.BITFIELDS,
        MD.NAME: MD,
        CH.NAME: CH,
        CHST.NAME: CHST,
        CHG.NAME: CHG,
        PUP.NAME: PUP,
        STR.NAME: STR,
        PG.NAME: PG,
        DC.NAME: DC,
        CMD0.NAME: CMD0,
        CMD1.NAME: CMD1,
        CCNT.NAME: CCNT,
        CMD_PEC.NAME: CMD_PEC,
        DATA_PEC.NAME: DATA_PEC,
        C1V.NAME: C1V,
        C2V.NAME: C2V,
        C3V.NAME: C3V,
        C4V.NAME: C4V,
        C5V.NAME: C5V,
        C6V.NAME: C6V,
        C7V.NAME: C7V,
        C8V.NAME: C8V,
        C9V.NAME: C9V,
        C10V.NAME: C10V,
        C11V.NAME: C11V,
        C12V.NAME: C12V,
        CD1V.NAME: CD1V,
        CD2V.NAME: CD2V,
        CD3V.NAME: CD3V,
        CD4V.NAME: CD4V,
        CD5V.NAME: CD5V,
        CD6V.NAME: CD6V,
        CD7V.NAME: CD7V,
        CD8V.NAME: CD8V,
        CD9V.NAME: CD9V,
        CD10V.NAME: CD10V,
        CD11V.NAME: CD11V,
        CD12V.NAME: CD12V,
        REFON.NAME: REFON,
        ADCOPT.NAME: ADCOPT,
        PS.NAME: PS,
        CVMIN.NAME: CVMIN,
        MCAL.NAME: MCAL,
        COMM_BK.NAME: COMM_BK,
        FLAG_D.NAME: FLAG_D,
        SOAKON.NAME: SOAKON,
        OWRNG.NAME: OWRNG,
        OWA.NAME: OWA,
        OWC.NAME: OWC,
        GPO1.NAME: GPO1,
        GPO2.NAME: GPO2,
        GPO3.NAME: GPO3,
        GPO4.NAME: GPO4,
        GPO5.NAME: GPO5,
        GPO6.NAME: GPO6,
        GPO7.NAME: GPO7,
        GPI1.NAME: GPI1,
        GPI2.NAME: GPI2,
        GPI3.NAME: GPI3,
        GPI4.NAME: GPI4,
        GPI5.NAME: GPI5,
        GPI6.NAME: GPI6,
        GPI7.NAME: GPI7,
        REV.NAME: REV,
        DTYPE.NAME: DTYPE,
        VOV.NAME: VOV,
        VUV.NAME: VUV,
        DCC1.NAME: DCC1,
        DCC2.NAME: DCC2,
        DCC3.NAME: DCC3,
        DCC4.NAME: DCC4,
        DCC5.NAME: DCC5,
        DCC6.NAME: DCC6,
        DCC7.NAME: DCC7,
        DCC8.NAME: DCC8,
        DCC9.NAME: DCC9,
        DCC10.NAME: DCC10,
        DCC11.NAME: DCC11,
        DCC12.NAME: DCC12,
        DTMEN.NAME: DTMEN,
        DTRNG.NAME: DTRNG,
        DCTO.NAME: DCTO,
        MUTE_ST.NAME: MUTE_ST,
        G1V.NAME: G1V,
        G2V.NAME: G2V,
        G3V.NAME: G3V,
        G4V.NAME: G4V,
        G5V.NAME: G5V,
        G6V.NAME: G6V,
        G7V.NAME: G7V,
        ITMP.NAME: ITMP,
        VD.NAME: VD,
        VA.NAME: VA,
        SC.NAME: SC,
        VA_OVHI.NAME: VA_OVHI,
        VA_UVLO.NAME: VA_UVLO,
        VD_OVHI.NAME: VD_OVHI,
        VD_UVLO.NAME: VD_UVLO,
        OC_CNTR.NAME: OC_CNTR,
        MUXFAIL.NAME: MUXFAIL,
        THSD.NAME: THSD,
        OSCCHK.NAME: OSCCHK,
        OTP_ED.NAME: OTP_ED,
        OTP_MED.NAME: OTP_MED,
        A_OTP_ED.NAME: A_OTP_ED,
        A_OTP_MED.NAME: A_OTP_MED,
        TMODECHK.NAME: TMODECHK,
        REDFAIL.NAME: REDFAIL,
        REF2.NAME: REF2,
        REF3.NAME: REF3,
        COMPCHK.NAME: COMPCHK,
        CPCHK.NAME: CPCHK,
        SLEEP.NAME: SLEEP,
        CL_A_OTP_ED.NAME: CL_A_OTP_ED,
        CL_A_OTP_MED.NAME: CL_A_OTP_MED,
        CL_COMPCHK.NAME: CL_COMPCHK,
        CL_CPCHK.NAME: CL_CPCHK,
        CL_MUXFAIL.NAME: CL_MUXFAIL,
        CL_OSCCHK.NAME: CL_OSCCHK,
        CL_OTP_ED.NAME: CL_OTP_ED,
        CL_OTP_MED.NAME: CL_OTP_MED,
        CL_THSD.NAME: CL_THSD,
        CL_TMODECHK.NAME: CL_TMODECHK,
        CL_REDFAIL.NAME: CL_REDFAIL,
        CL_SLEEP.NAME: CL_SLEEP,
        CL_VA_OVHI.NAME: CL_VA_OVHI,
        CL_VA_UVLO.NAME: CL_VA_UVLO,
        CL_VD_OVHI.NAME: CL_VD_OVHI,
        CL_VD_UVLO.NAME: CL_VD_UVLO,
        C1OV.NAME: C1OV,
        C2OV.NAME: C2OV,
        C3OV.NAME: C3OV,
        C4OV.NAME: C4OV,
        C5OV.NAME: C5OV,
        C6OV.NAME: C6OV,
        C7OV.NAME: C7OV,
        C8OV.NAME: C8OV,
        C9OV.NAME: C9OV,
        C10OV.NAME: C10OV,
        C11OV.NAME: C11OV,
        C12OV.NAME: C12OV,
        C1UV.NAME: C1UV,
        C2UV.NAME: C2UV,
        C3UV.NAME: C3UV,
        C4UV.NAME: C4UV,
        C5UV.NAME: C5UV,
        C6UV.NAME: C6UV,
        C7UV.NAME: C7UV,
        C8UV.NAME: C8UV,
        C9UV.NAME: C9UV,
        C10UV.NAME: C10UV,
        C11UV.NAME: C11UV,
        C12UV.NAME: C12UV,
        ICOM0.NAME: ICOM0,
        ICOM1.NAME: ICOM1,
        ICOM2.NAME: ICOM2,
        FCOM0.NAME: FCOM0,
        FCOM1.NAME: FCOM1,
        FCOM2.NAME: FCOM2,
        D0.NAME: D0,
        D1.NAME: D1,
        D2.NAME: D2,
        PWM1.NAME: PWM1,
        PWM2.NAME: PWM2,
        PWM3.NAME: PWM3,
        PWM4.NAME: PWM5,
        PWM5.NAME: PWM5,
        PWM6.NAME: PWM6,
        PWM7.NAME: PWM7,
        PWM8.NAME: PWM8,
        PWM9.NAME: PWM9,
        PWM10.NAME: PWM10,
        PWM11.NAME: PWM11,
        PWM12.NAME: PWM12,
        ADOL1.NAME: ADOL1,
        ADOL2.NAME: ADOL2,
        SID.NAME: SID,
        DATA0.NAME: DATA0,
        DATA1.NAME: DATA1,
        DATA2.NAME: DATA2,
        DATA3.NAME: DATA3,
        DATA4.NAME: DATA4,
        DATA5.NAME: DATA5,
    }
    COMMANDS = {
        **bmsbase.BMS_Config.COMMANDS,
        ADCV.NAME: ADCV,
        RDCVA.NAME: RDCVA,
        RDCVB.NAME: RDCVB,
        RDCVC.NAME: RDCVC,
        RDCVD.NAME: RDCVD,
        RDCVE.NAME: RDCVE,
        RDCVF.NAME: RDCVF,
        RDCDA.NAME: RDCDA,
        RDCDB.NAME: RDCDB,
        RDCDC.NAME: RDCDC,
        RDCDD.NAME: RDCDD,
        RDCVALL.NAME: RDCVALL,
        RDCDALL.NAME: RDCDALL,
        WRCFGA.NAME: WRCFGA,
        WRCFGB.NAME: WRCFGB,
        RDCFGA.NAME: RDCFGA,
        RDCFGB.NAME: RDCFGB,
        WRPWM.NAME: WRPWM,
        RDPWM.NAME: RDPWM,
        WRCOMM.NAME: WRCOMM,
        ADAX.NAME: ADAX,
        ADOL.NAME: ADOL,
        ADOW.NAME: ADOW,
        AXOW.NAME: AXOW,
        ADLEAK.NAME: ADLEAK,
        ADSC.NAME: ADSC,
        ADSTAT.NAME: ADSTAT,
        ADCVAX.NAME: ADCVAX,
        ADCVSC.NAME: ADCVSC,
        CVPG.NAME: CVPG,
        AXPG.NAME: AXPG,
        CDPG.NAME: CDPG,
        STATPG.NAME: STATPG,
        RDSTATA.NAME: RDSTATA,
        RDSTATB.NAME: RDSTATB,
        RDSTATC.NAME: RDSTATC,
        RDAUXA.NAME: RDAUXA,
        RDAUXB.NAME: RDAUXB,
        RDAUXC.NAME: RDAUXC,
        RDASALL.NAME: RDASALL,
        RDSID.NAME: RDSID,
        SRST.NAME: SRST,
        RSTCC.NAME: RSTCC,
        RSVDW1.NAME: RSVDW1,
        RSVDW2.NAME: RSVDW2,
        RSVDR1.NAME: RSVDR1,
        RSVDR2.NAME: RSVDR2,
        RSVDR3.NAME: RSVDR3,
        RSVDR4.NAME: RSVDR4,
        RSVDR5.NAME: RSVDR5,
        RSVDR6.NAME: RSVDR6,
        RSVDR7.NAME: RSVDR7,
        RSVDR8.NAME: RSVDR8,
        CVOW.NAME: CVOW,
        CLRCELL.NAME: CLRCELL,
        CLRAUX.NAME: CLRAUX,
        CLRSTAT.NAME: CLRSTAT,
        CLRCD.NAME: CLRCD,
        CLRFLAG.NAME: CLRFLAG,
        PLADC.NAME: PLADC,
        DIAGN.NAME: DIAGN,
        STCOMM.NAME: STCOMM,
        MUTE.NAME: MUTE,
        UNMUTE.NAME: UNMUTE,
        Broadcast_Command.NAME: Broadcast_Command,
        Write_Command.NAME: Write_Command,
        Read_Command.NAME: Read_Command,
        RDPSB.NAME: RDPSB,
        RDAUXD.NAME: RDAUXD
    }

    CELL_CONVERSION_CMDS = []
    SPIN_CONVERSION_CMDS = []
    AUX_CONVERSION_CMDS = []
    STAT_CONVERSION_CMDS = []
    CELL_ADC_POLL_CMDS = []
    AUX_ADC_POLL_CMDS = []
    STAT_ADC_POLL_CMDS = []
    ADC_POLL_CMDS = []
    SPIN_ADC_POLL_CMDS = []
    CELL_READ_CMDS = []
    SPIN_READ_CMDS = []
    AUX_READ_CMDS = []
    STAT_READ_CMDS = []
    WAKEUP_CMDS = []
    BCI_COM_CMD_LIST = []
    BCI_ANALOG_CMD_LIST = []
    GUI_LOOP_CMD_LIST = []
    SAFETY_COMMAND_LISTS = {}
    MAX_SPI_SPEED_CMDS = [
        {'command': '$SPI_SET_FREQUENCY_kHz$', 'arguments': {'Frequency': 2000}}
    ]
