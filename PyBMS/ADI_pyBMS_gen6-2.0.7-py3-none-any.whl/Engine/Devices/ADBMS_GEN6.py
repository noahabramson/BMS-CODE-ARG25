# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from abc import ABC
import Engine.Devices.BMS_Config as bmsbase


# ===================================================== Bitfields =====================================================
class CMD0(bmsbase.BitfieldInt):
    NAME = 'CMD0'
    DESCRIPTION = 'Command Byte 0'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD0, self).__init__(CMD0.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMD0.NAME


class CMD1(bmsbase.BitfieldInt):
    NAME = 'CMD1'
    DESCRIPTION = 'Command Byte 1'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMD1, self).__init__(CMD1.LENGTH, value=value, raw_value=raw_value)
        self.name = CMD1.NAME


class CCNT(bmsbase.BitfieldInt):
    NAME = 'CCNT'
    DESCRIPTION = 'Command Counter'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 63
    MIN_VALUE = 0
    LENGTH = 6
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CCNT, self).__init__(CCNT.LENGTH, value=value, raw_value=raw_value)
        self.name = CCNT.NAME


class CMD_PEC(bmsbase.BitfieldPEC):
    NAME = 'CMD PEC'
    DESCRIPTION = 'Command PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=16):
        super(CMD_PEC, self).__init__(CMD_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = CMD_PEC.NAME
        self.crc_cal_func = self.calc_pec15


class DATA_PEC(bmsbase.BitfieldPEC):
    NAME = 'DATA PEC'
    DESCRIPTION = 'Data PEC'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 10
    LIMITS = {}

    def __init__(self, value=0, raw_value=0, pec_size=54):
        super(DATA_PEC, self).__init__(DATA_PEC.LENGTH, value=value, raw_value=raw_value, pec_size=pec_size)
        self.name = DATA_PEC.NAME
        self.crc_cal_func = self.calc_pec10


class DATA0(bmsbase.BitfieldInt):
    NAME = 'DATA0'
    DESCRIPTION = 'Data Byte 0'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA0, self).__init__(DATA0.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA0.NAME


class DATA1(bmsbase.BitfieldInt):
    NAME = 'DATA1'
    DESCRIPTION = 'Data Byte 1'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA1, self).__init__(DATA1.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA1.NAME


class DATA2(bmsbase.BitfieldInt):
    NAME = 'DATA2'
    DESCRIPTION = 'Data Byte 2'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA2, self).__init__(DATA2.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA2.NAME


class DATA3(bmsbase.BitfieldInt):
    NAME = 'DATA3'
    DESCRIPTION = 'Data Byte 3'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA3, self).__init__(DATA3.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA3.NAME


class DATA4(bmsbase.BitfieldInt):
    NAME = 'DATA4'
    DESCRIPTION = 'Data Byte 4'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA4, self).__init__(DATA4.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA4.NAME


class DATA5(bmsbase.BitfieldInt):
    NAME = 'DATA5'
    DESCRIPTION = 'Data Byte 5'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DATA5, self).__init__(DATA5.LENGTH, value=value, raw_value=raw_value)
        self.name = DATA5.NAME



class TMODE(bmsbase.BitfieldBool):
    NAME = 'TMODE'
    DESCRIPTION = 'Test Mode Indicator'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(TMODE, self).__init__(TMODE.LENGTH,  value=value, raw_value=raw_value)
        self.name = TMODE.NAME


class CONT(bmsbase.BitfieldBool):
    NAME = 'CONT'
    DESCRIPTION = 'Continuous Conversion Enable'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}
    ALIASES = {
        'CONTINUOUS': True,
        'SINGLE': False
    }

    def __init__(self, value=False, raw_value=0):
        super(CONT, self).__init__(CONT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CONT.NAME


class RD(bmsbase.BitfieldBool):
    NAME = 'RD'
    DESCRIPTION = 'Redundant Conversion Enable'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(RD, self).__init__(RD.LENGTH,  value=value, raw_value=raw_value)
        self.name = RD.NAME


class OW(bmsbase.BitfieldInt):
    NAME = 'OW'
    DESCRIPTION = 'Open Wire Configuration'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x3
    MIN_VALUE = 0
    LENGTH = 2
    LIMITS = {
        'range': [0, 1, 2, 3]
    }
    ALIASES = {

    }

    def __init__(self, value=0, raw_value=0):
        super(OW, self).__init__(OW.LENGTH,  value=value, raw_value=raw_value)
        self.name = OW.NAME


class OW_AUX(bmsbase.BitfieldBool):
    NAME = 'OW_AUX'
    DESCRIPTION = 'Auxiliary Open Wire Switch Enable'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OW_AUX, self).__init__(OW_AUX.LENGTH, value=value, raw_value=raw_value)
        self.name = OW_AUX.NAME


class CH(bmsbase.BitfieldInt):
    NAME = 'CH'
    DESCRIPTION = 'Auxiliary Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x1F
    MIN_VALUE = 0
    LENGTH = 5
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CH, self).__init__(CH.LENGTH,  value=value, raw_value=raw_value)
        self.name = CH.NAME


class CH_AUX2(bmsbase.BitfieldInt):
    NAME = 'CH_AUX2'
    DESCRIPTION = 'Auxiliary 2 Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(CH_AUX2, self).__init__(CH_AUX2.LENGTH,  value=value, raw_value=raw_value)
        self.name = CH_AUX2.NAME


class DCP(bmsbase.BitfieldBool):
    NAME = 'DCP'
    DESCRIPTION = 'Discharge During Conversion Enable'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCP, self).__init__(DCP.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCP.NAME


class PUP(bmsbase.BitfieldBool):
    NAME = 'PUP'
    DESCRIPTION = 'Pull Up/Down Current Source for Open Wire Detection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(PUP, self).__init__(PUP.LENGTH,  value=value, raw_value=raw_value)
        self.name = PUP.NAME


class RSTF(bmsbase.BitfieldBool):
    NAME = 'RSTF'
    DESCRIPTION = 'Reset Filter'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(RSTF, self).__init__(RSTF.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSTF.NAME


class ERR(bmsbase.BitfieldBool):
    NAME = 'ERR'
    DESCRIPTION = 'Inject Error in SPI Read Out'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(ERR, self).__init__(ERR.LENGTH,  value=value, raw_value=raw_value)
        self.name = ERR.NAME


class REFON(bmsbase.BitfieldBool):
    NAME = 'REFON'
    DESCRIPTION = 'Reference Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=True, raw_value=1):
        super(REFON, self).__init__(REFON.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFON.NAME


class CTH(bmsbase.BitfieldInt):
    NAME = 'CTH'
    DESCRIPTION = 'C vs S ADC Comparison Voltage Threshold'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7]
    }

    def __init__(self, value=0, raw_value=0):
        super(CTH, self).__init__(CTH.LENGTH,  value=value, raw_value=raw_value)
        self.name = CTH.NAME


class FLAG_D(bmsbase.BitfieldInt):
    NAME = 'FLAG_D'
    DESCRIPTION = 'Diagnostic Mode Selection'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FLAG_D, self).__init__(FLAG_D.LENGTH,  value=value, raw_value=raw_value)
        self.name = FLAG_D.NAME


class SOAKON(bmsbase.BitfieldBool):
    NAME = 'SOAKON'
    DESCRIPTION = 'ADC Soak Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SOAKON, self).__init__(SOAKON.LENGTH,  value=value, raw_value=raw_value)
        self.name = SOAKON.NAME


class OWRNG(bmsbase.BitfieldBool):
    NAME = 'OWRNG'
    DESCRIPTION = 'Open Wire Soak Range Option'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OWRNG, self).__init__(OWRNG.LENGTH,  value=value, raw_value=raw_value)
        self.name = OWRNG.NAME


class OWA(bmsbase.BitfieldInt):
    NAME = 'OWA'
    DESCRIPTION = 'Auxiliary Open Wire Soak Time'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7]
    }

    def __init__(self, value=0, raw_value=0):
        super(OWA, self).__init__(OWA.LENGTH,  value=value, raw_value=raw_value)
        self.name = OWA.NAME


class GPO1(bmsbase.BitfieldBool):
    NAME = 'GPO1'
    DESCRIPTION = 'GPIO 1 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1, self).__init__(GPO1.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1.NAME


class GPO2(bmsbase.BitfieldBool):
    NAME = 'GPO2'
    DESCRIPTION = 'GPIO 2 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2, self).__init__(GPO2.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2.NAME


class GPO3(bmsbase.BitfieldBool):
    NAME = 'GPO3'
    DESCRIPTION = 'GPIO 3 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3, self).__init__(GPO3.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3.NAME


class GPO4(bmsbase.BitfieldBool):
    NAME = 'GPO4'
    DESCRIPTION = 'GPIO 4 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4, self).__init__(GPO4.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4.NAME


class GPO5(bmsbase.BitfieldBool):
    NAME = 'GPO5'
    DESCRIPTION = 'GPIO 5 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5, self).__init__(GPO5.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5.NAME


class GPO6(bmsbase.BitfieldBool):
    NAME = 'GPO6'
    DESCRIPTION = 'GPIO 6 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO6, self).__init__(GPO6.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6.NAME


class GPO7(bmsbase.BitfieldBool):
    NAME = 'GPO7'
    DESCRIPTION = 'GPIO 7 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO7, self).__init__(GPO7.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO7.NAME


class GPO8(bmsbase.BitfieldBool):
    NAME = 'GPO8'
    DESCRIPTION = 'GPIO 8 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO8, self).__init__(GPO8.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO8.NAME


class GPO9(bmsbase.BitfieldBool):
    NAME = 'GPO9'
    DESCRIPTION = 'GPIO 9 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO9, self).__init__(GPO9.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO9.NAME


class GPO10(bmsbase.BitfieldBool):
    NAME = 'GPO10'
    DESCRIPTION = 'GPIO 10 Output State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO10, self).__init__(GPO10.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO10.NAME


class FC(bmsbase.BitfieldInt):
    NAME = 'FC'
    DESCRIPTION = 'IIR Filter Parameter'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7]
    }

    def __init__(self, value=0, raw_value=0):
        super(FC, self).__init__(FC.LENGTH,  value=value, raw_value=raw_value)
        self.name = FC.NAME


class COMM_BK(bmsbase.BitfieldBool):
    NAME = 'COMM_BK'
    DESCRIPTION = 'Communication Break Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(COMM_BK, self).__init__(COMM_BK.LENGTH,  value=value, raw_value=raw_value)
        self.name = COMM_BK.NAME


class COMMBK(bmsbase.BitfieldBool):
    NAME = 'COMMBK'
    DESCRIPTION = 'Communication Break Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(COMMBK, self).__init__(COMMBK.LENGTH,  value=value, raw_value=raw_value)
        self.name = COMMBK.NAME

class MUTE_ST(bmsbase.BitfieldBool):
    NAME = 'MUTE_ST'
    DESCRIPTION = 'Discharge Mute Status'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MUTE_ST, self).__init__(MUTE_ST.LENGTH,  value=value, raw_value=raw_value)
        self.name = MUTE_ST.NAME


class SNAP_ST(bmsbase.BitfieldBool):
    NAME = 'SNAP_ST'
    DESCRIPTION = 'Snapshot Status'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SNAP_ST, self).__init__(SNAP_ST.LENGTH,  value=value, raw_value=raw_value)
        self.name = SNAP_ST.NAME


class VUV(bmsbase.BitfieldAdc):
    NAME = 'VUV'
    DESCRIPTION = 'Under Voltage Comparison Voltage'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VUV, self).__init__(VUV.LENGTH, value=value, raw_value=raw_value, lsb=16*0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VUV.NAME


class VOV(bmsbase.BitfieldAdc):
    NAME = 'VOV'
    DESCRIPTION = 'Over Voltage Comparison Voltage'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VOV, self).__init__(VOV.LENGTH, value=value, raw_value=raw_value, lsb=16*0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VOV.NAME


class DTMEN(bmsbase.BitfieldBool):
    NAME = 'DTMEN'
    DESCRIPTION = 'Discharge Monitor Timer Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTMEN, self).__init__(DTMEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTMEN.NAME


class DTRNG(bmsbase.BitfieldBool):
    NAME = 'DTRNG'
    DESCRIPTION = 'Discharge Monitor Timer Range Option'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DTRNG, self).__init__(DTRNG.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTRNG.NAME


class DCTO(bmsbase.BitfieldInt):
    NAME = 'DCTO'
    DESCRIPTION = 'Discharge Timeout Setting'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x3F
    MIN_VALUE = 0
    LENGTH = 6
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DCTO, self).__init__(DCTO.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCTO.NAME


class DCC1(bmsbase.BitfieldBool):
    NAME = 'DCC1'
    DESCRIPTION = 'Channel 1 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC1, self).__init__(DCC1.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC1.NAME


class DCC2(bmsbase.BitfieldBool):
    NAME = 'DCC2'
    DESCRIPTION = 'Channel 2 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC2, self).__init__(DCC2.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC2.NAME


class DCC3(bmsbase.BitfieldBool):
    NAME = 'DCC3'
    DESCRIPTION = 'Channel 3 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC3, self).__init__(DCC3.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC3.NAME


class DCC4(bmsbase.BitfieldBool):
    NAME = 'DCC4'
    DESCRIPTION = 'Channel 4 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC4, self).__init__(DCC4.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC4.NAME


class DCC5(bmsbase.BitfieldBool):
    NAME = 'DCC5'
    DESCRIPTION = 'Channel 5 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC5, self).__init__(DCC5.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC5.NAME


class DCC6(bmsbase.BitfieldBool):
    NAME = 'DCC6'
    DESCRIPTION = 'Channel 6 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC6, self).__init__(DCC6.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC6.NAME


class DCC7(bmsbase.BitfieldBool):
    NAME = 'DCC7'
    DESCRIPTION = 'Channel 7 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC7, self).__init__(DCC7.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC7.NAME


class DCC8(bmsbase.BitfieldBool):
    NAME = 'DCC8'
    DESCRIPTION = 'Channel 8 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC8, self).__init__(DCC8.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC8.NAME


class DCC9(bmsbase.BitfieldBool):
    NAME = 'DCC9'
    DESCRIPTION = 'Channel 9 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC9, self).__init__(DCC9.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC9.NAME


class DCC10(bmsbase.BitfieldBool):
    NAME = 'DCC10'
    DESCRIPTION = 'Channel 10 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC10, self).__init__(DCC10.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC10.NAME


class DCC11(bmsbase.BitfieldBool):
    NAME = 'DCC11'
    DESCRIPTION = 'Channel 11 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC11, self).__init__(DCC11.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC11.NAME


class DCC12(bmsbase.BitfieldBool):
    NAME = 'DCC12'
    DESCRIPTION = 'Channel 12 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC12, self).__init__(DCC12.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC12.NAME


class DCC13(bmsbase.BitfieldBool):
    NAME = 'DCC13'
    DESCRIPTION = 'Channel 13 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC13, self).__init__(DCC13.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC13.NAME


class DCC14(bmsbase.BitfieldBool):
    NAME = 'DCC14'
    DESCRIPTION = 'Channel 14 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC14, self).__init__(DCC14.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC14.NAME


class DCC15(bmsbase.BitfieldBool):
    NAME = 'DCC15'
    DESCRIPTION = 'Channel 15 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC15, self).__init__(DCC15.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC15.NAME


class DCC16(bmsbase.BitfieldBool):
    NAME = 'DCC16'
    DESCRIPTION = 'Channel 16 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC16, self).__init__(DCC16.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC16.NAME


class DCC17(bmsbase.BitfieldBool):
    NAME = 'DCC17'
    DESCRIPTION = 'Channel 17 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC17, self).__init__(DCC17.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC17.NAME


class DCC18(bmsbase.BitfieldBool):
    NAME = 'DCC18'
    DESCRIPTION = 'Channel 18 Discharge Switch Enable'
    MEM_KEY = 'Discharge Switch Setting'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(DCC18, self).__init__(DCC18.LENGTH,  value=value, raw_value=raw_value)
        self.name = DCC18.NAME


class ICOM0(bmsbase.BitfieldInt):
    NAME = 'ICOM0'
    DESCRIPTION = 'Initial Communication Control Setting Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(ICOM0, self).__init__(ICOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM0.NAME


class ICOM1(bmsbase.BitfieldInt):
    NAME = 'ICOM1'
    DESCRIPTION = 'Initial Communication Control Setting Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(ICOM1, self).__init__(ICOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM1.NAME


class ICOM2(bmsbase.BitfieldInt):
    NAME = 'ICOM2'
    DESCRIPTION = 'Initial Communication Control Setting Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(ICOM2, self).__init__(ICOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = ICOM2.NAME


class D0(bmsbase.BitfieldInt):
    NAME = 'D0'
    DESCRIPTION = 'Communication Data Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D0, self).__init__(D0.LENGTH,  value=value, raw_value=raw_value)
        self.name = D0.NAME


class D1(bmsbase.BitfieldInt):
    NAME = 'D1'
    DESCRIPTION = 'Communication Data Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D1, self).__init__(D1.LENGTH,  value=value, raw_value=raw_value)
        self.name = D1.NAME


class D2(bmsbase.BitfieldInt):
    NAME = 'D2'
    DESCRIPTION = 'Communication Data Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(D2, self).__init__(D2.LENGTH,  value=value, raw_value=raw_value)
        self.name = D2.NAME


class FCOM0(bmsbase.BitfieldInt):
    NAME = 'FCOM0'
    DESCRIPTION = 'Final Communication Control Setting Byte 0'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(FCOM0, self).__init__(FCOM0.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM0.NAME


class FCOM1(bmsbase.BitfieldInt):
    NAME = 'FCOM1'
    DESCRIPTION = 'Final Communication Control Setting Byte 1'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(FCOM1, self).__init__(FCOM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM1.NAME


class FCOM2(bmsbase.BitfieldInt):
    NAME = 'FCOM2'
    DESCRIPTION = 'Final Communication Control Setting Byte 2'
    MEM_KEY = 'COMM Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(FCOM2, self).__init__(FCOM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = FCOM2.NAME


class PWM1(bmsbase.BitfieldInt):
    NAME = 'PWM1'
    DESCRIPTION = 'Cell 1 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM1, self).__init__(PWM1.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM1.NAME


class PWM2(bmsbase.BitfieldInt):
    NAME = 'PWM2'
    DESCRIPTION = 'Cell 2 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM2, self).__init__(PWM2.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM2.NAME


class PWM3(bmsbase.BitfieldInt):
    NAME = 'PWM3'
    DESCRIPTION = 'Cell 3 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM3, self).__init__(PWM3.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM3.NAME


class PWM4(bmsbase.BitfieldInt):
    NAME = 'PWM4'
    DESCRIPTION = 'Cell 4 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM4, self).__init__(PWM4.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM4.NAME


class PWM5(bmsbase.BitfieldInt):
    NAME = 'PWM5'
    DESCRIPTION = 'Cell 5 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM5, self).__init__(PWM5.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM5.NAME


class PWM6(bmsbase.BitfieldInt):
    NAME = 'PWM6'
    DESCRIPTION = 'Cell 6 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM6, self).__init__(PWM6.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM6.NAME


class PWM7(bmsbase.BitfieldInt):
    NAME = 'PWM7'
    DESCRIPTION = 'Cell 7 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM7, self).__init__(PWM7.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM7.NAME


class PWM8(bmsbase.BitfieldInt):
    NAME = 'PWM8'
    DESCRIPTION = 'Cell 8 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM8, self).__init__(PWM8.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM8.NAME


class PWM9(bmsbase.BitfieldInt):
    NAME = 'PWM9'
    DESCRIPTION = 'Cell 9 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM9, self).__init__(PWM9.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM9.NAME


class PWM10(bmsbase.BitfieldInt):
    NAME = 'PWM10'
    DESCRIPTION = 'Cell 10 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM10, self).__init__(PWM10.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM10.NAME


class PWM11(bmsbase.BitfieldInt):
    NAME = 'PWM11'
    DESCRIPTION = 'Cell 11 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM11, self).__init__(PWM11.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM11.NAME


class PWM12(bmsbase.BitfieldInt):
    NAME = 'PWM12'
    DESCRIPTION = 'Cell 12 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM12, self).__init__(PWM12.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM12.NAME


class PWM13(bmsbase.BitfieldInt):
    NAME = 'PWM13'
    DESCRIPTION = 'Cell 13 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM13, self).__init__(PWM13.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM13.NAME


class PWM14(bmsbase.BitfieldInt):
    NAME = 'PWM14'
    DESCRIPTION = 'Cell 14 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM14, self).__init__(PWM14.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM14.NAME


class PWM15(bmsbase.BitfieldInt):
    NAME = 'PWM15'
    DESCRIPTION = 'Cell 15 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM15, self).__init__(PWM15.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM15.NAME


class PWM16(bmsbase.BitfieldInt):
    NAME = 'PWM16'
    DESCRIPTION = 'Cell 16 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM16, self).__init__(PWM16.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM16.NAME


class PWM17(bmsbase.BitfieldInt):
    NAME = 'PWM17'
    DESCRIPTION = 'Cell 17 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM17, self).__init__(PWM17.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM17.NAME


class PWM18(bmsbase.BitfieldInt):
    NAME = 'PWM18'
    DESCRIPTION = 'Cell 18 PWM Discharge Configuration'
    MEM_KEY = 'PWM Discharge Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xF
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(PWM18, self).__init__(PWM18.LENGTH,  value=value, raw_value=raw_value)
        self.name = PWM18.NAME


class SID(bmsbase.BitfieldInt):
    NAME = 'SID'
    DESCRIPTION = 'Serial ID'
    MEM_KEY = 'Serial ID Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = (2**6)-1
    MIN_VALUE = 0
    LENGTH = 48
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(SID, self).__init__(SID.LENGTH,  value=value, raw_value=raw_value)
        self.name = SID.NAME


class RR(bmsbase.BitfieldInt):
    NAME = 'RR'
    DESCRIPTION = 'Retention Register Data'
    MEM_KEY = 'Retention Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = (2**6)-1
    MIN_VALUE = 0
    LENGTH = 48
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RR, self).__init__(RR.LENGTH,  value=value, raw_value=raw_value)
        self.name = RR.NAME


class TEST_DATA0(bmsbase.BitfieldInt):
    NAME = 'TEST_DATA0'
    DESCRIPTION = 'Data Byte 0'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TEST_DATA0, self).__init__(TEST_DATA0.LENGTH,  value=value, raw_value=raw_value)
        self.name = TEST_DATA0.NAME


class TEST_DATA1(bmsbase.BitfieldInt):
    NAME = 'TEST_DATA1'
    DESCRIPTION = 'Data Byte 1'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TEST_DATA1, self).__init__(TEST_DATA1.LENGTH,  value=value, raw_value=raw_value)
        self.name = TEST_DATA1.NAME


class DTYPE(bmsbase.BitfieldInt):
    NAME = 'DTYPE'
    DESCRIPTION = 'Device Type ID'
    MEM_KEY = 'Serial ID Register Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x3F
    MIN_VALUE = 0
    LENGTH = 6
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DTYPE, self).__init__(DTYPE.LENGTH,  value=value, raw_value=raw_value)
        self.name = DTYPE.NAME


class C1V(bmsbase.BitfieldAdc):
    NAME = 'C1V'
    DESCRIPTION = 'Cell 1'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C1V, self).__init__(C1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C1V.NAME


class C2V(bmsbase.BitfieldAdc):
    NAME = 'C2V'
    DESCRIPTION = 'Cell 2'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C2V, self).__init__(C2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C2V.NAME


class C3V(bmsbase.BitfieldAdc):
    NAME = 'C3V'
    DESCRIPTION = 'Cell 3'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C3V, self).__init__(C3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C3V.NAME


class C4V(bmsbase.BitfieldAdc):
    NAME = 'C4V'
    DESCRIPTION = 'Cell 4'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C4V, self).__init__(C4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C4V.NAME


class C5V(bmsbase.BitfieldAdc):
    NAME = 'C5V'
    DESCRIPTION = 'Cell 5'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C5V, self).__init__(C5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C5V.NAME


class C6V(bmsbase.BitfieldAdc):
    NAME = 'C6V'
    DESCRIPTION = 'Cell 6'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C6V, self).__init__(C6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C6V.NAME


class C7V(bmsbase.BitfieldAdc):
    NAME = 'C7V'
    DESCRIPTION = 'Cell 7'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C7V, self).__init__(C7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C7V.NAME


class C8V(bmsbase.BitfieldAdc):
    NAME = 'C8V'
    DESCRIPTION = 'Cell 8'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C8V, self).__init__(C8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C8V.NAME


class C9V(bmsbase.BitfieldAdc):
    NAME = 'C9V'
    DESCRIPTION = 'Cell 9'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C9V, self).__init__(C9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C9V.NAME


class C10V(bmsbase.BitfieldAdc):
    NAME = 'C10V'
    DESCRIPTION = 'Cell 10'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C10V, self).__init__(C10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C10V.NAME


class C11V(bmsbase.BitfieldAdc):
    NAME = 'C11V'
    DESCRIPTION = 'Cell 11'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C11V, self).__init__(C11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C11V.NAME


class C12V(bmsbase.BitfieldAdc):
    NAME = 'C12V'
    DESCRIPTION = 'Cell 12'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C12V, self).__init__(C12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C12V.NAME


class C13V(bmsbase.BitfieldAdc):
    NAME = 'C13V'
    DESCRIPTION = 'Cell 13'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C13V, self).__init__(C13V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C13V.NAME


class C14V(bmsbase.BitfieldAdc):
    NAME = 'C14V'
    DESCRIPTION = 'Cell 14'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C14V, self).__init__(C14V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C14V.NAME


class C15V(bmsbase.BitfieldAdc):
    NAME = 'C15V'
    DESCRIPTION = 'Cell 15'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C15V, self).__init__(C15V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C15V.NAME


class C16V(bmsbase.BitfieldAdc):
    NAME = 'C16V'
    DESCRIPTION = 'Cell 16'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C16V, self).__init__(C16V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C16V.NAME


class C17V(bmsbase.BitfieldAdc):
    NAME = 'C17V'
    DESCRIPTION = 'Cell 17'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C17V, self).__init__(C17V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C17V.NAME


class C18V(bmsbase.BitfieldAdc):
    NAME = 'C18V'
    DESCRIPTION = 'Cell 18'
    MEM_KEY = 'Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(C18V, self).__init__(C18V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = C18V.NAME


class AC1V(bmsbase.BitfieldAdc):
    NAME = 'AC1V'
    DESCRIPTION = 'Averaged Cell 1'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC1V, self).__init__(AC1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC1V.NAME


class AC2V(bmsbase.BitfieldAdc):
    NAME = 'AC2V'
    DESCRIPTION = 'Averaged Cell 2'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC2V, self).__init__(AC2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC2V.NAME


class AC3V(bmsbase.BitfieldAdc):
    NAME = 'AC3V'
    DESCRIPTION = 'Averaged Cell 3'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC3V, self).__init__(AC3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC3V.NAME


class AC4V(bmsbase.BitfieldAdc):
    NAME = 'AC4V'
    DESCRIPTION = 'Averaged Cell 4'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC4V, self).__init__(AC4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC4V.NAME


class AC5V(bmsbase.BitfieldAdc):
    NAME = 'AC5V'
    DESCRIPTION = 'Averaged Cell 5'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC5V, self).__init__(AC5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC5V.NAME


class AC6V(bmsbase.BitfieldAdc):
    NAME = 'AC6V'
    DESCRIPTION = 'Averaged Cell 6'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC6V, self).__init__(AC6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC6V.NAME


class AC7V(bmsbase.BitfieldAdc):
    NAME = 'AC7V'
    DESCRIPTION = 'Averaged Cell 7'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC7V, self).__init__(AC7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC7V.NAME


class AC8V(bmsbase.BitfieldAdc):
    NAME = 'AC8V'
    DESCRIPTION = 'Averaged Cell 8'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC8V, self).__init__(AC8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC8V.NAME


class AC9V(bmsbase.BitfieldAdc):
    NAME = 'AC9V'
    DESCRIPTION = 'Averaged Cell 9'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC9V, self).__init__(AC9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC9V.NAME


class AC10V(bmsbase.BitfieldAdc):
    NAME = 'AC10V'
    DESCRIPTION = 'Averaged Cell 10'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC10V, self).__init__(AC10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC10V.NAME


class AC11V(bmsbase.BitfieldAdc):
    NAME = 'AC11V'
    DESCRIPTION = 'Averaged Cell 11'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC11V, self).__init__(AC11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC11V.NAME


class AC12V(bmsbase.BitfieldAdc):
    NAME = 'AC12V'
    DESCRIPTION = 'Averaged Cell 12'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC12V, self).__init__(AC12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC12V.NAME


class AC13V(bmsbase.BitfieldAdc):
    NAME = 'AC13V'
    DESCRIPTION = 'Averaged Cell 13'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC13V, self).__init__(AC13V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC13V.NAME


class AC14V(bmsbase.BitfieldAdc):
    NAME = 'AC14V'
    DESCRIPTION = 'Averaged Cell 14'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC14V, self).__init__(AC14V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC14V.NAME


class AC15V(bmsbase.BitfieldAdc):
    NAME = 'AC15V'
    DESCRIPTION = 'Averaged Cell 15'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC15V, self).__init__(AC15V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC15V.NAME


class AC16V(bmsbase.BitfieldAdc):
    NAME = 'AC16V'
    DESCRIPTION = 'Averaged Cell 16'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC16V, self).__init__(AC16V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC16V.NAME


class AC17V(bmsbase.BitfieldAdc):
    NAME = 'AC17V'
    DESCRIPTION = 'Averaged Cell 17'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC17V, self).__init__(AC17V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC17V.NAME


class AC18V(bmsbase.BitfieldAdc):
    NAME = 'AC18V'
    DESCRIPTION = 'Averaged Cell 18'
    MEM_KEY = 'Averaged Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(AC18V, self).__init__(AC18V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = AC18V.NAME


class FC1V(bmsbase.BitfieldAdc):
    NAME = 'FC1V'
    DESCRIPTION = 'Filtered Cell 1'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC1V, self).__init__(FC1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC1V.NAME


class FC2V(bmsbase.BitfieldAdc):
    NAME = 'FC2V'
    DESCRIPTION = 'Filtered Cell 2'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC2V, self).__init__(FC2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC2V.NAME


class FC3V(bmsbase.BitfieldAdc):
    NAME = 'FC3V'
    DESCRIPTION = 'Filtered Cell 3'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC3V, self).__init__(FC3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC3V.NAME


class FC4V(bmsbase.BitfieldAdc):
    NAME = 'FC4V'
    DESCRIPTION = 'Filtered Cell 4'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC4V, self).__init__(FC4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC4V.NAME


class FC5V(bmsbase.BitfieldAdc):
    NAME = 'FC5V'
    DESCRIPTION = 'Filtered Cell 5'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC5V, self).__init__(FC5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC5V.NAME


class FC6V(bmsbase.BitfieldAdc):
    NAME = 'FC6V'
    DESCRIPTION = 'Filtered Cell 6'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC6V, self).__init__(FC6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC6V.NAME


class FC7V(bmsbase.BitfieldAdc):
    NAME = 'FC7V'
    DESCRIPTION = 'Filtered Cell 7'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC7V, self).__init__(FC7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC7V.NAME


class FC8V(bmsbase.BitfieldAdc):
    NAME = 'FC8V'
    DESCRIPTION = 'Filtered Cell 8'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC8V, self).__init__(FC8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC8V.NAME


class FC9V(bmsbase.BitfieldAdc):
    NAME = 'FC9V'
    DESCRIPTION = 'Filtered Cell 9'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC9V, self).__init__(FC9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC9V.NAME


class FC10V(bmsbase.BitfieldAdc):
    NAME = 'FC10V'
    DESCRIPTION = 'Filtered Cell 10'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC10V, self).__init__(FC10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC10V.NAME


class FC11V(bmsbase.BitfieldAdc):
    NAME = 'FC11V'
    DESCRIPTION = 'Filtered Cell 11'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC11V, self).__init__(FC11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC11V.NAME


class FC12V(bmsbase.BitfieldAdc):
    NAME = 'FC12V'
    DESCRIPTION = 'Filtered Cell 12'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC12V, self).__init__(FC12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC12V.NAME


class FC13V(bmsbase.BitfieldAdc):
    NAME = 'FC13V'
    DESCRIPTION = 'Filtered Cell 13'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC13V, self).__init__(FC13V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC13V.NAME


class FC14V(bmsbase.BitfieldAdc):
    NAME = 'FC14V'
    DESCRIPTION = 'Filtered Cell 14'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC14V, self).__init__(FC14V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC14V.NAME


class FC15V(bmsbase.BitfieldAdc):
    NAME = 'FC15V'
    DESCRIPTION = 'Filtered Cell 15'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC15V, self).__init__(FC15V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC15V.NAME


class FC16V(bmsbase.BitfieldAdc):
    NAME = 'FC16V'
    DESCRIPTION = 'Filtered Cell 16'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC16V, self).__init__(FC16V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC16V.NAME


class FC17V(bmsbase.BitfieldAdc):
    NAME = 'FC17V'
    DESCRIPTION = 'Filtered Cell 17'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC17V, self).__init__(FC17V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC17V.NAME


class FC18V(bmsbase.BitfieldAdc):
    NAME = 'FC18V'
    DESCRIPTION = 'Filtered Cell 18'
    MEM_KEY = 'Filtered Cell Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FC18V, self).__init__(FC18V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = FC18V.NAME


class S1V(bmsbase.BitfieldAdc):
    NAME = 'S1V'
    DESCRIPTION = 'S Pin Voltage 1'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S1V, self).__init__(S1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S1V.NAME


class S2V(bmsbase.BitfieldAdc):
    NAME = 'S2V'
    DESCRIPTION = 'S Pin Voltage 2'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S2V, self).__init__(S2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S2V.NAME


class S3V(bmsbase.BitfieldAdc):
    NAME = 'S3V'
    DESCRIPTION = 'S Pin Voltage 3'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S3V, self).__init__(S3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S3V.NAME


class S4V(bmsbase.BitfieldAdc):
    NAME = 'S4V'
    DESCRIPTION = 'S Pin Voltage 4'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S4V, self).__init__(S4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S4V.NAME


class S5V(bmsbase.BitfieldAdc):
    NAME = 'S5V'
    DESCRIPTION = 'S Pin Voltage 5'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S5V, self).__init__(S5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S5V.NAME


class S6V(bmsbase.BitfieldAdc):
    NAME = 'S6V'
    DESCRIPTION = 'S Pin Voltage 6'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S6V, self).__init__(S6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S6V.NAME


class S7V(bmsbase.BitfieldAdc):
    NAME = 'S7V'
    DESCRIPTION = 'S Pin Voltage 7'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S7V, self).__init__(S7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S7V.NAME


class S8V(bmsbase.BitfieldAdc):
    NAME = 'S8V'
    DESCRIPTION = 'S Pin Voltage 8'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S8V, self).__init__(S8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S8V.NAME


class S9V(bmsbase.BitfieldAdc):
    NAME = 'S9V'
    DESCRIPTION = 'S Pin Voltage 9'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S9V, self).__init__(S9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S9V.NAME


class S10V(bmsbase.BitfieldAdc):
    NAME = 'S10V'
    DESCRIPTION = 'S Pin Voltage 10'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S10V, self).__init__(S10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S10V.NAME


class S11V(bmsbase.BitfieldAdc):
    NAME = 'S11V'
    DESCRIPTION = 'S Pin Voltage 11'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S11V, self).__init__(S11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S11V.NAME


class S12V(bmsbase.BitfieldAdc):
    NAME = 'S12V'
    DESCRIPTION = 'S Pin Voltage 12'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S12V, self).__init__(S12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S12V.NAME


class S13V(bmsbase.BitfieldAdc):
    NAME = 'S13V'
    DESCRIPTION = 'S Pin Voltage 13'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S13V, self).__init__(S13V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S13V.NAME


class S14V(bmsbase.BitfieldAdc):
    NAME = 'S14V'
    DESCRIPTION = 'S Pin Voltage 14'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S14V, self).__init__(S14V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S14V.NAME


class S15V(bmsbase.BitfieldAdc):
    NAME = 'S15V'
    DESCRIPTION = 'S Pin Voltage 15'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S15V, self).__init__(S15V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S15V.NAME


class S16V(bmsbase.BitfieldAdc):
    NAME = 'S16V'
    DESCRIPTION = 'S Pin Voltage 16'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S16V, self).__init__(S16V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S16V.NAME


class S17V(bmsbase.BitfieldAdc):
    NAME = 'S17V'
    DESCRIPTION = 'S Pin Voltage 17'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S17V, self).__init__(S17V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S17V.NAME


class S18V(bmsbase.BitfieldAdc):
    NAME = 'S18V'
    DESCRIPTION = 'S Pin Voltage 18'
    MEM_KEY = 'S-Pin Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(S18V, self).__init__(S18V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = S18V.NAME


class G1V(bmsbase.BitfieldAdc):
    NAME = 'G1V'
    DESCRIPTION = 'GPIO1 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G1V, self).__init__(G1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G1V.NAME


class G2V(bmsbase.BitfieldAdc):
    NAME = 'G2V'
    DESCRIPTION = 'GPIO2 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G2V, self).__init__(G2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G2V.NAME


class G3V(bmsbase.BitfieldAdc):
    NAME = 'G3V'
    DESCRIPTION = 'GPIO3 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G3V, self).__init__(G3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G3V.NAME


class G4V(bmsbase.BitfieldAdc):
    NAME = 'G4V'
    DESCRIPTION = 'GPIO4 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G4V, self).__init__(G4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G4V.NAME


class G5V(bmsbase.BitfieldAdc):
    NAME = 'G5V'
    DESCRIPTION = 'GPIO5 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G5V, self).__init__(G5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G5V.NAME


class G6V(bmsbase.BitfieldAdc):
    NAME = 'G6V'
    DESCRIPTION = 'GPIO6 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G6V, self).__init__(G6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G6V.NAME


class G7V(bmsbase.BitfieldAdc):
    NAME = 'G7V'
    DESCRIPTION = 'GPIO7 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G7V, self).__init__(G7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G7V.NAME


class G8V(bmsbase.BitfieldAdc):
    NAME = 'G8V'
    DESCRIPTION = 'GPIO8 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G8V, self).__init__(G8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G8V.NAME


class G9V(bmsbase.BitfieldAdc):
    NAME = 'G9V'
    DESCRIPTION = 'GPIO9 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G9V, self).__init__(G9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G9V.NAME


class G10V(bmsbase.BitfieldAdc):
    NAME = 'G10V'
    DESCRIPTION = 'GPIO10 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(G10V, self).__init__(G10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = G10V.NAME


class GA11V(bmsbase.BitfieldAdc):
    NAME = 'GA11V'
    DESCRIPTION = 'GPIO11 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(GA11V, self).__init__(GA11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = GA11V.NAME


class GA12V(bmsbase.BitfieldAdc):
    NAME = 'GA12V'
    DESCRIPTION = 'GPIO12 Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(GA12V, self).__init__(GA12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = GA12V.NAME


class VMV(bmsbase.BitfieldAdc):
    NAME = 'VMV'
    DESCRIPTION = 'V- to V- Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VMV, self).__init__(VMV.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VMV.NAME


class VPV(bmsbase.BitfieldAdc):
    NAME = 'VPV'
    DESCRIPTION = 'V+ to V- Voltage Measurement'
    MEM_KEY = 'Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VPV, self).__init__(VPV.LENGTH, value=value, raw_value=raw_value, lsb=0.000150*25, postpend=1.5*25, prepend=0, twos_complement=True)
        self.name = VPV.NAME


class R_G1V(bmsbase.BitfieldAdc):
    NAME = 'R_G1V'
    DESCRIPTION = 'Redundant GPIO1 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G1V, self).__init__(R_G1V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G1V.NAME


class R_G2V(bmsbase.BitfieldAdc):
    NAME = 'R_G2V'
    DESCRIPTION = 'Redundant GPIO2 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G2V, self).__init__(R_G2V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G2V.NAME


class R_G3V(bmsbase.BitfieldAdc):
    NAME = 'R_G3V'
    DESCRIPTION = 'Redundant GPIO3 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G3V, self).__init__(R_G3V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G3V.NAME


class R_G4V(bmsbase.BitfieldAdc):
    NAME = 'R_G4V'
    DESCRIPTION = 'Redundant GPIO4 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G4V, self).__init__(R_G4V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G4V.NAME


class R_G5V(bmsbase.BitfieldAdc):
    NAME = 'R_G5V'
    DESCRIPTION = 'Redundant GPIO5 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G5V, self).__init__(R_G5V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G5V.NAME


class R_G6V(bmsbase.BitfieldAdc):
    NAME = 'R_G6V'
    DESCRIPTION = 'Redundant GPIO6 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G6V, self).__init__(R_G6V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G6V.NAME


class R_G7V(bmsbase.BitfieldAdc):
    NAME = 'R_G7V'
    DESCRIPTION = 'Redundant GPIO7 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G7V, self).__init__(R_G7V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G7V.NAME


class R_G8V(bmsbase.BitfieldAdc):
    NAME = 'R_G8V'
    DESCRIPTION = 'Redundant GPIO8 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G8V, self).__init__(R_G8V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G8V.NAME


class R_G9V(bmsbase.BitfieldAdc):
    NAME = 'R_G9V'
    DESCRIPTION = 'Redundant GPIO9 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G9V, self).__init__(R_G9V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G9V.NAME


class R_G10V(bmsbase.BitfieldAdc):
    NAME = 'R_G10V'
    DESCRIPTION = 'Redundant GPIO10 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_G10V, self).__init__(R_G10V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_G10V.NAME


class R_GA11V(bmsbase.BitfieldAdc):
    NAME = 'R_GA11V'
    DESCRIPTION = 'Redundant GPIO11 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_GA11V, self).__init__(R_GA11V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_GA11V.NAME


class R_GA12V(bmsbase.BitfieldAdc):
    NAME = 'R_GA12V'
    DESCRIPTION = 'Redundant GPIO12 Voltage Measurement'
    MEM_KEY = 'Redundant Auxiliary Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(R_GA12V, self).__init__(R_GA12V.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = R_GA12V.NAME


class VREF2(bmsbase.BitfieldAdc):
    NAME = 'VREF2'
    DESCRIPTION = 'Secondary Reference Internal Measurement'
    MEM_KEY = 'Internal Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VREF2, self).__init__(VREF2.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VREF2.NAME


class ITMP(bmsbase.BitfieldAdc):
    NAME = 'ITMP'
    DESCRIPTION = 'Die Temperature Measurement'
    MEM_KEY = 'Internal Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 582.34
    MIN_VALUE = -728.36
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(ITMP, self).__init__(ITMP.LENGTH, value=value, raw_value=raw_value, lsb=0.02, postpend=-73, prepend=0)
        self.name = ITMP.NAME


class VA(bmsbase.BitfieldAdc):
    NAME = 'VA'
    DESCRIPTION = 'Vreg Internal Measurement'
    MEM_KEY = 'Internal Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VA, self).__init__(VA.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VA.NAME


class VD(bmsbase.BitfieldAdc):
    NAME = 'VD'
    DESCRIPTION = 'Digital Voltage Regulator Internal Measurement'
    MEM_KEY = 'Internal Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VD, self).__init__(VD.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VD.NAME


class VRES(bmsbase.BitfieldAdc):
    NAME = 'VRES'
    DESCRIPTION = 'VREF2 Across Resistor Voltage Measurement'
    MEM_KEY = 'Internal Voltages'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.41505
    MIN_VALUE = -3.4152
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VRES, self).__init__(VRES.LENGTH, value=value, raw_value=raw_value, lsb=0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = VRES.NAME


class CS1FLT(bmsbase.BitfieldBool):
    NAME = 'CS1FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 1'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS1FLT, self).__init__(CS1FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS1FLT.NAME


class CS2FLT(bmsbase.BitfieldBool):
    NAME = 'CS2FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 2'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS2FLT, self).__init__(CS2FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS2FLT.NAME


class CS3FLT(bmsbase.BitfieldBool):
    NAME = 'CS3FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 3'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS3FLT, self).__init__(CS3FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS3FLT.NAME


class CS4FLT(bmsbase.BitfieldBool):
    NAME = 'CS4FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 4'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS4FLT, self).__init__(CS4FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS4FLT.NAME


class CS5FLT(bmsbase.BitfieldBool):
    NAME = 'CS5FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 5'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS5FLT, self).__init__(CS5FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS5FLT.NAME


class CS6FLT(bmsbase.BitfieldBool):
    NAME = 'CS6FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 6'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS6FLT, self).__init__(CS6FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS6FLT.NAME


class CS7FLT(bmsbase.BitfieldBool):
    NAME = 'CS7FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 7'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS7FLT, self).__init__(CS7FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS7FLT.NAME


class CS8FLT(bmsbase.BitfieldBool):
    NAME = 'CS8FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 8'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS8FLT, self).__init__(CS8FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS8FLT.NAME


class CS9FLT(bmsbase.BitfieldBool):
    NAME = 'CS9FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 9'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS9FLT, self).__init__(CS9FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS9FLT.NAME


class CS10FLT(bmsbase.BitfieldBool):
    NAME = 'CS10FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 10'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS10FLT, self).__init__(CS10FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS10FLT.NAME


class CS11FLT(bmsbase.BitfieldBool):
    NAME = 'CS11FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 11'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS11FLT, self).__init__(CS11FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS11FLT.NAME


class CS12FLT(bmsbase.BitfieldBool):
    NAME = 'CS12FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 12'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS12FLT, self).__init__(CS12FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS12FLT.NAME

class CS13FLT(bmsbase.BitfieldBool):
    NAME = 'CS13FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 13'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS13FLT, self).__init__(CS13FLT.LENGTH, value=value, raw_value=raw_value)
        self.name = CS13FLT.NAME


class CS14FLT(bmsbase.BitfieldBool):
    NAME = 'CS14FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 14'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS14FLT, self).__init__(CS14FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS14FLT.NAME


class CS15FLT(bmsbase.BitfieldBool):
    NAME = 'CS15FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 15'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS15FLT, self).__init__(CS15FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS15FLT.NAME


class CS16FLT(bmsbase.BitfieldBool):
    NAME = 'CS16FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 16'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS16FLT, self).__init__(CS16FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS16FLT.NAME


class CS17FLT(bmsbase.BitfieldBool):
    NAME = 'CS17FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 17'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS17FLT, self).__init__(CS17FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS17FLT.NAME


class CS18FLT(bmsbase.BitfieldBool):
    NAME = 'CS18FLT'
    DESCRIPTION = 'C vs S ADC Fault Flag Channel 18'
    MEM_KEY = 'C vs S Comparison Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CS18FLT, self).__init__(CS18FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CS18FLT.NAME


class VA_OV(bmsbase.BitfieldBool):
    NAME = 'VA_OV'
    DESCRIPTION = 'Vreg Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VA_OV, self).__init__(VA_OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VA_OV.NAME


class VA_UV(bmsbase.BitfieldBool):
    NAME = 'VA_UV'
    DESCRIPTION = 'Vreg Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VA_UV, self).__init__(VA_UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VA_UV.NAME


class VD_OV(bmsbase.BitfieldBool):
    NAME = 'VD_OV'
    DESCRIPTION = 'Digital Voltage Over Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VD_OV, self).__init__(VD_OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VD_OV.NAME


class VD_UV(bmsbase.BitfieldBool):
    NAME = 'VD_UV'
    DESCRIPTION = 'Digital Voltage Under Voltage Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VD_UV, self).__init__(VD_UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VD_UV.NAME


class CED(bmsbase.BitfieldBool):
    NAME = 'CED'
    DESCRIPTION = 'C-ADC Trim Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CED, self).__init__(CED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CED.NAME


class CMED(bmsbase.BitfieldBool):
    NAME = 'CMED'
    DESCRIPTION = 'C-ADC Trim Multiple Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMED, self).__init__(CMED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMED.NAME


class SED(bmsbase.BitfieldBool):
    NAME = 'SED'
    DESCRIPTION = 'S-ADC Trim Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SED, self).__init__(SED.LENGTH,  value=value, raw_value=raw_value)
        self.name = SED.NAME


class SMED(bmsbase.BitfieldBool):
    NAME = 'SMED'
    DESCRIPTION = 'S-ADC Trim Multiple Error Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SMED, self).__init__(SMED.LENGTH,  value=value, raw_value=raw_value)
        self.name = SMED.NAME


class VDE(bmsbase.BitfieldBool):
    NAME = 'VDE'
    DESCRIPTION = 'Supply Voltage Delta Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDE, self).__init__(VDE.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDE.NAME


class VDEL(bmsbase.BitfieldBool):
    NAME = 'VDEL'
    DESCRIPTION = 'Supply Voltage Delta Latent Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDEL, self).__init__(VDEL.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDEL.NAME


class COMP(bmsbase.BitfieldBool):
    NAME = 'COMP'
    DESCRIPTION = 'C vs S Comparison Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(COMP, self).__init__(COMP.LENGTH,  value=value, raw_value=raw_value)
        self.name = COMP.NAME


class SPIFLT(bmsbase.BitfieldBool):
    NAME = 'SPIFLT'
    DESCRIPTION = 'SPI Fault Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SPIFLT, self).__init__(SPIFLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = SPIFLT.NAME


class SLEEP(bmsbase.BitfieldBool):
    NAME = 'SLEEP'
    DESCRIPTION = 'Sleep Mode Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SLEEP, self).__init__(SLEEP.LENGTH,  value=value, raw_value=raw_value)
        self.name = SLEEP.NAME


class THSD(bmsbase.BitfieldBool):
    NAME = 'THSD'
    DESCRIPTION = 'Thermal Shutdown Status Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(THSD, self).__init__(THSD.LENGTH,  value=value, raw_value=raw_value)
        self.name = THSD.NAME


class TMODCHK(bmsbase.BitfieldBool):
    NAME = 'TMODCHK'
    DESCRIPTION = 'Test Mode Detection Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(TMODCHK, self).__init__(TMODCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = TMODCHK.NAME


class OSCCHK(bmsbase.BitfieldBool):
    NAME = 'OSCCHK'
    DESCRIPTION = 'Oscillator Check Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OSCCHK, self).__init__(OSCCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = OSCCHK.NAME


class CL_CS1FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS1FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 1'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS1FLT, self).__init__(CL_CS1FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS1FLT.NAME


class CL_CS2FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS2FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 2'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS2FLT, self).__init__(CL_CS2FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS2FLT.NAME


class CL_CS3FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS3FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 3'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS3FLT, self).__init__(CL_CS3FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS3FLT.NAME


class CL_CS4FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS4FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 4'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS4FLT, self).__init__(CL_CS4FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS4FLT.NAME


class CL_CS5FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS5FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 5'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS5FLT, self).__init__(CL_CS5FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS5FLT.NAME


class CL_CS6FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS6FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 6'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS6FLT, self).__init__(CL_CS6FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS6FLT.NAME


class CL_CS7FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS7FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 7'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS7FLT, self).__init__(CL_CS7FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS7FLT.NAME


class CL_CS8FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS8FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 8'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS8FLT, self).__init__(CL_CS8FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS8FLT.NAME


class CL_CS9FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS9FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 9'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS9FLT, self).__init__(CL_CS9FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS9FLT.NAME


class CL_CS10FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS10FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 10'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS10FLT, self).__init__(CL_CS10FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS10FLT.NAME


class CL_CS11FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS11FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 11'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS11FLT, self).__init__(CL_CS11FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS11FLT.NAME


class CL_CS12FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS12FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 12'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS12FLT, self).__init__(CL_CS12FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS12FLT.NAME


class CL_CS13FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS13FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 13'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS13FLT, self).__init__(CL_CS13FLT.LENGTH, value=value, raw_value=raw_value)
        self.name = CL_CS13FLT.NAME


class CL_CS14FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS14FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 14'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS14FLT, self).__init__(CL_CS14FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS14FLT.NAME


class CL_CS15FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS15FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 15'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS15FLT, self).__init__(CL_CS15FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS15FLT.NAME


class CL_CS16FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS16FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 16'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS16FLT, self).__init__(CL_CS16FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS16FLT.NAME


class CL_CS17FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS17FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 17'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS17FLT, self).__init__(CL_CS17FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS17FLT.NAME


class CL_CS18FLT(bmsbase.BitfieldBool):
    NAME = 'CL_CS18FLT'
    DESCRIPTION = 'Clear C vs S ADC Fault Flag Channel 18'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CS18FLT, self).__init__(CL_CS18FLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CS18FLT.NAME


class CL_VA_OV(bmsbase.BitfieldBool):
    NAME = 'CL_VA_OV'
    DESCRIPTION = 'Clear Vreg Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VA_OV, self).__init__(CL_VA_OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VA_OV.NAME


class CL_VA_UV(bmsbase.BitfieldBool):
    NAME = 'CL_VA_UV'
    DESCRIPTION = 'Clear Vreg Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VA_UV, self).__init__(CL_VA_UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VA_UV.NAME


class CL_VD_OV(bmsbase.BitfieldBool):
    NAME = 'CL_VD_OV'
    DESCRIPTION = 'Clear Digital Voltage Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VD_OV, self).__init__(CL_VD_OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VD_OV.NAME


class CL_VD_UV(bmsbase.BitfieldBool):
    NAME = 'CL_VD_UV'
    DESCRIPTION = 'Clear Digital Voltage Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VD_UV, self).__init__(CL_VD_UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VD_UV.NAME


class CL_CED(bmsbase.BitfieldBool):
    NAME = 'CL_CED'
    DESCRIPTION = 'Clear C-ADC Trim Error Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CED, self).__init__(CL_CED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CED.NAME


class CL_CMED(bmsbase.BitfieldBool):
    NAME = 'CL_CMED'
    DESCRIPTION = 'Clear C-ADC Trim Multiple Error Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CMED, self).__init__(CL_CMED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CMED.NAME


class CL_SED(bmsbase.BitfieldBool):
    NAME = 'CL_SED'
    DESCRIPTION = 'Clear S-ADC Trim Error Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_SED, self).__init__(CL_SED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_SED.NAME


class CL_SMED(bmsbase.BitfieldBool):
    NAME = 'CL_SMED'
    DESCRIPTION = 'Clear S-ADC Trim Multiple Error Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_SMED, self).__init__(CL_SMED.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_SMED.NAME


class CL_VDE(bmsbase.BitfieldBool):
    NAME = 'CL_VDE'
    DESCRIPTION = 'Clear Supply Voltage Delta Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VDE, self).__init__(CL_VDE.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VDE.NAME


class CL_VDEL(bmsbase.BitfieldBool):
    NAME = 'CL_VDEL'
    DESCRIPTION = 'Clear Supply Voltage Delta Latent Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_VDEL, self).__init__(CL_VDEL.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_VDEL.NAME


class CL_SPIFLT(bmsbase.BitfieldBool):
    NAME = 'CL_SPIFLT'
    DESCRIPTION = 'Clear SPI Fault Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_SPIFLT, self).__init__(CL_SPIFLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_SPIFLT.NAME


class CL_SLEEP(bmsbase.BitfieldBool):
    NAME = 'CL_SLEEP'
    DESCRIPTION = 'Clear Sleep Mode Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_SLEEP, self).__init__(CL_SLEEP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_SLEEP.NAME


class CL_THSD(bmsbase.BitfieldBool):
    NAME = 'CL_THSD'
    DESCRIPTION = 'Clear Thermal Shutdown Status Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_THSD, self).__init__(CL_THSD.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_THSD.NAME


class CL_TMODCHK(bmsbase.BitfieldBool):
    NAME = 'CL_TMODCHK'
    DESCRIPTION = 'Clear Test Mode Detection Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_TMODCHK, self).__init__(CL_TMODCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_TMODCHK.NAME


class CL_OSCCHK(bmsbase.BitfieldBool):
    NAME = 'CL_OSCCHK'
    DESCRIPTION = 'Clear Oscillator Check Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_OSCCHK, self).__init__(CL_OSCCHK.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_OSCCHK.NAME


class CT(bmsbase.BitfieldInt):
    NAME = 'CT'
    DESCRIPTION = 'Conversion Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0
    MAX_VALUE = 2047
    MIN_VALUE = 0
    LENGTH = 11
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CT, self).__init__(CT.LENGTH,  value=value, raw_value=raw_value)
        self.name = CT.NAME


class CTS(bmsbase.BitfieldInt):
    NAME = 'CTS'
    DESCRIPTION = 'Conversion Sub-Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x3
    MIN_VALUE = 0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CTS, self).__init__(CTS.LENGTH,  value=value, raw_value=raw_value)
        self.name = CTS.NAME


class C1OV(bmsbase.BitfieldBool):
    NAME = 'C1OV'
    DESCRIPTION = 'Cell 1 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1OV, self).__init__(C1OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1OV.NAME


class C2OV(bmsbase.BitfieldBool):
    NAME = 'C2OV'
    DESCRIPTION = 'Cell 2 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2OV, self).__init__(C2OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2OV.NAME


class C3OV(bmsbase.BitfieldBool):
    NAME = 'C3OV'
    DESCRIPTION = 'Cell 3 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3OV, self).__init__(C3OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3OV.NAME


class C4OV(bmsbase.BitfieldBool):
    NAME = 'C4OV'
    DESCRIPTION = 'Cell 4 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4OV, self).__init__(C4OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4OV.NAME


class C5OV(bmsbase.BitfieldBool):
    NAME = 'C5OV'
    DESCRIPTION = 'Cell 5 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5OV, self).__init__(C5OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5OV.NAME


class C6OV(bmsbase.BitfieldBool):
    NAME = 'C6OV'
    DESCRIPTION = 'Cell 6 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6OV, self).__init__(C6OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6OV.NAME


class C7OV(bmsbase.BitfieldBool):
    NAME = 'C7OV'
    DESCRIPTION = 'Cell 7 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7OV, self).__init__(C7OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7OV.NAME


class C8OV(bmsbase.BitfieldBool):
    NAME = 'C8OV'
    DESCRIPTION = 'Cell 8 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8OV, self).__init__(C8OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8OV.NAME


class C9OV(bmsbase.BitfieldBool):
    NAME = 'C9OV'
    DESCRIPTION = 'Cell 9 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9OV, self).__init__(C9OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9OV.NAME


class C10OV(bmsbase.BitfieldBool):
    NAME = 'C10OV'
    DESCRIPTION = 'Cell 10 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10OV, self).__init__(C10OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10OV.NAME


class C11OV(bmsbase.BitfieldBool):
    NAME = 'C11OV'
    DESCRIPTION = 'Cell 11 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11OV, self).__init__(C11OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11OV.NAME


class C12OV(bmsbase.BitfieldBool):
    NAME = 'C12OV'
    DESCRIPTION = 'Cell 12 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12OV, self).__init__(C12OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12OV.NAME


class C13OV(bmsbase.BitfieldBool):
    NAME = 'C13OV'
    DESCRIPTION = 'Cell 13 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C13OV, self).__init__(C13OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C13OV.NAME


class C14OV(bmsbase.BitfieldBool):
    NAME = 'C14OV'
    DESCRIPTION = 'Cell 14 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C14OV, self).__init__(C14OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C14OV.NAME


class C15OV(bmsbase.BitfieldBool):
    NAME = 'C15OV'
    DESCRIPTION = 'Cell 15 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C15OV, self).__init__(C15OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C15OV.NAME


class C16OV(bmsbase.BitfieldBool):
    NAME = 'C16OV'
    DESCRIPTION = 'Cell 16 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C16OV, self).__init__(C16OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C16OV.NAME


class C17OV(bmsbase.BitfieldBool):
    NAME = 'C17OV'
    DESCRIPTION = 'Cell 17 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C17OV, self).__init__(C17OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C17OV.NAME


class C18OV(bmsbase.BitfieldBool):
    NAME = 'C18OV'
    DESCRIPTION = 'Cell 18 Over Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C18OV, self).__init__(C18OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C18OV.NAME


class CL_C1OV(bmsbase.BitfieldBool):
    NAME = 'CL_C1OV'
    DESCRIPTION = 'Clear Cell 1 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C1OV, self).__init__(CL_C1OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C1OV.NAME


class CL_C2OV(bmsbase.BitfieldBool):
    NAME = 'CL_C2OV'
    DESCRIPTION = 'Clear Cell 2 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C2OV, self).__init__(CL_C2OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C2OV.NAME


class CL_C3OV(bmsbase.BitfieldBool):
    NAME = 'CL_C3OV'
    DESCRIPTION = 'Clear Cell 3 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C3OV, self).__init__(CL_C3OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C3OV.NAME


class CL_C4OV(bmsbase.BitfieldBool):
    NAME = 'CL_C4OV'
    DESCRIPTION = 'Clear Cell 4 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C4OV, self).__init__(CL_C4OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C4OV.NAME


class CL_C5OV(bmsbase.BitfieldBool):
    NAME = 'CL_C5OV'
    DESCRIPTION = 'Clear Cell 5 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C5OV, self).__init__(CL_C5OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C5OV.NAME


class CL_C6OV(bmsbase.BitfieldBool):
    NAME = 'CL_C6OV'
    DESCRIPTION = 'Clear Cell 6 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C6OV, self).__init__(CL_C6OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C6OV.NAME


class CL_C7OV(bmsbase.BitfieldBool):
    NAME = 'CL_C7OV'
    DESCRIPTION = 'Clear Cell 7 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C7OV, self).__init__(CL_C7OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C7OV.NAME


class CL_C8OV(bmsbase.BitfieldBool):
    NAME = 'CL_C8OV'
    DESCRIPTION = 'Clear Cell 8 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C8OV, self).__init__(CL_C8OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C8OV.NAME


class CL_C9OV(bmsbase.BitfieldBool):
    NAME = 'CL_C9OV'
    DESCRIPTION = 'Clear Cell 9 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C9OV, self).__init__(CL_C9OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C9OV.NAME


class CL_C10OV(bmsbase.BitfieldBool):
    NAME = 'CL_C10OV'
    DESCRIPTION = 'Clear Cell 10 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C10OV, self).__init__(CL_C10OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C10OV.NAME


class CL_C11OV(bmsbase.BitfieldBool):
    NAME = 'CL_C11OV'
    DESCRIPTION = 'Clear Cell 11 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C11OV, self).__init__(CL_C11OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C11OV.NAME


class CL_C12OV(bmsbase.BitfieldBool):
    NAME = 'CL_C12OV'
    DESCRIPTION = 'Clear Cell 12 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C12OV, self).__init__(CL_C12OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C12OV.NAME


class CL_C13OV(bmsbase.BitfieldBool):
    NAME = 'CL_C13OV'
    DESCRIPTION = 'Clear Cell 13 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C13OV, self).__init__(CL_C13OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C13OV.NAME


class CL_C14OV(bmsbase.BitfieldBool):
    NAME = 'CL_C14OV'
    DESCRIPTION = 'Clear Cell 14 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C14OV, self).__init__(CL_C14OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C14OV.NAME


class CL_C15OV(bmsbase.BitfieldBool):
    NAME = 'CL_C15OV'
    DESCRIPTION = 'Clear Cell 15 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C15OV, self).__init__(CL_C15OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C15OV.NAME


class CL_C16OV(bmsbase.BitfieldBool):
    NAME = 'CL_C16OV'
    DESCRIPTION = 'Clear Cell 16 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C16OV, self).__init__(CL_C16OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C16OV.NAME


class CL_C17OV(bmsbase.BitfieldBool):
    NAME = 'CL_C17OV'
    DESCRIPTION = 'Clear Cell 17 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C17OV, self).__init__(CL_C17OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C17OV.NAME


class CL_C18OV(bmsbase.BitfieldBool):
    NAME = 'CL_C18OV'
    DESCRIPTION = 'Clear Cell 18 Over Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C18OV, self).__init__(CL_C18OV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C18OV.NAME


class C1UV(bmsbase.BitfieldBool):
    NAME = 'C1UV'
    DESCRIPTION = 'Cell 1 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C1UV, self).__init__(C1UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C1UV.NAME


class C2UV(bmsbase.BitfieldBool):
    NAME = 'C2UV'
    DESCRIPTION = 'Cell 2 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C2UV, self).__init__(C2UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C2UV.NAME


class C3UV(bmsbase.BitfieldBool):
    NAME = 'C3UV'
    DESCRIPTION = 'Cell 3 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C3UV, self).__init__(C3UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C3UV.NAME


class C4UV(bmsbase.BitfieldBool):
    NAME = 'C4UV'
    DESCRIPTION = 'Cell 4 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C4UV, self).__init__(C4UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C4UV.NAME


class C5UV(bmsbase.BitfieldBool):
    NAME = 'C5UV'
    DESCRIPTION = 'Cell 5 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C5UV, self).__init__(C5UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C5UV.NAME


class C6UV(bmsbase.BitfieldBool):
    NAME = 'C6UV'
    DESCRIPTION = 'Cell 6 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C6UV, self).__init__(C6UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C6UV.NAME


class C7UV(bmsbase.BitfieldBool):
    NAME = 'C7UV'
    DESCRIPTION = 'Cell 7 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C7UV, self).__init__(C7UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C7UV.NAME


class C8UV(bmsbase.BitfieldBool):
    NAME = 'C8UV'
    DESCRIPTION = 'Cell 8 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C8UV, self).__init__(C8UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C8UV.NAME


class C9UV(bmsbase.BitfieldBool):
    NAME = 'C9UV'
    DESCRIPTION = 'Cell 9 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C9UV, self).__init__(C9UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C9UV.NAME


class C10UV(bmsbase.BitfieldBool):
    NAME = 'C10UV'
    DESCRIPTION = 'Cell 10 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C10UV, self).__init__(C10UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C10UV.NAME


class C11UV(bmsbase.BitfieldBool):
    NAME = 'C11UV'
    DESCRIPTION = 'Cell 11 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C11UV, self).__init__(C11UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C11UV.NAME


class C12UV(bmsbase.BitfieldBool):
    NAME = 'C12UV'
    DESCRIPTION = 'Cell 12 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C12UV, self).__init__(C12UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C12UV.NAME


class C13UV(bmsbase.BitfieldBool):
    NAME = 'C13UV'
    DESCRIPTION = 'Cell 13 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C13UV, self).__init__(C13UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C13UV.NAME


class C14UV(bmsbase.BitfieldBool):
    NAME = 'C14UV'
    DESCRIPTION = 'Cell 14 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C14UV, self).__init__(C14UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C14UV.NAME


class C15UV(bmsbase.BitfieldBool):
    NAME = 'C15UV'
    DESCRIPTION = 'Cell 15 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C15UV, self).__init__(C15UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C15UV.NAME


class C16UV(bmsbase.BitfieldBool):
    NAME = 'C16UV'
    DESCRIPTION = 'Cell 16 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C16UV, self).__init__(C16UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C16UV.NAME


class C17UV(bmsbase.BitfieldBool):
    NAME = 'C17UV'
    DESCRIPTION = 'Cell 17 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C17UV, self).__init__(C17UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C17UV.NAME


class C18UV(bmsbase.BitfieldBool):
    NAME = 'C18UV'
    DESCRIPTION = 'Cell 18 Under Voltage Flag'
    MEM_KEY = 'Under/Over Voltage Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(C18UV, self).__init__(C18UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = C18UV.NAME


class CL_C1UV(bmsbase.BitfieldBool):
    NAME = 'CL_C1UV'
    DESCRIPTION = 'Clear Cell 1 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C1UV, self).__init__(CL_C1UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C1UV.NAME


class CL_C2UV(bmsbase.BitfieldBool):
    NAME = 'CL_C2UV'
    DESCRIPTION = 'Clear Cell 2 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C2UV, self).__init__(CL_C2UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C2UV.NAME


class CL_C3UV(bmsbase.BitfieldBool):
    NAME = 'CL_C3UV'
    DESCRIPTION = 'Clear Cell 3 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C3UV, self).__init__(CL_C3UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C3UV.NAME


class CL_C4UV(bmsbase.BitfieldBool):
    NAME = 'CL_C4UV'
    DESCRIPTION = 'Clear Cell 4 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C4UV, self).__init__(CL_C4UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C4UV.NAME


class CL_C5UV(bmsbase.BitfieldBool):
    NAME = 'CL_C5UV'
    DESCRIPTION = 'Clear Cell 5 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C5UV, self).__init__(CL_C5UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C5UV.NAME


class CL_C6UV(bmsbase.BitfieldBool):
    NAME = 'CL_C6UV'
    DESCRIPTION = 'Clear Cell 6 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C6UV, self).__init__(CL_C6UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C6UV.NAME


class CL_C7UV(bmsbase.BitfieldBool):
    NAME = 'CL_C7UV'
    DESCRIPTION = 'Clear Cell 7 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C7UV, self).__init__(CL_C7UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C7UV.NAME


class CL_C8UV(bmsbase.BitfieldBool):
    NAME = 'CL_C8UV'
    DESCRIPTION = 'Clear Cell 8 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C8UV, self).__init__(CL_C8UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C8UV.NAME


class CL_C9UV(bmsbase.BitfieldBool):
    NAME = 'CL_C9UV'
    DESCRIPTION = 'Clear Cell 9 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C9UV, self).__init__(CL_C9UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C9UV.NAME


class CL_C10UV(bmsbase.BitfieldBool):
    NAME = 'CL_C10UV'
    DESCRIPTION = 'Clear Cell 10 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C10UV, self).__init__(CL_C10UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C10UV.NAME


class CL_C11UV(bmsbase.BitfieldBool):
    NAME = 'CL_C11UV'
    DESCRIPTION = 'Clear Cell 11 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C11UV, self).__init__(CL_C11UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C11UV.NAME


class CL_C12UV(bmsbase.BitfieldBool):
    NAME = 'CL_C12UV'
    DESCRIPTION = 'Clear Cell 12 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C12UV, self).__init__(CL_C12UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C12UV.NAME


class CL_C13UV(bmsbase.BitfieldBool):
    NAME = 'CL_C13UV'
    DESCRIPTION = 'Clear Cell 13 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C13UV, self).__init__(CL_C13UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C13UV.NAME


class CL_C14UV(bmsbase.BitfieldBool):
    NAME = 'CL_C14UV'
    DESCRIPTION = 'Clear Cell 14 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C14UV, self).__init__(CL_C14UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C14UV.NAME


class CL_C15UV(bmsbase.BitfieldBool):
    NAME = 'CL_C15UV'
    DESCRIPTION = 'Clear Cell 15 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C15UV, self).__init__(CL_C15UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C15UV.NAME


class CL_C16UV(bmsbase.BitfieldBool):
    NAME = 'CL_C16UV'
    DESCRIPTION = 'Clear Cell 16 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C16UV, self).__init__(CL_C16UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C16UV.NAME


class CL_C17UV(bmsbase.BitfieldBool):
    NAME = 'CL_C17UV'
    DESCRIPTION = 'Clear Cell 17 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C17UV, self).__init__(CL_C17UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C17UV.NAME


class CL_C18UV(bmsbase.BitfieldBool):
    NAME = 'CL_C18UV'
    DESCRIPTION = 'Clear Cell 18 Under Voltage Flag'
    MEM_KEY = 'Clear Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_C18UV, self).__init__(CL_C18UV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_C18UV.NAME


class OC_CNTR(bmsbase.BitfieldInt):
    NAME = 'OC_CNTR'
    DESCRIPTION = 'Oscillator Check Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC_CNTR, self).__init__(OC_CNTR.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC_CNTR.NAME


class GPI1(bmsbase.BitfieldBool):
    NAME = 'GPI1'
    DESCRIPTION = 'GPIO 1 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI1, self).__init__(GPI1.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI1.NAME


class GPI2(bmsbase.BitfieldBool):
    NAME = 'GPI2'
    DESCRIPTION = 'GPIO 2 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI2, self).__init__(GPI2.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI2.NAME


class GPI3(bmsbase.BitfieldBool):
    NAME = 'GPI3'
    DESCRIPTION = 'GPIO 3 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI3, self).__init__(GPI3.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI3.NAME


class GPI4(bmsbase.BitfieldBool):
    NAME = 'GPI4'
    DESCRIPTION = 'GPIO 4 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI4, self).__init__(GPI4.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI4.NAME


class GPI5(bmsbase.BitfieldBool):
    NAME = 'GPI5'
    DESCRIPTION = 'GPIO 5 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI5, self).__init__(GPI5.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI5.NAME


class GPI6(bmsbase.BitfieldBool):
    NAME = 'GPI6'
    DESCRIPTION = 'GPIO 6 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI6, self).__init__(GPI6.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI6.NAME


class GPI7(bmsbase.BitfieldBool):
    NAME = 'GPI7'
    DESCRIPTION = 'GPIO 7 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI7, self).__init__(GPI7.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI7.NAME


class GPI8(bmsbase.BitfieldBool):
    NAME = 'GPI8'
    DESCRIPTION = 'GPIO 8 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI8, self).__init__(GPI8.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI8.NAME


class GPI9(bmsbase.BitfieldBool):
    NAME = 'GPI9'
    DESCRIPTION = 'GPIO 9 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI9, self).__init__(GPI9.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI9.NAME


class GPI10(bmsbase.BitfieldBool):
    NAME = 'GPI10'
    DESCRIPTION = 'GPIO 10 Input State'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPI10, self).__init__(GPI10.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPI10.NAME


class REV(bmsbase.BitfieldInt):
    NAME = 'REV'
    DESCRIPTION = 'Silicon Revision'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 15
    MIN_VALUE = 0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REV, self).__init__(REV.LENGTH,  value=value, raw_value=raw_value)
        self.name = REV.NAME


class CMC_NDEV(bmsbase.BitfieldInt):
    NAME = 'CMC_NDEV'
    DESCRIPTION = 'Number of Devices'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_NDEV, self).__init__(CMC_NDEV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_NDEV.NAME


class CMC_MAN(bmsbase.BitfieldBool):
    NAME = 'CMC_MAN'
    DESCRIPTION = 'Fault Monitoring Manager'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_MAN, self).__init__(CMC_MAN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_MAN.NAME


class CMC_MPER(bmsbase.BitfieldInt):
    NAME = 'CMC_MPER'
    DESCRIPTION = 'Fault Monitoring Measure Heartbeat Period'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_MPER, self).__init__(CMC_MPER.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_MPER.NAME


class CMC_BTM(bmsbase.BitfieldBool):
    NAME = 'CMC_BTM'
    DESCRIPTION = 'Fault Monitoring Bridgeless LPCM Timeout Monitor'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_BTM, self).__init__(CMC_BTM.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_BTM.NAME


class CMC_TPER(bmsbase.BitfieldInt):
    NAME = 'CMC_TPER'
    DESCRIPTION = 'Fault Monitoring Bridgeless Timeout Period'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_TPER, self).__init__(CMC_TPER.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_TPER.NAME


class CMC_DIR(bmsbase.BitfieldBool):
    NAME = 'CMC_DIR'
    DESCRIPTION = 'Manager Transmit Direction'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_DIR, self).__init__(CMC_DIR.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_DIR.NAME


class CMC_GOE(bmsbase.BitfieldInt):
    NAME = 'CMC_GOE'
    DESCRIPTION = 'LPCM Interrupt To GPIO'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0x7
    MIN_VALUE = 0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMC_GOE, self).__init__(CMC_GOE.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_GOE.NAME


class CMM_C(bmsbase.BitfieldInt):
    NAME = 'CMM_C'
    DESCRIPTION = 'Cell Mask'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMM_C, self).__init__(CMM_C.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMM_C.NAME


class CMM_G(bmsbase.BitfieldInt):
    NAME = 'CMM_G'
    DESCRIPTION = 'GPIO Mask'
    MEM_KEY = 'LPCM Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 1023
    MIN_VALUE = 0
    LENGTH = 10
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMM_G, self).__init__(CMM_G.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMM_G.NAME


class CMT_CUV(bmsbase.BitfieldAdc):
    NAME = 'CMT_CUV'
    DESCRIPTION = 'Cell Under Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_CUV, self).__init__(CMT_CUV.LENGTH, value=value, raw_value=raw_value, lsb=16 * 0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = CMT_CUV.NAME


class CMT_COV(bmsbase.BitfieldAdc):
    NAME = 'CMT_COV'
    DESCRIPTION = 'Cell Over Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_COV, self).__init__(CMT_COV.LENGTH, value=value, raw_value=raw_value, lsb=16 * 0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = CMT_COV.NAME


class CMT_CDV(bmsbase.BitfieldAdc):
    NAME = 'CMT_CDV'
    DESCRIPTION = 'Cell Delta Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_CDV, self).__init__(CMT_CDV.LENGTH, value=value, raw_value=raw_value, lsb=0.0012, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_CDV.NAME


class CMT_GUV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GUV'
    DESCRIPTION = 'GPIO Under Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GUV, self).__init__(CMT_GUV.LENGTH, value=value, raw_value=raw_value, lsb=16 * 0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = CMT_GUV.NAME


class CMT_GOV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GOV'
    DESCRIPTION = 'GPIO Over Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GOV, self).__init__(CMT_GOV.LENGTH, value=value, raw_value=raw_value, lsb=16 * 0.000150, postpend=1.5, prepend=0, twos_complement=True)
        self.name = CMT_GOV.NAME


class CMT_GDV(bmsbase.BitfieldAdc):
    NAME = 'CMT_GDV'
    DESCRIPTION = 'GPIO Delta Voltage Threshold'
    MEM_KEY = 'LPCM Threshold Configuration'
    DEFAULT_VALUE = 0
    MAX_VALUE = 6.4128
    MIN_VALUE = -3.4152
    LENGTH = 12
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(CMT_GDV, self).__init__(CMT_GDV.LENGTH, value=value, raw_value=raw_value, lsb=0.0012, postpend=0, prepend=0, twos_complement=False)
        self.name = CMT_GDV.NAME


class CMC_EN(bmsbase.BitfieldBool):
    NAME = 'CMC_EN'
    DESCRIPTION = 'LPCM Enabled Status'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMC_EN, self).__init__(CMC_EN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMC_EN.NAME


class CMF_BTMWD(bmsbase.BitfieldBool):
    NAME = 'CMF_BTMWD'
    DESCRIPTION = 'Bridgeless Watchdog Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_BTMWD, self).__init__(CMF_BTMWD.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_BTMWD.NAME


class CMF_BTMCMP(bmsbase.BitfieldBool):
    NAME = 'CMF_BTMCMP'
    DESCRIPTION = 'Bridgeless Message Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_BTMCMP, self).__init__(CMF_BTMCMP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_BTMCMP.NAME


class CMF_CUV(bmsbase.BitfieldBool):
    NAME = 'CMF_CUV'
    DESCRIPTION = 'LPCM Cell Under Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CUV, self).__init__(CMF_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CUV.NAME


class CMF_COV(bmsbase.BitfieldBool):
    NAME = 'CMF_COV'
    DESCRIPTION = 'LPCM Cell Over Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_COV, self).__init__(CMF_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_COV.NAME


class CMF_CDVP(bmsbase.BitfieldBool):
    NAME = 'CMF_CDVP'
    DESCRIPTION = 'LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CDVP, self).__init__(CMF_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CDVP.NAME


class CMF_CDVN(bmsbase.BitfieldBool):
    NAME = 'CMF_CDVN'
    DESCRIPTION = 'LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_CDVN, self).__init__(CMF_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_CDVN.NAME


class CMF_GUV(bmsbase.BitfieldBool):
    NAME = 'CMF_GUV'
    DESCRIPTION = 'LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GUV, self).__init__(CMF_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GUV.NAME


class CMF_GOV(bmsbase.BitfieldBool):
    NAME = 'CMF_GOV'
    DESCRIPTION = 'LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GOV, self).__init__(CMF_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GOV.NAME


class CMF_GDVP(bmsbase.BitfieldBool):
    NAME = 'CMF_GDVP'
    DESCRIPTION = 'LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GDVP, self).__init__(CMF_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GDVP.NAME


class CMF_GDVN(bmsbase.BitfieldBool):
    NAME = 'CMF_GDVN'
    DESCRIPTION = 'LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CMF_GDVN, self).__init__(CMF_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CMF_GDVN.NAME


class CL_CUV(bmsbase.BitfieldBool):
    NAME = 'CL_CUV'
    DESCRIPTION = 'Clear LPCM Cell Under Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CUV, self).__init__(CL_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CUV.NAME


class CL_COV(bmsbase.BitfieldBool):
    NAME = 'CL_COV'
    DESCRIPTION = 'Clear LPCM Cell Over Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_COV, self).__init__(CL_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_COV.NAME


class CL_CDVP(bmsbase.BitfieldBool):
    NAME = 'CL_CDVP'
    DESCRIPTION = 'Clear LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CDVP, self).__init__(CL_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CDVP.NAME


class CL_CDVN(bmsbase.BitfieldBool):
    NAME = 'CL_CDVN'
    DESCRIPTION = 'Clear LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_CDVN, self).__init__(CL_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_CDVN.NAME


class CL_GUV(bmsbase.BitfieldBool):
    NAME = 'CL_GUV'
    DESCRIPTION = 'Clear LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GUV, self).__init__(CL_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GUV.NAME


class CL_GOV(bmsbase.BitfieldBool):
    NAME = 'CL_GOV'
    DESCRIPTION = 'Clear LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GOV, self).__init__(CL_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GOV.NAME


class CL_GDVP(bmsbase.BitfieldBool):
    NAME = 'CL_GDVP'
    DESCRIPTION = 'Clear LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GDVP, self).__init__(CL_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GDVP.NAME


class CL_GDVN(bmsbase.BitfieldBool):
    NAME = 'CL_GDVN'
    DESCRIPTION = 'Clear LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'Clear LPCM'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(CL_GDVN, self).__init__(CL_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = CL_GDVN.NAME


class HB_DCNT(bmsbase.BitfieldInt):
    NAME = 'HB_DCNT'
    DESCRIPTION = 'Heartbeat Message Device Count'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = 0x42
    MAX_VALUE = 0xFF
    MIN_VALUE = 0x42
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(HB_DCNT, self).__init__(HB_DCNT.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_DCNT.NAME


class HB_GDVP(bmsbase.BitfieldBool):
    NAME = 'HB_GDVP'
    DESCRIPTION = 'LPCM GPIO Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GDVP, self).__init__(HB_GDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GDVP.NAME


class HB_GDVN(bmsbase.BitfieldBool):
    NAME = 'HB_GDVN'
    DESCRIPTION = 'LPCM GPIO Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GDVN, self).__init__(HB_GDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GDVN.NAME


class HB_GOV(bmsbase.BitfieldBool):
    NAME = 'HB_GOV'
    DESCRIPTION = 'LPCM GPIO Over Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GOV, self).__init__(HB_GOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GOV.NAME


class HB_GUV(bmsbase.BitfieldBool):
    NAME = 'HB_GUV'
    DESCRIPTION = 'LPCM GPIO Under Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_GUV, self).__init__(HB_GUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_GUV.NAME


class HB_CDVP(bmsbase.BitfieldBool):
    NAME = 'HB_CDVP'
    DESCRIPTION = 'LPCM Cell Positive Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CDVP, self).__init__(HB_CDVP.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CDVP.NAME


class HB_CDVN(bmsbase.BitfieldBool):
    NAME = 'HB_CDVN'
    DESCRIPTION = 'LPCM Cell Negative Delta Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CDVN, self).__init__(HB_CDVN.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CDVN.NAME


class HB_COV(bmsbase.BitfieldBool):
    NAME = 'HB_COV'
    DESCRIPTION = 'LPCM Cell Over Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_COV, self).__init__(HB_COV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_COV.NAME


class HB_CUV(bmsbase.BitfieldBool):
    NAME = 'HB_CUV'
    DESCRIPTION = 'LPCM Cell Under Voltage Flag'
    MEM_KEY = 'LPCM Heartbeat Message Group'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(HB_CUV, self).__init__(HB_CUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = HB_CUV.NAME

# ===================================================== ADBMS2950 =====================================================


class OPT(bmsbase.BitfieldInt):
    NAME = 'OPT'
    DESCRIPTION = 'Continuous/Diagnostic Measurement Options'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0x00
    MAX_VALUE = 0xF
    MIN_VALUE = 0x00
    LENGTH = 4
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }

    def __init__(self, value=0, raw_value=0):
        super(OPT, self).__init__(OPT.LENGTH,  value=value, raw_value=raw_value)
        self.name = OPT.NAME


class I1(bmsbase.BitfieldAdc):
    NAME = 'I1'
    DESCRIPTION = 'I1 ADC Result'
    MEM_KEY = 'I ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.000001
    MIN_VALUE = -1*((0xFFFFFF/2))*0.000001
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I1, self).__init__(I1.LENGTH, value=value, raw_value=raw_value, lsb=0.000001, postpend=0, prepend=0, twos_complement=True)
        self.name = I1.NAME


class I2(bmsbase.BitfieldAdc):
    NAME = 'I2'
    DESCRIPTION = 'I2 ADC Result'
    MEM_KEY = 'I ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.000001
    MIN_VALUE = -1*((0xFFFFFF/2))*0.000001
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I2, self).__init__(I2.LENGTH, value=value, raw_value=raw_value, lsb=-0.000001, postpend=0, prepend=0, twos_complement=True)
        self.name = I2.NAME


class VB1(bmsbase.BitfieldAdc):
    NAME = 'VB1'
    DESCRIPTION = 'VB1 ADC Result'
    MEM_KEY = 'VB ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VB1, self).__init__(VB1.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = VB1.NAME


class VB2(bmsbase.BitfieldAdc):
    NAME = 'VB2'
    DESCRIPTION = 'VB2 ADC Result'
    MEM_KEY = 'VB ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VB2, self).__init__(VB2.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = VB2.NAME


class I1ACC(bmsbase.BitfieldAdc):
    NAME = 'I1ACC'
    DESCRIPTION = 'I1 ADC Accumulated Result'
    MEM_KEY = 'I ADC Accumulated Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.000001
    MIN_VALUE = -1*((0xFFFFFF/2))*0.000001
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I1ACC, self).__init__(I1ACC.LENGTH, value=value, raw_value=raw_value, lsb=0.000001, postpend=0, prepend=0, twos_complement=True)
        self.name = I1ACC.NAME

    def convert_from_bitlist(self, bitlist, ACCI=0, **kwargs):
        div = (ACCI + 1)*4
        self.value = self.convert_adc_from_bitfields(bitlist, **kwargs) / div
        return self.value


class I2ACC(bmsbase.BitfieldAdc):
    NAME = 'I2ACC'
    DESCRIPTION = 'I2ACC ADC Accumulated Result'
    MEM_KEY = 'I ADC Accumulated Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.000001
    MIN_VALUE = -1*((0xFFFFFF/2))*0.000001
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I2ACC, self).__init__(I2ACC.LENGTH, value=value, raw_value=raw_value, lsb=-0.000001, postpend=0, prepend=0, twos_complement=True)
        self.name = I2ACC.NAME

    def convert_from_bitlist(self, bitlist, ACCI=0, **kwargs):
        div = (ACCI + 1)*4
        self.value = self.convert_adc_from_bitfields(bitlist, **kwargs) / div
        return self.value


class VB1ACC(bmsbase.BitfieldAdc):
    NAME = 'VB1ACC'
    DESCRIPTION = 'VB1 ADC Accumulated Result'
    MEM_KEY = 'VB ADC Accumulated Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFFFF/2))*0.0001
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VB1ACC, self).__init__(VB1ACC.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = VB1ACC.NAME

    def convert_from_bitlist(self, bitlist, ACCI=0, **kwargs):
        div = (ACCI + 1)*4
        self.value = self.convert_adc_from_bitfields(bitlist, **kwargs) / div
        return self.value


class VB2ACC(bmsbase.BitfieldAdc):
    NAME = 'VB2ACC'
    DESCRIPTION = 'VB2 ADC Accumulated Result'
    MEM_KEY = 'VB ADC Accumulated Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFFFF/2))*0.000085
    LENGTH = 24
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VB2ACC, self).__init__(VB2ACC.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = VB2ACC.NAME

    def convert_from_bitlist(self, bitlist, ACCI=0, **kwargs):
        div = (ACCI + 1)*4
        self.value = self.convert_adc_from_bitfields(bitlist, **kwargs) / div
        return self.value
    

class VCH(bmsbase.BitfieldInt):
    NAME = 'VCH'
    DESCRIPTION = 'VxADC Channel Selection'
    MEM_KEY = 'Command Configuration'
    DEFAULT_VALUE = 0x00
    MAX_VALUE = 0xF
    MIN_VALUE = 0x00
    LENGTH = 4
    LIMITS = {
        'range': [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    }

    def __init__(self, value=0, raw_value=0):
        super(VCH, self).__init__(VCH.LENGTH,  value=value, raw_value=raw_value)
        self.name = VCH.NAME


class V1A(bmsbase.BitfieldAdc):
    NAME = 'V1A'
    DESCRIPTION = 'V1 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V1A, self).__init__(V1A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V1A.NAME


class V1B(bmsbase.BitfieldAdc):
    NAME = 'V1B'
    DESCRIPTION = 'V1 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V1B, self).__init__(V1B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V1B.NAME


class V2A(bmsbase.BitfieldAdc):
    NAME = 'V2A'
    DESCRIPTION = 'V2 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V2A, self).__init__(V2A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V2A.NAME


class V2B(bmsbase.BitfieldAdc):
    NAME = 'V2B'
    DESCRIPTION = 'V2 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V2B, self).__init__(V2B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V2B.NAME


class V3A(bmsbase.BitfieldAdc):
    NAME = 'V3A'
    DESCRIPTION = 'V3 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V3A, self).__init__(V3A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V3A.NAME


class V3B(bmsbase.BitfieldAdc):
    NAME = 'V3B'
    DESCRIPTION = 'V3 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V3B, self).__init__(V3B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V3B.NAME


class V4A(bmsbase.BitfieldAdc):
    NAME = 'V4A'
    DESCRIPTION = 'V4 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V4A, self).__init__(V4A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V4A.NAME


class V4B(bmsbase.BitfieldAdc):
    NAME = 'V4B'
    DESCRIPTION = 'V4 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V4B, self).__init__(V4B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V4B.NAME


class V5A(bmsbase.BitfieldAdc):
    NAME = 'V5A'
    DESCRIPTION = 'V5 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V5A, self).__init__(V5A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V5A.NAME


class V5B(bmsbase.BitfieldAdc):
    NAME = 'V5B'
    DESCRIPTION = 'V5 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V5B, self).__init__(V5B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V5B.NAME


class V6A(bmsbase.BitfieldAdc):
    NAME = 'V6A'
    DESCRIPTION = 'V6 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V6A, self).__init__(V6A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V6A.NAME


class V6B(bmsbase.BitfieldAdc):
    NAME = 'V6B'
    DESCRIPTION = 'V6 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V6B, self).__init__(V6B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V6B.NAME


class V7A(bmsbase.BitfieldAdc):
    NAME = 'V7A'
    DESCRIPTION = 'V7 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V7A, self).__init__(V7A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V7A.NAME


class V8A(bmsbase.BitfieldAdc):
    NAME = 'V8A'
    DESCRIPTION = 'V8 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V8A, self).__init__(V8A.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = V8A.NAME


class V9B(bmsbase.BitfieldAdc):
    NAME = 'V9B'
    DESCRIPTION = 'V9 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V9B, self).__init__(V9B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V9B.NAME


class V10B(bmsbase.BitfieldAdc):
    NAME = 'V10B'
    DESCRIPTION = 'V10 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000085
    MIN_VALUE = -1*((0xFFFF/2))*0.000085
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(V10B, self).__init__(V10B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000085, postpend=0, prepend=0, twos_complement=True)
        self.name = V10B.NAME


class VREF2A(bmsbase.BitfieldAdc):
    NAME = 'VREF2A'
    DESCRIPTION = 'VREF2 Voltage A'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000240
    MIN_VALUE = -1*((0xFFFF/2))*0.000240
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VREF2A, self).__init__(VREF2A.LENGTH, value=value, raw_value=raw_value, lsb=0.000240, postpend=0, prepend=0, twos_complement=True)
        self.name = VREF2A.NAME


class VREF2B(bmsbase.BitfieldAdc):
    NAME = 'VREF2B'
    DESCRIPTION = 'VREF2 Voltage B'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000204
    MIN_VALUE = -1*((0xFFFF/2))*0.000204
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VREF2B, self).__init__(VREF2B.LENGTH, value=value, raw_value=raw_value, lsb=-0.000204, postpend=0, prepend=0, twos_complement=True)
        self.name = VREF2B.NAME


class VREF1P25(bmsbase.BitfieldAdc):
    NAME = 'VREF1P25'
    DESCRIPTION = 'VREF 1.25 Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VREF1P25, self).__init__(VREF1P25.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = VREF1P25.NAME


class VDIV(bmsbase.BitfieldAdc):
    NAME = 'VDIV'
    DESCRIPTION = 'Divided REF1 Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.0001
    MIN_VALUE = -1*((0xFFFF/2))*0.0001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VDIV, self).__init__(VDIV.LENGTH, value=value, raw_value=raw_value, lsb=0.0001, postpend=0, prepend=0, twos_complement=True)
        self.name = VDIV.NAME


class VREG(bmsbase.BitfieldAdc):
    NAME = 'VREG'
    DESCRIPTION = 'Vreg Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000240
    MIN_VALUE = -1*((0xFFFF/2))*0.000240
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VREG, self).__init__(VREG.LENGTH, value=value, raw_value=raw_value, lsb=0.000240, postpend=0, prepend=0, twos_complement=True)
        self.name = VREG.NAME


class VDD(bmsbase.BitfieldAdc):
    NAME = 'VDD'
    DESCRIPTION = 'VDD Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.001
    MIN_VALUE = -1*((0xFFFF/2))*0.001
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VDD, self).__init__(VDD.LENGTH, value=value, raw_value=raw_value, lsb=0.001, postpend=0, prepend=0, twos_complement=True)
        self.name = VDD.NAME


class VDIG(bmsbase.BitfieldAdc):
    NAME = 'VDIG'
    DESCRIPTION = 'Digital Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000240
    MIN_VALUE = -1*((0xFFFF/2))*0.000240
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VDIG, self).__init__(VDIG.LENGTH, value=value, raw_value=raw_value, lsb=0.000240, postpend=0, prepend=0, twos_complement=True)
        self.name = VDIG.NAME


class EPAD(bmsbase.BitfieldAdc):
    NAME = 'EPAD'
    DESCRIPTION = 'EPAD - Vm Voltage'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)*0.000100
    MIN_VALUE = -1*((0xFFFF/2))*0.000100
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(EPAD, self).__init__(EPAD.LENGTH, value=value, raw_value=raw_value, lsb=0.000100, postpend=0, prepend=0, twos_complement=True)
        self.name = EPAD.NAME


class TMP1(bmsbase.BitfieldAdc):
    NAME = 'TMP1'
    DESCRIPTION = 'Internal Die Temperature 1'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)/59.3-260
    MIN_VALUE = -1*((0xFFFF/2))/59.3-260
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TMP1, self).__init__(TMP1.LENGTH, value=value, raw_value=raw_value, lsb=1/59.3, postpend=-260, prepend=0, twos_complement=True)
        self.name = TMP1.NAME


class TMP2(bmsbase.BitfieldAdc):
    NAME = 'TMP2'
    DESCRIPTION = 'Internal Die Temperature 2'
    MEM_KEY = 'Voltage ADC Result Group'
    DEFAULT_VALUE = 0
    MAX_VALUE = ((0xFFFF/2)-1)/20.5-270
    MIN_VALUE = -1*((0xFFFF/2))/20.5-270
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TMP2, self).__init__(TMP2.LENGTH, value=value, raw_value=raw_value, lsb=1/20.5, postpend=-270, prepend=0, twos_complement=True)
        self.name = TMP2.NAME


class ACCI(bmsbase.BitfieldInt):
    NAME = 'ACCI'
    DESCRIPTION = 'Accumulation Setting'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x1
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}
    SAVE_STATE = True

    def __init__(self, value=0, raw_value=0):
        super(ACCI, self).__init__(ACCI.LENGTH,  value=value, raw_value=raw_value)
        self.name = ACCI.NAME


class DER(bmsbase.BitfieldInt):
    NAME = 'DER'
    DESCRIPTION = 'Device Derivative Code'
    MEM_KEY = 'Serial ID Register Group'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DER, self).__init__(DER.LENGTH,  value=value, raw_value=raw_value)
        self.name = DER.NAME


class DIAGSEL(bmsbase.BitfieldInt):
    NAME = 'DIAGSEL'
    DESCRIPTION = 'ADC Diagnostic Setting'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DIAGSEL, self).__init__(DIAGSEL.LENGTH,  value=value, raw_value=raw_value)
        self.name = DIAGSEL.NAME


class GPIO1C(bmsbase.BitfieldBool):
    NAME = 'GPIO1C'
    DESCRIPTION = 'GPIO 1 Output Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO1C, self).__init__(GPIO1C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO1C.NAME


class GPIO1FE(bmsbase.BitfieldBool):
    NAME = 'GPIO1FE'
    DESCRIPTION = 'GPIO 1 Fault Output Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO1FE, self).__init__(GPIO1FE.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO1FE.NAME


class GPIO1L(bmsbase.BitfieldBool):
    NAME = 'GPIO1L'
    DESCRIPTION = 'GPIO 1 Input Value'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO1L, self).__init__(GPIO1L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO1L.NAME


class GPIO2C(bmsbase.BitfieldBool):
    NAME = 'GPIO2C'
    DESCRIPTION = 'GPIO 2 Output Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO2C, self).__init__(GPIO2C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO2C.NAME


class GPIO2EOC(bmsbase.BitfieldBool):
    NAME = 'GPIO2EOC'
    DESCRIPTION = 'GPIO 2 End of OC1ADC Conversion Output Toggle Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO2EOC, self).__init__(GPIO2EOC.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO2EOC.NAME


class GPIO2L(bmsbase.BitfieldBool):
    NAME = 'GPIO2L'
    DESCRIPTION = 'GPIO 2 Input Value'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO2L, self).__init__(GPIO2L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO2L.NAME


class GPIO3C(bmsbase.BitfieldBool):
    NAME = 'GPIO3C'
    DESCRIPTION = 'GPIO 3 Output Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO3C, self).__init__(GPIO3C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO3C.NAME


class GPIO3L(bmsbase.BitfieldBool):
    NAME = 'GPIO3L'
    DESCRIPTION = 'GPIO 3 Input Value'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO3L, self).__init__(GPIO3L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO3L.NAME


class GPIO4C(bmsbase.BitfieldBool):
    NAME = 'GPIO4C'
    DESCRIPTION = 'GPIO 4 Output Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO4C, self).__init__(GPIO4C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO4C.NAME


class GPIO4L(bmsbase.BitfieldBool):
    NAME = 'GPIO4L'
    DESCRIPTION = 'GPIO 4 Input Value'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPIO4L, self).__init__(GPIO4L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO4L.NAME


class GPO1C(bmsbase.BitfieldBool):
    NAME = 'GPO1C'
    DESCRIPTION = 'GPO 1 Output State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1C, self).__init__(GPO1C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1C.NAME


class GPO1H(bmsbase.BitfieldBool):
    NAME = 'GPO1H'
    DESCRIPTION = 'GPO 1 Input Level (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1H, self).__init__(GPO1H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1H.NAME


class GPO1L(bmsbase.BitfieldBool):
    NAME = 'GPO1L'
    DESCRIPTION = 'GPO 1 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1L, self).__init__(GPO1L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1L.NAME


class GPO1OD(bmsbase.BitfieldBool):
    NAME = 'GPO1OD'
    DESCRIPTION = 'GPO 1 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO1OD, self).__init__(GPO1OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO1OD.NAME


class GPO2C(bmsbase.BitfieldBool):
    NAME = 'GPO2C'
    DESCRIPTION = 'GPO 2 Ouput State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2C, self).__init__(GPO2C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2C.NAME


class GPO2H(bmsbase.BitfieldBool):
    NAME = 'GPO2H'
    DESCRIPTION = 'GPO 2 Input Value (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2H, self).__init__(GPO2H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2H.NAME


class GPO2L(bmsbase.BitfieldBool):
    NAME = 'GPO2L'
    DESCRIPTION = 'GPO 2 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2L, self).__init__(GPO2L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2L.NAME


class GPO2OD(bmsbase.BitfieldBool):
    NAME = 'GPO2OD'
    DESCRIPTION = 'GPO 2 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO2OD, self).__init__(GPO2OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO2OD.NAME


class GPO3C(bmsbase.BitfieldBool):
    NAME = 'GPO3C'
    DESCRIPTION = 'GPO 3 Output State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3C, self).__init__(GPO3C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3C.NAME


class GPO3H(bmsbase.BitfieldBool):
    NAME = 'GPO3H'
    DESCRIPTION = 'GPO 3 Input Value (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3H, self).__init__(GPO3H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3H.NAME


class GPO3L(bmsbase.BitfieldBool):
    NAME = 'GPO3L'
    DESCRIPTION = 'GPO 3 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3L, self).__init__(GPO3L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3L.NAME


class GPO3OD(bmsbase.BitfieldBool):
    NAME = 'GPO3OD'
    DESCRIPTION = 'GPO 3 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO3OD, self).__init__(GPO3OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO3OD.NAME


class GPO4C(bmsbase.BitfieldBool):
    NAME = 'GPO4C'
    DESCRIPTION = 'GPO 4 Output State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4C, self).__init__(GPO4C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4C.NAME


class GPO4H(bmsbase.BitfieldBool):
    NAME = 'GPO4H'
    DESCRIPTION = 'GPO 4 Input State (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4H, self).__init__(GPO4H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4H.NAME


class GPO4L(bmsbase.BitfieldBool):
    NAME = 'GPO4L'
    DESCRIPTION = 'GPO 4 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4L, self).__init__(GPO4L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4L.NAME


class GPO4OD(bmsbase.BitfieldBool):
    NAME = 'GPO4OD'
    DESCRIPTION = 'GPO 4 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO4OD, self).__init__(GPO4OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO4OD.NAME


class GPO5C(bmsbase.BitfieldBool):
    NAME = 'GPO5C'
    DESCRIPTION = 'GPO 5 Output State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5C, self).__init__(GPO5C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5C.NAME


class GPO5H(bmsbase.BitfieldBool):
    NAME = 'GPO5H'
    DESCRIPTION = 'GPO 5 Input Value (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5H, self).__init__(GPO5H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5H.NAME


class GPO5L(bmsbase.BitfieldBool):
    NAME = 'GPO5L'
    DESCRIPTION = 'GPO 5 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5L, self).__init__(GPO5L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5L.NAME


class GPO5OD(bmsbase.BitfieldBool):
    NAME = 'GPO5OD'
    DESCRIPTION = 'GPO 5 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO5OD, self).__init__(GPO5OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO5OD.NAME


class GPO6C(bmsbase.BitfieldInt):
    NAME = 'GPO6C'
    DESCRIPTION = 'GPO 6 Output State Control'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = 0x1
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(GPO6C, self).__init__(GPO6C.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6C.NAME


class GPO6H(bmsbase.BitfieldBool):
    NAME = 'GPO6H'
    DESCRIPTION = 'GPO 6 Input Value (High Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO6H, self).__init__(GPO6H.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6H.NAME


class GPO6L(bmsbase.BitfieldBool):
    NAME = 'GPO6L'
    DESCRIPTION = 'GPO 6 Input Value (Low Threshold)'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO6L, self).__init__(GPO6L.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6L.NAME


class GPO6OD(bmsbase.BitfieldBool):
    NAME = 'GPO6OD'
    DESCRIPTION = 'GPO 6 Open Drain Enable'
    MEM_KEY = 'GPIO Configuration'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(GPO6OD, self).__init__(GPO6OD.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPO6OD.NAME


class I1CAL(bmsbase.BitfieldBool):
    NAME = 'I1CAL'
    DESCRIPTION = 'I1 ADC Self Calibration Status'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(I1CAL, self).__init__(I1CAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = I1CAL.NAME


class I1CNT(bmsbase.BitfieldInt):
    NAME = 'I1CNT'
    DESCRIPTION = 'I1/VB1 ADC Conversion Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7ff
    MIN_VALUE = 0x0
    LENGTH = 11
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I1CNT, self).__init__(I1CNT.LENGTH,  value=value, raw_value=raw_value)
        self.name = I1CNT.NAME


class I1D(bmsbase.BitfieldBool):
    NAME = 'I1D'
    DESCRIPTION = 'I1/VB1 ADC Diagnostic Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(I1D, self).__init__(I1D.LENGTH,  value=value, raw_value=raw_value)
        self.name = I1D.NAME


class I1PHA(bmsbase.BitfieldInt):
    NAME = 'I1PHA'
    DESCRIPTION = 'I1/VB1 ADC Sub Conversion Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I1PHA, self).__init__(I1PHA.LENGTH,  value=value, raw_value=raw_value)
        self.name = I1PHA.NAME


class I2CAL(bmsbase.BitfieldBool):
    NAME = 'I2CAL'
    DESCRIPTION = 'I2 ADC Self Calibration Status'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(I2CAL, self).__init__(I2CAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = I2CAL.NAME


class I2CNT(bmsbase.BitfieldInt):
    NAME = 'I2CNT'
    DESCRIPTION = 'I2/VB2 ADC Conversion Counter'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(I2CNT, self).__init__(I2CNT.LENGTH,  value=value, raw_value=raw_value)
        self.name = I2CNT.NAME


class I2D(bmsbase.BitfieldBool):
    NAME = 'I2D'
    DESCRIPTION = 'I2/VB2 ADC Diagnostic Flag'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(I2D, self).__init__(I2D.LENGTH,  value=value, raw_value=raw_value)
        self.name = I2D.NAME


class INJECC(bmsbase.BitfieldBool):
    NAME = 'INJECC'
    DESCRIPTION = 'ECC Diagnostic Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(INJECC, self).__init__(INJECC.LENGTH,  value=value, raw_value=raw_value)
        self.name = INJECC.NAME


class INJMON(bmsbase.BitfieldInt):
    NAME = 'INJMON'
    DESCRIPTION = 'Supply Monitor Diagnostic Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(INJMON, self).__init__(INJMON.LENGTH,  value=value, raw_value=raw_value)
        self.name = INJMON.NAME


class INJOSC(bmsbase.BitfieldInt):
    NAME = 'INJOSC'
    DESCRIPTION = 'Clock Monitor Diagnostic Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(INJOSC, self).__init__(INJOSC.LENGTH,  value=value, raw_value=raw_value)
        self.name = INJOSC.NAME


class INJTM(bmsbase.BitfieldBool):
    NAME = 'INJTM'
    DESCRIPTION = 'Test Mode Indicator Diagnostic Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(INJTM, self).__init__(INJTM.LENGTH,  value=value, raw_value=raw_value)
        self.name = INJTM.NAME


class INJTS(bmsbase.BitfieldBool):
    NAME = 'INJTS'
    DESCRIPTION = 'Thermal Shutdown Diagnostic Enable'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(INJTS, self).__init__(INJTS.LENGTH,  value=value, raw_value=raw_value)
        self.name = INJTS.NAME


class MED1(bmsbase.BitfieldBool):
    NAME = 'MED1'
    DESCRIPTION = 'NVM1 Multi-Bit ECC Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MED1, self).__init__(MED1.LENGTH,  value=value, raw_value=raw_value)
        self.name = MED1.NAME


class MED2(bmsbase.BitfieldBool):
    NAME = 'MED2'
    DESCRIPTION = 'NVM2 Multi-Bit ECC Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(MED2, self).__init__(MED2.LENGTH,  value=value, raw_value=raw_value)
        self.name = MED2.NAME


class NOCLK(bmsbase.BitfieldBool):
    NAME = 'NOCLK'
    DESCRIPTION = 'No Clock Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(NOCLK, self).__init__(NOCLK.LENGTH,  value=value, raw_value=raw_value)
        self.name = NOCLK.NAME


class OC1GC(bmsbase.BitfieldBool):
    NAME = 'OC1GC'
    DESCRIPTION = 'OC1ADC Analog Input Gain Control'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}
    SAVE_STATE = True

    def __init__(self, value=False, raw_value=0):
        super(OC1GC, self).__init__(OC1GC.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC1GC.NAME


class OC1L(bmsbase.BitfieldBool):
    NAME = 'OC1L'
    DESCRIPTION = 'OC1ADC Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC1L, self).__init__(OC1L.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC1L.NAME


class OC1R(bmsbase.BitfieldAdc):
    NAME = 'OC1R'
    DESCRIPTION = 'OC1ADC Output'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC1R, self).__init__(OC1R.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = OC1R.NAME

    def convert_from_bitlist(self, bitlist, OC1GC=0, **kwargs):
        if OC1GC:
            self.lsb = 0.0025
        else:
            self.lsb = 0.005
        return self.convert_adc_from_bitfields(bitlist, **kwargs)


class OC1TEN(bmsbase.BitfieldBool):
    NAME = 'OC1TEN'
    DESCRIPTION = 'OC1ADC Test Input Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC1TEN, self).__init__(OC1TEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC1TEN.NAME


class OC1TH(bmsbase.BitfieldInt):
    NAME = 'OC1TH'
    DESCRIPTION = 'OC1ADC Overcurrent Threshold'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7f
    MIN_VALUE = 0x0
    LENGTH = 7
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC1TH, self).__init__(OC1TH.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC1TH.NAME


class OC2GC(bmsbase.BitfieldBool):
    NAME = 'OC2GC'
    DESCRIPTION = 'OC2ADC Analog Input Gain Control'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}
    SAVE_STATE = True

    def __init__(self, value=False, raw_value=0):
        super(OC2GC, self).__init__(OC2GC.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC2GC.NAME


class OC2L(bmsbase.BitfieldBool):
    NAME = 'OC2L'
    DESCRIPTION = 'OC2ADC Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC2L, self).__init__(OC2L.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC2L.NAME


class OC2R(bmsbase.BitfieldAdc):
    NAME = 'OC2R'
    DESCRIPTION = 'OC2ADC Output'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC2R, self).__init__(OC2R.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = OC2R.NAME

    def convert_from_bitlist(self, bitlist, OC2GC=0, **kwargs):
        if OC2GC:
            self.lsb = 0.0025
        else:
            self.lsb = 0.005
        return self.convert_adc_from_bitfields(bitlist, **kwargs)


class OC2TEN(bmsbase.BitfieldBool):
    NAME = 'OC2TEN'
    DESCRIPTION = 'OC2ADC Test Input Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC2TEN, self).__init__(OC2TEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC2TEN.NAME


class OC2TH(bmsbase.BitfieldInt):
    NAME = 'OC2TH'
    DESCRIPTION = 'OC1ADC Overcurrent Threshold'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7f
    MIN_VALUE = 0x0
    LENGTH = 7
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC2TH, self).__init__(OC2TH.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC2TH.NAME


class OC3GC(bmsbase.BitfieldBool):
    NAME = 'OC3GC'
    DESCRIPTION = 'OC3ADC Analog Input Gain Control'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}
    SAVE_STATE = True

    def __init__(self, value=False, raw_value=0):
        super(OC3GC, self).__init__(OC3GC.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC3GC.NAME


class OC3L(bmsbase.BitfieldBool):
    NAME = 'OC3L'
    DESCRIPTION = 'OC3ADC Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC3L, self).__init__(OC3L.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC3L.NAME


class OC3MAX(bmsbase.BitfieldAdc):
    NAME = 'OC3MAX'
    DESCRIPTION = 'OC3ADC Maximum Output'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC3MAX, self).__init__(OC3MAX.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = OC3MAX.NAME

    def convert_from_bitlist(self, bitlist, OC3GC=0, **kwargs):
        if OC3GC:
            self.lsb = 0.0025
        else:
            self.lsb = 0.005
        return self.convert_adc_from_bitfields(bitlist, **kwargs)


class OC3MIN(bmsbase.BitfieldAdc):
    NAME = 'OC3MIN'
    DESCRIPTION = 'OC3ADC Minimum Output'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC3MIN, self).__init__(OC3MIN.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = OC3MIN.NAME

    def convert_from_bitlist(self, bitlist, OC3GC=0, **kwargs):
        if OC3GC:
            self.lsb = 0.0025
        else:
            self.lsb = 0.005
        return self.convert_adc_from_bitfields(bitlist, **kwargs)

class OC3R(bmsbase.BitfieldAdc):
    NAME = 'OC3R'
    DESCRIPTION = 'OC3ADC Output'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC3R, self).__init__(OC3R.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = OC3R.NAME

    def convert_from_bitlist(self, bitlist, OC3GC=0, **kwargs):
        if OC3GC:
            self.lsb = 0.0025
        else:
            self.lsb = 0.005
        return self.convert_adc_from_bitfields(bitlist, **kwargs)


class OC3TEN(bmsbase.BitfieldBool):
    NAME = 'OC3TEN'
    DESCRIPTION = 'OC3ADC Test Input Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OC3TEN, self).__init__(OC3TEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC3TEN.NAME


class OC3TH(bmsbase.BitfieldInt):
    NAME = 'OC3TH'
    DESCRIPTION = 'OC3ADC Overcurrent Threshold'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7f
    MIN_VALUE = 0x0
    LENGTH = 7
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OC3TH, self).__init__(OC3TH.LENGTH,  value=value, raw_value=raw_value)
        self.name = OC3TH.NAME


class OCAGD(bmsbase.BitfieldBool):
    NAME = 'OCAGD'
    DESCRIPTION = 'OCA Gate/Drain Mismatch Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCAGD, self).__init__(OCAGD.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCAGD.NAME


class OCAL(bmsbase.BitfieldBool):
    NAME = 'OCAL'
    DESCRIPTION = 'Majority Voter A Overcurrent Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCAL, self).__init__(OCAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCAL.NAME


class OCAP(bmsbase.BitfieldBool):
    NAME = 'OCAP'
    DESCRIPTION = 'OCA Pin State'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCAP, self).__init__(OCAP.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCAP.NAME


class OCAX(bmsbase.BitfieldBool):
    NAME = 'OCAX'
    DESCRIPTION = 'OCA Output XOR Inverter'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCAX, self).__init__(OCAX.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCAX.NAME


class OCBGD(bmsbase.BitfieldBool):
    NAME = 'OCBGD'
    DESCRIPTION = 'OCB Gate/Drain Mismatch Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCBGD, self).__init__(OCBGD.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCBGD.NAME


class OCBL(bmsbase.BitfieldBool):
    NAME = 'OCBL'
    DESCRIPTION = 'Majority Voter B Overcurrent Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCBL, self).__init__(OCBL.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCBL.NAME


class OCBP(bmsbase.BitfieldBool):
    NAME = 'OCBP'
    DESCRIPTION = 'OCB Pin State'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCBP, self).__init__(OCBP.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCBP.NAME


class OCBX(bmsbase.BitfieldBool):
    NAME = 'OCBX'
    DESCRIPTION = 'OCB Output XOR Inverter'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCBX, self).__init__(OCBX.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCBX.NAME


class OCDGT(bmsbase.BitfieldInt):
    NAME = 'OCDGT'
    DESCRIPTION = 'Overcurrent Deglitch Time Threshold'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OCDGT, self).__init__(OCDGT.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCDGT.NAME


class OCDP(bmsbase.BitfieldBool):
    NAME = 'OCDP'
    DESCRIPTION = 'OCA/B Output Pin Drive Diagnostic Latency'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCDP, self).__init__(OCDP.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCDP.NAME


class OCEN(bmsbase.BitfieldBool):
    NAME = 'OCEN'
    DESCRIPTION = 'OCxADC and REFADC Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCEN, self).__init__(OCEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCEN.NAME


class OCMM(bmsbase.BitfieldBool):
    NAME = 'OCMM'
    DESCRIPTION = 'OC Configuration Mismatch Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCMM, self).__init__(OCMM.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCMM.NAME


class OCMODE(bmsbase.BitfieldInt):
    NAME = 'OCMODE'
    DESCRIPTION = 'OCA/B Output Pin Mode Control'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {
        'range': [0, 1, 2, 3]
    }

    def __init__(self, value=0, raw_value=0):
        super(OCMODE, self).__init__(OCMODE.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCMODE.NAME


class OCOD(bmsbase.BitfieldBool):
    NAME = 'OCOD'
    DESCRIPTION = 'OCA/B Output Pin Open Drain Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OCOD, self).__init__(OCOD.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCOD.NAME


class OCTSEL(bmsbase.BitfieldInt):
    NAME = 'OCTSEL'
    DESCRIPTION = 'OCxADC Test Input Selection'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {
        'range': [0, 1, 2, 3]
    }

    def __init__(self, value=0, raw_value=0):
        super(OCTSEL, self).__init__(OCTSEL.LENGTH,  value=value, raw_value=raw_value)
        self.name = OCTSEL.NAME


class OSCCNT(bmsbase.BitfieldInt):
    NAME = 'OSCCNT'
    DESCRIPTION = ''
    MEM_KEY = ''
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0xff
    MIN_VALUE = 0x0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(OSCCNT, self).__init__(OSCCNT.LENGTH,  value=value, raw_value=raw_value)
        self.name = OSCCNT.NAME


class OSCFLT(bmsbase.BitfieldBool):
    NAME = 'OSCFLT'
    DESCRIPTION = 'Oscillator Frequency Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(OSCFLT, self).__init__(OSCFLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = OSCFLT.NAME


class REFFLT(bmsbase.BitfieldBool):
    NAME = 'REFFLT'
    DESCRIPTION = 'REFADC Fault Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(REFFLT, self).__init__(REFFLT.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFFLT.NAME


class REFR(bmsbase.BitfieldAdc):
    NAME = 'REFR'
    DESCRIPTION = 'REFADC Result'
    MEM_KEY = 'Over Current ADCs'
    DEFAULT_VALUE = 127
    MAX_VALUE = 0.6375000000000001
    MIN_VALUE = -0.64
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REFR, self).__init__(REFR.LENGTH, value=value, raw_value=raw_value, lsb=0.005, postpend=0, prepend=0, twos_complement=True)
        self.name = REFR.NAME


class REFTEN(bmsbase.BitfieldBool):
    NAME = 'REFTEN'
    DESCRIPTION = 'REFADC Test Input Enable'
    MEM_KEY = 'OC Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(REFTEN, self).__init__(REFTEN.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFTEN.NAME


class REFUP(bmsbase.BitfieldBool):
    NAME = 'REFUP'
    DESCRIPTION = 'References Enable State'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(REFUP, self).__init__(REFUP.LENGTH,  value=value, raw_value=raw_value)
        self.name = REFUP.NAME


class RESET(bmsbase.BitfieldBool):
    NAME = 'RESET'
    DESCRIPTION = 'Reset Indicator Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(RESET, self).__init__(RESET.LENGTH,  value=value, raw_value=raw_value)
        self.name = RESET.NAME


class REVID(bmsbase.BitfieldInt):
    NAME = 'REVID'
    DESCRIPTION = 'Silicon Revision'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = 0x2
    MAX_VALUE = 0xf
    MIN_VALUE = 0x0
    LENGTH = 4
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(REVID, self).__init__(REVID.LENGTH,  value=value, raw_value=raw_value)
        self.name = REVID.NAME


class SED1(bmsbase.BitfieldBool):
    NAME = 'SED1'
    DESCRIPTION = 'NVM1 1-Bit ECC Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SED1, self).__init__(SED1.LENGTH,  value=value, raw_value=raw_value)
        self.name = SED1.NAME


class SED2(bmsbase.BitfieldBool):
    NAME = 'SED2'
    DESCRIPTION = 'NVM2 1-Bit ECC Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SED2, self).__init__(SED2.LENGTH,  value=value, raw_value=raw_value)
        self.name = SED2.NAME


class SNAPST(bmsbase.BitfieldBool):
    NAME = 'SNAPST'
    DESCRIPTION = 'Snapshot Status'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SNAPST, self).__init__(SNAPST.LENGTH,  value=value, raw_value=raw_value)
        self.name = SNAPST.NAME


class SOAK(bmsbase.BitfieldInt):
    NAME = 'SOAK'
    DESCRIPTION = 'ADC Soak Time'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x7
    MIN_VALUE = 0x0
    LENGTH = 3
    LIMITS = {
        'range': [0, 1, 2, 3, 4, 5, 6, 7]
    }

    def __init__(self, value=0, raw_value=0):
        super(SOAK, self).__init__(SOAK.LENGTH,  value=value, raw_value=raw_value)
        self.name = SOAK.NAME


class SPI3W(bmsbase.BitfieldBool):
    NAME = 'SPI3W'
    DESCRIPTION = 'SPI Controller Mode Select'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(SPI3W, self).__init__(SPI3W.LENGTH,  value=value, raw_value=raw_value)
        self.name = SPI3W.NAME


class V1D(bmsbase.BitfieldBool):
    NAME = 'V1D'
    DESCRIPTION = 'V1ADC Diagnostic Indicator'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(V1D, self).__init__(V1D.LENGTH,  value=value, raw_value=raw_value)
        self.name = V1D.NAME


class V2D(bmsbase.BitfieldBool):
    NAME = 'V2D'
    DESCRIPTION = 'V2ADC Diagnostic Indicator'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(V2D, self).__init__(V2D.LENGTH,  value=value, raw_value=raw_value)
        self.name = V2D.NAME


class VB1MUX(bmsbase.BitfieldBool):
    NAME = 'VB1MUX'
    DESCRIPTION = 'VB1MUX Input Multiplexer Select'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VB1MUX, self).__init__(VB1MUX.LENGTH,  value=value, raw_value=raw_value)
        self.name = VB1MUX.NAME


class VB2MUX(bmsbase.BitfieldBool):
    NAME = 'VB2MUX'
    DESCRIPTION = 'VB2MUX Input Multiplexer Select'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VB2MUX, self).__init__(VB2MUX.LENGTH,  value=value, raw_value=raw_value)
        self.name = VB2MUX.NAME


class VDDUV(bmsbase.BitfieldBool):
    NAME = 'VDDUV'
    DESCRIPTION = 'VDD Under Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDDUV, self).__init__(VDDUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDDUV.NAME


class VDIGOV(bmsbase.BitfieldBool):
    NAME = 'VDIGOV'
    DESCRIPTION = 'Digitial Voltage Over Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDIGOV, self).__init__(VDIGOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDIGOV.NAME


class VDIGUV(bmsbase.BitfieldBool):
    NAME = 'VDIGUV'
    DESCRIPTION = 'Digital Voltage Under Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDIGUV, self).__init__(VDIGUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDIGUV.NAME


class VDRUV(bmsbase.BitfieldBool):
    NAME = 'VDRUV'
    DESCRIPTION = 'Drive Voltage Under Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VDRUV, self).__init__(VDRUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VDRUV.NAME


class VREGOV(bmsbase.BitfieldBool):
    NAME = 'VREGOV'
    DESCRIPTION = 'Vreg Over Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VREGOV, self).__init__(VREGOV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VREGOV.NAME


class VREGUV(bmsbase.BitfieldBool):
    NAME = 'VREGUV'
    DESCRIPTION = 'Vreg Under Voltage Latch'
    MEM_KEY = 'Status Flags'
    DEFAULT_VALUE = True
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VREGUV, self).__init__(VREGUV.LENGTH,  value=value, raw_value=raw_value)
        self.name = VREGUV.NAME


class VS1(bmsbase.BitfieldInt):
    NAME = 'VS1'
    DESCRIPTION = 'Reference Voltage For V1 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {
        'range': [0, 1, 2, 3]
    }

    def __init__(self, value=0, raw_value=0):
        super(VS1, self).__init__(VS1.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS1.NAME


class VS10(bmsbase.BitfieldBool):
    NAME = 'VS10'
    DESCRIPTION = 'Reference Voltage For V10 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS10, self).__init__(VS10.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS10.NAME


class VS2(bmsbase.BitfieldInt):
    NAME = 'VS2'
    DESCRIPTION = 'Reference Voltage For V2 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = 0x0
    MAX_VALUE = 0x3
    MIN_VALUE = 0x0
    LENGTH = 2
    LIMITS = {
        'range': [0, 1, 2, 3]
    }

    def __init__(self, value=0, raw_value=0):
        super(VS2, self).__init__(VS2.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS2.NAME


class VS3(bmsbase.BitfieldBool):
    NAME = 'VS3'
    DESCRIPTION = 'Reference Voltage For V3 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS3, self).__init__(VS3.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS3.NAME


class VS4(bmsbase.BitfieldBool):
    NAME = 'VS4'
    DESCRIPTION = 'Reference Voltage For V4 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS4, self).__init__(VS4.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS4.NAME


class VS5(bmsbase.BitfieldBool):
    NAME = 'VS5'
    DESCRIPTION = 'Reference Voltage For V5 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS5, self).__init__(VS5.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS5.NAME


class VS6(bmsbase.BitfieldBool):
    NAME = 'VS6'
    DESCRIPTION = 'Reference Voltage For V6 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS6, self).__init__(VS6.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS6.NAME


class VS7(bmsbase.BitfieldBool):
    NAME = 'VS7'
    DESCRIPTION = 'Reference Voltage For V7 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS7, self).__init__(VS7.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS7.NAME


class VS8(bmsbase.BitfieldBool):
    NAME = 'VS8'
    DESCRIPTION = 'Reference Voltage For V8 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS8, self).__init__(VS8.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS8.NAME


class VS9(bmsbase.BitfieldBool):
    NAME = 'VS9'
    DESCRIPTION = 'Reference Voltage For V9 Measurement'
    MEM_KEY = 'Configuration'
    DEFAULT_VALUE = False
    MAX_VALUE = True
    MIN_VALUE = False
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(VS9, self).__init__(VS9.LENGTH,  value=value, raw_value=raw_value)
        self.name = VS9.NAME

# ===================================================== Registers =====================================================
class CMD_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command Bytes'
    NAME = 'Command Bytes'
    
    def __init__(self):
        super(CMD_REGISTER, self).__init__(
            [[CMD0, 7], [CMD0, 6], [CMD0, 5], [CMD0, 4], [CMD0, 3], [CMD0, 2], [CMD0, 1], [CMD0, 0],
             [CMD1, 7], [CMD1, 6], [CMD1, 5], [CMD1, 4], [CMD1, 3], [CMD1, 2], [CMD1, 1], [CMD1, 0]])


class CCNT_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command Counter'
    NAME = 'Command Counter'

    def __init__(self):
        super(CCNT_REGISTER, self).__init__(
            [[CCNT, 5], [CCNT, 4], [CCNT, 3], [CCNT, 2], [CCNT, 1], [CCNT, 0]])


class CMD_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Command PEC Bytes'
    NAME = 'Command PEC Bytes'

    def __init__(self):
        super(CMD_PEC_REGISTER, self).__init__(
            [[CMD_PEC, 15], [CMD_PEC, 14], [CMD_PEC, 13], [CMD_PEC, 12], [CMD_PEC, 11], [CMD_PEC, 10], [CMD_PEC, 9], [CMD_PEC, 8],
             [CMD_PEC, 7], [CMD_PEC, 6], [CMD_PEC, 5], [CMD_PEC, 4], [CMD_PEC, 3], [CMD_PEC, 2], [CMD_PEC, 1], [CMD_PEC, 0]])


class DATA_PEC_REGISTER(bmsbase.Register):
    MEM_KEY = 'Data PEC Bytes'
    NAME = 'Data PEC Bytes'

    def __init__(self):
        super(DATA_PEC_REGISTER, self).__init__(
            [[DATA_PEC, 9], [DATA_PEC, 8],
             [DATA_PEC, 7], [DATA_PEC, 6], [DATA_PEC, 5], [DATA_PEC, 4], [DATA_PEC, 3], [DATA_PEC, 2], [DATA_PEC, 1], [DATA_PEC, 0]])


class WRITE_DATA_REGISTER(bmsbase.Register):
    MEM_KEY = 'Write Command Bytes'
    NAME = 'Write Command Bytes'

    def __init__(self):
        super(WRITE_DATA_REGISTER, self).__init__(
            [[DATA0, 7], [DATA0, 6], [DATA0, 5], [DATA0, 4], [DATA0, 3], [DATA0, 2], [DATA0, 1], [DATA0, 0],
             [DATA1, 7], [DATA1, 6], [DATA1, 5], [DATA1, 4], [DATA1, 3], [DATA1, 2], [DATA1, 1], [DATA1, 0],
             [DATA2, 7], [DATA2, 6], [DATA2, 5], [DATA2, 4], [DATA2, 3], [DATA2, 2], [DATA2, 1], [DATA2, 0],
             [DATA3, 7], [DATA3, 6], [DATA3, 5], [DATA3, 4], [DATA3, 3], [DATA3, 2], [DATA3, 1], [DATA3, 0],
             [DATA4, 7], [DATA4, 6], [DATA4, 5], [DATA4, 4], [DATA4, 3], [DATA4, 2], [DATA4, 1], [DATA4, 0],
             [DATA5, 7], [DATA5, 6], [DATA5, 5], [DATA5, 4], [DATA5, 3], [DATA5, 2], [DATA5, 1], [DATA5, 0]])


class DATA0_REGISTER(bmsbase.Register):
    MEM_KEY = 'Write/Read Bytes'
    NAME = 'Data0 Register'

    def __init__(self):
        super(DATA0_REGISTER, self).__init__([[DATA0, 7], [DATA0, 6], [DATA0, 5], [DATA0, 4], [DATA0, 3], [DATA0, 2], [DATA0, 1], [DATA0, 0]])



class DATA1_REGISTER(bmsbase.Register):
    MEM_KEY = 'Write/Read Bytes'
    NAME = 'Data1 Register'

    def __init__(self):
        super(DATA1_REGISTER, self).__init__([[DATA1, 7], [DATA1, 6], [DATA1, 5], [DATA1, 4], [DATA1, 3], [DATA1, 2], [DATA1, 1], [DATA1, 0]])


class SIDR0(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR0'

    def __init__(self):
        super(SIDR0, self).__init__([[SID, 7], [SID, 6], [SID, 5], [SID, 4], [SID, 3], [SID, 2], [SID, 1], [SID, 0]])


class SIDR1(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR1'

    def __init__(self):
        super(SIDR1, self).__init__([[SID, 15], [SID, 14], [SID, 13], [SID, 12], [SID, 11], [SID, 10], [SID, 9], [SID, 8]])


class SIDR2(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR2'

    def __init__(self):
        super(SIDR2, self).__init__([[SID, 23], [SID, 22], [SID, 21], [SID, 20], [SID, 19], [SID, 18], [SID, 17], [SID, 16]])


class SIDR3(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR3'

    def __init__(self):
        super(SIDR3, self).__init__([[SID, 31], [SID, 30], [SID, 29], [SID, 28], [SID, 27], [SID, 26], [SID, 25], [SID, 24]])


class SIDR4(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR4'

    def __init__(self):
        super(SIDR4, self).__init__([[SID, 39], [SID, 38], [SID, 37], [SID, 36], [SID, 35], [SID, 34], [SID, 33], [SID, 32]])


class SIDR5(bmsbase.Register):
    MEM_KEY = 'Serial ID Register Group'
    NAME = 'SIDR5'

    def __init__(self):
        super(SIDR5, self).__init__([[SID, 47], [SID, 46, DTYPE, 5], [SID, 45, DTYPE, 4], [SID, 44, DTYPE, 3], [SID, 43, DTYPE, 2], [SID, 42, DTYPE, 1], [SID, 41, DTYPE, 0], [SID, 40]])


class CFGAR0(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR0'

    def __init__(self):
        super(CFGAR0, self).__init__([[REFON, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CTH, 2], [CTH, 1], [CTH, 0]])


class CFGAR1(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR1'

    def __init__(self):
        super(CFGAR1, self).__init__([[FLAG_D, 7], [FLAG_D, 6], [FLAG_D, 5], [FLAG_D, 4], [FLAG_D, 3], [FLAG_D, 2], [FLAG_D, 1], [FLAG_D, 0]])


class CFGAR2(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR2'

    def __init__(self):
        super(CFGAR2, self).__init__([[SOAKON, 0], [OWRNG, 0], [OWA, 2], [OWA, 1], [OWA, 0],  [bmsbase.RSVD0, 0],  [bmsbase.RSVD0, 0],  [bmsbase.RSVD0, 0]])


class CFGAR3(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR3'

    def __init__(self):
        super(CFGAR3, self).__init__([[GPO8, 0], [GPO7, 0], [GPO6, 0], [GPO5, 0], [GPO4, 0], [GPO3, 0], [GPO2, 0], [GPO1, 0]])


class CFGAR4(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR4'

    def __init__(self):
        super(CFGAR4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [GPO10, 0], [GPO9, 0]])


class CFGAR5(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group A'
    NAME = 'CFGAR5'

    def __init__(self):
        super(CFGAR5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [SNAP_ST, 0], [MUTE_ST, 0], [COMM_BK, 0], [FC, 2], [FC, 1], [FC, 0]])


class CFGBR0(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR0'

    def __init__(self):
        super(CFGBR0, self).__init__([[VUV, 7], [VUV, 6], [VUV, 5], [VUV, 4], [VUV, 3], [VUV, 2], [VUV, 1], [VUV, 0]])


class CFGBR1(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR1'

    def __init__(self):
        super(CFGBR1, self).__init__([[VOV, 3], [VOV, 2], [VOV, 1], [VOV, 0], [VUV, 11], [VUV, 10], [VUV, 9], [VUV, 8]])


class CFGBR2(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR2'

    def __init__(self):
        super(CFGBR2, self).__init__([[VOV, 11], [VOV, 10], [VOV, 9], [VOV, 8], [VOV, 7], [VOV, 6], [VOV, 5], [VOV, 4]])


class CFGBR3(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR3'

    def __init__(self):
        super(CFGBR3, self).__init__([[DTMEN, 0], [DTRNG, 0], [DCTO, 5], [DCTO, 4], [DCTO, 3], [DCTO, 2], [DCTO, 1], [DCTO, 0]])


class CFGBR4(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR4'

    def __init__(self):
        super(CFGBR4, self).__init__([[DCC8, 0], [DCC7, 0], [DCC6, 0], [DCC5, 0], [DCC4, 0], [DCC3, 0], [DCC2, 0], [DCC1, 0]])


class CFGBR5(bmsbase.Register):
    MEM_KEY = 'Configuration Register Group B'
    NAME = 'CFGBR5'

    def __init__(self):
        super(CFGBR5, self).__init__([[DCC16, 0], [DCC15, 0], [DCC14, 0], [DCC13, 0], [DCC12, 0], [DCC11, 0], [DCC10, 0], [DCC9, 0]])


class CVAR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR0'

    def __init__(self):
        super(CVAR0, self).__init__([[C1V, 7], [C1V, 6], [C1V, 5], [C1V, 4], [C1V, 3], [C1V, 2], [C1V, 1], [C1V, 0]])


class CVAR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR1'

    def __init__(self):
        super(CVAR1, self).__init__([[C1V, 15], [C1V, 14], [C1V, 13], [C1V, 12], [C1V, 11], [C1V, 10], [C1V, 9], [C1V, 8]])


class CVAR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR2'

    def __init__(self):
        super(CVAR2, self).__init__([[C2V, 7], [C2V, 6], [C2V, 5], [C2V, 4], [C2V, 3], [C2V, 2], [C2V, 1], [C2V, 0]])


class CVAR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR3'

    def __init__(self):
        super(CVAR3, self).__init__([[C2V, 15], [C2V, 14], [C2V, 13], [C2V, 12], [C2V, 11], [C2V, 10], [C2V, 9], [C2V, 8]])


class CVAR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR4'

    def __init__(self):
        super(CVAR4, self).__init__([[C3V, 7], [C3V, 6], [C3V, 5], [C3V, 4], [C3V, 3], [C3V, 2], [C3V, 1], [C3V, 0]])


class CVAR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group A'
    NAME = 'CVAR5'

    def __init__(self):
        super(CVAR5, self).__init__([[C3V, 15], [C3V, 14], [C3V, 13], [C3V, 12], [C3V, 11], [C3V, 10], [C3V, 9], [C3V, 8]])


class CVBR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR0'

    def __init__(self):
        super(CVBR0, self).__init__([[C4V, 7], [C4V, 6], [C4V, 5], [C4V, 4], [C4V, 3], [C4V, 2], [C4V, 1], [C4V, 0]])


class CVBR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR1'

    def __init__(self):
        super(CVBR1, self).__init__([[C4V, 15], [C4V, 14], [C4V, 13], [C4V, 12], [C4V, 11], [C4V, 10], [C4V, 9], [C4V, 8]])


class CVBR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR2'

    def __init__(self):
        super(CVBR2, self).__init__([[C5V, 7], [C5V, 6], [C5V, 5], [C5V, 4], [C5V, 3], [C5V, 2], [C5V, 1], [C5V, 0]])


class CVBR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR3'

    def __init__(self):
        super(CVBR3, self).__init__([[C5V, 15], [C5V, 14], [C5V, 13], [C5V, 12], [C5V, 11], [C5V, 10], [C5V, 9], [C5V, 8]])


class CVBR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR4'

    def __init__(self):
        super(CVBR4, self).__init__([[C6V, 7], [C6V, 6], [C6V, 5], [C6V, 4], [C6V, 3], [C6V, 2], [C6V, 1], [C6V, 0]])


class CVBR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group B'
    NAME = 'CVBR5'

    def __init__(self):
        super(CVBR5, self).__init__([[C6V, 15], [C6V, 14], [C6V, 13], [C6V, 12], [C6V, 11], [C6V, 10], [C6V, 9], [C6V, 8]])


class CVCR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR0'

    def __init__(self):
        super(CVCR0, self).__init__([[C7V, 7], [C7V, 6], [C7V, 5], [C7V, 4], [C7V, 3], [C7V, 2], [C7V, 1], [C7V, 0]])


class CVCR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR1'

    def __init__(self):
        super(CVCR1, self).__init__([[C7V, 15], [C7V, 14], [C7V, 13], [C7V, 12], [C7V, 11], [C7V, 10], [C7V, 9], [C7V, 8]])


class CVCR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR2'

    def __init__(self):
        super(CVCR2, self).__init__([[C8V, 7], [C8V, 6], [C8V, 5], [C8V, 4], [C8V, 3], [C8V, 2], [C8V, 1], [C8V, 0]])


class CVCR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR3'

    def __init__(self):
        super(CVCR3, self).__init__([[C8V, 15], [C8V, 14], [C8V, 13], [C8V, 12], [C8V, 11], [C8V, 10], [C8V, 9], [C8V, 8]])


class CVCR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR4'

    def __init__(self):
        super(CVCR4, self).__init__([[C9V, 7], [C9V, 6], [C9V, 5], [C9V, 4], [C9V, 3], [C9V, 2], [C9V, 1], [C9V, 0]])


class CVCR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group C'
    NAME = 'CVCR5'

    def __init__(self):
        super(CVCR5, self).__init__([[C9V, 15], [C9V, 14], [C9V, 13], [C9V, 12], [C9V, 11], [C9V, 10], [C9V, 9], [C9V, 8]])


class CVDR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR0'

    def __init__(self):
        super(CVDR0, self).__init__([[C10V, 7], [C10V, 6], [C10V, 5], [C10V, 4], [C10V, 3], [C10V, 2], [C10V, 1], [C10V, 0]])


class CVDR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR1'

    def __init__(self):
        super(CVDR1, self).__init__([[C10V, 15], [C10V, 14], [C10V, 13], [C10V, 12], [C10V, 11], [C10V, 10], [C10V, 9], [C10V, 8]])


class CVDR2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR2'

    def __init__(self):
        super(CVDR2, self).__init__([[C11V, 7], [C11V, 6], [C11V, 5], [C11V, 4], [C11V, 3], [C11V, 2], [C11V, 1], [C11V, 0]])


class CVDR3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR3'

    def __init__(self):
        super(CVDR3, self).__init__([[C11V, 15], [C11V, 14], [C11V, 13], [C11V, 12], [C11V, 11], [C11V, 10], [C11V, 9], [C11V, 8]])


class CVDR4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR4'

    def __init__(self):
        super(CVDR4, self).__init__([[C12V, 7], [C12V, 6], [C12V, 5], [C12V, 4], [C12V, 3], [C12V, 2], [C12V, 1], [C12V, 0]])


class CVDR5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group D'
    NAME = 'CVDR5'

    def __init__(self):
        super(CVDR5, self).__init__([[C12V, 15], [C12V, 14], [C12V, 13], [C12V, 12], [C12V, 11], [C12V, 10], [C12V, 9], [C12V, 8]])


class CVER0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER0'

    def __init__(self):
        super(CVER0, self).__init__([[C13V, 7], [C13V, 6], [C13V, 5], [C13V, 4], [C13V, 3], [C13V, 2], [C13V, 1], [C13V, 0]])


class CVER1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER1'

    def __init__(self):
        super(CVER1, self).__init__([[C13V, 15], [C13V, 14], [C13V, 13], [C13V, 12], [C13V, 11], [C13V, 10], [C13V, 9], [C13V, 8]])


class CVER2(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER2'

    def __init__(self):
        super(CVER2, self).__init__([[C14V, 7], [C14V, 6], [C14V, 5], [C14V, 4], [C14V, 3], [C14V, 2], [C14V, 1], [C14V, 0]])


class CVER3(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER3'

    def __init__(self):
        super(CVER3, self).__init__([[C14V, 15], [C14V, 14], [C14V, 13], [C14V, 12], [C14V, 11], [C14V, 10], [C14V, 9], [C14V, 8]])


class CVER4(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER4'

    def __init__(self):
        super(CVER4, self).__init__([[C15V, 7], [C15V, 6], [C15V, 5], [C15V, 4], [C15V, 3], [C15V, 2], [C15V, 1], [C15V, 0]])


class CVER5(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group E'
    NAME = 'CVER5'

    def __init__(self):
        super(CVER5, self).__init__([[C15V, 15], [C15V, 14], [C15V, 13], [C15V, 12], [C15V, 11], [C15V, 10], [C15V, 9], [C15V, 8]])


class CVFR0(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR0'

    def __init__(self):
        super(CVFR0, self).__init__([[C16V, 7], [C16V, 6], [C16V, 5], [C16V, 4], [C16V, 3], [C16V, 2], [C16V, 1], [C16V, 0]])


class CVFR1(bmsbase.Register):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR1'

    def __init__(self):
        super(CVFR1, self).__init__([[C16V, 15], [C16V, 14], [C16V, 13], [C16V, 12], [C16V, 11], [C16V, 10], [C16V, 9], [C16V, 8]])


class CVFR2(bmsbase.RSVDR2):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR2'

    def __init__(self):
        super(CVFR2, self).__init__()


class CVFR3(bmsbase.RSVDR3):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR3'

    def __init__(self):
        super(CVFR3, self).__init__()


class CVFR4(bmsbase.RSVDR4):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR4'

    def __init__(self):
        super(CVFR4, self).__init__()


class CVFR5(bmsbase.RSVDR5):
    MEM_KEY = 'Cell Voltage Register Group F'
    NAME = 'CVFR5'

    def __init__(self):
        super(CVFR5, self).__init__()


class ACVAR0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR0'

    def __init__(self):
        super(ACVAR0, self).__init__([[AC1V, 7], [AC1V, 6], [AC1V, 5], [AC1V, 4], [AC1V, 3], [AC1V, 2], [AC1V, 1], [AC1V, 0]])


class ACVAR1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR1'

    def __init__(self):
        super(ACVAR1, self).__init__([[AC1V, 15], [AC1V, 14], [AC1V, 13], [AC1V, 12], [AC1V, 11], [AC1V, 10], [AC1V, 9], [AC1V, 8]])


class ACVAR2(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR2'

    def __init__(self):
        super(ACVAR2, self).__init__([[AC2V, 7], [AC2V, 6], [AC2V, 5], [AC2V, 4], [AC2V, 3], [AC2V, 2], [AC2V, 1], [AC2V, 0]])


class ACVAR3(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR3'

    def __init__(self):
        super(ACVAR3, self).__init__([[AC2V, 15], [AC2V, 14], [AC2V, 13], [AC2V, 12], [AC2V, 11], [AC2V, 10], [AC2V, 9], [AC2V, 8]])


class ACVAR4(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR4'

    def __init__(self):
        super(ACVAR4, self).__init__([[AC3V, 7], [AC3V, 6], [AC3V, 5], [AC3V, 4], [AC3V, 3], [AC3V, 2], [AC3V, 1], [AC3V, 0]])


class ACVAR5(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group A'
    NAME = 'ACVAR5'

    def __init__(self):
        super(ACVAR5, self).__init__([[AC3V, 15], [AC3V, 14], [AC3V, 13], [AC3V, 12], [AC3V, 11], [AC3V, 10], [AC3V, 9], [AC3V, 8]])


class ACVBR0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR0'

    def __init__(self):
        super(ACVBR0, self).__init__([[AC4V, 7], [AC4V, 6], [AC4V, 5], [AC4V, 4], [AC4V, 3], [AC4V, 2], [AC4V, 1], [AC4V, 0]])


class ACVBR1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR1'

    def __init__(self):
        super(ACVBR1, self).__init__([[AC4V, 15], [AC4V, 14], [AC4V, 13], [AC4V, 12], [AC4V, 11], [AC4V, 10], [AC4V, 9], [AC4V, 8]])


class ACVBR2(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR2'

    def __init__(self):
        super(ACVBR2, self).__init__([[AC5V, 7], [AC5V, 6], [AC5V, 5], [AC5V, 4], [AC5V, 3], [AC5V, 2], [AC5V, 1], [AC5V, 0]])


class ACVBR3(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR3'

    def __init__(self):
        super(ACVBR3, self).__init__([[AC5V, 15], [AC5V, 14], [AC5V, 13], [AC5V, 12], [AC5V, 11], [AC5V, 10], [AC5V, 9], [AC5V, 8]])


class ACVBR4(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR4'

    def __init__(self):
        super(ACVBR4, self).__init__([[AC6V, 7], [AC6V, 6], [AC6V, 5], [AC6V, 4], [AC6V, 3], [AC6V, 2], [AC6V, 1], [AC6V, 0]])


class ACVBR5(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group B'
    NAME = 'ACVBR5'

    def __init__(self):
        super(ACVBR5, self).__init__([[AC6V, 15], [AC6V, 14], [AC6V, 13], [AC6V, 12], [AC6V, 11], [AC6V, 10], [AC6V, 9], [AC6V, 8]])


class ACVCR0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR0'

    def __init__(self):
        super(ACVCR0, self).__init__([[AC7V, 7], [AC7V, 6], [AC7V, 5], [AC7V, 4], [AC7V, 3], [AC7V, 2], [AC7V, 1], [AC7V, 0]])


class ACVCR1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR1'

    def __init__(self):
        super(ACVCR1, self).__init__([[AC7V, 15], [AC7V, 14], [AC7V, 13], [AC7V, 12], [AC7V, 11], [AC7V, 10], [AC7V, 9], [AC7V, 8]])


class ACVCR2(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR2'

    def __init__(self):
        super(ACVCR2, self).__init__([[AC8V, 7], [AC8V, 6], [AC8V, 5], [AC8V, 4], [AC8V, 3], [AC8V, 2], [AC8V, 1], [AC8V, 0]])


class ACVCR3(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR3'

    def __init__(self):
        super(ACVCR3, self).__init__([[AC8V, 15], [AC8V, 14], [AC8V, 13], [AC8V, 12], [AC8V, 11], [AC8V, 10], [AC8V, 9], [AC8V, 8]])


class ACVCR4(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR4'

    def __init__(self):
        super(ACVCR4, self).__init__([[AC9V, 7], [AC9V, 6], [AC9V, 5], [AC9V, 4], [AC9V, 3], [AC9V, 2], [AC9V, 1], [AC9V, 0]])


class ACVCR5(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group C'
    NAME = 'ACVCR5'

    def __init__(self):
        super(ACVCR5, self).__init__([[AC9V, 15], [AC9V, 14], [AC9V, 13], [AC9V, 12], [AC9V, 11], [AC9V, 10], [AC9V, 9], [AC9V, 8]])


class ACVDR0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR0'

    def __init__(self):
        super(ACVDR0, self).__init__([[AC10V, 7], [AC10V, 6], [AC10V, 5], [AC10V, 4], [AC10V, 3], [AC10V, 2], [AC10V, 1], [AC10V, 0]])


class ACVDR1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR1'

    def __init__(self):
        super(ACVDR1, self).__init__([[AC10V, 15], [AC10V, 14], [AC10V, 13], [AC10V, 12], [AC10V, 11], [AC10V, 10], [AC10V, 9], [AC10V, 8]])


class ACVDR2(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR2'

    def __init__(self):
        super(ACVDR2, self).__init__([[AC11V, 7], [AC11V, 6], [AC11V, 5], [AC11V, 4], [AC11V, 3], [AC11V, 2], [AC11V, 1], [AC11V, 0]])


class ACVDR3(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR3'

    def __init__(self):
        super(ACVDR3, self).__init__([[AC11V, 15], [AC11V, 14], [AC11V, 13], [AC11V, 12], [AC11V, 11], [AC11V, 10], [AC11V, 9], [AC11V, 8]])


class ACVDR4(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR4'

    def __init__(self):
        super(ACVDR4, self).__init__([[AC12V, 7], [AC12V, 6], [AC12V, 5], [AC12V, 4], [AC12V, 3], [AC12V, 2], [AC12V, 1], [AC12V, 0]])


class ACVDR5(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group D'
    NAME = 'ACVDR5'

    def __init__(self):
        super(ACVDR5, self).__init__([[AC12V, 15], [AC12V, 14], [AC12V, 13], [AC12V, 12], [AC12V, 11], [AC12V, 10], [AC12V, 9], [AC12V, 8]])


class ACVER0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER0'

    def __init__(self):
        super(ACVER0, self).__init__([[AC13V, 7], [AC13V, 6], [AC13V, 5], [AC13V, 4], [AC13V, 3], [AC13V, 2], [AC13V, 1], [AC13V, 0]])


class ACVER1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER1'

    def __init__(self):
        super(ACVER1, self).__init__([[AC13V, 15], [AC13V, 14], [AC13V, 13], [AC13V, 12], [AC13V, 11], [AC13V, 10], [AC13V, 9], [AC13V, 8]])


class ACVER2(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER2'

    def __init__(self):
        super(ACVER2, self).__init__([[AC14V, 7], [AC14V, 6], [AC14V, 5], [AC14V, 4], [AC14V, 3], [AC14V, 2], [AC14V, 1], [AC14V, 0]])


class ACVER3(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER3'

    def __init__(self):
        super(ACVER3, self).__init__([[AC14V, 15], [AC14V, 14], [AC14V, 13], [AC14V, 12], [AC14V, 11], [AC14V, 10], [AC14V, 9], [AC14V, 8]])


class ACVER4(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER4'

    def __init__(self):
        super(ACVER4, self).__init__([[AC15V, 7], [AC15V, 6], [AC15V, 5], [AC15V, 4], [AC15V, 3], [AC15V, 2], [AC15V, 1], [AC15V, 0]])


class ACVER5(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group E'
    NAME = 'ACVER5'

    def __init__(self):
        super(ACVER5, self).__init__([[AC15V, 15], [AC15V, 14], [AC15V, 13], [AC15V, 12], [AC15V, 11], [AC15V, 10], [AC15V, 9], [AC15V, 8]])


class ACVFR0(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR0'

    def __init__(self):
        super(ACVFR0, self).__init__([[AC16V, 7], [AC16V, 6], [AC16V, 5], [AC16V, 4], [AC16V, 3], [AC16V, 2], [AC16V, 1], [AC16V, 0]])


class ACVFR1(bmsbase.Register):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR1'

    def __init__(self):
        super(ACVFR1, self).__init__([[AC16V, 15], [AC16V, 14], [AC16V, 13], [AC16V, 12], [AC16V, 11], [AC16V, 10], [AC16V, 9], [AC16V, 8]])


class ACVFR2(bmsbase.RSVDR2):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR2'

    def __init__(self):
        super(ACVFR2, self).__init__()


class ACVFR3(bmsbase.RSVDR3):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR3'

    def __init__(self):
        super(ACVFR3, self).__init__()


class ACVFR4(bmsbase.RSVDR4):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR4'

    def __init__(self):
        super(ACVFR4, self).__init__()


class ACVFR5(bmsbase.RSVDR5):
    MEM_KEY = 'Averaged Cell Voltage Register Group F'
    NAME = 'ACVFR5'

    def __init__(self):
        super(ACVFR5, self).__init__()


class FCVAR0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR0'

    def __init__(self):
        super(FCVAR0, self).__init__([[FC1V, 7], [FC1V, 6], [FC1V, 5], [FC1V, 4], [FC1V, 3], [FC1V, 2], [FC1V, 1], [FC1V, 0]])


class FCVAR1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR1'

    def __init__(self):
        super(FCVAR1, self).__init__([[FC1V, 15], [FC1V, 14], [FC1V, 13], [FC1V, 12], [FC1V, 11], [FC1V, 10], [FC1V, 9], [FC1V, 8]])


class FCVAR2(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR2'

    def __init__(self):
        super(FCVAR2, self).__init__([[FC2V, 7], [FC2V, 6], [FC2V, 5], [FC2V, 4], [FC2V, 3], [FC2V, 2], [FC2V, 1], [FC2V, 0]])


class FCVAR3(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR3'

    def __init__(self):
        super(FCVAR3, self).__init__([[FC2V, 15], [FC2V, 14], [FC2V, 13], [FC2V, 12], [FC2V, 11], [FC2V, 10], [FC2V, 9], [FC2V, 8]])


class FCVAR4(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR4'

    def __init__(self):
        super(FCVAR4, self).__init__([[FC3V, 7], [FC3V, 6], [FC3V, 5], [FC3V, 4], [FC3V, 3], [FC3V, 2], [FC3V, 1], [FC3V, 0]])


class FCVAR5(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group A'
    NAME = 'FCVAR5'

    def __init__(self):
        super(FCVAR5, self).__init__([[FC3V, 15], [FC3V, 14], [FC3V, 13], [FC3V, 12], [FC3V, 11], [FC3V, 10], [FC3V, 9], [FC3V, 8]])


class FCVBR0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR0'

    def __init__(self):
        super(FCVBR0, self).__init__([[FC4V, 7], [FC4V, 6], [FC4V, 5], [FC4V, 4], [FC4V, 3], [FC4V, 2], [FC4V, 1], [FC4V, 0]])


class FCVBR1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR1'

    def __init__(self):
        super(FCVBR1, self).__init__([[FC4V, 15], [FC4V, 14], [FC4V, 13], [FC4V, 12], [FC4V, 11], [FC4V, 10], [FC4V, 9], [FC4V, 8]])


class FCVBR2(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR2'

    def __init__(self):
        super(FCVBR2, self).__init__([[FC5V, 7], [FC5V, 6], [FC5V, 5], [FC5V, 4], [FC5V, 3], [FC5V, 2], [FC5V, 1], [FC5V, 0]])


class FCVBR3(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR3'

    def __init__(self):
        super(FCVBR3, self).__init__([[FC5V, 15], [FC5V, 14], [FC5V, 13], [FC5V, 12], [FC5V, 11], [FC5V, 10], [FC5V, 9], [FC5V, 8]])


class FCVBR4(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR4'

    def __init__(self):
        super(FCVBR4, self).__init__([[FC6V, 7], [FC6V, 6], [FC6V, 5], [FC6V, 4], [FC6V, 3], [FC6V, 2], [FC6V, 1], [FC6V, 0]])


class FCVBR5(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group B'
    NAME = 'FCVBR5'

    def __init__(self):
        super(FCVBR5, self).__init__([[FC6V, 15], [FC6V, 14], [FC6V, 13], [FC6V, 12], [FC6V, 11], [FC6V, 10], [FC6V, 9], [FC6V, 8]])


class FCVCR0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR0'

    def __init__(self):
        super(FCVCR0, self).__init__([[FC7V, 7], [FC7V, 6], [FC7V, 5], [FC7V, 4], [FC7V, 3], [FC7V, 2], [FC7V, 1], [FC7V, 0]])


class FCVCR1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR1'

    def __init__(self):
        super(FCVCR1, self).__init__([[FC7V, 15], [FC7V, 14], [FC7V, 13], [FC7V, 12], [FC7V, 11], [FC7V, 10], [FC7V, 9], [FC7V, 8]])


class FCVCR2(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR2'

    def __init__(self):
        super(FCVCR2, self).__init__([[FC8V, 7], [FC8V, 6], [FC8V, 5], [FC8V, 4], [FC8V, 3], [FC8V, 2], [FC8V, 1], [FC8V, 0]])


class FCVCR3(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR3'

    def __init__(self):
        super(FCVCR3, self).__init__([[FC8V, 15], [FC8V, 14], [FC8V, 13], [FC8V, 12], [FC8V, 11], [FC8V, 10], [FC8V, 9], [FC8V, 8]])


class FCVCR4(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR4'

    def __init__(self):
        super(FCVCR4, self).__init__([[FC9V, 7], [FC9V, 6], [FC9V, 5], [FC9V, 4], [FC9V, 3], [FC9V, 2], [FC9V, 1], [FC9V, 0]])


class FCVCR5(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group C'
    NAME = 'FCVCR5'

    def __init__(self):
        super(FCVCR5, self).__init__([[FC9V, 15], [FC9V, 14], [FC9V, 13], [FC9V, 12], [FC9V, 11], [FC9V, 10], [FC9V, 9], [FC9V, 8]])


class FCVDR0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR0'

    def __init__(self):
        super(FCVDR0, self).__init__([[FC10V, 7], [FC10V, 6], [FC10V, 5], [FC10V, 4], [FC10V, 3], [FC10V, 2], [FC10V, 1], [FC10V, 0]])


class FCVDR1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR1'

    def __init__(self):
        super(FCVDR1, self).__init__([[FC10V, 15], [FC10V, 14], [FC10V, 13], [FC10V, 12], [FC10V, 11], [FC10V, 10], [FC10V, 9], [FC10V, 8]])


class FCVDR2(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR2'

    def __init__(self):
        super(FCVDR2, self).__init__([[FC11V, 7], [FC11V, 6], [FC11V, 5], [FC11V, 4], [FC11V, 3], [FC11V, 2], [FC11V, 1], [FC11V, 0]])


class FCVDR3(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR3'

    def __init__(self):
        super(FCVDR3, self).__init__([[FC11V, 15], [FC11V, 14], [FC11V, 13], [FC11V, 12], [FC11V, 11], [FC11V, 10], [FC11V, 9], [FC11V, 8]])


class FCVDR4(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR4'

    def __init__(self):
        super(FCVDR4, self).__init__([[FC12V, 7], [FC12V, 6], [FC12V, 5], [FC12V, 4], [FC12V, 3], [FC12V, 2], [FC12V, 1], [FC12V, 0]])


class FCVDR5(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group D'
    NAME = 'FCVDR5'

    def __init__(self):
        super(FCVDR5, self).__init__([[FC12V, 15], [FC12V, 14], [FC12V, 13], [FC12V, 12], [FC12V, 11], [FC12V, 10], [FC12V, 9], [FC12V, 8]])


class FCVER0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER0'

    def __init__(self):
        super(FCVER0, self).__init__([[FC13V, 7], [FC13V, 6], [FC13V, 5], [FC13V, 4], [FC13V, 3], [FC13V, 2], [FC13V, 1], [FC13V, 0]])


class FCVER1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER1'

    def __init__(self):
        super(FCVER1, self).__init__([[FC13V, 15], [FC13V, 14], [FC13V, 13], [FC13V, 12], [FC13V, 11], [FC13V, 10], [FC13V, 9], [FC13V, 8]])


class FCVER2(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER2'

    def __init__(self):
        super(FCVER2, self).__init__([[FC14V, 7], [FC14V, 6], [FC14V, 5], [FC14V, 4], [FC14V, 3], [FC14V, 2], [FC14V, 1], [FC14V, 0]])


class FCVER3(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER3'

    def __init__(self):
        super(FCVER3, self).__init__([[FC14V, 15], [FC14V, 14], [FC14V, 13], [FC14V, 12], [FC14V, 11], [FC14V, 10], [FC14V, 9], [FC14V, 8]])


class FCVER4(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER4'

    def __init__(self):
        super(FCVER4, self).__init__([[FC15V, 7], [FC15V, 6], [FC15V, 5], [FC15V, 4], [FC15V, 3], [FC15V, 2], [FC15V, 1], [FC15V, 0]])


class FCVER5(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group E'
    NAME = 'FCVER5'

    def __init__(self):
        super(FCVER5, self).__init__([[FC15V, 15], [FC15V, 14], [FC15V, 13], [FC15V, 12], [FC15V, 11], [FC15V, 10], [FC15V, 9], [FC15V, 8]])


class FCVFR0(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR0'

    def __init__(self):
        super(FCVFR0, self).__init__([[FC16V, 7], [FC16V, 6], [FC16V, 5], [FC16V, 4], [FC16V, 3], [FC16V, 2], [FC16V, 1], [FC16V, 0]])


class FCVFR1(bmsbase.Register):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR1'

    def __init__(self):
        super(FCVFR1, self).__init__([[FC16V, 15], [FC16V, 14], [FC16V, 13], [FC16V, 12], [FC16V, 11], [FC16V, 10], [FC16V, 9], [FC16V, 8]])


class FCVFR2(bmsbase.RSVDR2):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR2'

    def __init__(self):
        super(FCVFR2, self).__init__()


class FCVFR3(bmsbase.RSVDR3):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR3'

    def __init__(self):
        super(FCVFR3, self).__init__()


class FCVFR4(bmsbase.RSVDR4):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR4'

    def __init__(self):
        super(FCVFR4, self).__init__()


class FCVFR5(bmsbase.RSVDR5):
    MEM_KEY = 'Filtered Cell Voltage Register Group F'
    NAME = 'FCVFR5'

    def __init__(self):
        super(FCVFR5, self).__init__()


class SVAR0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR0'

    def __init__(self):
        super(SVAR0, self).__init__([[S1V, 7], [S1V, 6], [S1V, 5], [S1V, 4], [S1V, 3], [S1V, 2], [S1V, 1], [S1V, 0]])


class SVAR1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR1'

    def __init__(self):
        super(SVAR1, self).__init__([[S1V, 15], [S1V, 14], [S1V, 13], [S1V, 12], [S1V, 11], [S1V, 10], [S1V, 9], [S1V, 8]])


class SVAR2(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR2'

    def __init__(self):
        super(SVAR2, self).__init__([[S2V, 7], [S2V, 6], [S2V, 5], [S2V, 4], [S2V, 3], [S2V, 2], [S2V, 1], [S2V, 0]])


class SVAR3(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR3'

    def __init__(self):
        super(SVAR3, self).__init__([[S2V, 15], [S2V, 14], [S2V, 13], [S2V, 12], [S2V, 11], [S2V, 10], [S2V, 9], [S2V, 8]])


class SVAR4(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR4'

    def __init__(self):
        super(SVAR4, self).__init__([[S3V, 7], [S3V, 6], [S3V, 5], [S3V, 4], [S3V, 3], [S3V, 2], [S3V, 1], [S3V, 0]])


class SVAR5(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group A'
    NAME = 'SVAR5'

    def __init__(self):
        super(SVAR5, self).__init__([[S3V, 15], [S3V, 14], [S3V, 13], [S3V, 12], [S3V, 11], [S3V, 10], [S3V, 9], [S3V, 8]])


class SVBR0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR0'

    def __init__(self):
        super(SVBR0, self).__init__([[S4V, 7], [S4V, 6], [S4V, 5], [S4V, 4], [S4V, 3], [S4V, 2], [S4V, 1], [S4V, 0]])


class SVBR1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR1'

    def __init__(self):
        super(SVBR1, self).__init__([[S4V, 15], [S4V, 14], [S4V, 13], [S4V, 12], [S4V, 11], [S4V, 10], [S4V, 9], [S4V, 8]])


class SVBR2(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR2'

    def __init__(self):
        super(SVBR2, self).__init__([[S5V, 7], [S5V, 6], [S5V, 5], [S5V, 4], [S5V, 3], [S5V, 2], [S5V, 1], [S5V, 0]])


class SVBR3(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR3'

    def __init__(self):
        super(SVBR3, self).__init__([[S5V, 15], [S5V, 14], [S5V, 13], [S5V, 12], [S5V, 11], [S5V, 10], [S5V, 9], [S5V, 8]])


class SVBR4(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR4'

    def __init__(self):
        super(SVBR4, self).__init__([[S6V, 7], [S6V, 6], [S6V, 5], [S6V, 4], [S6V, 3], [S6V, 2], [S6V, 1], [S6V, 0]])


class SVBR5(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group B'
    NAME = 'SVBR5'

    def __init__(self):
        super(SVBR5, self).__init__([[S6V, 15], [S6V, 14], [S6V, 13], [S6V, 12], [S6V, 11], [S6V, 10], [S6V, 9], [S6V, 8]])


class SVCR0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR0'

    def __init__(self):
        super(SVCR0, self).__init__([[S7V, 7], [S7V, 6], [S7V, 5], [S7V, 4], [S7V, 3], [S7V, 2], [S7V, 1], [S7V, 0]])


class SVCR1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR1'

    def __init__(self):
        super(SVCR1, self).__init__([[S7V, 15], [S7V, 14], [S7V, 13], [S7V, 12], [S7V, 11], [S7V, 10], [S7V, 9], [S7V, 8]])


class SVCR2(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR2'

    def __init__(self):
        super(SVCR2, self).__init__([[S8V, 7], [S8V, 6], [S8V, 5], [S8V, 4], [S8V, 3], [S8V, 2], [S8V, 1], [S8V, 0]])


class SVCR3(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR3'

    def __init__(self):
        super(SVCR3, self).__init__([[S8V, 15], [S8V, 14], [S8V, 13], [S8V, 12], [S8V, 11], [S8V, 10], [S8V, 9], [S8V, 8]])


class SVCR4(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR4'

    def __init__(self):
        super(SVCR4, self).__init__([[S9V, 7], [S9V, 6], [S9V, 5], [S9V, 4], [S9V, 3], [S9V, 2], [S9V, 1], [S9V, 0]])


class SVCR5(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group C'
    NAME = 'SVCR5'

    def __init__(self):
        super(SVCR5, self).__init__([[S9V, 15], [S9V, 14], [S9V, 13], [S9V, 12], [S9V, 11], [S9V, 10], [S9V, 9], [S9V, 8]])


class SVDR0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR0'

    def __init__(self):
        super(SVDR0, self).__init__([[S10V, 7], [S10V, 6], [S10V, 5], [S10V, 4], [S10V, 3], [S10V, 2], [S10V, 1], [S10V, 0]])


class SVDR1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR1'

    def __init__(self):
        super(SVDR1, self).__init__([[S10V, 15], [S10V, 14], [S10V, 13], [S10V, 12], [S10V, 11], [S10V, 10], [S10V, 9], [S10V, 8]])


class SVDR2(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR2'

    def __init__(self):
        super(SVDR2, self).__init__([[S11V, 7], [S11V, 6], [S11V, 5], [S11V, 4], [S11V, 3], [S11V, 2], [S11V, 1], [S11V, 0]])


class SVDR3(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR3'

    def __init__(self):
        super(SVDR3, self).__init__([[S11V, 15], [S11V, 14], [S11V, 13], [S11V, 12], [S11V, 11], [S11V, 10], [S11V, 9], [S11V, 8]])


class SVDR4(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR4'

    def __init__(self):
        super(SVDR4, self).__init__([[S12V, 7], [S12V, 6], [S12V, 5], [S12V, 4], [S12V, 3], [S12V, 2], [S12V, 1], [S12V, 0]])


class SVDR5(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group D'
    NAME = 'SVDR5'

    def __init__(self):
        super(SVDR5, self).__init__([[S12V, 15], [S12V, 14], [S12V, 13], [S12V, 12], [S12V, 11], [S12V, 10], [S12V, 9], [S12V, 8]])


class SVER0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER0'

    def __init__(self):
        super(SVER0, self).__init__([[S13V, 7], [S13V, 6], [S13V, 5], [S13V, 4], [S13V, 3], [S13V, 2], [S13V, 1], [S13V, 0]])


class SVER1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER1'

    def __init__(self):
        super(SVER1, self).__init__([[S13V, 15], [S13V, 14], [S13V, 13], [S13V, 12], [S13V, 11], [S13V, 10], [S13V, 9], [S13V, 8]])


class SVER2(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER2'

    def __init__(self):
        super(SVER2, self).__init__([[S14V, 7], [S14V, 6], [S14V, 5], [S14V, 4], [S14V, 3], [S14V, 2], [S14V, 1], [S14V, 0]])


class SVER3(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER3'

    def __init__(self):
        super(SVER3, self).__init__([[S14V, 15], [S14V, 14], [S14V, 13], [S14V, 12], [S14V, 11], [S14V, 10], [S14V, 9], [S14V, 8]])


class SVER4(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER4'

    def __init__(self):
        super(SVER4, self).__init__([[S15V, 7], [S15V, 6], [S15V, 5], [S15V, 4], [S15V, 3], [S15V, 2], [S15V, 1], [S15V, 0]])


class SVER5(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group E'
    NAME = 'SVER5'

    def __init__(self):
        super(SVER5, self).__init__([[S15V, 15], [S15V, 14], [S15V, 13], [S15V, 12], [S15V, 11], [S15V, 10], [S15V, 9], [S15V, 8]])


class SVFR0(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR0'

    def __init__(self):
        super(SVFR0, self).__init__([[S16V, 7], [S16V, 6], [S16V, 5], [S16V, 4], [S16V, 3], [S16V, 2], [S16V, 1], [S16V, 0]])


class SVFR1(bmsbase.Register):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR1'

    def __init__(self):
        super(SVFR1, self).__init__([[S16V, 15], [S16V, 14], [S16V, 13], [S16V, 12], [S16V, 11], [S16V, 10], [S16V, 9], [S16V, 8]])


class SVFR2(bmsbase.RSVDR2):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR2'

    def __init__(self):
        super(SVFR2, self).__init__()


class SVFR3(bmsbase.RSVDR3):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR3'

    def __init__(self):
        super(SVFR3, self).__init__()


class SVFR4(bmsbase.RSVDR4):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR4'

    def __init__(self):
        super(SVFR4, self).__init__()


class SVFR5(bmsbase.RSVDR5):
    MEM_KEY = 'S-Pin Voltage Register Group F'
    NAME = 'SVFR5'

    def __init__(self):
        super(SVFR5, self).__init__()


class GPAR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR0'

    def __init__(self):
        super(GPAR0, self).__init__([[G1V, 7], [G1V, 6], [G1V, 5], [G1V, 4], [G1V, 3], [G1V, 2], [G1V, 1], [G1V, 0]])


class GPAR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR1'

    def __init__(self):
        super(GPAR1, self).__init__([[G1V, 15], [G1V, 14], [G1V, 13], [G1V, 12], [G1V, 11], [G1V, 10], [G1V, 9], [G1V, 8]])


class GPAR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR2'

    def __init__(self):
        super(GPAR2, self).__init__([[G2V, 7], [G2V, 6], [G2V, 5], [G2V, 4], [G2V, 3], [G2V, 2], [G2V, 1], [G2V, 0]])


class GPAR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR3'

    def __init__(self):
        super(GPAR3, self).__init__([[G2V, 15], [G2V, 14], [G2V, 13], [G2V, 12], [G2V, 11], [G2V, 10], [G2V, 9], [G2V, 8]])


class GPAR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR4'

    def __init__(self):
        super(GPAR4, self).__init__([[G3V, 7], [G3V, 6], [G3V, 5], [G3V, 4], [G3V, 3], [G3V, 2], [G3V, 1], [G3V, 0]])


class GPAR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group A'
    NAME = 'GPAR5'

    def __init__(self):
        super(GPAR5, self).__init__([[G3V, 15], [G3V, 14], [G3V, 13], [G3V, 12], [G3V, 11], [G3V, 10], [G3V, 9], [G3V, 8]])


class GPBR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR0'

    def __init__(self):
        super(GPBR0, self).__init__([[G4V, 7], [G4V, 6], [G4V, 5], [G4V, 4], [G4V, 3], [G4V, 2], [G4V, 1], [G4V, 0]])


class GPBR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR1'

    def __init__(self):
        super(GPBR1, self).__init__([[G4V, 15], [G4V, 14], [G4V, 13], [G4V, 12], [G4V, 11], [G4V, 10], [G4V, 9], [G4V, 8]])


class GPBR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR2'

    def __init__(self):
        super(GPBR2, self).__init__([[G5V, 7], [G5V, 6], [G5V, 5], [G5V, 4], [G5V, 3], [G5V, 2], [G5V, 1], [G5V, 0]])


class GPBR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR3'

    def __init__(self):
        super(GPBR3, self).__init__([[G5V, 15], [G5V, 14], [G5V, 13], [G5V, 12], [G5V, 11], [G5V, 10], [G5V, 9], [G5V, 8]])


class GPBR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR4'

    def __init__(self):
        super(GPBR4, self).__init__([[G6V, 7], [G6V, 6], [G6V, 5], [G6V, 4], [G6V, 3], [G6V, 2], [G6V, 1], [G6V, 0]])


class GPBR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group B'
    NAME = 'GPBR5'

    def __init__(self):
        super(GPBR5, self).__init__([[G6V, 15], [G6V, 14], [G6V, 13], [G6V, 12], [G6V, 11], [G6V, 10], [G6V, 9], [G6V, 8]])


class GPCR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR0'

    def __init__(self):
        super(GPCR0, self).__init__([[G7V, 7], [G7V, 6], [G7V, 5], [G7V, 4], [G7V, 3], [G7V, 2], [G7V, 1], [G7V, 0]])


class GPCR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR1'

    def __init__(self):
        super(GPCR1, self).__init__([[G7V, 15], [G7V, 14], [G7V, 13], [G7V, 12], [G7V, 11], [G7V, 10], [G7V, 9], [G7V, 8]])


class GPCR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR2'

    def __init__(self):
        super(GPCR2, self).__init__([[G8V, 7], [G8V, 6], [G8V, 5], [G8V, 4], [G8V, 3], [G8V, 2], [G8V, 1], [G8V, 0]])


class GPCR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR3'

    def __init__(self):
        super(GPCR3, self).__init__([[G8V, 15], [G8V, 14], [G8V, 13], [G8V, 12], [G8V, 11], [G8V, 10], [G8V, 9], [G8V, 8]])


class GPCR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR4'

    def __init__(self):
        super(GPCR4, self).__init__([[G9V, 7], [G9V, 6], [G9V, 5], [G9V, 4], [G9V, 3], [G9V, 2], [G9V, 1], [G9V, 0]])


class GPCR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group C'
    NAME = 'GPCR5'

    def __init__(self):
        super(GPCR5, self).__init__([[G9V, 15], [G9V, 14], [G9V, 13], [G9V, 12], [G9V, 11], [G9V, 10], [G9V, 9], [G9V, 8]])


class GPDR0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR0'

    def __init__(self):
        super(GPDR0, self).__init__([[G10V, 7], [G10V, 6], [G10V, 5], [G10V, 4], [G10V, 3], [G10V, 2], [G10V, 1], [G10V, 0]])


class GPDR1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR1'

    def __init__(self):
        super(GPDR1, self).__init__([[G10V, 15], [G10V, 14], [G10V, 13], [G10V, 12], [G10V, 11], [G10V, 10], [G10V, 9], [G10V, 8]])


class GPDR2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR2'

    def __init__(self):
        super(GPDR2, self).__init__([[VMV, 7], [VMV, 6], [VMV, 5], [VMV, 4], [VMV, 3], [VMV, 2], [VMV, 1], [VMV, 0]])


class GPDR3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR3'

    def __init__(self):
        super(GPDR3, self).__init__([[VMV, 15], [VMV, 14], [VMV, 13], [VMV, 12], [VMV, 11], [VMV, 10], [VMV, 9], [VMV, 8]])


class GPDR4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR4'

    def __init__(self):
        super(GPDR4, self).__init__([[VPV, 7], [VPV, 6], [VPV, 5], [VPV, 4], [VPV, 3], [VPV, 2], [VPV, 1], [VPV, 0]])


class GPDR5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group D'
    NAME = 'GPDR5'

    def __init__(self):
        super(GPDR5, self).__init__([[VPV, 15], [VPV, 14], [VPV, 13], [VPV, 12], [VPV, 11], [VPV, 10], [VPV, 9], [VPV, 8]])


class GPER0(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER0'

    def __init__(self):
        super(GPER0, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class GPER1(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER1'

    def __init__(self):
        super(GPER1, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class GPER2(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER2'

    def __init__(self):
        super(GPER2, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class GPER3(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER3'

    def __init__(self):
        super(GPER3, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class GPER4(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER4'

    def __init__(self):
        super(GPER4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class GPER5(bmsbase.Register):
    MEM_KEY = 'Auxiliary Register Group E'
    NAME = 'GPER5'

    def __init__(self):
        super(GPER5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class RGPAR0(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR0'

    def __init__(self):
        super(RGPAR0, self).__init__([[R_G1V, 7], [R_G1V, 6], [R_G1V, 5], [R_G1V, 4], [R_G1V, 3], [R_G1V, 2], [R_G1V, 1], [R_G1V, 0]])


class RGPAR1(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR1'

    def __init__(self):
        super(RGPAR1, self).__init__([[R_G1V, 15], [R_G1V, 14], [R_G1V, 13], [R_G1V, 12], [R_G1V, 11], [R_G1V, 10], [R_G1V, 9], [R_G1V, 8]])


class RGPAR2(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR2'

    def __init__(self):
        super(RGPAR2, self).__init__([[R_G2V, 7], [R_G2V, 6], [R_G2V, 5], [R_G2V, 4], [R_G2V, 3], [R_G2V, 2], [R_G2V, 1], [R_G2V, 0]])


class RGPAR3(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR3'

    def __init__(self):
        super(RGPAR3, self).__init__([[R_G2V, 15], [R_G2V, 14], [R_G2V, 13], [R_G2V, 12], [R_G2V, 11], [R_G2V, 10], [R_G2V, 9], [R_G2V, 8]])


class RGPAR4(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR4'

    def __init__(self):
        super(RGPAR4, self).__init__([[R_G3V, 7], [R_G3V, 6], [R_G3V, 5], [R_G3V, 4], [R_G3V, 3], [R_G3V, 2], [R_G3V, 1], [R_G3V, 0]])


class RGPAR5(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group A'
    NAME = 'RGPAR5'

    def __init__(self):
        super(RGPAR5, self).__init__([[R_G3V, 15], [R_G3V, 14], [R_G3V, 13], [R_G3V, 12], [R_G3V, 11], [R_G3V, 10], [R_G3V, 9], [R_G3V, 8]])


class RGPBR0(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR0'

    def __init__(self):
        super(RGPBR0, self).__init__([[R_G4V, 7], [R_G4V, 6], [R_G4V, 5], [R_G4V, 4], [R_G4V, 3], [R_G4V, 2], [R_G4V, 1], [R_G4V, 0]])


class RGPBR1(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR1'

    def __init__(self):
        super(RGPBR1, self).__init__([[R_G4V, 15], [R_G4V, 14], [R_G4V, 13], [R_G4V, 12], [R_G4V, 11], [R_G4V, 10], [R_G4V, 9], [R_G4V, 8]])


class RGPBR2(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR2'

    def __init__(self):
        super(RGPBR2, self).__init__([[R_G5V, 7], [R_G5V, 6], [R_G5V, 5], [R_G5V, 4], [R_G5V, 3], [R_G5V, 2], [R_G5V, 1], [R_G5V, 0]])


class RGPBR3(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR3'

    def __init__(self):
        super(RGPBR3, self).__init__([[R_G5V, 15], [R_G5V, 14], [R_G5V, 13], [R_G5V, 12], [R_G5V, 11], [R_G5V, 10], [R_G5V, 9], [R_G5V, 8]])


class RGPBR4(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR4'

    def __init__(self):
        super(RGPBR4, self).__init__([[R_G6V, 7], [R_G6V, 6], [R_G6V, 5], [R_G6V, 4], [R_G6V, 3], [R_G6V, 2], [R_G6V, 1], [R_G6V, 0]])


class RGPBR5(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group B'
    NAME = 'RGPBR5'

    def __init__(self):
        super(RGPBR5, self).__init__([[R_G6V, 15], [R_G6V, 14], [R_G6V, 13], [R_G6V, 12], [R_G6V, 11], [R_G6V, 10], [R_G6V, 9], [R_G6V, 8]])


class RGPCR0(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR0'

    def __init__(self):
        super(RGPCR0, self).__init__([[R_G7V, 7], [R_G7V, 6], [R_G7V, 5], [R_G7V, 4], [R_G7V, 3], [R_G7V, 2], [R_G7V, 1], [R_G7V, 0]])


class RGPCR1(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR1'

    def __init__(self):
        super(RGPCR1, self).__init__([[R_G7V, 15], [R_G7V, 14], [R_G7V, 13], [R_G7V, 12], [R_G7V, 11], [R_G7V, 10], [R_G7V, 9], [R_G7V, 8]])


class RGPCR2(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR2'

    def __init__(self):
        super(RGPCR2, self).__init__([[R_G8V, 7], [R_G8V, 6], [R_G8V, 5], [R_G8V, 4], [R_G8V, 3], [R_G8V, 2], [R_G8V, 1], [R_G8V, 0]])


class RGPCR3(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR3'

    def __init__(self):
        super(RGPCR3, self).__init__([[R_G8V, 15], [R_G8V, 14], [R_G8V, 13], [R_G8V, 12], [R_G8V, 11], [R_G8V, 10], [R_G8V, 9], [R_G8V, 8]])


class RGPCR4(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR4'

    def __init__(self):
        super(RGPCR4, self).__init__([[R_G9V, 7], [R_G9V, 6], [R_G9V, 5], [R_G9V, 4], [R_G9V, 3], [R_G9V, 2], [R_G9V, 1], [R_G9V, 0]])


class RGPCR5(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group C'
    NAME = 'RGPCR5'

    def __init__(self):
        super(RGPCR5, self).__init__([[R_G9V, 15], [R_G9V, 14], [R_G9V, 13], [R_G9V, 12], [R_G9V, 11], [R_G9V, 10], [R_G9V, 9], [R_G9V, 8]])


class RGPDR0(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR0'

    def __init__(self):
        super(RGPDR0, self).__init__([[R_G10V, 7], [R_G10V, 6], [R_G10V, 5], [R_G10V, 4], [R_G10V, 3], [R_G10V, 2], [R_G10V, 1], [R_G10V, 0]])


class RGPDR1(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR1'

    def __init__(self):
        super(RGPDR1, self).__init__([[R_G10V, 15], [R_G10V, 14], [R_G10V, 13], [R_G10V, 12], [R_G10V, 11], [R_G10V, 10], [R_G10V, 9], [R_G10V, 8]])


class RGPDR2(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR2'

    def __init__(self):
        super(RGPDR2, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class RGPDR3(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR3'

    def __init__(self):
        super(RGPDR3, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class RGPDR4(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR4'

    def __init__(self):
        super(RGPDR4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class RGPDR5(bmsbase.Register):
    MEM_KEY = 'Redundant Auxiliary Register Group D'
    NAME = 'RGPDR5'

    def __init__(self):
        super(RGPDR5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STAR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR0'

    def __init__(self):
        super(STAR0, self).__init__([[VREF2, 7], [VREF2, 6], [VREF2, 5], [VREF2, 4], [VREF2, 3], [VREF2, 2], [VREF2, 1], [VREF2, 0]])


class STAR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR1'

    def __init__(self):
        super(STAR1, self).__init__([[VREF2, 15], [VREF2, 14], [VREF2, 13], [VREF2, 12], [VREF2, 11], [VREF2, 10], [VREF2, 9], [VREF2, 8]])


class STAR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR2'

    def __init__(self):
        super(STAR2, self).__init__([[ITMP, 7], [ITMP, 6], [ITMP, 5], [ITMP, 4], [ITMP, 3], [ITMP, 2], [ITMP, 1], [ITMP, 0]])


class STAR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR3'

    def __init__(self):
        super(STAR3, self).__init__([[ITMP, 15], [ITMP, 14], [ITMP, 13], [ITMP, 12], [ITMP, 11], [ITMP, 10], [ITMP, 9], [ITMP, 8]])


class STAR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR4'

    def __init__(self):
        super(STAR4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STAR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group A'
    NAME = 'STAR5'

    def __init__(self):
        super(STAR5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STBR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR0'

    def __init__(self):
        super(STBR0, self).__init__([[VD, 7], [VD, 6], [VD, 5], [VD, 4], [VD, 3], [VD, 2], [VD, 1], [VD, 0]])


class STBR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR1'

    def __init__(self):
        super(STBR1, self).__init__([[VD, 15], [VD, 14], [VD, 13], [VD, 12], [VD, 11], [VD, 10], [VD, 9], [VD, 8]])


class STBR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR2'

    def __init__(self):
        super(STBR2, self).__init__([[VA, 7], [VA, 6], [VA, 5], [VA, 4], [VA, 3], [VA, 2], [VA, 1], [VA, 0]])


class STBR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR3'

    def __init__(self):
        super(STBR3, self).__init__([[VA, 15], [VA, 14], [VA, 13], [VA, 12], [VA, 11], [VA, 10], [VA, 9], [VA, 8]])


class STBR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR4'

    def __init__(self):
        super(STBR4, self).__init__([[VRES, 7], [VRES, 6], [VRES, 5], [VRES, 4], [VRES, 3], [VRES, 2], [VRES, 1], [VRES, 0]])


class STBR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group B'
    NAME = 'STBR5'

    def __init__(self):
        super(STBR5, self).__init__([[VRES, 15], [VRES, 14], [VRES, 13], [VRES, 12], [VRES, 11], [VRES, 10], [VRES, 9], [VRES, 8]])


class STCR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR0'

    def __init__(self):
        super(STCR0, self).__init__([[CS8FLT, 0], [CS7FLT, 0], [CS6FLT, 0], [CS5FLT, 0], [CS4FLT, 0], [CS3FLT, 0], [CS2FLT, 0], [CS1FLT, 0]])


class STCR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR1'

    def __init__(self):
        super(STCR1, self).__init__([[CS16FLT, 0], [CS15FLT, 0], [CS14FLT, 0], [CS13FLT, 0], [CS12FLT, 0], [CS11FLT, 0], [CS10FLT, 0], [CS9FLT, 0]])


class STCR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR2'

    def __init__(self):
        super(STCR2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CT, 10], [CT, 9], [CT, 8], [CT, 7], [CT, 6]])


class STCR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR3'

    def __init__(self):
        super(STCR3, self).__init__([[CT, 5], [CT, 4], [CT, 3], [CT, 2], [CT, 1], [CT, 0], [CTS, 1], [CTS, 0]])


class STCR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR4'

    def __init__(self):
        super(STCR4, self).__init__([[VA_OV, 0], [VA_UV, 0], [VD_OV, 0], [VD_UV, 0], [CED, 0], [CMED, 0], [SED, 0], [SMED, 0]])


class STCR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group C'
    NAME = 'STCR5'

    def __init__(self):
        super(STCR5, self).__init__([[VDEL, 0], [VDE, 0], [COMP, 0], [SPIFLT, 0], [SLEEP, 0], [THSD, 0], [TMODCHK, 0], [OSCCHK, 0]])


class STDR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR0'

    def __init__(self):
        super(STDR0, self).__init__([[C4OV, 0], [C4UV, 0], [C3OV, 0], [C3UV, 0], [C2OV, 0], [C2UV, 0], [C1OV, 0], [C1UV, 0]])


class STDR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR1'

    def __init__(self):
        super(STDR1, self).__init__([[C8OV, 0], [C8UV, 0], [C7OV, 0], [C7UV, 0], [C6OV, 0], [C6UV, 0], [C5OV, 0], [C5UV, 0]])


class STDR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR2'

    def __init__(self):
        super(STDR2, self).__init__([[C12OV, 0], [C12UV, 0], [C11OV, 0], [C11UV, 0], [C10OV, 0], [C10UV, 0], [C9OV, 0], [C9UV, 0]])


class STDR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR3'

    def __init__(self):
        super(STDR3, self).__init__([[C16OV, 0], [C16UV, 0], [C15OV, 0], [C15UV, 0], [C14OV, 0], [C14UV, 0], [C13OV, 0], [C13UV, 0]])


class STDR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR4'

    def __init__(self):
        super(STDR4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STDR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'STDR5'

    def __init__(self):
        super(STDR5, self).__init__([[OC_CNTR, 7], [OC_CNTR, 6], [OC_CNTR, 5], [OC_CNTR, 4], [OC_CNTR, 3], [OC_CNTR, 2], [OC_CNTR, 1], [OC_CNTR, 0]])


class STER0(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER0'

    def __init__(self):
        super(STER0, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STER1(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER1'

    def __init__(self):
        super(STER1, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STER2(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER2'

    def __init__(self):
        super(STER2, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STER3(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER3'

    def __init__(self):
        super(STER3, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class STER4(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER4'

    def __init__(self):
        super(STER4, self).__init__([[GPI8, 0], [GPI7, 0], [GPI6, 0], [GPI5, 0], [GPI4, 0], [GPI3, 0], [GPI2, 0], [GPI1, 0]])


class STER5(bmsbase.Register):
    MEM_KEY = 'Status Register Group E'
    NAME = 'STER5'

    def __init__(self):
        super(STER5, self).__init__([[REV, 3], [REV, 2], [REV, 1], [REV, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [GPI10, 0], [GPI9, 0]])


class CL_STDR0(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR0'

    def __init__(self):
        super(CL_STDR0, self).__init__([[CL_C4OV, 0], [CL_C4UV, 0], [CL_C3OV, 0], [CL_C3UV, 0], [CL_C2OV, 0], [CL_C2UV, 0], [CL_C1OV, 0], [CL_C1UV, 0]])


class CL_STDR1(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR1'

    def __init__(self):
        super(CL_STDR1, self).__init__([[CL_C8OV, 0], [CL_C8UV, 0], [CL_C7OV, 0], [CL_C7UV, 0], [CL_C6OV, 0], [CL_C6UV, 0], [CL_C5OV, 0], [CL_C5UV, 0]])


class CL_STDR2(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR2'

    def __init__(self):
        super(CL_STDR2, self).__init__([[CL_C12OV, 0], [CL_C12UV, 0], [CL_C11OV, 0], [CL_C11UV, 0], [CL_C10OV, 0], [CL_C10UV, 0], [CL_C9OV, 0], [CL_C9UV, 0]])


class CL_STDR3(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR3'

    def __init__(self):
        super(CL_STDR3, self).__init__([[CL_C16OV, 0], [CL_C16UV, 0], [CL_C15OV, 0], [CL_C15UV, 0], [CL_C14OV, 0], [CL_C14UV, 0], [CL_C13OV, 0], [CL_C13UV, 0]])


class CL_STDR4(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR4'

    def __init__(self):
        super(CL_STDR4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class CL_STDR5(bmsbase.Register):
    MEM_KEY = 'Status Register Group D'
    NAME = 'CL_STDR5'

    def __init__(self):
        super(CL_STDR5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class COMM0(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM0'

    def __init__(self):
        super(COMM0, self).__init__([[ICOM0, 3], [ICOM0, 2], [ICOM0, 1], [ICOM0, 0], [FCOM0, 3], [FCOM0, 2], [FCOM0, 1], [FCOM0, 0]])


class COMM1(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM1'

    def __init__(self):
        super(COMM1, self).__init__([[D0, 7], [D0, 6], [D0, 5], [D0, 4], [D0, 3], [D0, 2], [D0, 1], [D0, 0]])


class COMM2(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM2'

    def __init__(self):
        super(COMM2, self).__init__([[ICOM1, 3], [ICOM1, 2], [ICOM1, 1], [ICOM1, 0], [FCOM1, 3], [FCOM1, 2], [FCOM1, 1], [FCOM1, 0]])


class COMM3(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM3'

    def __init__(self):
        super(COMM3, self).__init__([[D1, 7], [D1, 6], [D1, 5], [D1, 4], [D1, 3], [D1, 2], [D1, 1], [D1, 0]])


class COMM4(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM4'

    def __init__(self):
        super(COMM4, self).__init__([[ICOM2, 3], [ICOM2, 2], [ICOM2, 1], [ICOM2, 0], [FCOM2, 3], [FCOM2, 2], [FCOM2, 1], [FCOM2, 0]])


class COMM5(bmsbase.Register):
    MEM_KEY = 'COMM Register Group'
    NAME = 'COMM5'

    def __init__(self):
        super(COMM5, self).__init__([[D2, 7], [D2, 6], [D2, 5], [D2, 4], [D2, 3], [D2, 2], [D2, 1], [D2, 0]])


class PWMR0(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR0'

    def __init__(self):
        super(PWMR0, self).__init__([[PWM2, 3], [PWM2, 2], [PWM2, 1], [PWM2, 0], [PWM1, 3], [PWM1, 2], [PWM1, 1], [PWM1, 0]])


class PWMR1(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR1'

    def __init__(self):
        super(PWMR1, self).__init__([[PWM4, 3], [PWM4, 2], [PWM4, 1], [PWM4, 0], [PWM3, 3], [PWM3, 2], [PWM3, 1], [PWM3, 0]])


class PWMR2(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR2'

    def __init__(self):
        super(PWMR2, self).__init__([[PWM6, 3], [PWM6, 2], [PWM6, 1], [PWM6, 0], [PWM5, 3], [PWM5, 2], [PWM5, 1], [PWM5, 0]])


class PWMR3(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR3'

    def __init__(self):
        super(PWMR3, self).__init__([[PWM8, 3], [PWM8, 2], [PWM8, 1], [PWM8, 0], [PWM7, 3], [PWM7, 2], [PWM7, 1], [PWM7, 0]])


class PWMR4(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR4'

    def __init__(self):
        super(PWMR4, self).__init__([[PWM10, 3], [PWM10, 2], [PWM10, 1], [PWM10, 0], [PWM9, 3], [PWM9, 2], [PWM9, 1], [PWM9, 0]])


class PWMR5(bmsbase.Register):
    MEM_KEY = 'PWM Register Group A'
    NAME = 'PWMR5'

    def __init__(self):
        super(PWMR5, self).__init__([[PWM12, 3], [PWM12, 2], [PWM12, 1], [PWM12, 0], [PWM11, 3], [PWM11, 2], [PWM11, 1], [PWM11, 0]])


class PSR0(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR0'

    def __init__(self):
        super(PSR0, self).__init__([[PWM14, 3], [PWM14, 2], [PWM14, 1], [PWM14, 0], [PWM13, 3], [PWM13, 2], [PWM13, 1], [PWM13, 0]])


class PSR1(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR1'

    def __init__(self):
        super(PSR1, self).__init__([[PWM16, 3], [PWM16, 2], [PWM16, 1], [PWM16, 0], [PWM15, 3], [PWM15, 2], [PWM15, 1], [PWM15, 0]])


class PSR2(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR2'

    def __init__(self):
        super(PSR2, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class PSR3(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR3'

    def __init__(self):
        super(PSR3, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class PSR4(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR4'

    def __init__(self):
        super(PSR4, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class PSR5(bmsbase.Register):
    MEM_KEY = 'PWM Register Group B'
    NAME = 'PSR5'

    def __init__(self):
        super(PSR5, self).__init__([[bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0], [bmsbase.RSVD1, 0]])


class CFD0(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD0'

    def __init__(self):
        super(CFD0, self).__init__([[CL_CS8FLT, 0], [CL_CS7FLT, 0], [CL_CS6FLT, 0], [CL_CS5FLT, 0], [CL_CS4FLT, 0], [CL_CS3FLT, 0], [CL_CS2FLT, 0], [CL_CS1FLT, 0]])


class CFD1(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD1'

    def __init__(self):
        super(CFD1, self).__init__([[CL_CS16FLT, 0], [CL_CS15FLT, 0], [CL_CS14FLT, 0], [CL_CS13FLT, 0], [CL_CS12FLT, 0], [CL_CS11FLT, 0], [CL_CS10FLT, 0], [CL_CS9FLT, 0]])


class CFD2(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD2'

    def __init__(self):
        super(CFD2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFD3(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD3'

    def __init__(self):
        super(CFD3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CFD4(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD4'

    def __init__(self):
        super(CFD4, self).__init__([[CL_VA_OV, 0], [CL_VA_UV, 0], [CL_VD_OV, 0], [CL_VD_UV, 0], [CL_CED, 0], [CL_CMED, 0], [CL_SED, 0], [CL_SMED, 0]])


class CFD5(bmsbase.Register):
    MEM_KEY = 'Clear Flag Register Group'
    NAME = 'CFD5'

    def __init__(self):
        super(CFD5, self).__init__([[CL_VDEL, 0], [CL_VDE, 0], [bmsbase.RSVD0, 0], [CL_SPIFLT, 0], [CL_SLEEP, 0], [CL_THSD, 0], [CL_TMODCHK, 0], [CL_OSCCHK, 0]])


class CMCF0(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF0'

    def __init__(self):
        super(CMCF0, self).__init__([[CMC_MAN, 0], [CMC_MPER, 2], [CMC_MPER, 1], [CMC_MPER, 0], [CMC_BTM, 0], [CMC_TPER, 2], [CMC_TPER, 1], [CMC_TPER, 0]])


class CMCF1(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF1'

    def __init__(self):
        super(CMCF1, self).__init__([[CMC_NDEV, 7], [CMC_NDEV, 6], [CMC_NDEV, 5], [CMC_NDEV, 4], [CMC_NDEV, 3], [CMC_NDEV, 2], [CMC_NDEV, 1], [CMC_NDEV, 0]])


class CMCF2(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF2'

    def __init__(self):
        super(CMCF2, self).__init__([[CMM_C, 7], [CMM_C, 6], [CMM_C, 5], [CMM_C, 4], [CMM_C, 3], [CMM_C, 2], [CMM_C, 1], [CMM_C, 0]])


class CMCF3(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF3'

    def __init__(self):
        super(CMCF3, self).__init__([[CMM_C, 15], [CMM_C, 14], [CMM_C, 13], [CMM_C, 12], [CMM_C, 11], [CMM_C, 10], [CMM_C, 9], [CMM_C, 8]])


class CMCF4(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF4'

    def __init__(self):
        super(CMCF4, self).__init__([[CMM_G, 1], [CMM_G, 0], [CMC_DIR, 0], [CMC_GOE, 2], [CMC_GOE, 1], [CMC_GOE, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMCF5(bmsbase.Register):
    MEM_KEY = 'LPCM Configuration Register Group'
    NAME = 'CMCF5'

    def __init__(self):
        super(CMCF5, self).__init__([[CMM_G, 9], [CMM_G, 8], [CMM_G, 7], [CMM_G, 6], [CMM_G, 5], [CMM_G, 4], [CMM_G, 3], [CMM_G, 2]])


class CMTC0(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC0'

    def __init__(self):
        super(CMTC0, self).__init__([[CMT_CUV, 7], [CMT_CUV, 6], [CMT_CUV, 5], [CMT_CUV, 4], [CMT_CUV, 3], [CMT_CUV, 2], [CMT_CUV, 1], [CMT_CUV, 0]])


class CMTC1(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC1'

    def __init__(self):
        super(CMTC1, self).__init__([[CMT_COV, 3], [CMT_COV, 2], [CMT_COV, 1], [CMT_COV, 0], [CMT_CUV, 11], [CMT_CUV, 10], [CMT_CUV, 9], [CMT_CUV, 8]])


class CMTC2(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC2'

    def __init__(self):
        super(CMTC2, self).__init__([[CMT_COV, 11], [CMT_COV, 10], [CMT_COV, 9], [CMT_COV, 8], [CMT_COV, 7], [CMT_COV, 6], [CMT_COV, 5], [CMT_COV, 4]])


class CMTC3(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC3'

    def __init__(self):
        super(CMTC3, self).__init__([[CMT_CDV, 7], [CMT_CDV, 6], [CMT_CDV, 5], [CMT_CDV, 4], [CMT_CDV, 3], [CMT_CDV, 2], [CMT_CDV, 1], [CMT_CDV, 0]])


class CMTC4(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC4'

    def __init__(self):
        super(CMTC4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMT_CDV, 11], [CMT_CDV, 10], [CMT_CDV, 9], [CMT_CDV, 8]])


class CMTC5(bmsbase.Register):
    MEM_KEY = 'LPCM Cell Threshold Register Group'
    NAME = 'CMTC5'

    def __init__(self):
        super(CMTC5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMTG0(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG0'

    def __init__(self):
        super(CMTG0, self).__init__([[CMT_GUV, 7], [CMT_GUV, 6], [CMT_GUV, 5], [CMT_GUV, 4], [CMT_GUV, 3], [CMT_GUV, 2], [CMT_GUV, 1], [CMT_GUV, 0]])


class CMTG1(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG1'

    def __init__(self):
        super(CMTG1, self).__init__([[CMT_GOV, 3], [CMT_GOV, 2], [CMT_GOV, 1], [CMT_GOV, 0], [CMT_GUV, 11], [CMT_GUV, 10], [CMT_GUV, 9], [CMT_GUV, 8]])


class CMTG2(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG2'

    def __init__(self):
        super(CMTG2, self).__init__([[CMT_GOV, 11], [CMT_GOV, 10], [CMT_GOV, 9], [CMT_GOV, 8], [CMT_GOV, 7], [CMT_GOV, 6], [CMT_GOV, 5], [CMT_GOV, 4]])


class CMTG3(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG3'

    def __init__(self):
        super(CMTG3, self).__init__([[CMT_GDV, 7], [CMT_GDV, 6], [CMT_GDV, 5], [CMT_GDV, 4], [CMT_GDV, 3], [CMT_GDV, 2], [CMT_GDV, 1], [CMT_GDV, 0]])


class CMTG4(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG4'

    def __init__(self):
        super(CMTG4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMT_GDV, 11], [CMT_GDV, 10], [CMT_GDV, 9], [CMT_GDV, 8]])


class CMTG5(bmsbase.Register):
    MEM_KEY = 'LPCM GPIO Threshold Register Group'
    NAME = 'CMTG5'

    def __init__(self):
        super(CMTG5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF0(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF0'

    def __init__(self):
        super(CMF0, self).__init__([[CMF_GDVP, 0], [CMF_GDVN, 0], [CMF_GOV, 0], [CMF_GUV, 0], [CMF_CDVP, 0], [CMF_CDVN, 0], [CMF_COV, 0], [CMF_CUV, 0]])


class CMF1(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF1'

    def __init__(self):
        super(CMF1, self).__init__([[CMC_EN, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [CMF_BTMWD, 0], [CMF_BTMCMP, 0]])


class CCMFD0(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CCMFD0'

    def __init__(self):
        super(CCMFD0, self).__init__([[CL_GDVP, 0], [CL_GDVN, 0], [CL_GOV, 0], [CL_GUV, 0], [CL_CDVP, 0], [CL_CDVN, 0], [CL_COV, 0], [CL_CUV, 0]])


class CCMFD1(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CCMFD1'

    def __init__(self):
        super(CCMFD1, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF2(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF2'

    def __init__(self):
        super(CMF2, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF3(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF3'

    def __init__(self):
        super(CMF3, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF4(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF4'

    def __init__(self):
        super(CMF4, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class CMF5(bmsbase.Register):
    MEM_KEY = 'LPCM Flags Register Group'
    NAME = 'CMF5'

    def __init__(self):
        super(CMF5, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class HBD0(bmsbase.Register):
    MEM_KEY = 'LPCM Heartbeat Group'
    NAME = 'HBD0'

    def __init__(self):
        super(HBD0, self).__init__([[HB_DCNT, 7], [HB_DCNT, 6], [HB_DCNT, 5], [HB_DCNT, 4], [HB_DCNT, 3], [HB_DCNT, 2], [HB_DCNT, 1], [HB_DCNT, 0]])


class HBD1(bmsbase.Register):
    MEM_KEY = 'LPCM Heartbeat Group'
    NAME = 'HBD1'

    def __init__(self):
        super(HBD1, self).__init__([[HB_GDVP, 0], [HB_GDVN, 0], [HB_GOV, 0], [HB_GUV, 0], [HB_CDVP, 0], [HB_CDVN, 0], [HB_COV, 0], [HB_CUV, 0]])


class RRR0(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR0'

    def __init__(self):
        super(RRR0, self).__init__([[RR, 7], [RR, 6], [RR, 5], [RR, 4], [RR, 3], [RR, 2], [RR, 1], [RR, 0]])


class RRR1(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR1'

    def __init__(self):
        super(RRR1, self).__init__([[RR, 15], [RR, 14], [RR, 13], [RR, 12], [RR, 11], [RR, 10], [RR, 9], [RR, 8]])


class RRR2(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR2'

    def __init__(self):
        super(RRR2, self).__init__([[RR, 23], [RR, 22], [RR, 21], [RR, 20], [RR, 19], [RR, 18], [RR, 17], [RR, 16]])


class RRR3(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR3'

    def __init__(self):
        super(RRR3, self).__init__([[RR, 31], [RR, 30], [RR, 29], [RR, 28], [RR, 27], [RR, 26], [RR, 25], [RR, 24]])


class RRR4(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR4'

    def __init__(self):
        super(RRR4, self).__init__([[RR, 39], [RR, 38], [RR, 37], [RR, 36], [RR, 35], [RR, 34], [RR, 33], [RR, 32]])


class RRR5(bmsbase.Register):
    MEM_KEY = 'Retention Register Group'
    NAME = 'RRR5'

    def __init__(self):
        super(RRR5, self).__init__([[RR, 47], [RR, 46], [RR, 45], [RR, 44], [RR, 43], [RR, 42], [RR, 41], [RR, 40]])


# ===================================================== ADBMS2950 =====================================================
class AUXAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR0'

    def __init__(self):
        super(AUXAR0, self).__init__([[VREF1P25, 7], [VREF1P25, 6], [VREF1P25, 5], [VREF1P25, 4], [VREF1P25, 3], [VREF1P25, 2], [VREF1P25, 1], [VREF1P25, 0]])


class AUXAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR1'

    def __init__(self):
        super(AUXAR1, self).__init__([[VREF1P25, 15], [VREF1P25, 14], [VREF1P25, 13], [VREF1P25, 12], [VREF1P25, 11], [VREF1P25, 10], [VREF1P25, 9], [VREF1P25, 8]])


class AUXAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR2'

    def __init__(self):
        super(AUXAR2, self).__init__([[TMP1, 7], [TMP1, 6], [TMP1, 5], [TMP1, 4], [TMP1, 3], [TMP1, 2], [TMP1, 1], [TMP1, 0]])


class AUXAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR3'

    def __init__(self):
        super(AUXAR3, self).__init__([[TMP1, 15], [TMP1, 14], [TMP1, 13], [TMP1, 12], [TMP1, 11], [TMP1, 10], [TMP1, 9], [TMP1, 8]])


class AUXAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR4'

    def __init__(self):
        super(AUXAR4, self).__init__([[VREG, 7], [VREG, 6], [VREG, 5], [VREG, 4], [VREG, 3], [VREG, 2], [VREG, 1], [VREG, 0]])


class AUXAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXAR5'

    def __init__(self):
        super(AUXAR5, self).__init__([[VREG, 15], [VREG, 14], [VREG, 13], [VREG, 12], [VREG, 11], [VREG, 10], [VREG, 9], [VREG, 8]])

class AUXBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR0'

    def __init__(self):
        super(AUXBR0, self).__init__([[VDD, 7], [VDD, 6], [VDD, 5], [VDD, 4], [VDD, 3], [VDD, 2], [VDD, 1], [VDD, 0]])


class AUXBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR1'

    def __init__(self):
        super(AUXBR1, self).__init__([[VDD, 15], [VDD, 14], [VDD, 13], [VDD, 12], [VDD, 11], [VDD, 10], [VDD, 9], [VDD, 8]])

class AUXBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR2'

    def __init__(self):
        super(AUXBR2, self).__init__([[VDIG, 7], [VDIG, 6], [VDIG, 5], [VDIG, 4], [VDIG, 3], [VDIG, 2], [VDIG, 1], [VDIG, 0]])


class AUXBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR3'

    def __init__(self):
        super(AUXBR3, self).__init__([[VDIG, 15], [VDIG, 14], [VDIG, 13], [VDIG, 12], [VDIG, 11], [VDIG, 10], [VDIG, 9], [VDIG, 8]])


class AUXBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR4'

    def __init__(self):
        super(AUXBR4, self).__init__([[EPAD, 7], [EPAD, 6], [EPAD, 5], [EPAD, 4], [EPAD, 3], [EPAD, 2], [EPAD, 1], [EPAD, 0]])


class AUXBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXBR5'

    def __init__(self):
        super(AUXBR5, self).__init__([[EPAD, 15], [EPAD, 14], [EPAD, 13], [EPAD, 12], [EPAD, 11], [EPAD, 10], [EPAD, 9], [EPAD, 8]])


class AUXCR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXCR0'

    def __init__(self):
        super(AUXCR0, self).__init__([[VDIV, 7], [VDIV, 6], [VDIV, 5], [VDIV, 4], [VDIV, 3], [VDIV, 2], [VDIV, 1], [VDIV, 0]])


class AUXCR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXCR1'

    def __init__(self):
        super(AUXCR1, self).__init__([[VDIV, 15], [VDIV, 14], [VDIV, 13], [VDIV, 12], [VDIV, 11], [VDIV, 10], [VDIV, 9], [VDIV, 8]])


class AUXCR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXCR2'

    def __init__(self):
        super(AUXCR2, self).__init__([[TMP2, 7], [TMP2, 6], [TMP2, 5], [TMP2, 4], [TMP2, 3], [TMP2, 2], [TMP2, 1], [TMP2, 0]])


class AUXCR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXCR3'

    def __init__(self):
        super(AUXCR3, self).__init__([[TMP2, 15], [TMP2, 14], [TMP2, 13], [TMP2, 12], [TMP2, 11], [TMP2, 10], [TMP2, 9], [TMP2, 8]])


class AUXCR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'AUXCR5'

    def __init__(self):
        super(AUXCR5, self).__init__([[OSCCNT, 7], [OSCCNT, 6], [OSCCNT, 5], [OSCCNT, 4], [OSCCNT, 3], [OSCCNT, 2], [OSCCNT, 1], [OSCCNT, 0]])


class IAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR0'

    def __init__(self):
        super(IAR0, self).__init__([[I1ACC, 7], [I1ACC, 6], [I1ACC, 5], [I1ACC, 4], [I1ACC, 3], [I1ACC, 2], [I1ACC, 1], [I1ACC, 0]])

class IAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR1'

    def __init__(self):
        super(IAR1, self).__init__([[I1ACC, 15], [I1ACC, 14], [I1ACC, 13], [I1ACC, 12], [I1ACC, 11], [I1ACC, 10], [I1ACC, 9], [I1ACC, 8]])

class IAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR2'

    def __init__(self):
        super(IAR2, self).__init__([[I1ACC, 23], [I1ACC, 22], [I1ACC, 21], [I1ACC, 20], [I1ACC, 19], [I1ACC, 18], [I1ACC, 17], [I1ACC, 16]])

class IAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR3'

    def __init__(self):
        super(IAR3, self).__init__([[I2ACC, 7], [I2ACC, 6], [I2ACC, 5], [I2ACC, 4], [I2ACC, 3], [I2ACC, 2], [I2ACC, 1], [I2ACC, 0]])

class IAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR4'

    def __init__(self):
        super(IAR4, self).__init__([[I2ACC, 15], [I2ACC, 14], [I2ACC, 13], [I2ACC, 12], [I2ACC, 11], [I2ACC, 10], [I2ACC, 9], [I2ACC, 8]])

class IAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IAR5'

    def __init__(self):
        super(IAR5, self).__init__([[I2ACC, 23], [I2ACC, 22], [I2ACC, 21], [I2ACC, 20], [I2ACC, 19], [I2ACC, 18], [I2ACC, 17], [I2ACC, 16]])

class IR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR0'

    def __init__(self):
        super(IR0, self).__init__([[I1, 7], [I1, 6], [I1, 5], [I1, 4], [I1, 3], [I1, 2], [I1, 1], [I1, 0]])

class IR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR1'

    def __init__(self):
        super(IR1, self).__init__([[I1, 15], [I1, 14], [I1, 13], [I1, 12], [I1, 11], [I1, 10], [I1, 9], [I1, 8]])

class IR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR2'

    def __init__(self):
        super(IR2, self).__init__([[I1, 23], [I1, 22], [I1, 21], [I1, 20], [I1, 19], [I1, 18], [I1, 17], [I1, 16]])

class IR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR3'

    def __init__(self):
        super(IR3, self).__init__([[I2, 7], [I2, 6], [I2, 5], [I2, 4], [I2, 3], [I2, 2], [I2, 1], [I2, 0]])

class IR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR4'

    def __init__(self):
        super(IR4, self).__init__([[I2, 15], [I2, 14], [I2, 13], [I2, 12], [I2, 11], [I2, 10], [I2, 9], [I2, 8]])

class IR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IR5'

    def __init__(self):
        super(IR5, self).__init__([[I2, 23], [I2, 22], [I2, 21], [I2, 20], [I2, 19], [I2, 18], [I2, 17], [I2, 16]])


class IVBAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR0'

    def __init__(self):
        super(IVBAR0, self).__init__([[I1ACC, 7], [I1ACC, 6], [I1ACC, 5], [I1ACC, 4], [I1ACC, 3], [I1ACC, 2], [I1ACC, 1], [I1ACC, 0]])


class IVBAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR1'

    def __init__(self):
        super(IVBAR1, self).__init__([[I1ACC, 15], [I1ACC, 14], [I1ACC, 13], [I1ACC, 12], [I1ACC, 11], [I1ACC, 10], [I1ACC, 9], [I1ACC, 8]])


class IVBAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR2'

    def __init__(self):
        super(IVBAR2, self).__init__([[I1ACC, 23], [I1ACC, 22], [I1ACC, 21], [I1ACC, 20], [I1ACC, 19], [I1ACC, 18], [I1ACC, 17], [I1ACC, 16]])


class IVBAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR3'

    def __init__(self):
        super(IVBAR3, self).__init__([[VB1ACC, 7], [VB1ACC, 6], [VB1ACC, 5], [VB1ACC, 4], [VB1ACC, 3], [VB1ACC, 2], [VB1ACC, 1], [VB1ACC, 0]])


class IVBAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR4'

    def __init__(self):
        super(IVBAR4, self).__init__([[VB1ACC, 15], [VB1ACC, 14], [VB1ACC, 13], [VB1ACC, 12], [VB1ACC, 11], [VB1ACC, 10], [VB1ACC, 9], [VB1ACC, 8]])


class IVBAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBAR5'

    def __init__(self):
        super(IVBAR5, self).__init__([[VB1ACC, 23], [VB1ACC, 22], [VB1ACC, 21], [VB1ACC, 20], [VB1ACC, 19], [VB1ACC, 18], [VB1ACC, 17], [VB1ACC, 16]])


class IVBR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBR0'

    def __init__(self):
        super(IVBR0, self).__init__([[I1, 7], [I1, 6], [I1, 5], [I1, 4], [I1, 3], [I1, 2], [I1, 1], [I1, 0]])


class IVBR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBR1'

    def __init__(self):
        super(IVBR1, self).__init__([[I1, 15], [I1, 14], [I1, 13], [I1, 12], [I1, 11], [I1, 10], [I1, 9], [I1, 8]])


class IVBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBR2'

    def __init__(self):
        super(IVBR2, self).__init__([[I1, 23], [I1, 22], [I1, 21], [I1, 20], [I1, 19], [I1, 18], [I1, 17], [I1, 16]])


class IVBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBR4'

    def __init__(self):
        super(IVBR4, self).__init__([[VB1, 7], [VB1, 6], [VB1, 5], [VB1, 4], [VB1, 3], [VB1, 2], [VB1, 1], [VB1, 0]])


class IVBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'IVBR5'

    def __init__(self):
        super(IVBR5, self).__init__([[VB1, 15], [VB1, 14], [VB1, 13], [VB1, 12], [VB1, 11], [VB1, 10], [VB1, 9], [VB1, 8]])


class OVRIR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR0'

    def __init__(self):
        super(OVRIR0, self).__init__([[OC1R, 7], [OC1R, 6], [OC1R, 5], [OC1R, 4], [OC1R, 3], [OC1R, 2], [OC1R, 1], [OC1R, 0]])

class OVRIR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR1'

    def __init__(self):
        super(OVRIR1, self).__init__([[OC2R, 7], [OC2R, 6], [OC2R, 5], [OC2R, 4], [OC2R, 3], [OC2R, 2], [OC2R, 1], [OC2R, 0]])

class OVRIR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR2'

    def __init__(self):
        super(OVRIR2, self).__init__([[OC3R, 7], [OC3R, 6], [OC3R, 5], [OC3R, 4], [OC3R, 3], [OC3R, 2], [OC3R, 1], [OC3R, 0]])

class OVRIR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR3'

    def __init__(self):
        super(OVRIR3, self).__init__([[REFR, 7], [REFR, 6], [REFR, 5], [REFR, 4], [REFR, 3], [REFR, 2], [REFR, 1], [REFR, 0]])

class OVRIR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR4'

    def __init__(self):
        super(OVRIR4, self).__init__([[OC3MAX, 7], [OC3MAX, 6], [OC3MAX, 5], [OC3MAX, 4], [OC3MAX, 3], [OC3MAX, 2], [OC3MAX, 1], [OC3MAX, 0]])

class OVRIR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'OVRIR5'

    def __init__(self):
        super(OVRIR5, self).__init__([[OC3MIN, 7], [OC3MIN, 6], [OC3MIN, 5], [OC3MIN, 4], [OC3MIN, 3], [OC3MIN, 2], [OC3MIN, 1], [OC3MIN, 0]])


class STR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STR0'

    def __init__(self):
        super(STR0, self).__init__([[bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [OCBP, 0], [OCAP, 0]])

class STR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STR1'

    def __init__(self):
        super(STR1, self).__init__([[I2CAL, 0], [I1CAL, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [DER, 1], [DER, 0]])

class STR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STR3'

    def __init__(self):
        super(STR3, self).__init__([[GPO6H, 0], [GPO5H, 0], [GPO4H, 0], [GPO3H, 0], [GPO2H, 0], [GPO1H, 0], [GPO6L, 0], [GPO5L, 0]])

class STR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STR4'

    def __init__(self):
        super(STR4, self).__init__([[GPO4L, 0], [GPO3L, 0], [GPO2L, 0], [GPO1L, 0], [GPIO4L, 0], [GPIO3L, 0], [GPIO2L, 0], [GPIO1L, 0]])

class STR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'STR5'

    def __init__(self):
        super(STR5, self).__init__([[REVID, 3], [REVID, 2], [REVID, 1], [REVID, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0], [bmsbase.RSVD0, 0]])


class V1AR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR0'

    def __init__(self):
        super(V1AR0, self).__init__([[V1A, 7], [V1A, 6], [V1A, 5], [V1A, 4], [V1A, 3], [V1A, 2], [V1A, 1], [V1A, 0]])

class V1AR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR1'

    def __init__(self):
        super(V1AR1, self).__init__([[V1A, 15], [V1A, 14], [V1A, 13], [V1A, 12], [V1A, 11], [V1A, 10], [V1A, 9], [V1A, 8]])

class V1AR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR2'

    def __init__(self):
        super(V1AR2, self).__init__([[V2A, 7], [V2A, 6], [V2A, 5], [V2A, 4], [V2A, 3], [V2A, 2], [V2A, 1], [V2A, 0]])

class V1AR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR3'

    def __init__(self):
        super(V1AR3, self).__init__([[V2A, 15], [V2A, 14], [V2A, 13], [V2A, 12], [V2A, 11], [V2A, 10], [V2A, 9], [V2A, 8]])

class V1AR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR4'

    def __init__(self):
        super(V1AR4, self).__init__([[V3A, 7], [V3A, 6], [V3A, 5], [V3A, 4], [V3A, 3], [V3A, 2], [V3A, 1], [V3A, 0]])

class V1AR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1AR5'

    def __init__(self):
        super(V1AR5, self).__init__([[V3A, 15], [V3A, 14], [V3A, 13], [V3A, 12], [V3A, 11], [V3A, 10], [V3A, 9], [V3A, 8]])

class V1BR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR0'

    def __init__(self):
        super(V1BR0, self).__init__([[V4A, 7], [V4A, 6], [V4A, 5], [V4A, 4], [V4A, 3], [V4A, 2], [V4A, 1], [V4A, 0]])

class V1BR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR1'

    def __init__(self):
        super(V1BR1, self).__init__([[V4A, 15], [V4A, 14], [V4A, 13], [V4A, 12], [V4A, 11], [V4A, 10], [V4A, 9], [V4A, 8]])

class V1BR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR2'

    def __init__(self):
        super(V1BR2, self).__init__([[V5A, 7], [V5A, 6], [V5A, 5], [V5A, 4], [V5A, 3], [V5A, 2], [V5A, 1], [V5A, 0]])

class V1BR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR3'

    def __init__(self):
        super(V1BR3, self).__init__([[V5A, 15], [V5A, 14], [V5A, 13], [V5A, 12], [V5A, 11], [V5A, 10], [V5A, 9], [V5A, 8]])

class V1BR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR4'

    def __init__(self):
        super(V1BR4, self).__init__([[V6A, 7], [V6A, 6], [V6A, 5], [V6A, 4], [V6A, 3], [V6A, 2], [V6A, 1], [V6A, 0]])

class V1BR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1BR5'

    def __init__(self):
        super(V1BR5, self).__init__([[V6A, 15], [V6A, 14], [V6A, 13], [V6A, 12], [V6A, 11], [V6A, 10], [V6A, 9], [V6A, 8]])

class V1CR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR0'

    def __init__(self):
        super(V1CR0, self).__init__([[V7A, 7], [V7A, 6], [V7A, 5], [V7A, 4], [V7A, 3], [V7A, 2], [V7A, 1], [V7A, 0]])

class V1CR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR1'

    def __init__(self):
        super(V1CR1, self).__init__([[V7A, 15], [V7A, 14], [V7A, 13], [V7A, 12], [V7A, 11], [V7A, 10], [V7A, 9], [V7A, 8]])

class V1CR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR2'

    def __init__(self):
        super(V1CR2, self).__init__([[V8A, 7], [V8A, 6], [V8A, 5], [V8A, 4], [V8A, 3], [V8A, 2], [V8A, 1], [V8A, 0]])

class V1CR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR3'

    def __init__(self):
        super(V1CR3, self).__init__([[V8A, 15], [V8A, 14], [V8A, 13], [V8A, 12], [V8A, 11], [V8A, 10], [V8A, 9], [V8A, 8]])

class V1CR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR4'

    def __init__(self):
        super(V1CR4, self).__init__([[VREF2A, 7], [VREF2A, 6], [VREF2A, 5], [VREF2A, 4], [VREF2A, 3], [VREF2A, 2], [VREF2A, 1], [VREF2A, 0]])

class V1CR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1CR5'

    def __init__(self):
        super(V1CR5, self).__init__([[VREF2A, 15], [VREF2A, 14], [VREF2A, 13], [VREF2A, 12], [VREF2A, 11], [VREF2A, 10], [VREF2A, 9], [VREF2A, 8]])

class V1DR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR0'

    def __init__(self):
        super(V1DR0, self).__init__([[V7A, 7], [V7A, 6], [V7A, 5], [V7A, 4], [V7A, 3], [V7A, 2], [V7A, 1], [V7A, 0]])

class V1DR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR1'

    def __init__(self):
        super(V1DR1, self).__init__([[V7A, 15], [V7A, 14], [V7A, 13], [V7A, 12], [V7A, 11], [V7A, 10], [V7A, 9], [V7A, 8]])

class V1DR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR2'

    def __init__(self):
        super(V1DR2, self).__init__([[V8A, 7], [V8A, 6], [V8A, 5], [V8A, 4], [V8A, 3], [V8A, 2], [V8A, 1], [V8A, 0]])

class V1DR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR3'

    def __init__(self):
        super(V1DR3, self).__init__([[V8A, 15], [V8A, 14], [V8A, 13], [V8A, 12], [V8A, 11], [V8A, 10], [V8A, 9], [V8A, 8]])

class V1DR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR4'

    def __init__(self):
        super(V1DR4, self).__init__([[V9B, 7], [V9B, 6], [V9B, 5], [V9B, 4], [V9B, 3], [V9B, 2], [V9B, 1], [V9B, 0]])

class V1DR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V1DR5'

    def __init__(self):
        super(V1DR5, self).__init__([[V9B, 15], [V9B, 14], [V9B, 13], [V9B, 12], [V9B, 11], [V9B, 10], [V9B, 9], [V9B, 8]])

class V2AR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR0'

    def __init__(self):
        super(V2AR0, self).__init__([[V1B, 7], [V1B, 6], [V1B, 5], [V1B, 4], [V1B, 3], [V1B, 2], [V1B, 1], [V1B, 0]])

class V2AR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR1'

    def __init__(self):
        super(V2AR1, self).__init__([[V1B, 15], [V1B, 14], [V1B, 13], [V1B, 12], [V1B, 11], [V1B, 10], [V1B, 9], [V1B, 8]])

class V2AR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR2'

    def __init__(self):
        super(V2AR2, self).__init__([[V2B, 7], [V2B, 6], [V2B, 5], [V2B, 4], [V2B, 3], [V2B, 2], [V2B, 1], [V2B, 0]])

class V2AR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR3'

    def __init__(self):
        super(V2AR3, self).__init__([[V2B, 15], [V2B, 14], [V2B, 13], [V2B, 12], [V2B, 11], [V2B, 10], [V2B, 9], [V2B, 8]])

class V2AR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR4'

    def __init__(self):
        super(V2AR4, self).__init__([[V3B, 7], [V3B, 6], [V3B, 5], [V3B, 4], [V3B, 3], [V3B, 2], [V3B, 1], [V3B, 0]])

class V2AR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2AR5'

    def __init__(self):
        super(V2AR5, self).__init__([[V3B, 15], [V3B, 14], [V3B, 13], [V3B, 12], [V3B, 11], [V3B, 10], [V3B, 9], [V3B, 8]])

class V2BR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR0'

    def __init__(self):
        super(V2BR0, self).__init__([[V4B, 7], [V4B, 6], [V4B, 5], [V4B, 4], [V4B, 3], [V4B, 2], [V4B, 1], [V4B, 0]])

class V2BR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR1'

    def __init__(self):
        super(V2BR1, self).__init__([[V4B, 15], [V4B, 14], [V4B, 13], [V4B, 12], [V4B, 11], [V4B, 10], [V4B, 9], [V4B, 8]])

class V2BR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR2'

    def __init__(self):
        super(V2BR2, self).__init__([[V5B, 7], [V5B, 6], [V5B, 5], [V5B, 4], [V5B, 3], [V5B, 2], [V5B, 1], [V5B, 0]])

class V2BR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR3'

    def __init__(self):
        super(V2BR3, self).__init__([[V5B, 15], [V5B, 14], [V5B, 13], [V5B, 12], [V5B, 11], [V5B, 10], [V5B, 9], [V5B, 8]])

class V2BR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR4'

    def __init__(self):
        super(V2BR4, self).__init__([[V6B, 7], [V6B, 6], [V6B, 5], [V6B, 4], [V6B, 3], [V6B, 2], [V6B, 1], [V6B, 0]])

class V2BR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2BR5'

    def __init__(self):
        super(V2BR5, self).__init__([[V6B, 15], [V6B, 14], [V6B, 13], [V6B, 12], [V6B, 11], [V6B, 10], [V6B, 9], [V6B, 8]])

class V2CR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR0'

    def __init__(self):
        super(V2CR0, self).__init__([[V9B, 7], [V9B, 6], [V9B, 5], [V9B, 4], [V9B, 3], [V9B, 2], [V9B, 1], [V9B, 0]])

class V2CR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR1'

    def __init__(self):
        super(V2CR1, self).__init__([[V9B, 15], [V9B, 14], [V9B, 13], [V9B, 12], [V9B, 11], [V9B, 10], [V9B, 9], [V9B, 8]])

class V2CR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR2'

    def __init__(self):
        super(V2CR2, self).__init__([[V10B, 7], [V10B, 6], [V10B, 5], [V10B, 4], [V10B, 3], [V10B, 2], [V10B, 1], [V10B, 0]])

class V2CR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR3'

    def __init__(self):
        super(V2CR3, self).__init__([[V10B, 15], [V10B, 14], [V10B, 13], [V10B, 12], [V10B, 11], [V10B, 10], [V10B, 9], [V10B, 8]])

class V2CR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR4'

    def __init__(self):
        super(V2CR4, self).__init__([[VREF2B, 7], [VREF2B, 6], [VREF2B, 5], [VREF2B, 4], [VREF2B, 3], [VREF2B, 2], [VREF2B, 1], [VREF2B, 0]])

class V2CR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2CR5'

    def __init__(self):
        super(V2CR5, self).__init__([[VREF2B, 15], [VREF2B, 14], [VREF2B, 13], [VREF2B, 12], [VREF2B, 11], [VREF2B, 10], [VREF2B, 9], [VREF2B, 8]])

class V2DR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR0'

    def __init__(self):
        super(V2DR0, self).__init__([[V10B, 7], [V10B, 6], [V10B, 5], [V10B, 4], [V10B, 3], [V10B, 2], [V10B, 1], [V10B, 0]])

class V2DR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR1'

    def __init__(self):
        super(V2DR1, self).__init__([[V10B, 15], [V10B, 14], [V10B, 13], [V10B, 12], [V10B, 11], [V10B, 10], [V10B, 9], [V10B, 8]])

class V2DR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR2'

    def __init__(self):
        super(V2DR2, self).__init__([[VREF2A, 7], [VREF2A, 6], [VREF2A, 5], [VREF2A, 4], [VREF2A, 3], [VREF2A, 2], [VREF2A, 1], [VREF2A, 0]])

class V2DR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR3'

    def __init__(self):
        super(V2DR3, self).__init__([[VREF2A, 15], [VREF2A, 14], [VREF2A, 13], [VREF2A, 12], [VREF2A, 11], [VREF2A, 10], [VREF2A, 9], [VREF2A, 8]])

class V2DR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR4'

    def __init__(self):
        super(V2DR4, self).__init__([[VREF2B, 7], [VREF2B, 6], [VREF2B, 5], [VREF2B, 4], [VREF2B, 3], [VREF2B, 2], [VREF2B, 1], [VREF2B, 0]])

class V2DR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2DR5'

    def __init__(self):
        super(V2DR5, self).__init__([[VREF2B, 15], [VREF2B, 14], [VREF2B, 13], [VREF2B, 12], [VREF2B, 11], [VREF2B, 10], [VREF2B, 9], [VREF2B, 8]])

class V2ER0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2ER0'

    def __init__(self):
        super(V2ER0, self).__init__([[V10B, 7], [V10B, 6], [V10B, 5], [V10B, 4], [V10B, 3], [V10B, 2], [V10B, 1], [V10B, 0]])

class V2ER1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'V2ER1'

    def __init__(self):
        super(V2ER1, self).__init__([[V10B, 15], [V10B, 14], [V10B, 13], [V10B, 12], [V10B, 11], [V10B, 10], [V10B, 9], [V10B, 8]])

class VBAR0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR0'

    def __init__(self):
        super(VBAR0, self).__init__([[VB1ACC, 7], [VB1ACC, 6], [VB1ACC, 5], [VB1ACC, 4], [VB1ACC, 3], [VB1ACC, 2], [VB1ACC, 1], [VB1ACC, 0]])

class VBAR1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR1'

    def __init__(self):
        super(VBAR1, self).__init__([[VB1ACC, 15], [VB1ACC, 14], [VB1ACC, 13], [VB1ACC, 12], [VB1ACC, 11], [VB1ACC, 10], [VB1ACC, 9], [VB1ACC, 8]])

class VBAR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR2'

    def __init__(self):
        super(VBAR2, self).__init__([[VB1ACC, 23], [VB1ACC, 22], [VB1ACC, 21], [VB1ACC, 20], [VB1ACC, 19], [VB1ACC, 18], [VB1ACC, 17], [VB1ACC, 16]])

class VBAR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR3'

    def __init__(self):
        super(VBAR3, self).__init__([[VB2ACC, 7], [VB2ACC, 6], [VB2ACC, 5], [VB2ACC, 4], [VB2ACC, 3], [VB2ACC, 2], [VB2ACC, 1], [VB2ACC, 0]])

class VBAR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR4'

    def __init__(self):
        super(VBAR4, self).__init__([[VB2ACC, 15], [VB2ACC, 14], [VB2ACC, 13], [VB2ACC, 12], [VB2ACC, 11], [VB2ACC, 10], [VB2ACC, 9], [VB2ACC, 8]])

class VBAR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBAR5'

    def __init__(self):
        super(VBAR5, self).__init__([[VB2ACC, 23], [VB2ACC, 22], [VB2ACC, 21], [VB2ACC, 20], [VB2ACC, 19], [VB2ACC, 18], [VB2ACC, 17], [VB2ACC, 16]])

class VBR2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBR2'

    def __init__(self):
        super(VBR2, self).__init__([[VB1, 7], [VB1, 6], [VB1, 5], [VB1, 4], [VB1, 3], [VB1, 2], [VB1, 1], [VB1, 0]])

class VBR3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBR3'

    def __init__(self):
        super(VBR3, self).__init__([[VB1, 15], [VB1, 14], [VB1, 13], [VB1, 12], [VB1, 11], [VB1, 10], [VB1, 9], [VB1, 8]])

class VBR4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBR4'

    def __init__(self):
        super(VBR4, self).__init__([[VB2, 7], [VB2, 6], [VB2, 5], [VB2, 4], [VB2, 3], [VB2, 2], [VB2, 1], [VB2, 0]])

class VBR5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'VBR5'

    def __init__(self):
        super(VBR5, self).__init__([[VB2, 15], [VB2, 14], [VB2, 13], [VB2, 12], [VB2, 11], [VB2, 10], [VB2, 9], [VB2, 8]])


# ===================================================== Commands =====================================================
class Broadcast_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'Broadcast Command'
    DESCRIPTION = 'Generic Broadcast Command'


    def __init__(self, **kwargs):
        super(Broadcast_Command, self).__init__(**kwargs)


class Write_Command(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'Write Command'
    DESCRIPTION = 'Generic Write Command'


    def __init__(self, **kwargs):
        super(Write_Command, self).__init__(**kwargs)
        self.local_definitions = {
            CCNT.NAME: CCNT(value=0x00)
        }


class Read_Command(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[WRITE_DATA_REGISTER(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'Read Command'
    DESCRIPTION = 'Generic Read Command'


    def __init__(self, **kwargs):
        super(Read_Command, self).__init__(**kwargs)


class WRCFGA(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), False], [CFGAR1(), False], [CFGAR2(), False], [CFGAR3(), False], [CFGAR4(), False], [CFGAR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGA'
    DESCRIPTION = 'Write Configuration Group A'


    def __init__(self, **kwargs):
        super(WRCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x01),
            CCNT.NAME: CCNT(value=0x00)
        }


class WRCFGB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), False], [CFGBR1(), False], [CFGBR2(), False], [CFGBR3(), False], [CFGBR4(), False], [CFGBR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCFGB'
    DESCRIPTION = 'Write Configuration Group B'


    def __init__(self, **kwargs):
        super(WRCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x24),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCFGA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGA'
    DESCRIPTION = 'Read Configuration Group A'


    def __init__(self, **kwargs):
        super(RDCFGA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x02),
        }


class RDCFGB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFGBR0(), True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCFGB'
    DESCRIPTION = 'Read Configuration Group B'


    def __init__(self, **kwargs):
        super(RDCFGB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x26),
        }


class RDCVA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVA'
    DESCRIPTION = 'Readback Cell Voltage Register Group A'


    def __init__(self, **kwargs):
        super(RDCVA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x04)
        }


class RDCVB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVB'
    DESCRIPTION = 'Readback Cell Voltage Register Group B'


    def __init__(self, **kwargs):
        super(RDCVB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x06)
        }


class RDCVC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVC'
    DESCRIPTION = 'Readback Cell Voltage Register Group C'


    def __init__(self, **kwargs):
        super(RDCVC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x08)
        }


class RDCVD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVD'
    DESCRIPTION = 'Readback Cell Voltage Register Group D'


    def __init__(self, **kwargs):
        super(RDCVD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0A)
        }


class RDCVE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVER0(), True], [CVER1(), True], [CVER2(), True], [CVER3(), True], [CVER4(), True], [CVER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVE'
    DESCRIPTION = 'Readback Cell Voltage Register Group E'


    def __init__(self, **kwargs):
        super(RDCVE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x09)
        }


class RDCVF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CVFR0(), True], [CVFR1(), True], [CVFR2(), True], [CVFR3(), True], [CVFR4(), True], [CVFR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCVF'
    DESCRIPTION = 'Readback Cell Voltage Register Group F'


    def __init__(self, **kwargs):
        super(RDCVF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0B)
        }


class RDCVALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True],
              [CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True],
              [CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True],
              [CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True],
              [CVER0(), True], [CVER1(), True], [CVER2(), True], [CVER3(), True], [CVER4(), True], [CVER5(), True],
              [CVFR0(), True], [CVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 38
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDCVALL'
    DESCRIPTION = 'Readback Cell Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDCVALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0C),
            DATA_PEC.NAME: DATA_PEC(pec_size=32*8+6)
        }


class RDACA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVAR0(), True], [ACVAR1(), True], [ACVAR2(), True], [ACVAR3(), True], [ACVAR4(), True], [ACVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACA'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group A'


    def __init__(self, **kwargs):
        super(RDACA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x44)
        }


class RDACB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVBR0(), True], [ACVBR1(), True], [ACVBR2(), True], [ACVBR3(), True], [ACVBR4(), True], [ACVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACB'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group B'


    def __init__(self, **kwargs):
        super(RDACB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x46)
        }


class RDACC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVCR0(), True], [ACVCR1(), True], [ACVCR2(), True], [ACVCR3(), True], [ACVCR4(), True], [ACVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACC'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group C'


    def __init__(self, **kwargs):
        super(RDACC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x48)
        }


class RDACD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVDR0(), True], [ACVDR1(), True], [ACVDR2(), True], [ACVDR3(), True], [ACVDR4(), True], [ACVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACD'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group D'


    def __init__(self, **kwargs):
        super(RDACD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x4A)
        }


class RDACE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVER0(), True], [ACVER1(), True], [ACVER2(), True], [ACVER3(), True], [ACVER4(), True], [ACVER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACE'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group E'


    def __init__(self, **kwargs):
        super(RDACE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x49)
        }


class RDACF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[ACVFR0(), True], [ACVFR1(), True], [ACVFR2(), True], [ACVFR3(), True], [ACVFR4(), True], [ACVFR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDACF'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Group F'


    def __init__(self, **kwargs):
        super(RDACF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x4B)
        }


class RDACALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [ACVAR0(), True], [ACVAR1(), True], [ACVAR2(), True], [ACVAR3(), True], [ACVAR4(), True], [ACVAR5(), True],
              [ACVBR0(), True], [ACVBR1(), True], [ACVBR2(), True], [ACVBR3(), True], [ACVBR4(), True], [ACVBR5(), True],
              [ACVCR0(), True], [ACVCR1(), True], [ACVCR2(), True], [ACVCR3(), True], [ACVCR4(), True], [ACVCR5(), True],
              [ACVDR0(), True], [ACVDR1(), True], [ACVDR2(), True], [ACVDR3(), True], [ACVDR4(), True], [ACVDR5(), True],
              [ACVER0(), True], [ACVER1(), True], [ACVER2(), True], [ACVER3(), True], [ACVER4(), True], [ACVER5(), True],
              [ACVFR0(), True], [ACVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 38
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDACALL'
    DESCRIPTION = 'Readback Averaged Cell Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDACALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x4C),
            DATA_PEC.NAME: DATA_PEC(pec_size=32*8+6)
        }


class RDSVA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVAR0(), True], [SVAR1(), True], [SVAR2(), True], [SVAR3(), True], [SVAR4(), True], [SVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVA'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group A'


    def __init__(self, **kwargs):
        super(RDSVA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x03)
        }


class RDSVB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVBR0(), True], [SVBR1(), True], [SVBR2(), True], [SVBR3(), True], [SVBR4(), True], [SVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVB'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group B'


    def __init__(self, **kwargs):
        super(RDSVB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x05)
        }


class RDSVC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVCR0(), True], [SVCR1(), True], [SVCR2(), True], [SVCR3(), True], [SVCR4(), True], [SVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVC'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group C'


    def __init__(self, **kwargs):
        super(RDSVC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x07)
        }


class RDSVD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVDR0(), True], [SVDR1(), True], [SVDR2(), True], [SVDR3(), True], [SVDR4(), True], [SVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVD'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group D'


    def __init__(self, **kwargs):
        super(RDSVD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0D)
        }


class RDSVE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVER0(), True], [SVER1(), True], [SVER2(), True], [SVER3(), True], [SVER4(), True], [SVER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVE'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group E'


    def __init__(self, **kwargs):
        super(RDSVE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0E)
        }


class RDSVF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SVFR0(), True], [SVFR1(), True], [SVFR2(), True], [SVFR3(), True], [SVFR4(), True], [SVFR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSVF'
    DESCRIPTION = 'Readback S-Pin Voltage Register Group F'


    def __init__(self, **kwargs):
        super(RDSVF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x0F)
        }


class RDSALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [SVAR0(), True], [SVAR1(), True], [SVAR2(), True], [SVAR3(), True], [SVAR4(), True], [SVAR5(), True],
              [SVBR0(), True], [SVBR1(), True], [SVBR2(), True], [SVBR3(), True], [SVBR4(), True], [SVBR5(), True],
              [SVCR0(), True], [SVCR1(), True], [SVCR2(), True], [SVCR3(), True], [SVCR4(), True], [SVCR5(), True],
              [SVDR0(), True], [SVDR1(), True], [SVDR2(), True], [SVDR3(), True], [SVDR4(), True], [SVDR5(), True],
              [SVER0(), True], [SVER1(), True], [SVER2(), True], [SVER3(), True], [SVER4(), True], [SVER5(), True],
              [SVFR0(), True], [SVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 38
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDSALL'
    DESCRIPTION = 'Readback S-Pin Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDSALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x10),
            DATA_PEC.NAME: DATA_PEC(pec_size=32*8+6)
        }


class RDCSALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [CVAR0(), True], [CVAR1(), True], [CVAR2(), True], [CVAR3(), True], [CVAR4(), True], [CVAR5(), True],
              [CVBR0(), True], [CVBR1(), True], [CVBR2(), True], [CVBR3(), True], [CVBR4(), True], [CVBR5(), True],
              [CVCR0(), True], [CVCR1(), True], [CVCR2(), True], [CVCR3(), True], [CVCR4(), True], [CVCR5(), True],
              [CVDR0(), True], [CVDR1(), True], [CVDR2(), True], [CVDR3(), True], [CVDR4(), True], [CVDR5(), True],
              [CVER0(), True], [CVER1(), True], [CVER2(), True], [CVER3(), True], [CVER4(), True], [CVER5(), True],
              [CVFR0(), True], [CVFR1(), True],
              [SVAR0(), True], [SVAR1(), True], [SVAR2(), True], [SVAR3(), True], [SVAR4(), True], [SVAR5(), True],
              [SVBR0(), True], [SVBR1(), True], [SVBR2(), True], [SVBR3(), True], [SVBR4(), True], [SVBR5(), True],
              [SVCR0(), True], [SVCR1(), True], [SVCR2(), True], [SVCR3(), True], [SVCR4(), True], [SVCR5(), True],
              [SVDR0(), True], [SVDR1(), True], [SVDR2(), True], [SVDR3(), True], [SVDR4(), True], [SVDR5(), True],
              [SVER0(), True], [SVER1(), True], [SVER2(), True], [SVER3(), True], [SVER4(), True], [SVER5(), True],
              [SVFR0(), True], [SVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 70
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDCSALL'
    DESCRIPTION = 'Readback Cell and S-Pin Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDCSALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x11),
            DATA_PEC.NAME: DATA_PEC(pec_size=64*8+6)
        }


class RDACSALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [ACVAR0(), True], [ACVAR1(), True], [ACVAR2(), True], [ACVAR3(), True], [ACVAR4(), True], [ACVAR5(), True],
              [ACVBR0(), True], [ACVBR1(), True], [ACVBR2(), True], [ACVBR3(), True], [ACVBR4(), True], [ACVBR5(), True],
              [ACVCR0(), True], [ACVCR1(), True], [ACVCR2(), True], [ACVCR3(), True], [ACVCR4(), True], [ACVCR5(), True],
              [ACVDR0(), True], [ACVDR1(), True], [ACVDR2(), True], [ACVDR3(), True], [ACVDR4(), True], [ACVDR5(), True],
              [ACVER0(), True], [ACVER1(), True], [ACVER2(), True], [ACVER3(), True], [ACVER4(), True], [ACVER5(), True],
              [ACVFR0(), True], [ACVFR1(), True],
              [SVAR0(), True], [SVAR1(), True], [SVAR2(), True], [SVAR3(), True], [SVAR4(), True], [SVAR5(), True],
              [SVBR0(), True], [SVBR1(), True], [SVBR2(), True], [SVBR3(), True], [SVBR4(), True], [SVBR5(), True],
              [SVCR0(), True], [SVCR1(), True], [SVCR2(), True], [SVCR3(), True], [SVCR4(), True], [SVCR5(), True],
              [SVDR0(), True], [SVDR1(), True], [SVDR2(), True], [SVDR3(), True], [SVDR4(), True], [SVDR5(), True],
              [SVER0(), True], [SVER1(), True], [SVER2(), True], [SVER3(), True], [SVER4(), True], [SVER5(), True],
              [SVFR0(), True], [SVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 70
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDACSALL'
    DESCRIPTION = 'Readback Averaged Cell and S-Pin Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDACSALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x51),
            DATA_PEC.NAME: DATA_PEC(pec_size=64*8+6)
        }


class RDFCA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVAR0(), True], [FCVAR1(), True], [FCVAR2(), True], [FCVAR3(), True], [FCVAR4(), True], [FCVAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCA'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group A'


    def __init__(self, **kwargs):
        super(RDFCA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x12)
        }


class RDFCB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVBR0(), True], [FCVBR1(), True], [FCVBR2(), True], [FCVBR3(), True], [FCVBR4(), True], [FCVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCB'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group B'


    def __init__(self, **kwargs):
        super(RDFCB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x13)
        }


class RDFCC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVCR0(), True], [FCVCR1(), True], [FCVCR2(), True], [FCVCR3(), True], [FCVCR4(), True], [FCVCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCC'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group C'


    def __init__(self, **kwargs):
        super(RDFCC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x14)
        }


class RDFCD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVDR0(), True], [FCVDR1(), True], [FCVDR2(), True], [FCVDR3(), True], [FCVDR4(), True], [FCVDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCD'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group D'


    def __init__(self, **kwargs):
        super(RDFCD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x15)
        }


class RDFCE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVER0(), True], [FCVER1(), True], [FCVER2(), True], [FCVER3(), True], [FCVER4(), True], [FCVER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCE'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group E'


    def __init__(self, **kwargs):
        super(RDFCE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x16)
        }


class RDFCF(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[FCVFR0(), True], [FCVFR1(), True], [FCVFR2(), True], [FCVFR3(), True], [FCVFR4(), True], [FCVFR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFCF'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Group F'


    def __init__(self, **kwargs):
        super(RDFCF, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x17)
        }


class RDFCALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [FCVAR0(), True], [FCVAR1(), True], [FCVAR2(), True], [FCVAR3(), True], [FCVAR4(), True], [FCVAR5(), True],
              [FCVBR0(), True], [FCVBR1(), True], [FCVBR2(), True], [FCVBR3(), True], [FCVBR4(), True], [FCVBR5(), True],
              [FCVCR0(), True], [FCVCR1(), True], [FCVCR2(), True], [FCVCR3(), True], [FCVCR4(), True], [FCVCR5(), True],
              [FCVDR0(), True], [FCVDR1(), True], [FCVDR2(), True], [FCVDR3(), True], [FCVDR4(), True], [FCVDR5(), True],
              [FCVER0(), True], [FCVER1(), True], [FCVER2(), True], [FCVER3(), True], [FCVER4(), True], [FCVER5(), True],
              [FCVFR0(), True], [FCVFR1(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]
              ]
    STATIC_LENGTH = 38
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDFCALL'
    DESCRIPTION = 'Readback Filtered Cell Voltage Register Groups A-F; 1 device only'


    def __init__(self, **kwargs):
        super(RDFCALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x18),
            DATA_PEC.NAME: DATA_PEC(pec_size=32*8+6)
        }


class RDAUXA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[GPAR0(), True], [GPAR1(), True], [GPAR2(), True], [GPAR3(), True], [GPAR4(), True], [GPAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXA'
    DESCRIPTION = 'Readback Auxiliary Register Group A'


    def __init__(self, **kwargs):
        super(RDAUXA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x19)
        }


class RDAUXB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[GPBR0(), True], [GPBR1(), True], [GPBR2(), True], [GPBR3(), True], [GPBR4(), True], [GPBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXB'
    DESCRIPTION = 'Readback Auxiliary Register Group B'


    def __init__(self, **kwargs):
        super(RDAUXB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1A)
        }


class RDAUXC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[GPCR0(), True], [GPCR1(), True], [GPCR2(), True], [GPCR3(), True], [GPCR4(), True], [GPCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXC'
    DESCRIPTION = 'Readback Auxiliary Register Group C'


    def __init__(self, **kwargs):
        super(RDAUXC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1B)
        }


class RDAUXD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[GPDR0(), True], [GPDR1(), True], [GPDR2(), True], [GPDR3(), True], [GPDR4(), True], [GPDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXD'
    DESCRIPTION = 'Readback Auxiliary Register Group D'


    def __init__(self, **kwargs):
        super(RDAUXD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1F)
        }


class RDAUXE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[GPER0(), True], [GPER1(), True], [GPER2(), True], [GPER3(), True], [GPER4(), True], [GPER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDAUXE'
    DESCRIPTION = 'Readback Auxiliary Register Group E'


    def __init__(self, **kwargs):
        super(RDAUXE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x36)
        }


class RDRAXA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RGPAR0(), True], [RGPAR1(), True], [RGPAR2(), True], [RGPAR3(), True], [RGPAR4(), True], [RGPAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDRAXA'
    DESCRIPTION = 'Readback Redundant Auxiliary Register Group A'


    def __init__(self, **kwargs):
        super(RDRAXA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1C)
        }


class RDRAXB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RGPBR0(), True], [RGPBR1(), True], [RGPBR2(), True], [RGPBR3(), True], [RGPBR4(), True], [RGPBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDRAXB'
    DESCRIPTION = 'Readback Redundant Auxiliary Register Group B'


    def __init__(self, **kwargs):
        super(RDRAXB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1D)
        }


class RDRAXC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RGPCR0(), True], [RGPCR1(), True], [RGPCR2(), True], [RGPCR3(), True], [RGPCR4(), True], [RGPCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDRAXC'
    DESCRIPTION = 'Readback Redundant Auxiliary Register Group C'


    def __init__(self, **kwargs):
        super(RDRAXC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x1E)
        }


class RDRAXD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RGPDR0(), True], [RGPDR1(), True], [RGPDR2(), True], [RGPDR3(), True], [RGPDR4(), True], [RGPDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDRAXD'
    DESCRIPTION = 'Readback Redundant Auxiliary Register Group D'


    def __init__(self, **kwargs):
        super(RDRAXD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x25)
        }


class RDSTATA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATA'
    DESCRIPTION = 'Readback Status Register Group A'


    def __init__(self, **kwargs):
        super(RDSTATA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x30)
        }


class RDSTATB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATB'
    DESCRIPTION = 'Readback Status Register Group B'


    def __init__(self, **kwargs):
        super(RDSTATB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x31)
        }


class RDSTATC(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [ERR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STCR0(), True], [STCR1(), True], [STCR2(), True], [STCR3(), True], [STCR4(), True], [STCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATC'
    DESCRIPTION = 'Readback Status Register Group C'


    def __init__(self, **kwargs):
        super(RDSTATC, self).__init__(**kwargs)


class RDSTATD(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STDR0(), True], [STDR1(), True], [STDR2(), True], [STDR3(), True], [STDR4(), True], [STDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATD'
    DESCRIPTION = 'Readback Status Register Group D'


    def __init__(self, **kwargs):
        super(RDSTATD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x33)
        }


class RDSTATE(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STER0(), True], [STER1(), True], [STER2(), True], [STER3(), True], [STER4(), True], [STER5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTATE'
    DESCRIPTION = 'Readback Status Register Group E'


    def __init__(self, **kwargs):
        super(RDSTATE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x34)
        }


class RDASALL(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [GPAR0(), True], [GPAR1(), True], [GPAR2(), True], [GPAR3(), True], [GPAR4(), True], [GPAR5(), True],
              [GPBR0(), True], [GPBR1(), True], [GPBR2(), True], [GPBR3(), True], [GPBR4(), True], [GPBR5(), True],
              [GPCR0(), True], [GPCR1(), True], [GPCR2(), True], [GPCR3(), True], [GPCR4(), True], [GPCR5(), True],
              [GPDR0(), True], [GPDR1(), True],
              [RGPAR0(), True], [RGPAR1(), True], [RGPAR2(), True], [RGPAR3(), True], [RGPAR4(), True], [RGPAR5(), True],
              [RGPBR0(), True], [RGPBR1(), True], [RGPBR2(), True], [RGPBR3(), True], [RGPBR4(), True], [RGPBR5(), True],
              [RGPCR0(), True], [RGPCR1(), True], [RGPCR2(), True], [RGPCR3(), True], [RGPCR4(), True], [RGPCR5(), True],
              [RGPDR0(), True], [RGPDR1(), True],
              [STAR0(), True], [STAR1(), True], [STAR2(), True], [STAR3(), True], [STAR4(), True], [STAR5(), True],
              [STBR0(), True], [STBR1(), True], [STBR2(), True], [STBR3(), True], [STBR4(), True], [STBR5(), True],
              [STCR0(), True], [STCR1(), True], [STCR4(), True], [STCR5(), True],
              [STDR0(), True], [STDR1(), True], [STDR2(), True], [STDR3(), True], [STDR4(), True], [STDR5(), True],
              [STER0(), True], [STER1(), True], [STER2(), True], [STER3(), True], [STER4(), True], [STER5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 74
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDASALL'
    DESCRIPTION = 'Readback All Status/Auxiliary Register Groups; 1 Device Only'


    def __init__(self, **kwargs):
        super(RDASALL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x35),
            DATA_PEC.NAME: DATA_PEC(pec_size=68*8+6)
        }


class WRPWMA(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), False], [PWMR1(), False], [PWMR2(), False], [PWMR3(), False], [PWMR4(), False], [PWMR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPWMA'
    DESCRIPTION = 'Write PWM Register Group A'


    def __init__(self, **kwargs):
        super(WRPWMA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x20),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDPWMA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PWMR0(), True], [PWMR1(), True], [PWMR2(), True], [PWMR3(), True], [PWMR4(), True], [PWMR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPWMA'
    DESCRIPTION = 'Read PWM Register Group A'


    def __init__(self, **kwargs):
        super(RDPWMA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x22)
        }


class WRPWMB(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), False], [PSR1(), False], [PSR2(), False], [PSR3(), False], [PSR4(), False], [PSR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRPWMB'
    DESCRIPTION = 'Write PWM Register Group B'


    def __init__(self, **kwargs):
        super(WRPWMB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x21),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDPWMB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[PSR0(), True], [PSR1(), True], [PSR2(), True], [PSR3(), True], [PSR4(), True], [PSR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDPWMB'
    DESCRIPTION = 'Read PWM Register Group B'


    def __init__(self, **kwargs):
        super(RDPWMB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x23)
        }


class CMDIS(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CMDIS'
    DESCRIPTION = 'LPCM Disable'


    def __init__(self, **kwargs):
        super(CMDIS, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x40)
        }


class CMEN(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CMEN'
    DESCRIPTION = 'LPCM Enable'


    def __init__(self, **kwargs):
        super(CMEN, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x41)
        }


class CMHB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[HBD0(), True], [HBD1(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 4
    NAME = 'CMHB'
    DESCRIPTION = 'LPCM Heartbeat'


    def __init__(self, **kwargs):
        super(CMHB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x41),
            DATA_PEC.NAME: DATA_PEC(pec_size=2 * 8 + 6)
        }


class WRCMCFG(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMCF0(), False], [CMCF1(), False], [CMCF2(), False], [CMCF3(), False], [CMCF4(), False], [CMCF5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMCFG'
    DESCRIPTION = 'Write LPCM Configuration Group'


    def __init__(self, **kwargs):
        super(WRCMCFG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x58),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCMCFG(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMCF0(), True], [CMCF1(), True], [CMCF2(), True], [CMCF3(), True], [CMCF4(), True], [CMCF5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMCFG'
    DESCRIPTION = 'Read LPCM Configuration Group'


    def __init__(self, **kwargs):
        super(RDCMCFG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x59),
            CCNT.NAME: CCNT(value=0x00)
        }


class WRCMCELLT(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTC0(), False], [CMTC1(), False], [CMTC2(), False], [CMTC3(), False], [CMTC4(), False], [CMTC5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMCELLT'
    DESCRIPTION = 'Write LPCM Cell Threshold Group'


    def __init__(self, **kwargs):
        super(WRCMCELLT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5A),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCMCELLT(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTC0(), True], [CMTC1(), True], [CMTC2(), True], [CMTC3(), True], [CMTC4(), True], [CMTC5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMCELLT'
    DESCRIPTION = 'Read LPCM Cell Threshold Group'


    def __init__(self, **kwargs):
        super(RDCMCELLT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5B),
            CCNT.NAME: CCNT(value=0x00)
        }


class WRCMGPIOT(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTG0(), False], [CMTG1(), False], [CMTG2(), False], [CMTG3(), False], [CMTG4(), False], [CMTG5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCMGPIOT'
    DESCRIPTION = 'Write LPCM GPIO Threshold Group'


    def __init__(self, **kwargs):
        super(WRCMGPIOT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5C),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCMGPIOT(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMTG0(), True], [CMTG1(), True], [CMTG2(), True], [CMTG3(), True], [CMTG4(), True], [CMTG5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMGPIOT'
    DESCRIPTION = 'Read LPCM GPIO Threshold Group'


    def __init__(self, **kwargs):
        super(RDCMGPIOT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5D),
            CCNT.NAME: CCNT(value=0x00)
        }


class CLRCMFLAG(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CCMFD0(), False], [CCMFD1(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 4
    NAME = 'CLRCMFLAG'
    DESCRIPTION = 'Clear LPCM Flags'


    def __init__(self, **kwargs):
        super(CLRCMFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5E),
            CCNT.NAME: CCNT(value=0x00),
            DATA_PEC.NAME: DATA_PEC(pec_size=2 * 8 + 6)
        }


class RDCMFLAG(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CMF0(), True], [CMF1(), True], [CMF2(), True], [CMF3(), True], [CMF4(), True], [CMF5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCMFLAG'
    DESCRIPTION = 'Read LPCM Flags'


    def __init__(self, **kwargs):
        super(RDCMFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x5F),
            CCNT.NAME: CCNT(value=0x00),
        }


class ADCV(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [RD, 0],
        [CONT, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0],
        [bmsbase.Bit0, 0], [RSTF, 0], [OW, 1], [OW, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADCV'
    DESCRIPTION = 'Start Cell Conversion'


    def __init__(self, **kwargs):
        super(ADCV, self).__init__(**kwargs)


class ADSV(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0],
        [CONT, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [DCP, 0],
        [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [OW, 1], [OW, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADSV'
    DESCRIPTION = 'Start S-Pin Conversion'


    def __init__(self, **kwargs):
        super(ADSV, self).__init__(**kwargs)


class ADAX(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [OW_AUX, 0],
        [PUP, 0], [CH, 4], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0],
        [CH, 3], [CH, 2], [CH, 1], [CH, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAX'
    DESCRIPTION = 'Start Auxiliary ADC Conversion'


    def __init__(self, **kwargs):
        super(ADAX, self).__init__(**kwargs)


class ADAX2(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0],
        [CH_AUX2, 3], [CH_AUX2, 2], [CH_AUX2, 1], [CH_AUX2, 0]]), False],
        [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADAX2'
    DESCRIPTION = 'Start Auxiliary2 ADC Conversion'


    def __init__(self, **kwargs):
        super(ADAX2, self).__init__(**kwargs)


class CLRCELL(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRCELL'
    DESCRIPTION = 'Clear Cell Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRCELL, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x11)
        }


class CLRFC(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRFC'
    DESCRIPTION = 'Clear Filtered Cell Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRFC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x14)
        }


class CLRAUX(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRAUX'
    DESCRIPTION = 'Clear Auxiliary Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRAUX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x12)
        }


class CLRSPIN(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRSPIN'
    DESCRIPTION = 'Clear S-Pin Voltage Register Groups'


    def __init__(self, **kwargs):
        super(CLRSPIN, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x16)
        }


class CLRFLAG(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFD0(), False], [CFD1(), False], [CFD2(), False], [CFD3(), False], [CFD4(), False], [CFD5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'CLRFLAG'
    DESCRIPTION = 'Clear Diagnostic Flags'


    def __init__(self, **kwargs):
        super(CLRFLAG, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x17),
            CCNT.NAME: CCNT(value=0x00),
        }


class CLOVUV(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CL_STDR0(), False], [CL_STDR1(), False], [CL_STDR2(), False], [CL_STDR3(), False], [CL_STDR4(), False], [CL_STDR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'CLOVUV'
    DESCRIPTION = 'Clear OV/UV Threshold Flags'


    def __init__(self, **kwargs):
        super(CLOVUV, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x15),
            CCNT.NAME: CCNT(value=0x00),
        }


class PLADC(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLADC'
    DESCRIPTION = 'Poll ADC Status'


    def __init__(self, **kwargs):
        super(PLADC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x18)
        }


class PLCADC(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLCADC'
    DESCRIPTION = 'Poll C-ADC Status'


    def __init__(self, **kwargs):
        super(PLCADC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x1C)
        }


class PLSADC(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLSADC'
    DESCRIPTION = 'Poll S-ADC Status'


    def __init__(self, **kwargs):
        super(PLSADC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x1D)
        }


class PLAUX(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLAUX'
    DESCRIPTION = 'Poll Aux-ADC Status'


    def __init__(self, **kwargs):
        super(PLAUX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x1E)
        }


class PLAUX2(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLAUX2'
    DESCRIPTION = 'Poll Aux2-ADC Status'


    def __init__(self, **kwargs):
        super(PLAUX2, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x1F)
        }


class WRCOMM(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), False], [COMM1(), False], [COMM2(), False], [COMM3(), False], [COMM4(), False], [COMM5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRCOMM'
    DESCRIPTION = 'Write COMM Register Group'


    def __init__(self, **kwargs):
        super(WRCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x21),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDCOMM(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[COMM0(), True], [COMM1(), True], [COMM2(), True], [COMM3(), True], [COMM4(), True], [COMM5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDCOMM'
    DESCRIPTION = 'Read COMM Register Group'


    def __init__(self, **kwargs):
        super(RDCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x22),
            CCNT.NAME: CCNT(value=0x00)
        }


class STCOMM(bmsbase.SPIWriteOpen):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'STCOMM'
    DESCRIPTION = 'Start I2C/SPI Communication'


    def __init__(self, **kwargs):
        super(STCOMM, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x07),
            CMD1.NAME: CMD1(value=0x23)
        }


class MUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'MUTE'
    DESCRIPTION = 'Mute Discharge'


    def __init__(self, **kwargs):
        super(MUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x28)
        }


class UNMUTE(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'UNMUTE'
    DESCRIPTION = 'Unmute Discharge'


    def __init__(self, **kwargs):
        super(UNMUTE, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x29)
        }


class RDSID(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[SIDR0(), True], [SIDR1(), True], [SIDR2(), True], [SIDR3(), True], [SIDR4(), True], [SIDR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSID'
    DESCRIPTION = 'Read Serial ID Register Group'


    def __init__(self, **kwargs):
        super(RDSID, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2C),
        }


class SRST(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'SRST'
    DESCRIPTION = 'Soft Reset'


    def __init__(self, **kwargs):
        super(SRST, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x27)
        }


class SNAP(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'SNAP'
    DESCRIPTION = 'Snapshot Measurements'


    def __init__(self, **kwargs):
        super(SNAP, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2D)
        }


class UNSNAP(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'UNSNAP'
    DESCRIPTION = 'Release Snapshot'


    def __init__(self, **kwargs):
        super(UNSNAP, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2F)
        }


class RSTCC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RSTCC'
    DESCRIPTION = 'Reset Command Counter'


    def __init__(self, **kwargs):
        super(RSTCC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x2E)
        }


class ULRR(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ULRR'
    DESCRIPTION = 'Unlock Retention Register'


    def __init__(self, **kwargs):
        super(ULRR, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x38)
        }


class WRRR(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RRR0(), False], [RRR1(), False], [RRR2(), False], [RRR3(), False], [RRR4(), False], [RRR5(), False], [CCNT_REGISTER(), False], [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'WRRR'
    DESCRIPTION = 'Write Retention Register Group'


    def __init__(self, **kwargs):
        super(WRRR, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x39),
            CCNT.NAME: CCNT(value=0x00)
        }


class RDRR(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[RRR0(), True], [RRR1(), True], [RRR2(), True], [RRR3(), True], [RRR4(), True], [RRR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDRR'
    DESCRIPTION = 'Read Retention Register Group'


    def __init__(self, **kwargs):
        super(RDRR, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x00),
            CMD1.NAME: CMD1(value=0x3A),
            CCNT.NAME: CCNT(value=0x00)
        }


# ===================================================== ADBMS2950 =====================================================
class ADI1(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [RD, 0], [OPT, 3], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [OPT, 2], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [OPT, 1], [OPT, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADI1'
    DESCRIPTION = 'Start I1/VB1 Conversion'

    def __init__(self, **kwargs):
        super(ADI1, self).__init__(**kwargs)


class ADI2(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [OPT, 3], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [OPT, 2], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [OPT, 1], [OPT, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADI2'
    DESCRIPTION = 'Start I2/VB2 Conversion'

    def __init__(self, **kwargs):
        super(ADI2, self).__init__(**kwargs)


class ADV(bmsbase.SPIWrite):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [OW, 1], [OW, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [VCH, 3], [VCH, 2], [VCH, 1], [VCH, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADV'
    DESCRIPTION = 'Start Link Voltage Input Conversion'

    def __init__(self, **kwargs):
        super(ADV, self).__init__(**kwargs)


class ADX(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'ADX'
    DESCRIPTION = 'Start Auxiliary Voltage Conversion'

    def __init__(self, **kwargs):
        super(ADX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x5),
            CMD1.NAME: CMD1(value=0x30)
        }


class CLRA(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRA'
    DESCRIPTION = 'Clear I/VB ADC Accumulator Results'

    def __init__(self, **kwargs):
        super(CLRA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x14)
        }


class CLRI(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRI'
    DESCRIPTION = 'Clear I/VB ADC Results'

    def __init__(self, **kwargs):
        super(CLRI, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x11)
        }


class CLRO(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRO'
    DESCRIPTION = 'Clear Overcurrent/Ref Results'

    def __init__(self, **kwargs):
        super(CLRO, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x13)
        }


class CLRVX(bmsbase.SPIWrite):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'CLRVX'
    DESCRIPTION = 'Clear Link and Aux Voltage Results'

    def __init__(self, **kwargs):
        super(CLRVX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x12),
            CCNT.NAME: CCNT(value=0x0)
        }


class PLI1(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLI1'
    DESCRIPTION = 'Poll I1/VB1 ADC Conversion Status'

    def __init__(self, **kwargs):
        super(PLI1, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x1c)
        }


class PLI2(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLI2'
    DESCRIPTION = 'Poll I2/VB2 ADC Conversion Status'

    def __init__(self, **kwargs):
        super(PLI2, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x1d)
        }


class PLV(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLV'
    DESCRIPTION = 'Poll Link Voltage Conversion'

    def __init__(self, **kwargs):
        super(PLV, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x1e)
        }


class PLX(bmsbase.SPIPoll):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'PLX'
    DESCRIPTION = 'Poll Auxiliary Voltage Conversion'

    def __init__(self, **kwargs):
        super(PLX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x7),
            CMD1.NAME: CMD1(value=0x1f)
        }


class RDALLA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [IAR0(), True], [IAR1(), True], [IAR2(), True], [IAR3(), True], [IAR4(), True], [IAR5(), True],
              [VBAR0(), True], [VBAR1(), True], [VBAR2(), True], [VBAR3(), True], [VBAR4(), True], [VBAR5(), True],
              [STR3(), True], [STR4(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLA'
    DESCRIPTION = 'Readback Battery Current/Voltage and Flags; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x4c),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDALLC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [CFGAR0(), True], [CFGAR1(), True], [CFGAR2(), True], [CFGAR3(), True], [CFGAR4(), True], [CFGAR5(), True],
              [CFGBR0, True], [CFGBR1(), True], [CFGBR2(), True], [CFGBR3(), True], [CFGBR4(), True], [CFGBR5(), True],
              [STR3(), True], [STR4(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLC'
    DESCRIPTION = 'Readback Configuration and Flags; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x10),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDALLI(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [IR0(), True], [IR1(), True], [IR2(), True], [IR3(), True], [IR4(), True], [IR5(), True],
              [VBR2(), True], [VBR3(), True], [VBR4(), True], [VBR5(), True],
              [OVRIR0(), True], [OVRIR1(), True], [OVRIR2(), True],
              [STR3(), True],
              [CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLI'
    DESCRIPTION = 'Readback Battery I1ADC Current/Voltage and Flags; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLI, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xc),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDALLR(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [V2AR0(), True], [V2AR1(), True], [V2AR2(), True], [V2AR3(), True], [V2AR4(), True], [V2AR5(), True],
              [V2BR0(), True], [V2BR1(), True], [V2BR2(), True], [V2BR3(), True], [V2BR4(), True], [V2BR5(), True],
              [V1CR0(), True], [V1CR1(), True], [V1CR2(), True], [V1CR3(), True], [V1DR4(), True], [V1DR5(), True],
              [V2CR2(), True], [V2CR3(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLR'
    DESCRIPTION = 'Readback Battery I2ADC Current/Voltage and Flags; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLR, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x11),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDALLV(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [V1AR0(), True], [V1AR1(), True], [V1AR2(), True], [V1AR3(), True], [V1AR4(), True], [V1AR5(), True],
              [V1BR0(), True], [V1BR1(), True], [V1BR2(), True], [V1BR3(), True], [V1BR4(), True], [V1BR5(), True],
              [V1CR0(), True], [V1CR1(), True], [V1CR2(), True], [V1CR3(), True], [V1DR4(), True], [V1DR5(), True],
              [V2CR2(), True], [V2CR3(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLV'
    DESCRIPTION = 'Readback All Link Voltage Results; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLV, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x35),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDALLX(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False],
              [V1CR4(), True], [V1CR5(), True], [V2CR4(), True], [V2CR5(), True],
              [AUXAR0(), True], [AUXAR1(), True], [AUXAR2(), True], [AUXAR3(), True], [AUXAR4(), True], [AUXAR5(), True],
              [AUXBR0(), True], [AUXBR1(), True], [AUXBR2(), True], [AUXBR3(), True], [AUXBR4(), True], [AUXBR5(), True],
              [AUXCR0(), True], [AUXCR1(), True], [AUXCR2(), True], [AUXCR3(), True],
              [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    STATIC_LENGTH = 26
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = 'RDALLX'
    DESCRIPTION = 'Readback All Auxiliary Voltage Results; 1 device only'

    def __init__(self, **kwargs):
        super(RDALLX, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x51),
            DATA_PEC.NAME: DATA_PEC(pec_size=20 * 8 + 6)
        }


class RDFLAG(bmsbase.SPIRead):
    STATIC = [[bmsbase.Register([[bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [ERR, 0], [bmsbase.Bit1, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], [bmsbase.Bit0, 0], [bmsbase.Bit1, 0], [bmsbase.Bit0, 0], ]), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[CFD0(), True], [CFD1(), True], [CFD2(), True], [CFD3(), True], [CFD4(), True], [CFD5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDFLAG'
    DESCRIPTION = 'Readback Flag Registers'

    def __init__(self, **kwargs):
        super(RDFLAG, self).__init__(**kwargs)


class RDI(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[IR0(), True], [IR1(), True], [IR2(), True], [IR3(), True], [IR4(), True], [IR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDI'
    DESCRIPTION = 'Readback Battery Current Results'

    def __init__(self, **kwargs):
        super(RDI, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x4)
        }


class RDIACC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[IAR0(), True], [IAR1(), True], [IAR2(), True], [IAR3(), True], [IAR4(), True], [IAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDIACC'
    DESCRIPTION = 'Readback Battery Current Accumulator Results'

    def __init__(self, **kwargs):
        super(RDIACC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x44)
        }


class RDIVB1(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[IVBR0(), True], [IVBR1(), True], [IVBR2(), True], [bmsbase.RSVDR0(), True], [IVBR4(), True], [IVBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDIVB1'
    DESCRIPTION = 'Readback I1 ADC Battery/Current Results'

    def __init__(self, **kwargs):
        super(RDIVB1, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x8)
        }


class RDIVB1ACC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[IVBAR0(), True], [IVBAR1(), True], [IVBAR2(), True], [IVBAR3(), True], [IVBAR4(), True], [IVBAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDIVB1ACC'
    DESCRIPTION = 'Readback I1 ADC Battery/Current Accumulator Results'

    def __init__(self, **kwargs):
        super(RDIVB1ACC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x48)
        }


class RDOC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[OVRIR0(), True], [OVRIR1(), True], [OVRIR2(), True], [OVRIR3(), True], [OVRIR4(), True], [OVRIR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDOC'
    DESCRIPTION = 'Readback Overcurrent and Reference ADC Results'

    def __init__(self, **kwargs):
        super(RDOC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xb)
        }


class RDSTAT(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[STR0(), True], [STR1(), True], [bmsbase.RSVDR0(), True], [STR3(), True], [STR4(), True], [STR5(), True],  [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDSTAT'
    DESCRIPTION = 'Readback Status Flags'

    def __init__(self, **kwargs):
        super(RDSTAT, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x34)
        }


class RDV1A(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V1AR0(), True], [V1AR1(), True], [V1AR2(), True], [V1AR3(), True], [V1AR4(), True], [V1AR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV1A'
    DESCRIPTION = 'Readback V1ADC V1-3 Results'

    def __init__(self, **kwargs):
        super(RDV1A, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xa)
        }


class RDV1B(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V1BR0(), True], [V1BR1(), True], [V1BR2(), True], [V1BR3(), True], [V1BR4(), True], [V1BR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV1B'
    DESCRIPTION = 'Readback V1ADC V4-6 Results'

    def __init__(self, **kwargs):
        super(RDV1B, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x9)
        }


class RDV1C(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V1CR0(), True], [V1CR1(), True], [V1CR2(), True], [V1CR3(), True], [V1CR4(), True], [V1CR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV1C'
    DESCRIPTION = 'Readback V1ADC V7,8,REF2 Results'

    def __init__(self, **kwargs):
        super(RDV1C, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x3)
        }


class RDV1D(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V1DR0(), True], [V1DR1(), True], [V1DR2(), True], [V1DR3(), True], [V1DR4(), True], [V1DR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV1D'
    DESCRIPTION = 'Readback V1ADC V7-9 Results'

    def __init__(self, **kwargs):
        super(RDV1D, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x1b)
        }


class RDV2A(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V2AR0(), True], [V2AR1(), True], [V2AR2(), True], [V2AR3(), True], [V2AR4(), True], [V2AR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV2A'
    DESCRIPTION = 'Readback V2ADC V1-3 Results'

    def __init__(self, **kwargs):
        super(RDV2A, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x7)
        }


class RDV2B(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V2BR0(), True], [V2BR1(), True], [V2BR2(), True], [V2BR3(), True], [V2BR4(), True], [V2BR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV2B'
    DESCRIPTION = 'Readback V1ADC V4-6 Results'

    def __init__(self, **kwargs):
        super(RDV2B, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0xd)
        }


class RDV2C(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V2CR0(), True], [V2CR1(), True], [V2CR2(), True], [V2CR3(), True], [V2CR4(), True], [V2CR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV2C'
    DESCRIPTION = 'Readback V1ADC V9,10,REF2 Results'

    def __init__(self, **kwargs):
        super(RDV2C, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x5)
        }


class RDV2D(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V2DR0(), True], [V2DR1(), True], [V2DR2(), True], [V2DR3(), True], [V2DR4(), True], [V2DR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV2D'
    DESCRIPTION = 'Readback V1ADC REF2 V2ADC REF2, V10 Results'

    def __init__(self, **kwargs):
        super(RDV2D, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x1f)
        }


class RDV2E(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[V2ER0(), True], [V2ER1(), True], [bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [bmsbase.RSVDR2(), True], [bmsbase.RSVDR3(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDV2E'
    DESCRIPTION = 'Readback V2ADC V10 Results'

    def __init__(self, **kwargs):
        super(RDV2E, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x25)
        }


class RDVB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[bmsbase.RSVDR0(), True], [bmsbase.RSVDR1(), True], [VBR2(), True], [VBR3(), True], [VBR4(), True], [VBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDVB'
    DESCRIPTION = 'Readback Battery Voltage Results'

    def __init__(self, **kwargs):
        super(RDVB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x6)
        }


class RDVBACC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[VBAR0(), True], [VBAR1(), True], [VBAR2(), True], [VBAR3(), True], [VBAR4(), True], [VBAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDVBACC'
    DESCRIPTION = 'Readback Battery Voltage Acculumator Results'

    def __init__(self, **kwargs):
        super(RDVBACC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x46)
        }


class RDXA(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AUXAR0(), True], [AUXAR1(), True], [AUXAR2(), True], [AUXAR3(), True], [AUXAR4(), True], [AUXAR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDXA'
    DESCRIPTION = 'Readback Auxiliary Result Group A'

    def __init__(self, **kwargs):
        super(RDXA, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x30)
        }


class RDXB(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AUXBR0(), True], [AUXBR1(), True], [AUXBR2(), True], [AUXBR3(), True], [AUXBR4(), True], [AUXBR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDXB'
    DESCRIPTION = 'Readback Auxiliary Result Group A'

    def __init__(self, **kwargs):
        super(RDXB, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x31)
        }


class RDXC(bmsbase.SPIRead):
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[AUXCR0(), True], [AUXCR1(), True], [AUXCR2(), True], [AUXCR3(), True], [bmsbase.RSVDR0(), True], [AUXCR5(), True], [CCNT_REGISTER(), True], [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'RDXC'
    DESCRIPTION = 'Readback Auxiliary Result Group A'

    def __init__(self, **kwargs):
        super(RDXC, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=0x0),
            CMD1.NAME: CMD1(value=0x33)
        }


# ===================================================== DUT =====================================================
class ADBMS_GEN6(ABC):
    NAME = 'ADBMS_GEN6'
    PASS = 'Pass'
    FAIL = 'Fail'
    MEMORY_MAP = {
        **bmsbase.BMS_Config.MEMORY_MAP,
        CMD_REGISTER.NAME: CMD_REGISTER,
        CMD_PEC_REGISTER.NAME: CMD_PEC_REGISTER,
        DATA_PEC_REGISTER.NAME: DATA_PEC_REGISTER,
        CFGAR0.NAME: CFGAR0,
        CFGAR1.NAME: CFGAR1,
        CFGAR2.NAME: CFGAR2,
        CFGAR3.NAME: CFGAR3,
        CFGAR4.NAME: CFGAR4,
        CFGAR5.NAME: CFGAR5,
        CFGBR0.NAME: CFGBR0,
        CFGBR1.NAME: CFGBR1,
        CFGBR2.NAME: CFGBR2,
        CFGBR3.NAME: CFGBR3,
        CFGBR4.NAME: CFGBR4,
        CFGBR5.NAME: CFGBR5,
        SIDR0.NAME: SIDR0,
        SIDR1.NAME: SIDR1,
        SIDR2.NAME: SIDR2,
        SIDR3.NAME: SIDR3,
        SIDR4.NAME: SIDR4,
        SIDR5.NAME: SIDR5,
        WRITE_DATA_REGISTER.NAME: WRITE_DATA_REGISTER,
        DATA0_REGISTER.NAME: DATA0_REGISTER,
        DATA1_REGISTER.NAME: DATA1_REGISTER,
    }
    BITFIELDS = {
        **bmsbase.BMS_Config.BITFIELDS,
        CMD0.NAME: CMD0,
        CMD1.NAME: CMD1,
        CCNT.NAME: CCNT,
        CMD_PEC.NAME: CMD_PEC,
        DATA_PEC.NAME: DATA_PEC,
        SID.NAME: SID,
        DATA0.NAME: DATA0,
        DATA1.NAME: DATA1,
        DATA2.NAME: DATA2,
        DATA3.NAME: DATA3,
        DATA4.NAME: DATA4,
        DATA5.NAME: DATA5,
    }
    COMMANDS = {
        **bmsbase.BMS_Config.COMMANDS,
        WRCFGA.NAME: WRCFGA,
        WRCFGB.NAME: WRCFGB,
        RDCFGA.NAME: RDCFGA,
        RDCFGB.NAME: RDCFGB,
        RDCVA.NAME: RDCVA,
        RDCVB.NAME: RDCVB,
        RDCVC.NAME: RDCVC,
        RDCVD.NAME: RDCVD,
        RDCVE.NAME: RDCVE,
        RDCVF.NAME: RDCVF,
        RDACA.NAME: RDACA,
        RDACB.NAME: RDACB,
        RDACC.NAME: RDACC,
        RDACD.NAME: RDACD,
        RDACE.NAME: RDACE,
        RDACF.NAME: RDACF,
        RDSVA.NAME: RDSVA,
        RDSVB.NAME: RDSVB,
        RDSVC.NAME: RDSVC,
        RDSVD.NAME: RDSVD,
        RDSVE.NAME: RDSVE,
        RDSVF.NAME: RDSVF,
        RDFCA.NAME: RDFCA,
        RDFCB.NAME: RDFCB,
        RDFCC.NAME: RDFCC,
        RDFCD.NAME: RDFCD,
        RDFCE.NAME: RDFCE,
        RDFCF.NAME: RDFCF,
        RDAUXA.NAME: RDAUXA,
        RDAUXB.NAME: RDAUXB,
        RDAUXC.NAME: RDAUXC,
        RDAUXD.NAME: RDAUXD,
        RDAUXE.NAME: RDAUXE,
        RDRAXA.NAME: RDRAXA,
        RDRAXB.NAME: RDRAXB,
        RDRAXC.NAME: RDRAXC,
        RDRAXD.NAME: RDRAXD,
        RDSTATA.NAME: RDSTATA,
        RDSTATB.NAME: RDSTATB,
        RDSTATC.NAME: RDSTATC,
        RDSTATD.NAME: RDSTATD,
        RDSTATE.NAME: RDSTATE,
        WRPWMA.NAME: WRPWMA,
        RDPWMA.NAME: RDPWMA,
        WRPWMB.NAME: WRPWMB,
        RDPWMB.NAME: RDPWMB,
        CMDIS.NAME: CMDIS,
        CMEN.NAME: CMEN,
        CMHB.NAME: CMHB,
        WRCMCFG.NAME: WRCMCFG,
        RDCMCFG.NAME: RDCMCFG,
        WRCMCELLT.NAME: WRCMCELLT,
        RDCMCELLT.NAME: RDCMCELLT,
        WRCMGPIOT.NAME: WRCMGPIOT,
        RDCMGPIOT.NAME: RDCMGPIOT,
        CLRCMFLAG.NAME: CLRCMFLAG,
        RDCMFLAG.NAME: RDCMFLAG,
        ADCV.NAME: ADCV,
        ADSV.NAME: ADSV,
        ADAX.NAME: ADAX,
        ADAX2.NAME: ADAX2,
        CLRCELL.NAME: CLRCELL,
        CLRFC.NAME: CLRFC,
        CLRAUX.NAME: CLRAUX,
        CLRSPIN.NAME: CLRSPIN,
        CLOVUV.NAME: CLOVUV,
        PLADC.NAME: PLADC,
        PLCADC.NAME: PLCADC,
        PLSADC.NAME: PLSADC,
        PLAUX.NAME: PLAUX,
        PLAUX2.NAME: PLAUX2,
        WRCOMM.NAME: WRCOMM,
        RDCOMM.NAME: RDCOMM,
        STCOMM.NAME: STCOMM,
        MUTE.NAME: MUTE,
        UNMUTE.NAME: UNMUTE,
        RDSID.NAME: RDSID,
        RSTCC.NAME: RSTCC,
        SNAP.NAME: SNAP,
        UNSNAP.NAME: UNSNAP,
        SRST.NAME: SRST,
        ULRR.NAME: ULRR,
        WRRR.NAME: WRRR,
        RDRR.NAME: RDRR,
        Broadcast_Command.NAME: Broadcast_Command,
        Write_Command.NAME: Write_Command,
        Read_Command.NAME: Read_Command,
        ADI1.NAME: ADI1,
        ADI2.NAME: ADI2,
        ADV.NAME: ADV,
        ADX.NAME: ADX,
        # BLFSC.NAME: BLFSC,
        # BLFSS.NAME: BLFSS,
        CLRA.NAME: CLRA,
        CLRFLAG.NAME: CLRFLAG,
        CLRI.NAME: CLRI,
        CLRO.NAME: CLRO,
        CLRVX.NAME: CLRVX,
        PLI1.NAME: PLI1,
        PLI2.NAME: PLI2,
        PLV.NAME: PLV,
        PLX.NAME: PLX,
        RDFLAG.NAME: RDFLAG,
        # RDFSC.NAME: RDFSC,
        # RDFSS.NAME: RDFSS,
        RDI.NAME: RDI,
        RDIACC.NAME: RDIACC,
        RDIVB1.NAME: RDIVB1,
        RDIVB1ACC.NAME: RDIVB1ACC,
        RDOC.NAME: RDOC,
        RDSTAT.NAME: RDSTAT,
        # RDTSTA.NAME: RDTSTA,
        # RDTSTB.NAME: RDTSTB,
        # RDTSTC.NAME: RDTSTC,
        RDV1A.NAME: RDV1A,
        RDV1B.NAME: RDV1B,
        RDV1C.NAME: RDV1C,
        RDV1D.NAME: RDV1D,
        RDV2A.NAME: RDV2A,
        RDV2B.NAME: RDV2B,
        RDV2C.NAME: RDV2C,
        RDV2D.NAME: RDV2D,
        RDV2E.NAME: RDV2E,
        RDVB.NAME: RDVB,
        RDVBACC.NAME: RDVBACC,
        RDXA.NAME: RDXA,
        RDXB.NAME: RDXB,
        RDXC.NAME: RDXC,
        # WRFSC.NAME: WRFSC,
        # WRFSS.NAME: WRFSS,
        # WRTSTA.NAME: WRTSTA,
        # WRTSTB.NAME: WRTSTB,
        # WRTSTC.NAME: WRTSTC,
    }

    CELL_CONVERSION_CMDS = []
    SPIN_CONVERSION_CMDS = []
    AUX_CONVERSION_CMDS = []
    STAT_CONVERSION_CMDS = []
    CELL_ADC_POLL_CMDS = []
    AUX_ADC_POLL_CMDS = []
    STAT_ADC_POLL_CMDS = []
    ADC_POLL_CMDS = []
    SPIN_ADC_POLL_CMDS = []
    CELL_READ_CMDS = []
    SPIN_READ_CMDS = []
    AUX_READ_CMDS = []
    STAT_READ_CMDS = []
    WAKEUP_CMDS = []
    BCI_COM_CMD_LIST = []
    BCI_ANALOG_CMD_LIST = []
    GUI_LOOP_CMD_LIST = []
    SAFETY_COMMAND_LISTS = {}
    MAX_SPI_SPEED_CMDS = [
        {'command': '$SPI_SET_FREQUENCY_kHz$', 'arguments': {'Frequency': 2000}}
    ]
