import Engine.Devices.BMS_Config as bmsbase
from Engine.Devices.ADBMS_GEN6 import CMD_PEC_REGISTER, DATA_PEC_REGISTER, CCNT_REGISTER, CMD0, CMD1,CMD_REGISTER

# Create test bitfield based on SID. Just one big 48 bit value that you easily fill up
class TEST_BITFIELD(bmsbase.BitfieldInt):
    NAME = 'TEST_BITFIELD0'
    DESCRIPTION = 'Testing bitfield0'
    MEM_KEY = 'TEST_BITFIELD'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFFFFFFFFFF
    MIN_VALUE = 0
    LENGTH = 48
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TEST_BITFIELD, self).__init__(TEST_BITFIELD.LENGTH,  value=value, raw_value=raw_value)
        self.name = TEST_BITFIELD.NAME

# Create test registers based on SID.
class TEST_REGISTER0(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER0'

    def __init__(self):
        super(TEST_REGISTER0, self).__init__([[TEST_BITFIELD, 7], [TEST_BITFIELD, 6], [TEST_BITFIELD, 5], [TEST_BITFIELD, 4], [TEST_BITFIELD, 3], [TEST_BITFIELD, 2], [TEST_BITFIELD, 1], [TEST_BITFIELD, 0]])

class TEST_REGISTER1(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER1'

    def __init__(self):
        super(TEST_REGISTER1, self).__init__([[TEST_BITFIELD, 15], [TEST_BITFIELD, 14], [TEST_BITFIELD, 13], [TEST_BITFIELD, 12], [TEST_BITFIELD, 11], [TEST_BITFIELD, 10], [TEST_BITFIELD, 9], [TEST_BITFIELD, 8]])

class TEST_REGISTER2(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER2'

    def __init__(self):
        super(TEST_REGISTER2, self).__init__([[TEST_BITFIELD, 23], [TEST_BITFIELD, 22], [TEST_BITFIELD, 21], [TEST_BITFIELD, 20], [TEST_BITFIELD, 19], [TEST_BITFIELD, 18], [TEST_BITFIELD, 17], [TEST_BITFIELD, 16]])

class TEST_REGISTER3(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER3'

    def __init__(self):
        super(TEST_REGISTER3, self).__init__([[TEST_BITFIELD, 31], [TEST_BITFIELD, 30], [TEST_BITFIELD, 29], [TEST_BITFIELD, 28], [TEST_BITFIELD, 27], [TEST_BITFIELD, 26], [TEST_BITFIELD, 25], [TEST_BITFIELD, 24]])

class TEST_REGISTER4(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER4'

    def __init__(self):
        super(TEST_REGISTER4, self).__init__([[TEST_BITFIELD, 39], [TEST_BITFIELD, 38], [TEST_BITFIELD, 37], [TEST_BITFIELD, 36], [TEST_BITFIELD, 35], [TEST_BITFIELD, 34], [TEST_BITFIELD, 33], [TEST_BITFIELD, 32]])

class TEST_REGISTER5(bmsbase.Register):
    MEM_KEY = ''
    NAME = 'TEST_REGISTER5'

    def __init__(self):
        super(TEST_REGISTER5, self).__init__([[TEST_BITFIELD, 47], [TEST_BITFIELD, 46], [TEST_BITFIELD, 45], [TEST_BITFIELD, 44], [TEST_BITFIELD, 43], [TEST_BITFIELD, 42], [TEST_BITFIELD, 41], [TEST_BITFIELD, 40]])

class TEST_RD_CMD(bmsbase.SPIRead):
    """
    Test read command. This command allows for flexible setting of cmd. Pec however is calculated
    """
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[TEST_REGISTER0(), True],
                [TEST_REGISTER1(), True],
                [TEST_REGISTER2(), True],
                [TEST_REGISTER3(), True],
                [TEST_REGISTER4(), True],
                [TEST_REGISTER5(), True],
                [CCNT_REGISTER(), True],
                [DATA_PEC_REGISTER(), True]]
    VARIABLE_LENGTH = 8
    NAME = 'TEST_RD_CMD'
    DESCRIPTION = 'Testing a gen6 RD Command'

    def __init__(self, **kwargs):
        super(TEST_RD_CMD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=kwargs['test_cmd_code'][0]),
            CMD1.NAME: CMD1(value=kwargs['test_cmd_code'][1]),
        }

class TEST_WR_CMD(bmsbase.SPIRead):
    """
    Test write command. This command allows for flexible setting of cmd and data. PEC however is calculated.
    """
    STATIC = [[CMD_REGISTER(), False], [CMD_PEC_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = [[TEST_REGISTER0(), False],
                [TEST_REGISTER1(), False],
                [TEST_REGISTER2(), False],
                [TEST_REGISTER3(), False],
                [TEST_REGISTER4(), False],
                [TEST_REGISTER5(), False],
                [CCNT_REGISTER(), False],
                [DATA_PEC_REGISTER(), False]]
    VARIABLE_LENGTH = 8
    NAME = 'TEST_WR_CMD'
    DESCRIPTION = 'Testing a gen6 WR Command'

    def __init__(self, **kwargs):
        super(TEST_WR_CMD, self).__init__(**kwargs)
        self.local_definitions = {
            CMD0.NAME: CMD0(value=kwargs['test_cmd_code'][0]),
            CMD1.NAME: CMD1(value=kwargs['test_cmd_code'][1]),
            TEST_BITFIELD.NAME: TEST_BITFIELD(value=kwargs['test_value'])
        }