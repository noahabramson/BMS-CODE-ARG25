# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
from dataclasses import dataclass

@dataclass
class ADBMS2950_Appendix:
    Voltages = ['V1A', 'V2A', 'V3A', 'V4A', 'V5A', 'V6A', 'V7A', 'V8A',
                'V1B', 'V2B', 'V3B', 'V4B', 'V5B', 'V6B', 'V9B', 'V10B']
    Currents = ['I1', 'I2']
    Avg_Currents = ['I1ACC', 'I2ACC']
    Avg_BAT = ['VB1ACC', 'VB2ACC']
    VBAT = ['VB1', 'VB2']
    GPIOS = ['GPO6C', 'GPO5C', 'GPO5', 'GPO4C',  'GPO3C', 'GPIO3', 'GPO2C', 'GPO1C']
    STAT = ['OCBP', 'OCAP', 'I2CAL', 'I1CAL', 'GPO6H', 'GPO5H', 'GPO4H', 'GPO3H', 'GPO2H', 'GPO1H', 'GPO6L','GPO5L','GPO4L','GPO3L','GPO2L','GPO1L']
    CFG = ['OCEN', 'VS5', 'VS4', 'VS3', 'VS2', 'VS1', 'INJTM', 'INJECC', 'INJTS',
           'SOAK','VS10', 'VS9', 'VS8', 'VS7', 'VS6',
           'GPO6C', 'GPO5C', 'GPO4C',  'GPO3C', 'GPIO3C', 'GPO2C', 'GPO1C',
           'SPI3W', 'GPIO1FE', 'GPO6OD', 'GPO5OD','GPO4OD', 'GPO2OD', 'GPO1OD',
           'VB2MUX', 'VB1MUX', 'SNAPST', 'REFUP', 'COMMBK', 'ACCI',
           'OC1TEN','OC1TH', 'OC2TEN', 'OC2TH', 'OC3TEN', 'OC3TH', 'OCTSEL', 'REFTEN', 'OCDP', 'OCDGT',
           'OCBX', 'OCAX', 'OCMODE', 'OC3GC', 'OC2GC', 'OC1GC', 'OCOD',
           'GPIO4C', 'GPIO3C', 'GPIO2C', 'GPIO1C', 'GPIO2EOC']
    WAKEUP_CMDS = [
        {'command': 'spi_wakeup', 'arguments': {'wakeup_time': 500}},
    ]
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    CURRENT_CONVERSION_CMD1 = [
        {'command': 'ADI1'},
    ]
    CURRENT_CONVERSION_CMD1_CONT_RD = [
        {'command': 'ADI1','arguments': {'OPT': 8, 'RD':True}},
    ]
    CURRENT_CONVERSION_CMD2 = [
        {'command': 'ADI2'},
    ]
    VOLTAGE_CONVERSION_CMD = [
        {"command": "ADV", "arguments": {"VCH": 9}},
    ]
    AUX_CONVERSION_CMD = [
        {'command': 'ADX', "arguments": {"ACH": 0}},
    ]

    CURRENT_READ_CMDS = [
        {'command': 'RDI', 'map_key': 'CURRENT'},
    ]
    CURRENT_AVG_CURRENT_READ_CMDS = [
        {'command': 'RDI', 'map_key': 'CURRENT'},
        {'command': 'RDIACC', 'map_key': 'CURRENT'}
    ]

    CURRENT_READ_CMDS_2 = [
        {'command': 'RDI', 'map_key': 'CURRENT'},
        {'command': 'RDOC', 'map_key': 'CURRENT'},
        {'command': 'RDIACC', 'map_key': 'CURRENT'}
    ]

    VOLTAGE_READ_CMDS = [
        {'command': 'RDV1A', 'map_key': 'V_CHAN'},
        {'command': 'RDV1B', 'map_key': 'V_CHAN'},
        {'command': 'RDV1C', 'map_key': 'V_CHAN'},
        {'command': 'RDV1D', 'map_key': 'V_CHAN'},
        {'command': 'RDV2A', 'map_key': 'V_CHAN'},
        {'command': 'RDV2B', 'map_key': 'V_CHAN'},
        {'command': 'RDV2C', 'map_key': 'V_CHAN'},
        {'command': 'RDV2D', 'map_key': 'V_CHAN'},
    ]
    VBAT_READ_CMDS = [
        {'command': 'RDVB', 'map_key': 'VBAT'},
    ]

    ADC_POLL_CMDS = [
        {'command': 'PLADC'},
    ]

    I_VBat_POLL_CMDS = [
        {'command': 'PLIADC'},
    ]

    VADC_POLL_CMDS = [
        {'command': 'PLVADC'},
    ]

    PLAUX_POLL_CMDS = [
        {'command': 'PLAUX'},
    ]
    RDSTATC_READ_CMD = [
        {'command': 'RDSTATC', 'map_key': 'STATC'},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]
    BCI_ANALOG_INIT_CMD_LIST = [
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 500}},
        {"command": "SRST", "arguments": {}},
        {"command": "WRCFGA", "arguments": {}},
        {"command": "WRCFGB", "arguments": {}},
        {'command': 'RDCFGA', "arguments": {}},
        {'command': 'RDCFGB', "arguments": {}},
        {"command": "ADI1", "arguments": {"OPT": 8, "RD": True}},
        {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},  # see Tiger errata A.IADCOFFS
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 500}},
        {"command": "RDIACC"},
    ]
    BCI_ANALOG_CMD_LIST = [
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 500}},
        {"command": "ADI1", "arguments": {"OPT": 8, "RD": True}},
    ]
    BCI_ANALOG_LOOP_LIST = [
        {'command': '$DELAY_US$', 'arguments': {'Delay': 6000}},  # minimum time 8ms
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 500}},
        {"command": "RDSTAT", "map_key": "BCI_ANALOG_{}"},  # to read CT,CTS
        {'command': 'loop',
         'arguments': {'loops': 0x00FF, 'mask': [0x00, 0x00, 0x1F, 0xFC, 0x00, 0x00, 0x00, 0x00], 'counter': 1}},
        # RDSTAC with STCR2/3 (CT) being monitored
        {"command": "RDIACC", "map_key": "BCI_ANALOG_{}"},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['I1ACC', 'I2ACC', 'CT', 'CTS']
    GUI_LOOP_CMD_LIST = [
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 500}},
        {"command": "RDCFGA", "arguments": {}, "map_key": "GUI"},
        {"command": "RDCFGB", "arguments": {}, "map_key": "GUI"},
        {"command": "ADI1", "arguments": {"OPT": 8, "RD": True}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 10}},
        {"command": "RDI", "map_key": "GUI"},
        {"command": "RDVB", "map_key": "GUI"},
        {"command": "ADV", "arguments": {"VCH": 9}},
        {"command": "ADX", "arguments": {"ACH": 0}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 10}},
        {"command": "RDV1A", "map_key": "GUI"},
        {"command": "RDV1B", "map_key": "GUI"},
        {"command": "RDV1C", "map_key": "GUI"},
        {"command": "RDV1D", "map_key": "GUI"},
        {"command": "RDV2A", "map_key": "GUI"},
        {"command": "RDV2B", "map_key": "GUI"},
        {"command": "RDV2C", "map_key": "GUI"},
        {"command": "RDV2D", "map_key": "GUI"},
        {"command": "RDSTAT", "map_key": "GUI"},
        {"command": "RDFLAG", "map_key": "GUI"},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 500}},
    ]

    STAT_READ_CMDS = [
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 400}},
        {"command": "ADV", "arguments": {"VCH": 9}},
        {"command": "ADX", "arguments": {"ACH": 0}},
        {"command": "$DELAY_MS$", "arguments": {"Delay": 7}},
        {"command": "$SPI_WAKEUP$", "arguments": {"Wakeup Time": 10}},
        {"command": "RDCFGA", "arguments": {}, "map_key": "STAT"},
        {"command": "RDCFGB", "arguments": {}, "map_key": "STAT"},
        {"command": "RDSTAT", "map_key": "STAT"},
        {"command": "RDFLAG", "map_key": "STAT"},
    ]

    SAFETY_COMMAND_LISTS = {
        'Latent': [],
        'Loop': [],
    }