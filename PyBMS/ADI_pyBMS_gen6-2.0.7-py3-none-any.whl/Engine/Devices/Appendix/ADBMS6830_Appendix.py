# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
from dataclasses import dataclass
from copy import deepcopy

@dataclass
class ADBMS6830_Appendix:
    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V', 'C14V',
             'C15V', 'C16V']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V']
    FILTERED_CELLS = ['FC1V', 'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V',
                      'FC13V', 'FC14V', 'FC15V', 'FC16V']
    AVERAGED_CELLS = ['AC1V', 'AC2V', 'AC3V', 'AC4V', 'AC5V', 'AC6V', 'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V',
                      'AC13V', 'AC14V', 'AC15V', 'AC16V']
    OPEN_CELLS = ['S0V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V',
                  'S14V', 'S15V', 'S16V']
    SPINS = ['S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
             'S15V', 'S16V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V', 'VMV', 'VPV']
    STAT = ['VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV',
            'C4UV', 'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
            'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV', 'C16OV',
            'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT', 'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT', 'CS9FLT',
            'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'VA_OV', 'VA_UV',
            'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT',
            'SLEEP', 'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS']
    CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
           'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG', 'DCTO',
           'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12', 'DCC13',
           'DCC14', 'DCC15', 'DCC16']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    CONT_CELL_CONVERSION_CMDS = [
        {'command': 'WRCFGA', 'arguments': {'FC': 5}},
        {'command': 'WRCFGB', 'arguments': {'FC': 5}},
        {'command': 'ADCV', 'arguments': {'CONT': True}}
    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSV'}
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'SPINS'},
        {'command': 'RDCVB', 'map_key': 'SPINS'},
        {'command': 'RDCVC', 'map_key': 'SPINS'},
        {'command': 'RDCVD', 'map_key': 'SPINS'},
        {'command': 'RDCVE', 'map_key': 'SPINS'},
        {'command': 'RDCVF', 'map_key': 'SPINS'},
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S1V', 'function': '{C1V}-{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S2V', 'function': '{C2V}-{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S3V', 'function': '{C3V}-{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S4V', 'function': '{C4V}-{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S5V', 'function': '{C5V}-{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S6V', 'function': '{C6V}-{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S7V', 'function': '{C7V}-{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S8V', 'function': '{C8V}-{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S9V', 'function': '{C9V}-{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S10V', 'function': '{C10V}-{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S11V', 'function': '{C11V}-{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S12V', 'function': '{C12V}-{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S13V', 'function': '{C13V}-{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S14V', 'function': '{C14V}-{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S15V', 'function': '{C15V}-{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS',
         'arguments': {'result_name': 'S16V', 'function': '{C16V}-{S16V}'}},
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLCADC'}
    ]
    CONT_CELL_ADC_POLL_CMDS = [
        {'command': 'RDSTATC', 'map_key': 'COUNTERS_{}'},
        {'command': '$LOOP_CMD$',
         'arguments': {'loop_num': 0x00FF, 'mask': [0x00, 0x00, 0x1F, 0xFC, 0x00, 0x00, 0x00, 0x00], 'counter': 1}}
        # RDSTAD with STDR4 (CT) being monitored
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLSADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'}
    ]
    STAT_ADC_POLL_CMDS = [
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
        {'command': 'RDCVC', 'map_key': 'CELLS'},
        {'command': 'RDCVD', 'map_key': 'CELLS'},
        {'command': 'RDCVE', 'map_key': 'CELLS'},
        {'command': 'RDCVF', 'map_key': 'CELLS'},
    ]
    CONT_CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVB', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVC', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVD', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVE', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVF', 'map_key': 'CELLS_{}'},
    ]
    FILTERED_CELL_READ_CMDS = [
        {'command': 'RDFCA', 'map_key': 'FCELLS'},
        {'command': 'RDFCB', 'map_key': 'FCELLS'},
        {'command': 'RDFCC', 'map_key': 'FCELLS'},
        {'command': 'RDFCD', 'map_key': 'FCELLS'},
        {'command': 'RDFCE', 'map_key': 'FCELLS'},
        {'command': 'RDFCF', 'map_key': 'FCELLS'},
    ]
    AVERAGED_CELL_READ_CMDS = [
        {'command': 'RDACA', 'map_key': 'ACELLS'},
        {'command': 'RDACB', 'map_key': 'ACELLS'},
        {'command': 'RDACC', 'map_key': 'ACELLS'},
        {'command': 'RDACD', 'map_key': 'ACELLS'},
        {'command': 'RDACE', 'map_key': 'ACELLS'},
        {'command': 'RDACF', 'map_key': 'ACELLS'},
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
        {'command': 'RDAUXD', 'map_key': 'AUX'},

    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
        {'command': 'RDSTATD', 'map_key': 'STAT'},
        {'command': 'RDSTATE', 'map_key': 'STAT'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]

    # BCI_ANALOG_INIT_CMD_LIST = [
    #     {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    #     {'command': 'WRCFGA'},
    #     {'command': 'WRCFGB'},
    #     {'command': 'RDCFGA'},
    #     {'command': 'RDCFGB'},
    # ]
    # BCI_ANALOG_CMD_LIST = [
    #     {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
    #     {"command": "ADCV", "arguments": {"CONT": True}},
    # ]
    # BCI_ANALOG_LOOP_LIST = [
    #     {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
    #     {'command': 'RDFCVA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDFCVB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDFCVC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDFCVD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDFCVE', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDFCVF', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'ADSV'},
    #     {'command': 'PLSADC'},
    #     {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'ADAX'},
    #     {'command': 'PLAUX1'},
    #     {'command': 'PLAUX2'},
    #     {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATE', 'map_key': 'BCI_ANALOG'},
    # ]
    BCI_ANALOG_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'CLRFLAG'},
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'ADAX'},
        {'command': 'ADAX2'},
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'},
        {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDCVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDRAXD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATD', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED1', 'function': '{G1V}-{R_G1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED2', 'function': '{G2V}-{R_G2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED3', 'function': '{G3V}-{R_G3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED4', 'function': '{G4V}-{R_G4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED5', 'function': '{G5V}-{R_G5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED6', 'function': '{G6V}-{R_G6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED7', 'function': '{G7V}-{R_G7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED8', 'function': '{G8V}-{R_G8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED9', 'function': '{G9V}-{R_G9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'GPIO_RED10', 'function': '{G10V}-{R_G10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'EVEN_BASE_S16', 'function': '{S16V}'}},
        {'command': 'ADSV', 'arguments': {'OW': 1}},
        {'command': 'PLSADC'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'EVEN_S16', 'function': '{S16V}'}},
        {'command': 'ADSV', 'arguments': {'OW': 2}},
        {'command': 'PLSADC'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S1', 'function': '{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S2', 'function': '{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S3', 'function': '{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S4', 'function': '{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S5', 'function': '{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S6', 'function': '{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S7', 'function': '{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S8', 'function': '{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S9', 'function': '{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S10', 'function': '{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S11', 'function': '{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S12', 'function': '{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S13', 'function': '{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S14', 'function': '{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S15', 'function': '{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG', 'arguments': {'result': 'ODD_S16', 'function': '{S16V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN1', 'function': '{ODD_S1}/{EVEN_S1}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN3', 'function': '{ODD_S3}/{EVEN_S3}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN5', 'function': '{ODD_S5}/{EVEN_S5}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN7', 'function': '{ODD_S7}/{EVEN_S7}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN9', 'function': '{ODD_S9}/{EVEN_S9}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN12', 'function': '{ODD_S11}/{EVEN_S11}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN13', 'function': '{ODD_S13}/{EVEN_S13}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN15', 'function': '{ODD_S15}/{EVEN_S15}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN2', 'function': '{EVEN_S2}/{EVEN_BASE_S2}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN4', 'function': '{EVEN_S4}/{EVEN_BASE_S4}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN6', 'function': '{EVEN_S6}/{EVEN_BASE_S6}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN8', 'function': '{EVEN_S8}/{EVEN_BASE_S8}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN10', 'function': '{EVEN_S10}/{EVEN_BASE_S10}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN12', 'function': '{EVEN_S12}/{EVEN_BASE_S12}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN14', 'function': '{EVEN_S14}/{EVEN_BASE_S14}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'BCI_ANALOG',
         'arguments': {'result': 'OPEN16', 'function': '{EVEN_S16}/{EVEN_BASE_S16}'}},
    ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['FC1V', 'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V',
                          'FC12V', 'FC13V',
                          'FC14V', 'FC15V', 'FC16V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V',
                          'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
                          'S15V', 'S16V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                          'VMV', 'V+', 'VREF2', 'ITMP', 'VREF3', 'VA', 'VD', 'VR4K']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'RDCVC', 'map_key': 'GUI'},
        {'command': 'RDCVD', 'map_key': 'GUI'},
        {'command': 'RDCVE', 'map_key': 'GUI'},
        {'command': 'RDCVF', 'map_key': 'GUI'},
        {'command': 'RDSVA', 'map_key': 'GUI'},
        {'command': 'RDSVB', 'map_key': 'GUI'},
        {'command': 'RDSVC', 'map_key': 'GUI'},
        {'command': 'RDSVD', 'map_key': 'GUI'},
        {'command': 'RDSVE', 'map_key': 'GUI'},
        {'command': 'RDSVF', 'map_key': 'GUI'},
        {'command': 'RDACA', 'map_key': 'GUI'},
        {'command': 'RDACB', 'map_key': 'GUI'},
        {'command': 'RDACC', 'map_key': 'GUI'},
        {'command': 'RDACD', 'map_key': 'GUI'},
        {'command': 'RDACE', 'map_key': 'GUI'},
        {'command': 'RDACF', 'map_key': 'GUI'},
        {'command': 'RDFCA', 'map_key': 'GUI'},
        {'command': 'RDFCB', 'map_key': 'GUI'},
        {'command': 'RDFCC', 'map_key': 'GUI'},
        {'command': 'RDFCD', 'map_key': 'GUI'},
        {'command': 'RDFCE', 'map_key': 'GUI'},
        {'command': 'RDFCF', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'RDAUXD', 'map_key': 'GUI'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
        {'command': 'RDSTATD', 'map_key': 'GUI'},
        {'command': 'RDSTATE', 'map_key': 'GUI'},
    ]
    GUI_CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
               'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG',
               'DCTO',
               'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12',
               'DCC13',
               'DCC14', 'DCC15', 'DCC16']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                   'C14V', 'C15V', 'C16V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V',
                   'S11V', 'S12V', 'S13V', 'S14V', 'S15V', 'S16V', 'AC1V', 'AC2V', 'AC3V', 'AC4V', 'AC5V', 'AC6V',
                   'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V', 'AC13V', 'AC14V', 'AC15V', 'AC16V', 'FC1V',
                   'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V', 'FC13V',
                   'FC14V', 'FC15V', 'FC16V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                   'VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV',
                   'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
                   'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV',
                   'C16OV', 'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT', 'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT',
                   'CS9FLT', 'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'VA_OV',
                   'VA_UV', 'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT', 'SLEEP',
                   'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS'
                   ]
    SAFETY_COMMAND_LISTS = {
        'Latent': [],
        'Loop_Init': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'SRST'},
            {'command': 'WRCFGA'},
            {'command': 'WRCFGB'},
            {'command': 'WRPWM'},
            {'command': 'WRPWM2'},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 5000}},  # Let REF come up
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDCFGA', 'map_key': 'CFG'},
            {'command': 'RDCFGB', 'map_key': 'CFG'},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'OW': 0, 'RD': False}},  # Continuous Measurement
        ],
        'Loop': [
            # ========================= Cycle 1 ========================
            {'command': 'timer_start', 'arguments': {'timer': 0}},  # Timer for loop execution time
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT1'},
            {'command': 'RDFCB', 'map_key': 'FILT1'},
            {'command': 'RDFCC', 'map_key': 'FILT1'},
            {'command': 'RDFCD', 'map_key': 'FILT1'},
            {'command': 'RDFCE', 'map_key': 'FILT1'},
            {'command': 'RDFCF', 'map_key': 'FILT1'},
            {'command': 'UNSNAP'},
            {'command': 'SNAP'},
            {'command': 'CLRCELL'},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 2000}},
            {'command': 'RDCVA', 'map_key': 'SM6_INIT_0'},
            {'command': 'UNSNAP'},
            {'command': 'RDCVA', 'map_key': 'SM6_FINAL_0'},
            {'command': 'timer_stop', 'map_key': 'cycle1_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 6424}},  # Margin, change based on CMC count
            # ========================= Cycle 2 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT2'},
            {'command': 'RDFCB', 'map_key': 'FILT2'},
            {'command': 'RDFCC', 'map_key': 'FILT2'},
            {'command': 'RDFCD', 'map_key': 'FILT2'},
            {'command': 'RDFCE', 'map_key': 'FILT2'},
            {'command': 'RDFCF', 'map_key': 'FILT2'},
            {'command': 'UNSNAP'},
            {'command': 'CLRAUX', 'arguments': {}},
            {'command': 'ADAX', 'arguments': {}},
            {'command': 'ADAX2', 'arguments': {}},
            {'command': 'ADSV', 'arguments': {'CONT': True, 'DC': False, 'OW': 0}},
            {'command': 'timer_stop', 'map_key': 'cycle2_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 8687}},  # Margin, change based on CMC count
            # ========================= Cycle 3 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT3'},
            {'command': 'RDFCB', 'map_key': 'FILT3'},
            {'command': 'RDFCC', 'map_key': 'FILT3'},
            {'command': 'RDFCD', 'map_key': 'FILT3'},
            {'command': 'RDFCE', 'map_key': 'FILT3'},
            {'command': 'RDFCF', 'map_key': 'FILT3'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle3_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 8911}},  # Margin, change based on CMC count
            # ========================= Cycle 4 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT4'},
            {'command': 'RDFCB', 'map_key': 'FILT4'},
            {'command': 'RDFCC', 'map_key': 'FILT4'},
            {'command': 'RDFCD', 'map_key': 'FILT4'},
            {'command': 'RDFCE', 'map_key': 'FILT4'},
            {'command': 'RDFCF', 'map_key': 'FILT4'},
            {'command': 'UNSNAP'},
            # {'command': "$DELAY_US$", 'arguments': {'Delay': 1000}},  # Optional delay for spin conversion completion
            {'command': 'SNAP'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'DC': False, 'OW': 1}},
            {'command': 'RDSVA', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'RDSVB', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'RDSVC', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'RDSVD', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'RDSVE', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'RDSVF', 'map_key': 'OPEN_WIRE_EVEN_BASE'},
            {'command': 'CLRSPIN'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle4_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 7748}},  # Margin, change based on CMC count
            # ========================= Cycle 5 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT5'},
            {'command': 'RDFCB', 'map_key': 'FILT5'},
            {'command': 'RDFCC', 'map_key': 'FILT5'},
            {'command': 'RDFCD', 'map_key': 'FILT5'},
            {'command': 'RDFCE', 'map_key': 'FILT5'},
            {'command': 'RDFCF', 'map_key': 'FILT5'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle5_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 8909}},  # Margin, change based on CMC count
            # ========================= Cycle 6 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDSVA', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'RDSVB', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'RDSVC', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'RDSVD', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'RDSVE', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'RDSVF', 'map_key': 'OPEN_WIRE_EVEN'},
            {'command': 'CLRSPIN'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'DC': False, 'OW': 2}},
            {'command': 'RDFCA', 'map_key': 'FILT6'},
            {'command': 'RDFCB', 'map_key': 'FILT6'},
            {'command': 'RDFCC', 'map_key': 'FILT6'},
            {'command': 'RDFCD', 'map_key': 'FILT6'},
            {'command': 'RDFCE', 'map_key': 'FILT6'},
            {'command': 'RDFCF', 'map_key': 'FILT6'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle6_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 7860}},  # Margin, change based on CMC count
            # ========================= Cycle 7 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT7'},
            {'command': 'RDFCB', 'map_key': 'FILT7'},
            {'command': 'RDFCC', 'map_key': 'FILT7'},
            {'command': 'RDFCD', 'map_key': 'FILT7'},
            {'command': 'RDFCE', 'map_key': 'FILT7'},
            {'command': 'RDFCF', 'map_key': 'FILT7'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle7_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 8910}},  # Margin, change based on CMC count
            # ========================= Cycle 8 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDSVA', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDSVB', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDSVC', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDSVD', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDSVE', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDSVF', 'map_key': 'OPEN_WIRE_ODD'},
            {'command': 'RDFCA', 'map_key': 'FILT8'},
            {'command': 'RDFCB', 'map_key': 'FILT8'},
            {'command': 'RDFCC', 'map_key': 'FILT8'},
            {'command': 'RDFCD', 'map_key': 'FILT8'},
            {'command': 'RDFCE', 'map_key': 'FILT8'},
            {'command': 'RDFCF', 'map_key': 'FILT8'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle8_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 7973}},  # Margin, change based on CMC count
            # ========================= Cycle 9 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT9'},
            {'command': 'RDFCB', 'map_key': 'FILT9'},
            {'command': 'RDFCC', 'map_key': 'FILT9'},
            {'command': 'RDFCD', 'map_key': 'FILT9'},
            {'command': 'RDFCE', 'map_key': 'FILT9'},
            {'command': 'RDFCF', 'map_key': 'FILT9'},
            {'command': 'RDAUXA', 'map_key': 'AUX'},
            {'command': 'RDAUXB', 'map_key': 'AUX'},
            {'command': 'RDAUXC', 'map_key': 'AUX'},
            {'command': 'RDAUXD', 'map_key': 'AUX'},
            {'command': 'RDRAXA', 'map_key': 'AUX'},
            {'command': 'RDRAXB', 'map_key': 'AUX'},
            {'command': 'RDRAXC', 'map_key': 'AUX'},
            {'command': 'RDRAXD', 'map_key': 'AUX'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle9_time', 'arguments': {'timer': 1}},
            {'command': "$DELAY_US$", 'arguments': {'Delay': 7660}},  # Margin, change based on CMC count
            # ========================= Cycle 10 ========================
            {'command': 'timer_start', 'arguments': {'timer': 1}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'RDFCA', 'map_key': 'FILT10'},
            {'command': 'RDFCB', 'map_key': 'FILT10'},
            {'command': 'RDFCC', 'map_key': 'FILT10'},
            {'command': 'RDFCD', 'map_key': 'FILT10'},
            {'command': 'RDFCE', 'map_key': 'FILT10'},
            {'command': 'RDFCF', 'map_key': 'FILT10'},
            {'command': 'RDSTATA', 'map_key': 'STAT'},
            {'command': 'RDSTATB', 'map_key': 'STAT'},
            {'command': 'UNSNAP'},
            {'command': 'SNAP'},
            {'command': 'RDSTATC', 'map_key': 'STAT'},
            {'command': 'CLRFLAG'},
            {'command': 'RDSTATD', 'map_key': 'STAT'},
            {'command': 'CLOVUV'},
            {'command': 'UNSNAP'},
            {'command': 'timer_stop', 'map_key': 'cycle10_time', 'arguments': {'timer': 1}},
        ],
        'Cell_Open_Wire': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0}},  # Redundant Measurement
            {'command': 'PLSADC'},
            {'command': 'RDSVA', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'RDSVB', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'RDSVC', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'RDSVD', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'RDSVE', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'RDSVF', 'map_key': 'CELL_OPEN_WIRE_BASE_EVEN'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 1}},
            {'command': 'PLSADC'},
            {'command': 'RDSVA', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'RDSVB', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'RDSVC', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'RDSVD', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'RDSVE', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'RDSVF', 'map_key': 'CELL_OPEN_WIRE_EVENS'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 2}},
            {'command': 'PLSADC'},
            {'command': 'RDSVA', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
            {'command': 'RDSVB', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
            {'command': 'RDSVC', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
            {'command': 'RDSVD', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
            {'command': 'RDSVE', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
            {'command': 'RDSVF', 'map_key': 'CELL_OPEN_WIRE_ODDS'},
        ],
        'Aux_Open_Wire': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'CVMIN': 0, 'SOAKON': True}},  # Provide OWA, OWRNG value in kwargs
            {'command': 'ADAX'},
            {'command': 'PLAUX1'},
            {'command': 'RDAUXA', 'map_key': 'AUX_OPEN_ADAX'},
            {'command': 'RDAUXB', 'map_key': 'AUX_OPEN_ADAX'},
            {'command': 'RDAUXC', 'map_key': 'AUX_OPEN_ADAX'},
            {'command': 'RDAUXD', 'map_key': 'AUX_OPEN_ADAX'},
            {'command': 'ADAX', 'arguments': {'OW_B': True, 'PUP': False}},
            {'command': 'PLAUX1'},
            {'command': 'RDAUXA', 'map_key': 'AUX_OPEN_PD'},
            {'command': 'RDAUXB', 'map_key': 'AUX_OPEN_PD'},
            {'command': 'RDAUXC', 'map_key': 'AUX_OPEN_PD'},
            {'command': 'RDAUXD', 'map_key': 'AUX_OPEN_PD'},
            {'command': 'ADAX', 'arguments': {'OW_B': True, 'PUP': True}},
            {'command': 'PLAUX1'},
            {'command': 'RDAUXA', 'map_key': 'AUX_OPEN_PU'},
            {'command': 'RDAUXB', 'map_key': 'AUX_OPEN_PU'},
            {'command': 'RDAUXC', 'map_key': 'AUX_OPEN_PU'},
            {'command': 'RDAUXD', 'map_key': 'AUX_OPEN_PU'},
        ],
    }
    LIMITS = {
        'Verification': {},
        'Safety': {
            'C1V': {
                'max': 4.2,
                'min': 3.75
            },
            'C2V': {
                'max': 4.2,
                'min': 3.75
            },
            'C3V': {
                'max': 4.2,
                'min': 3.75
            },
            'C4V': {
                'max': 4.2,
                'min': 3.75
            },
            'C5V': {
                'max': 4.2,
                'min': 3.75
            },
            'C6V': {
                'max': 4.2,
                'min': 3.75
            },
            'C7V': {
                'max': 4.2,
                'min': 3.75
            },
            'C8V': {
                'max': 4.2,
                'min': 3.75
            },
            'C9V': {
                'max': 4.2,
                'min': 3.75
            },
            'C10V': {
                'max': 4.2,
                'min': 3.75
            },
            'C11V': {
                'max': 4.2,
                'min': 3.75
            },
            'C12V': {
                'max': 4.2,
                'min': 3.75
            },
            'C13V': {
                'max': 4.2,
                'min': 3.75
            },
            'C14V': {
                'max': 4.2,
                'min': 3.75
            },
            'C15V': {
                'max': 4.2,
                'min': 3.75
            },
            'C16V': {
                'max': 4.2,
                'min': 3.75
            },
            'CELL_OPEN_WIRE_THRESHOLD': {
                'value': 0.85,
            },
            'AUX_OPEN_WIRE_THRESHOLD': {
                'value': 0.600,
            },
            'AC1V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC2V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC3V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC4V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC5V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC6V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC7V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC8V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC9V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC10V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC11V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC12V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC13V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC14V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC15V': {
                'max': 4.2,
                'min': 3.75
            },
            'AC16V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC1V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC2V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC3V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC4V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC5V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC6V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC7V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC8V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC9V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC10V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC11V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC12V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC13V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC14V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC15V': {
                'max': 4.2,
                'min': 3.75
            },
            'FC16V': {
                'max': 4.2,
                'min': 3.75
            },
        },
        'Manufacturing': {},
        'Loose': {}
    }
    OPEN_WIRE_LIMIT = 0.85
    ADC_OVERLAP_LIMIT = 0.0025
    C_CODE_EXPORT = {
        'measure_cells': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'WRCFGA'},
                {'command': 'ADCV'},
                {'command': 'PLCADC'},
                {'command': 'RDCVA'},
                {'command': 'RDCVB'},
                {'command': 'RDCVC'},
                {'command': 'RDCVD'},
                {'command': 'RDCVE'},
                {'command': 'RDCVF'},
            ],
            'output': ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                       'C14V', 'C15V', 'C16V']
        },
        'write_read_config': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'WRCFGA'},
                {'command': 'RDCFGA'},
            ],
            'output': ['REFON', 'FC', 'CCNT']
        },
        'lpcm': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'CMHB'},
                {'command': 'RDCFGA'},
            ],
            'output': ['REFON', 'FC', 'CCNT']
        },
        'start_adcs': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}}
            ],
        },
        'read_data': {
            'commands': [
                {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
                {'command': 'RDCVALL'},
            ],
        },
        'print_data': {
            'output': ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                       'C14V', 'C15V', 'C16V', 'pec_error']
        },

    }

    @staticmethod
    def decode_safety_loop(result_dict, ic_num, safety_metric=None, limit_override=None):
        limits = deepcopy(ADBMS6830.LIMITS['Safety'])
        if limit_override:
            limits.update(limit_override)
        global_status = ADBMS6830.PASS
        safety_results = {}
        if 'Safety_Results' not in result_dict:
            result_dict['Safety_Results'] = []
        for metric in ADBMS6830.SAFETY_COMMAND_LISTS:
            if safety_metric:
                if metric != safety_metric:
                    continue
            safety_results[metric] = {'Result': None}
            if metric == 'Cell_Open_Wire':
                safety_results[metric]['Opens'] = []
                safety_results[metric]['Delta'] = []
                safety_results[metric]['Error Messages'] = []
                i = 0
                #  Gather open wire measurements into one array
                open_data = {}
                base_data = {}
                for spin in ['S2V', 'S4V', 'S6V', 'S8V', 'S10V', 'S12V', 'S14V', 'S16V']:
                    open_data[spin] = result_dict['CELL_OPEN_WIRE_EVENS'][ic_num][spin]
                    base_data[spin] = result_dict['CELL_OPEN_WIRE_BASE_EVEN'][ic_num][spin]
                for spin in ['S1V', 'S3V', 'S5V', 'S7V', 'S9V', 'S11V', 'S13V', 'S15V']:
                    open_data[spin] = result_dict['CELL_OPEN_WIRE_ODDS'][ic_num][spin]
                    base_data[spin] = result_dict['CELL_OPEN_WIRE_EVENS'][ic_num][spin]
                while i < len(ADBMS6830.SPINS):
                    spin = ADBMS6830.SPINS[i]
                    if i == 0:
                        safety_results[metric]['Delta'].append(open_data[spin])  # Once for C0, once for C1
                        if open_data[spin] < 0.010:
                            safety_results[metric]['Opens'].append('S0V')
                            safety_results[metric]['Error Messages'].append(
                                'S0V open detected. S1V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[metric]['Delta'].append(
                                (open_data[spin] / base_data[spin]) * 100)  # Once for C0, once for C1
                            i += 1
                            continue
                    if i == 15:
                        if open_data[spin] < 0.010:
                            safety_results[metric]['Opens'].append('S16V')
                            safety_results[metric]['Error Messages'].append(
                                'S16V open detected. S16V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[metric]['Delta'].append(open_data[spin])
                            i += 1
                            continue
                    safety_results[metric]['Delta'].append((open_data[spin] / base_data[spin]) * 100)
                    if base_data[spin] < 0:
                        if abs(open_data[spin]) < abs(base_data[spin]) * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                            safety_results[metric]['Opens'].append(spin)
                            safety_results[metric]['Error Messages'].append(
                                '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                                    spin, spin, open_data[spin], base_data[spin],
                                    limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                            if i < 15:
                                safety_results[metric]['Delta'].append(
                                    (open_data[ADBMS6830.SPINS[i]] / base_data[ADBMS6830.SPINS[i]]) * 100)
                            i += 1
                    elif open_data[spin] < base_data[spin] * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                        safety_results[metric]['Opens'].append(spin)
                        safety_results[metric]['Error Messages'].append(
                            '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                                spin, spin, open_data[spin], base_data[spin],
                                limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                        if i < 15:
                            safety_results[metric]['Delta'].append(
                                (open_data[ADBMS6830.SPINS[i]] / base_data[ADBMS6830.SPINS[i]]) * 100)
                        i += 1

                    i += 1
                if len(safety_results[metric]['Opens']) != 0:
                    safety_results[metric]['Result'] = ADBMS6830.FAIL
                    global_status = ADBMS6830.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6830.PASS
            elif metric == 'Loop':
                safety_results[metric]['Error Messages'] = []
                # Check voltages for OV/UV
                for average_map_key in ['FILT1', 'FILT2', 'FILT3', 'FILT4', 'FILT5', 'FILT6', 'FILT7', 'FILT8', 'FILT9',
                                        'FILT10']:
                    for cell in ADBMS6830.FILTERED_CELLS:
                        if result_dict[average_map_key][ic_num][cell] > limits[cell]['max']:
                            safety_results[metric]['Error Messages'].append(
                                '%s Cell [%s] voltage [%s] is over voltage limit [%s]' % (
                                    average_map_key, cell, result_dict[average_map_key][ic_num][cell],
                                    limits[cell]['max']))
                        if result_dict[average_map_key][ic_num][cell] < limits[cell]['min']:
                            safety_results[metric]['Error Messages'].append(
                                '%s Cell [%s] voltage [%s] is under voltage limit [%s]' % (
                                    average_map_key, cell, result_dict[average_map_key][ic_num][cell],
                                    limits[cell]['min']))
            elif metric == 'Aux_Open_Wire':
                safety_results[metric]['Opens'] = []
                safety_results[metric]['Delta'] = []
                safety_results[metric]['Error Messages'] = []
                i = 0
                while i < len(ADBMS6830.GPIOS):
                    gpio = ADBMS6830.GPIOS[i]
                    # Just check for #3,5,6,7,8 error for now, will implement the rest later
                    if result_dict['AUX_OPEN_ADAX'][ic_num][gpio] >= 2.75:
                        delta = abs(
                            result_dict['AUX_OPEN_PD'][ic_num][gpio] - result_dict['AUX_OPEN_ADAX'][ic_num][gpio])
                    else:
                        delta = abs(
                            result_dict['AUX_OPEN_PU'][ic_num][gpio] - result_dict['AUX_OPEN_ADAX'][ic_num][gpio])
                    safety_results[metric]['Delta'].append(delta)
                    if delta > limits['AUX_OPEN_WIRE_THRESHOLD']['value']:
                        safety_results[metric]['Opens'].append(gpio)
                        safety_results[metric]['Error Messages'].append(
                            '[%s] delta [%s] is greater than GPIO open wire limit [%s]' % (
                                gpio, delta, limits['AUX_OPEN_WIRE_THRESHOLD']['value']))
                    elif delta < 0.03:
                        safety_results[metric]['Opens'].append(gpio)
                        safety_results[metric]['Error Messages'].append(
                            '[%s] delta [%s] is less than GPIO open wire limit [0.03] current source is stuck on/off' % (
                                gpio, delta))
                    i += 1
                if len(safety_results[metric]['Opens']) != 0:
                    safety_results[metric]['Result'] = ADBMS6830.FAIL
                    global_status = ADBMS6830.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6830.PASS
        if len(result_dict['Safety_Results']) <= ic_num:
            result_dict['Safety_Results'].append(safety_results)
        else:
            result_dict['Safety_Results'][ic_num].update(safety_results)
        return global_status
