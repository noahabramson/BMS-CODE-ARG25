# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
# Using: 5-10-22

from dataclasses import dataclass
import Engine.Devices.BMS_Config as bmsbase
import Engine.Devices.ADBMS_GEN6 as gen6base

@dataclass
class ADBMS6832_Appendix:
    CELLS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V', 'C14V',
             'C15V', 'C16V', 'C17V', 'C18V']
    GPIOS = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V', 'GA11V', 'GA12V']
    FILTERED_CELLS = ['FC1V', 'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V',
                      'FC13V', 'FC14V', 'FC15V', 'FC16V', 'FC17V', 'FC18V']
    AVERAGED_CELLS = ['AC1V', 'AC2V', 'AC3V', 'AC4V', 'AC5V', 'AC6V', 'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V',
                      'AC13V', 'AC14V', 'AC15V', 'AC16V', 'AC17V', 'AC18V']
    OPEN_CELLS = ['S0V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V',
                  'S14V', 'S15V', 'S16V', 'S17V', 'S18V']
    SPINS = ['S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
             'S15V', 'S16V', 'S17V', 'S18V']
    AUX = ['G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V', 'GA11V', 'GA12V', 'VMV', 'VPV']
    STAT = ['VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV',
            'C4UV', 'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
            'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV', 'C16OV',
            'C17UV', 'C17OV', 'C18UV', 'C18OV',
            'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT', 'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT', 'CS9FLT',
            'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'CS17FLT', 'CS18FLT',
            'VA_OV', 'VA_UV',
            'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT',
            'SLEEP', 'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS']
    CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
           'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG', 'DCTO',
           'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12', 'DCC13',
           'DCC14', 'DCC15', 'DCC16', 'DCC17', 'DCC18']
    CFG_WRITE_CMDS = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
    ]
    CFG_READ_CMDS = [
        {'command': 'RDCFGA', 'map_key': 'CONFIG'},
        {'command': 'RDCFGB', 'map_key': 'CONFIG'},
    ]
    CELL_CONVERSION_CMDS = [
        {'command': 'ADCV'}
    ]
    CONT_CELL_CONVERSION_CMDS = [
        {'command': 'WRCFGA', 'arguments': {'FC': 5}},
        {'command': 'WRCFGB', 'arguments': {'FC': 5}},
        {'command': 'ADCV', 'arguments': {'CONT': True}}
    ]
    SPIN_CONVERSION_CMDS = [
        {'command': 'ADSV'}
    ]
    AUX_CONVERSION_CMDS = [
        {'command': 'ADAX'}
    ]
    STAT_CONVERSION_CMDS = [
    ]
    LEAKAGE_CMDS = [
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'SPINS'},
        {'command': 'RDCVB', 'map_key': 'SPINS'},
        {'command': 'RDCVC', 'map_key': 'SPINS'},
        {'command': 'RDCVD', 'map_key': 'SPINS'},
        {'command': 'RDCVE', 'map_key': 'SPINS'},
        {'command': 'RDCVF', 'map_key': 'SPINS'},
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S1V', 'function': '{C1V}-{S1V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S2V', 'function': '{C2V}-{S2V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S3V', 'function': '{C3V}-{S3V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S4V', 'function': '{C4V}-{S4V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S5V', 'function': '{C5V}-{S5V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S6V', 'function': '{C6V}-{S6V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S7V', 'function': '{C7V}-{S7V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S8V', 'function': '{C8V}-{S8V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S9V', 'function': '{C9V}-{S9V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S10V', 'function': '{C10V}-{S10V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S11V', 'function': '{C11V}-{S11V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S12V', 'function': '{C12V}-{S12V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S13V', 'function': '{C13V}-{S13V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S14V', 'function': '{C14V}-{S14V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S15V', 'function': '{C15V}-{S15V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S16V', 'function': '{C16V}-{S16V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S17V', 'function': '{C17V}-{S17V}'}},
        {'command': '$MATH_EVAL$', 'map_key': 'SPINS', 'arguments': {'result_name': 'S18V', 'function': '{C18V}-{S18V}'}},
    ]
    CELL_ADC_POLL_CMDS = [
        {'command': 'PLCADC'}
    ]
    CONT_CELL_ADC_POLL_CMDS = [
        {'command': 'RDSTATC', 'map_key': 'COUNTERS_{}'},
        {'command': '$LOOP_CMD$',
         'arguments': {'loop_num': 0x00FF, 'mask': [0x00, 0x00, 0x1F, 0xFC, 0x00, 0x00, 0x00, 0x00], 'counter': 1}}
        # RDSTAD with STDR4 (CT) being monitored
    ]
    SPIN_ADC_POLL_CMDS = [
        {'command': 'PLSADC'}
    ]
    AUX_ADC_POLL_CMDS = [
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'}
    ]
    STAT_ADC_POLL_CMDS = [
    ]
    ADC_POLL_CMDS = [
        {'command': 'PLADC'}
    ]
    CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS'},
        {'command': 'RDCVB', 'map_key': 'CELLS'},
        {'command': 'RDCVC', 'map_key': 'CELLS'},
        {'command': 'RDCVD', 'map_key': 'CELLS'},
        {'command': 'RDCVE', 'map_key': 'CELLS'},
        {'command': 'RDCVF', 'map_key': 'CELLS'},
    ]
    CONT_CELL_READ_CMDS = [
        {'command': 'RDCVA', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVB', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVC', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVD', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVE', 'map_key': 'CELLS_{}'},
        {'command': 'RDCVF', 'map_key': 'CELLS_{}'},
    ]
    FILTERED_CELL_READ_CMDS = [
        {'command': 'RDFCA', 'map_key': 'FCELLS'},
        {'command': 'RDFCB', 'map_key': 'FCELLS'},
        {'command': 'RDFCC', 'map_key': 'FCELLS'},
        {'command': 'RDFCD', 'map_key': 'FCELLS'},
        {'command': 'RDFCE', 'map_key': 'FCELLS'},
        {'command': 'RDFCF', 'map_key': 'FCELLS'},
    ]
    AVERAGED_CELL_READ_CMDS = [
        {'command': 'RDACA', 'map_key': 'ACELLS'},
        {'command': 'RDACB', 'map_key': 'ACELLS'},
        {'command': 'RDACC', 'map_key': 'ACELLS'},
        {'command': 'RDACD', 'map_key': 'ACELLS'},
        {'command': 'RDACE', 'map_key': 'ACELLS'},
        {'command': 'RDACF', 'map_key': 'ACELLS'},
    ]
    SPIN_READ_CMDS = [
        {'command': 'RDSVA', 'map_key': 'SPINS'},
        {'command': 'RDSVB', 'map_key': 'SPINS'},
        {'command': 'RDSVC', 'map_key': 'SPINS'},
        {'command': 'RDSVD', 'map_key': 'SPINS'},
        {'command': 'RDSVE', 'map_key': 'SPINS'},
        {'command': 'RDSVF', 'map_key': 'SPINS'},
    ]
    AUX_READ_CMDS = [
        {'command': 'RDAUXA', 'map_key': 'AUX'},
        {'command': 'RDAUXB', 'map_key': 'AUX'},
        {'command': 'RDAUXC', 'map_key': 'AUX'},
        {'command': 'RDAUXD', 'map_key': 'AUX'},
        {'command': 'RDAUXE', 'map_key': 'AUX'},

    ]
    STAT_READ_CMDS = [
        {'command': 'RDSTATA', 'map_key': 'STAT'},
        {'command': 'RDSTATB', 'map_key': 'STAT'},
        {'command': 'RDSTATC', 'map_key': 'STAT'},
        {'command': 'RDSTATD', 'map_key': 'STAT'},
        {'command': 'RDSTATE', 'map_key': 'STAT'},
    ]
    WAKEUP_CMDS = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
    ]
    SID_READ_CMDS = [
        {'command': 'RDSID', 'map_key': 'SID'},
    ]
    BCI_COM_CMD_LIST = [
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'BCI_COM'},
        {'command': 'RDCFGB', 'map_key': 'BCI_COM'},
    ]

    BCI_ANALOG_INIT_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA'},
        {'command': 'RDCFGB'},
    ]
    BCI_ANALOG_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
        {"command": "ADCV", "arguments": {"CONT": True}},
    ]
    BCI_ANALOG_LOOP_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
        {'command': 'RDFCVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDFCVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDFCVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDFCVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDFCVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDFCVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADSV'},
        {'command': 'PLSADC'},
        {'command': 'RDSVA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVE', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSVF', 'map_key': 'BCI_ANALOG'},
        {'command': 'ADAX'},
        {'command': 'PLAUX1'},
        {'command': 'PLAUX2'},
        {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDAUXD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATD', 'map_key': 'BCI_ANALOG'},
        {'command': 'RDSTATE', 'map_key': 'BCI_ANALOG'},
    ]
    # BCI_ANALOG_CMD_LIST = [
    #     {'command': 'WRCFGA'},
    #     {'command': 'WRCFGB'},
    #     {'command': 'RDCFGA'},
    #     {'command': 'RDCFGB'},
    #     {'command': 'ADCV'},
    #     {'command': 'PLCADC'},
    #     {'command': 'RDCVA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDCVB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDCVC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDCVD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDCVE', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDCVF', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'ADAX'},
    #     {'command': 'PLAUX1'},
    #     {'command': 'PLAUX2'},
    #     {'command': 'RDAUXA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDAUXD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATA', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATB', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATC', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATD', 'map_key': 'BCI_ANALOG'},
    #     {'command': 'RDSTATE', 'map_key': 'BCI_ANALOG'},
    # ]
    BCI_COM_MAP_KEY = 'BCI_COM'
    BCI_ANALOG_MAP_KEY = 'BCI_ANALOG'
    BCI_ANALOG_METRICS = ['FC1V', 'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V', 'FC13V',
                          'FC14V', 'FC15V', 'FC16V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V', 'S9V', 'S10V', 'S11V', 'S12V', 'S13V', 'S14V',
                          'S15V', 'S16V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                          'VMV', 'V+', 'VREF2', 'ITMP', 'VREF3', 'VA', 'VD', 'VR4K']
    GUI_LOOP_CMD_LIST = [
        {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
        {'command': 'WRCFGA'},
        {'command': 'WRCFGB'},
        {'command': 'RDCFGA', 'map_key': 'GUI'},
        {'command': 'RDCFGB', 'map_key': 'GUI'},
        {'command': 'ADCV', 'arguments': {'RD': True}},
        {'command': 'PLSADC'},
        {'command': 'RDCVA', 'map_key': 'GUI'},
        {'command': 'RDCVB', 'map_key': 'GUI'},
        {'command': 'RDCVC', 'map_key': 'GUI'},
        {'command': 'RDCVD', 'map_key': 'GUI'},
        {'command': 'RDCVE', 'map_key': 'GUI'},
        {'command': 'RDCVF', 'map_key': 'GUI'},
        {'command': 'RDSVA', 'map_key': 'GUI'},
        {'command': 'RDSVB', 'map_key': 'GUI'},
        {'command': 'RDSVC', 'map_key': 'GUI'},
        {'command': 'RDSVD', 'map_key': 'GUI'},
        {'command': 'RDSVE', 'map_key': 'GUI'},
        {'command': 'RDSVF', 'map_key': 'GUI'},
        {'command': 'RDACA', 'map_key': 'GUI'},
        {'command': 'RDACB', 'map_key': 'GUI'},
        {'command': 'RDACC', 'map_key': 'GUI'},
        {'command': 'RDACD', 'map_key': 'GUI'},
        {'command': 'RDACE', 'map_key': 'GUI'},
        {'command': 'RDACF', 'map_key': 'GUI'},
        {'command': 'RDFCA', 'map_key': 'GUI'},
        {'command': 'RDFCB', 'map_key': 'GUI'},
        {'command': 'RDFCC', 'map_key': 'GUI'},
        {'command': 'RDFCD', 'map_key': 'GUI'},
        {'command': 'RDFCE', 'map_key': 'GUI'},
        {'command': 'RDFCF', 'map_key': 'GUI'},
        {'command': 'ADAX'},
        {'command': 'PLAUX'},
        {'command': 'PLAUX2'},
        {'command': 'RDAUXA', 'map_key': 'GUI'},
        {'command': 'RDAUXB', 'map_key': 'GUI'},
        {'command': 'RDAUXC', 'map_key': 'GUI'},
        {'command': 'RDAUXD', 'map_key': 'GUI'},
        {'command': 'RDAUXE', 'map_key': 'GUI'},
        {'command': 'RDSTATA', 'map_key': 'GUI'},
        {'command': 'RDSTATB', 'map_key': 'GUI'},
        {'command': 'RDSTATC', 'map_key': 'GUI'},
        {'command': 'RDSTATD', 'map_key': 'GUI'},
        {'command': 'RDSTATE', 'map_key': 'GUI'},
    ]
    GUI_CFG = ['REFON', 'CTH', 'COMM_BK', 'FLAG_D', 'SOAKON', 'OWRNG', 'OWA', 'GPO1', 'GPO2', 'GPO3', 'GPO4', 'GPO5',
               'GPO6', 'GPO7', 'GPO8', 'GPO9', 'GPO10', 'MUTE_ST', 'SNAP_ST', 'FC', 'VUV', 'VOV', 'DTMEN', 'DTRNG',
               'DCTO',
               'DCC1', 'DCC2', 'DCC3', 'DCC4', 'DCC5', 'DCC6', 'DCC7', 'DCC8', 'DCC9', 'DCC10', 'DCC11', 'DCC12',
               'DCC13',
               'DCC14', 'DCC15', 'DCC16', 'DCC17', 'DCC18']
    GUI_METRICS = ['C1V', 'C2V', 'C3V', 'C4V', 'C5V', 'C6V', 'C7V', 'C8V', 'C9V', 'C10V', 'C11V', 'C12V', 'C13V',
                   'C14V', 'C15V', 'C16V', 'C17V', 'C18V', 'S1V', 'S2V', 'S3V', 'S4V', 'S5V', 'S6V', 'S7V', 'S8V',
                   'S9V', 'S10V',
                   'S11V', 'S12V', 'S13V', 'S14V', 'S15V', 'S16V', 'S17V', 'S18V', 'AC1V', 'AC2V', 'AC3V', 'AC4V',
                   'AC5V', 'AC6V',
                   'AC7V', 'AC8V', 'AC9V', 'AC10V', 'AC11V', 'AC12V', 'AC13V', 'AC14V', 'AC15V', 'AC16V', 'AC17V', 'AC18V',
                   'FC1V',
                   'FC2V', 'FC3V', 'FC4V', 'FC5V', 'FC6V', 'FC7V', 'FC8V', 'FC9V', 'FC10V', 'FC11V', 'FC12V', 'FC13V',
                   'FC14V', 'FC15V', 'FC16V', 'FC17V', 'FC18V', 'G1V', 'G2V', 'G3V', 'G4V', 'G5V', 'G6V', 'G7V', 'G8V', 'G9V', 'G10V',
                   'VREF2', 'ITMP', 'VA', 'VD', 'VRES', 'C1OV', 'C1UV', 'C2OV', 'C2UV', 'C3OV', 'C3UV', 'C4OV', 'C4UV',
                   'C5OV', 'C5UV', 'C6OV', 'C6UV', 'C7OV', 'C7UV', 'C8OV', 'C8UV', 'C9OV', 'C9UV', 'C10OV', 'C10UV',
                   'C11OV', 'C11UV', 'C12OV', 'C12UV', 'C13OV', 'C13UV', 'C14OV', 'C14UV', 'C15OV', 'C15UV', 'C16UV',
                   'C16OV', 'C17UV', 'C17OV', 'C18UV', 'C18OV', 'OC_CNTR', 'CS1FLT', 'CS2FLT', 'CS3FLT', 'CS4FLT',
                   'CS5FLT', 'CS6FLT', 'CS7FLT', 'CS8FLT',
                   'CS9FLT', 'CS10FLT', 'CS11FLT', 'CS12FLT', 'CS13FLT', 'CS14FLT', 'CS15FLT', 'CS16FLT', 'CS17FLT', 'CS18FLT', 'VA_OV',
                   'VA_UV', 'VD_OV', 'VD_UV', 'CED', 'CMED', 'SED', 'SMED', 'VDE', 'VDEL', 'COMP', 'SPIFLT', 'SLEEP',
                   'THSD', 'TMODCHK', 'OSCCHK', 'CT', 'CTS'
                   ]
    SAFETY_COMMAND_LISTS = {
        'SM_AUXREGS_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': False}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATA', 'map_key': 'SM_AUXREGS_DIAG1'},
            {'command': 'RDSTATB', 'map_key': 'SM_AUXREGS_DIAG1'},
            {'command': 'CLRAUX'},
            {'command': 'RDSTATA', 'map_key': 'SM_AUXREGS_DIAG2'},
            {'command': 'RDSTATB', 'map_key': 'SM_AUXREGS_DIAG2'},
        ],
        'SM_CELL_OWD': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x0}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD1'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x1}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD2'},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD3'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD3'},
        ],
        'SM_CELL_OWD_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
                'CL_CS17FLT': True,
                'CL_CS18FLT': True,
            }},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'CTH': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': False, 'OW': 0x0}},
            {'command': 'ADSV', 'arguments': {'CONT': True, 'OW': 0x1}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 16}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDACA', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACB', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACD', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACE', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDACF', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG1'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
                'CL_CS17FLT': True,
                'CL_CS18FLT': True,
            }},
            {'command': 'ADSV', 'arguments': {'CONT': True, 'OW': 0x2}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 16}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDACA', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACB', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACD', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACE', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDACF', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVA', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVB', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVD', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVE', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSVF', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG2'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
                'CL_CS17FLT': True,
                'CL_CS18FLT': True,
            }},
            {'command': 'ADSV', 'arguments': {'CONT': False, 'OW': 0x0}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 8}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CELL_OWD_DIAG3'},
        ],
        'SM_CLOCK_MON': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON'},
        ],
        'SM_CLOCK_MON_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x01}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG1'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x02}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG2'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG2'},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_OSCCHK': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_CLOCK_MON_DIAG3'},
            {'command': 'RDSTATD', 'map_key': 'SM_CLOCK_MON_DIAG3'},
        ],
        'SM_DIETEMP_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADAX', 'arguments': {'CH': 0x13}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATA', 'map_key': 'SM_DIETEMP_OOR'},
        ],
        'SM_FREEZE_SEQ': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': 'ADCV', 'arguments': {'CONT': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'SNAP'},
            {'command': 'CLRCELL'},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
                'CL_CS17FLT': True,
                'CL_CS18FLT': True,
            }},
            {'command': 'RDCVA', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVB', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVC', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVD', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVE', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'RDCVF', 'map_key': 'SM_FREEZE_SEQ1'},
            {'command': 'UNSNAP'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 2}},
            {'command': 'RDCVA', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVB', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVC', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVD', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVE', 'map_key': 'SM_FREEZE_SEQ2'},
            {'command': 'RDCVF', 'map_key': 'SM_FREEZE_SEQ2'},

        ],
        'SM_IIR_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True, 'FC': 1}},
            {'command': 'ADCV', 'arguments': {'CONT': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_IIR_RED'}
        ],
        'SM_NVM_ECC': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC'}
        ],
        'SM_NVM_ECC_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x60}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_CMED': True, 'CL_SMED': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_NVM_ECC_DIAG2'},
        ],
        'SM_POWER_MON': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON'}
        ],
        'SM_POWER_MON_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x04}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x0C}},
            {'command': 'ADCV', 'arguments': {'CONT': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG2'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG',
             'arguments': {'CL_VA_OV': True, 'CL_VA_UV': True, 'CL_VD_OV': True, 'CL_VD_UV': True, 'CL_VDE': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_POWER_MON_DIAG3'},
        ],
        'SM_POWER_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'GPO10': True}},
            {'command': 'ADAX'},
            {'command': 'ADAX2', 'arguments': {'CH_AUX2': 0xA}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 20}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATB', 'map_key': 'SM_POWER_OOR'},
            {'command': 'RDAUXD', 'map_key': 'SM_POWER_OOR'},
            {'command': 'RDRAXD', 'map_key': 'SM_POWER_OOR'},
        ],
        'SM_POWER_OOR_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'GPO10': True}},
            {'command': 'ADAX', 'arguments': {'CH': 0xA, 'PUP': True, 'OW_AUX': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXD', 'map_key': 'SM_POWER_OOR_DIAG'},
        ],
        'SM_SLEEP_IND': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'SRST'},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RDSTATC', 'map_key': 'SM_SLEEP_IND1'},
            {'command': 'CLRFLAG', 'arguments': {'CL_SLEEP': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SLEEP_IND2'},
        ],
        'SM_SPI_CNT': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'RSTCC'},
            {'command': 'RDCFGA', 'map_key': 'SM_SPI_CNT1'},
            {'command': 'WRCFGA'},
            {'command': 'RDCFGA', 'map_key': 'SM_SPI_CNT2'},
        ],
        'SM_SPI_PEC_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RSTCC'},
            {'command': 'MUTE'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG1'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3, 'CMD PEC': gen6base.CMD_PEC(pec_size=1)}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG2'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x3, 'DATA PEC': gen6base.DATA_PEC(pec_size=1)}},
            {'command': 'RDPWMA', 'map_key': 'SM_SPI_PEC_DIAG3'},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_PEC_DIAG4'},
            {'command': 'WRPWMA', 'arguments': {'PWM1': 0x00}},
            {'command': 'UNMUTE'},
        ],
        'SM_SPI_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED'},
        ],
        'SM_SPI_RED_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_SPIFLT': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED_DIAG1', 'arguments': {'ERR': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_SPI_RED_DIAG2', 'arguments': {'ERR': False}},
        ],
        'SM_THSD_IND_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_THSD': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x10}},
            {'command': 'RDSTATC', 'map_key': 'SM_THSD_IND_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_THSD': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_THSD_IND_DIAG2'},
        ],
        'SM_TMOD_IND': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND'},
        ],
        'SM_TMOD_IND_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x80}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND_DIAG1'},
            {'command': 'WRCFGA', 'arguments': {'FLAG_D': 0x00}},
            {'command': 'CLRFLAG', 'arguments': {'CL_TMODCHK': True}},
            {'command': 'RDSTATC', 'map_key': 'SM_TMOD_IND_DIAG2'},
        ],
        'SM_VCELL_CMP_DIAG': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_CMP_DIAG1'},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': False}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_CMP_DIAG2'},

        ],
        'SM_VCELL_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'ADCV', 'arguments': {'CONT': True, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDCVA', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVB', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVC', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVD', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVE', 'map_key': 'SM_VCELL_OOR'},
            {'command': 'RDCVF', 'map_key': 'SM_VCELL_OOR'},
        ],
        'SM_VCELL_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'CLRFLAG', 'arguments': {
                'CL_CS1FLT': True,
                'CL_CS2FLT': True,
                'CL_CS3FLT': True,
                'CL_CS4FLT': True,
                'CL_CS5FLT': True,
                'CL_CS6FLT': True,
                'CL_CS7FLT': True,
                'CL_CS8FLT': True,
                'CL_CS9FLT': True,
                'CL_CS10FLT': True,
                'CL_CS11FLT': True,
                'CL_CS12FLT': True,
                'CL_CS13FLT': True,
                'CL_CS14FLT': True,
                'CL_CS15FLT': True,
                'CL_CS16FLT': True,
                'CL_CS17FLT': True,
                'CL_CS18FLT': True,
            }},
            {'command': 'WRCFGA', 'arguments': {'CTH': 0x2}},
            {'command': 'ADCV', 'arguments': {'CONT': False, 'RD': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 10}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATC', 'map_key': 'SM_VCELL_RED'},
        ],
        'SM_VGPIO_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {
                'GPO1': True,
                'GPO2': True,
                'GPO3': True,
                'GPO4': True,
                'GPO5': True,
                'GPO6': True,
                'GPO7': True,
                'GPO8': True,
                'GPO9': True,
                'GPO10': True,
                'REFON': True
            }},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 25}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXA', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXB', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXC', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXD', 'map_key': 'SM_VGPIO_OOR'},
            {'command': 'RDAUXE', 'map_key': 'SM_VGPIO_OOR'},
        ],
        'SM_VGPIO_RED': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {
                'GPO1': True,
                'GPO2': True,
                'GPO3': True,
                'GPO4': True,
                'GPO5': True,
                'GPO6': True,
                'GPO7': True,
                'GPO8': True,
                'GPO9': True,
                'GPO10': True,
                'REFON': True
            }},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 15}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': 'ADAX2'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 25}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDAUXA', 'map_key': 'SM_VGPIO_RED'},
            {'command': 'RDRAXA', 'map_key': 'SM_VGPIO_RED'},
        ],
        'SM_VREF2_OOR': [
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 400}},
            {'command': 'WRCFGA', 'arguments': {'REFON': True}},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 5}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'ADAX'},
            {'command': '$DELAY_MS$', 'arguments': {'Delay': 20}},
            {'command': '$SPI_WAKEUP$', 'arguments': {'Wakeup Time': 10}},
            {'command': 'RDSTATB', 'map_key': 'SM_VREF2_OOR'},
        ],
    }
    LIMITS = {
        'Verification': {},
        'Safety': {
            'CELL_OPEN_WIRE_THRESHOLD': {
                'value': 0.85,
            },
            'CELL_OPEN_WIRE_DIAG_THRESHOLD': {
                'value': 0.95,
            },
            'AUX_OPEN_WIRE_THRESHOLD': {
                'value': 0.600,
            },
            'OSCCHK_OCCNTR': {
                'min': 52,
                'max': 70
            },
            'ITMP': {
                'max': 125
            },
            'VA': {
                'max': 5.486,
                'min': 4.512
            },
            'VD': {
                'max': 3.528,
                'min': 2.754
            },
            'VRES': {
                'max': 3.012,
                'min': 2.988
            },
            'G1V': {
                'max': 2.9,
                'min': 0.1
            },
            'G2V': {
                'max': 2.9,
                'min': 0.1
            },
            'G3V': {
                'max': 2.9,
                'min': 0.1
            },
            'G4V': {
                'max': 2.9,
                'min': 0.1
            },
            'G5V': {
                'max': 2.9,
                'min': 0.1
            },
            'G6V': {
                'max': 2.9,
                'min': 0.1
            },
            'G7V': {
                'max': 2.9,
                'min': 0.1
            },
            'G8V': {
                'max': 2.9,
                'min': 0.1
            },
            'G9V': {
                'max': 2.9,
                'min': 0.1
            },
            'G10V': {
                'max': 0.005,
                'min': -0.005
            },
            'GA11V': {
                'max': 0.005,
                'min': -0.005
            },
            'GA12V': {
                'max': 0.005,
                'min': -0.005
            },
            'G10V_OOR_DIAG': {
                'max': 0.5,
                'min': 0.05
            },
            'R_G10V': {
                'max': 0.005,
                'min': -0.005
            },
            'C1V': {
                'min': 0.1,
                'max': 4.5
            },
            'C2V': {
                'min': 0.1,
                'max': 4.5
            },
            'C3V': {
                'min': 0.1,
                'max': 4.5
            },
            'C4V': {
                'min': 0.1,
                'max': 4.5
            },
            'C5V': {
                'min': 0.1,
                'max': 4.5
            },
            'C6V': {
                'min': 0.1,
                'max': 4.5
            },
            'C7V': {
                'min': 0.1,
                'max': 4.5
            },
            'C8V': {
                'min': 0.1,
                'max': 4.5
            },
            'C9V': {
                'min': 0.1,
                'max': 4.5
            },
            'C10V': {
                'min': 0.1,
                'max': 4.5
            },
            'C11V': {
                'min': 0.1,
                'max': 4.5
            },
            'C12V': {
                'min': 0.1,
                'max': 4.5
            },
            'C13V': {
                'min': 0.1,
                'max': 4.5
            },
            'C14V': {
                'min': 0.1,
                'max': 4.5
            },
            'C15V': {
                'min': 0.1,
                'max': 4.5
            },
            'C16V': {
                'min': 0.1,
                'max': 4.5
            },
            'C17V': {
                'min': 0.1,
                'max': 4.5
            },
            'C18V': {
                'min': 0.1,
                'max': 4.5
            },
            'GPIO_RED_THRESHOLD': {
                'max': 0.01
            }
        },
        'Manufacturing': {},
        'Loose': {}
    }

    @staticmethod
    def decode_safety_loop(result_dict, ic_num, safety_metric=None, limit_override=None):
        limits = deepcopy(ADBMS6832.LIMITS['Safety'])
        if limit_override:
            limits.update(limit_override)
        global_status = ADBMS6832.PASS
        safety_results = {}
        if 'Safety_Results' not in result_dict:
            result_dict['Safety_Results'] = []
        for metric in ADBMS6832.SAFETY_COMMAND_LISTS:
            if safety_metric:
                if metric != safety_metric:
                    continue
            safety_results[metric] = {'Result': None}
            safety_results[metric]['Error Messages'] = []
            try:
                for map_key in result_dict:
                    if map_key in ['Total_PEC_Status', 'All', 'Safety_Results']:
                        continue
                    if map_key.endswith('_RAW'):
                        continue
                    if not result_dict[map_key][ic_num]['Total_PEC_Status']:
                        safety_results[metric]['Error Messages'].append('PEC Error Detected')
            except:
                pass
            if metric == 'SM_AUXREGS_DIAG':
                for item in ['ITMP', 'VA', 'VD', 'VRES']:
                    if result_dict['SM_AUXREGS_DIAG1_RAW'][ic_num][item] != 0x7FFF:
                        safety_results[metric]['Error Messages'].append('%s incorrect POR reset value' % item)
                    if result_dict['SM_AUXREGS_DIAG2_RAW'][ic_num][item] != 0x8000:
                        safety_results[metric]['Error Messages'].append('%s incorrect CLRAUX value' % item)
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_CELL_OWD':
                safety_results[metric]['Opens'] = []
                safety_results[metric]['Delta'] = []
                i = 0
                #  Gather open wire measurements into one array
                open_data = {}
                base_data = {}
                for spin in ['S2V', 'S4V', 'S6V', 'S8V', 'S10V', 'S12V', 'S14V', 'S16V', 'S18V']:
                    open_data[spin] = result_dict['SM_CELL_OWD2'][ic_num][spin]
                    base_data[spin] = result_dict['SM_CELL_OWD1'][ic_num][spin]
                for spin in ['S1V', 'S3V', 'S5V', 'S7V', 'S9V', 'S11V', 'S13V', 'S15V', 'S17V']:
                    open_data[spin] = result_dict['SM_CELL_OWD3'][ic_num][spin]
                    base_data[spin] = result_dict['SM_CELL_OWD2'][ic_num][spin]
                while i < len(ADBMS6832.SPINS):
                    spin = ADBMS6832.SPINS[i]
                    if i == 0:
                        safety_results[metric]['Delta'].append(open_data[spin])  # Once for C0, once for C1
                        if open_data[spin] < 0.010:
                            safety_results[metric]['Opens'].append('S0V')
                            safety_results[metric]['Error Messages'].append(
                                'S0V open detected. S1V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[metric]['Delta'].append(
                                (open_data[spin] / base_data[spin]) * 100)  # Once for C0, once for C1
                            i += 1
                            continue
                    if i == 17:
                        if open_data[spin] < 0.010:
                            safety_results[metric]['Opens'].append('S18V')
                            safety_results[metric]['Error Messages'].append(
                                'S18V open detected. S18V [%s] is less than 0.010V' % open_data[spin])
                            safety_results[metric]['Delta'].append(open_data[spin])
                            i += 1
                            continue
                    safety_results[metric]['Delta'].append((open_data[spin] / base_data[spin]) * 100)
                    if base_data[spin] < 0:
                        if abs(open_data[spin]) < abs(base_data[spin]) * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                            safety_results[metric]['Opens'].append(spin)
                            safety_results[metric]['Error Messages'].append(
                                '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                                    spin, spin, open_data[spin], base_data[spin],
                                    limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                            if i < 17:
                                safety_results[metric]['Delta'].append(
                                    (open_data[ADBMS6832.SPINS[i]] / base_data[ADBMS6832.SPINS[i]]) * 100)
                            i += 1
                    elif open_data[spin] < base_data[spin] * limits['CELL_OPEN_WIRE_THRESHOLD']['value']:
                        safety_results[metric]['Opens'].append(spin)
                        safety_results[metric]['Error Messages'].append(
                            '%s open detected. %s OW voltage [%s] < (Base Voltage [%s] * OPEN_WIRE_LIMIT [%s])' % (
                                spin, spin, open_data[spin], base_data[spin],
                                limits['CELL_OPEN_WIRE_THRESHOLD']['value']))
                        if i < 17:
                            safety_results[metric]['Delta'].append(
                                (open_data[ADBMS6832.SPINS[i]] / base_data[ADBMS6832.SPINS[i]]) * 100)
                        i += 1

                    i += 1
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_CELL_OWD_DIAG':
                for i in range(len(ADBMS6832.SPINS)):
                    if i % 2:
                        # Evens
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['S%sV' % str(i + 1)] / \
                                result_dict['SM_CELL_OWD_DIAG1'][ic_num]['AC%sV' % str(i + 1)] > \
                                limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[metric]['Error Messages'].append(
                                'S%s open wire switch not active' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['S%sV' % str(i + 1)] / \
                                result_dict['SM_CELL_OWD_DIAG2'][ic_num]['AC%sV' % str(i + 1)] < \
                                limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[metric]['Error Messages'].append(
                                'S%s open wire switch incorrectly enabled' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[metric]['Error Messages'].append(
                                'S%s comparison flag incorrectly set' % str(i + 1))
                        if not result_dict['SM_CELL_OWD_DIAG1'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[metric]['Error Messages'].append('S%s comparison flag not set' % str(i + 1))
                    else:
                        # Evens
                        if result_dict['SM_CELL_OWD_DIAG2'][ic_num]['S%sV' % str(i + 1)] / \
                                result_dict['SM_CELL_OWD_DIAG2'][ic_num]['AC%sV' % str(i + 1)] > \
                                limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[metric]['Error Messages'].append(
                                'S%s open wire switch not active' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['S%sV' % str(i + 1)] / \
                                result_dict['SM_CELL_OWD_DIAG1'][ic_num]['AC%sV' % str(i + 1)] < \
                                limits['CELL_OPEN_WIRE_DIAG_THRESHOLD']['value']:
                            safety_results[metric]['Error Messages'].append(
                                'S%s open wire switch incorrectly enabled' % str(i + 1))
                        if result_dict['SM_CELL_OWD_DIAG1'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[metric]['Error Messages'].append(
                                'S%s comparison flag incorrectly set' % str(i + 1))
                        if not result_dict['SM_CELL_OWD_DIAG2'][ic_num]['CS%sFLT' % str(i + 1)]:
                            safety_results[metric]['Error Messages'].append('S%s comparison flag not set' % str(i + 1))
                    if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['CS%sFLT' % str(i + 1)]:
                        safety_results[metric]['Error Messages'].append(
                            'S%s comparison fault with switches disabled' % str(i + 1))
                if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['COMP']:
                    safety_results[metric]['Error Messages'].append('COMP bit set with comparison disabled')
                if result_dict['SM_CELL_OWD_DIAG3'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('SPI fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_CLOCK_MON':
                if result_dict['SM_CLOCK_MON'][ic_num]['OSCCHK']:
                    safety_results[metric]['Error Messages'].append('Oscillator check failed')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_CLOCK_MON_DIAG':
                if not result_dict['SM_CLOCK_MON_DIAG1'][ic_num]['OSCCHK']:
                    safety_results[metric]['Error Messages'].append('Oscillator check fast failed to set flag')
                if result_dict['SM_CLOCK_MON_DIAG1'][ic_num]['OC_CNTR'] <= limits['OSCCHK_OCCNTR']['max']:
                    safety_results[metric]['Error Messages'].append('Oscillator check fast counter too low')
                if not result_dict['SM_CLOCK_MON_DIAG2'][ic_num]['OSCCHK']:
                    safety_results[metric]['Error Messages'].append('Oscillator check slow failed to set flag')
                if result_dict['SM_CLOCK_MON_DIAG2'][ic_num]['OC_CNTR'] >= limits['OSCCHK_OCCNTR']['min']:
                    safety_results[metric]['Error Messages'].append('Oscillator check slow counter too high')
                if result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OSCCHK']:
                    safety_results[metric]['Error Messages'].append('Oscillator check failed')
                if result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OC_CNTR'] < limits['OSCCHK_OCCNTR']['min'] or \
                        result_dict['SM_CLOCK_MON_DIAG3'][ic_num]['OC_CNTR'] > limits['OSCCHK_OCCNTR']['max']:
                    safety_results[metric]['Error Messages'].append('Oscillator check counter out of range')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_DIETEMP_OOR':
                if result_dict['SM_DIETEMP_OOR'][ic_num]['ITMP'] > limits['ITMP']['max']:
                    safety_results[metric]['Error Messages'].append('Die temperature too high')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_FREEZE_SEQ':
                for cell in ADBMS6832.CELLS:
                    if result_dict['SM_FREEZE_SEQ1_RAW'][ic_num][cell] != 0x8000:
                        safety_results[metric]['Error Messages'].append('CLRCELL did not reset register')
                    if result_dict['SM_FREEZE_SEQ2_RAW'][ic_num][cell] == 0x8000:
                        safety_results[metric]['Error Messages'].append('CVARx register did not update')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_IIR_RED':
                if result_dict['SM_IIR_RED'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('IIR match failure')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_NVM_ECC':
                if result_dict['SM_NVM_ECC'][ic_num]['CMED'] or result_dict['SM_NVM_ECC'][ic_num]['SMED']:
                    safety_results[metric]['Error Messages'].append('NVM multiple errors detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_NVM_ECC_DIAG':
                if not result_dict['SM_NVM_ECC_DIAG1'][ic_num]['CMED'] or not result_dict['SM_NVM_ECC_DIAG1'][ic_num][
                    'SMED']:
                    safety_results[metric]['Error Messages'].append('NVM multiple errors latch did not set')
                if result_dict['SM_NVM_ECC_DIAG2'][ic_num]['CMED'] or result_dict['SM_NVM_ECC_DIAG2'][ic_num]['SMED']:
                    safety_results[metric]['Error Messages'].append('NVM multiple errors latch did not clear')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_POWER_MON':
                for item in ['VA_OV', 'VA_UV', 'VD_OV', 'VD_UV', 'VDE']:
                    if result_dict['SM_POWER_MON'][ic_num][item]:
                        safety_results[metric]['Error Messages'].append('%s power domain fault' % item)
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_POWER_MON_DIAG':
                for item in ['VA_UV', 'VD_UV']:
                    if not result_dict['SM_POWER_MON_DIAG1'][ic_num][item]:
                        safety_results[metric]['Error Messages'].append('%s power domain fault did not set' % item)
                for item in ['VA_OV', 'VD_OV']:
                    if not result_dict['SM_POWER_MON_DIAG2'][ic_num][item]:
                        safety_results[metric]['Error Messages'].append('%s power domain fault did not set' % item)
                for item in ['VA_OV', 'VA_UV', 'VD_OV', 'VD_UV', 'VDE']:
                    if result_dict['SM_POWER_MON_DIAG3'][ic_num][item]:
                        safety_results[metric]['Error Messages'].append('%s power domain fault did not clear' % item)
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_POWER_OOR':
                for item in ['VA', 'VD', 'G10V', 'R_G10V']:
                    if result_dict['SM_POWER_OOR'][ic_num][item] < limits[item]['min'] or \
                            result_dict['SM_POWER_OOR'][ic_num][item] > limits[item]['max']:
                        safety_results[metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % (
                        item, result_dict['SM_POWER_OOR'][ic_num][item], limits[item]['min'], limits[item]['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_POWER_OOR_DIAG':
                if result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'] < limits['G10V_OOR_DIAG']['min'] or \
                        result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'] > limits['G10V_OOR_DIAG']['max']:
                    safety_results[metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % (
                    'G10V', result_dict['SM_POWER_OOR_DIAG'][ic_num]['G10V'], limits['G10V_OOR_DIAG']['min'],
                    limits['G10V_OOR_DIAG']['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_SLEEP_IND':
                if not result_dict['SM_SLEEP_IND1'][ic_num]['SLEEP']:
                    safety_results[metric]['Error Messages'].append('SLEEP bit did not set on reset')
                if result_dict['SM_SLEEP_IND2'][ic_num]['SLEEP']:
                    safety_results[metric]['Error Messages'].append('SLEEP bit did not clear')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_SPI_CNT':
                if result_dict['SM_SPI_CNT1'][ic_num]['CCNT']:
                    safety_results[metric]['Error Messages'].append('CCNT did not reset')
                if result_dict['SM_SPI_CNT2'][ic_num]['CCNT'] != 1:
                    safety_results[metric]['Error Messages'].append('CCNT did not increment')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_SPI_PEC_DIAG':
                safety_results[metric]['Error Messages'] = []
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['CCNT'] != 0x2:
                    safety_results[metric]['Error Messages'].append('CCNT did not increment')
                if result_dict['SM_SPI_PEC_DIAG1'][ic_num]['PWM1'] != 0x3:
                    safety_results[metric]['Error Messages'].append('Written value did not latch')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['CCNT'] != 0x2:
                    safety_results[metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG2'][ic_num]['PWM1'] != 0x3:
                    safety_results[metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['CCNT'] != 0x2:
                    safety_results[metric]['Error Messages'].append('CCNT value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG3'][ic_num]['PWM1'] != 0x00:
                    safety_results[metric]['Error Messages'].append('Written value changed with incorrect PEC')
                if result_dict['SM_SPI_PEC_DIAG4'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('SPI fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_SPI_RED':
                if result_dict['SM_SPI_RED'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('SPI fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_SPI_RED_DIAG':
                if not result_dict['SM_SPI_RED_DIAG1'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('SPI fault detected latch did not set')
                if result_dict['SM_SPI_RED_DIAG2'][ic_num]['SPIFLT']:
                    safety_results[metric]['Error Messages'].append('SPI fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_THSD_IND_DIAG':
                if not result_dict['SM_THSD_IND_DIAG1'][ic_num]['THSD']:
                    safety_results[metric]['Error Messages'].append('Temperature shutdown latch did not set')
                if result_dict['SM_THSD_IND_DIAG2'][ic_num]['THSD']:
                    safety_results[metric]['Error Messages'].append('Temperature shutdown detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_TMOD_IND':
                if result_dict['SM_TMOD_IND'][ic_num]['TMODCHK']:
                    safety_results[metric]['Error Messages'].append('Test mode fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_TMOD_IND_DIAG':
                if not result_dict['SM_TMOD_IND_DIAG1'][ic_num]['TMODCHK']:
                    safety_results[metric]['Error Messages'].append('Test mode activation latch did not set')
                if result_dict['SM_TMOD_IND_DIAG2'][ic_num]['TMODCHK']:
                    safety_results[metric]['Error Messages'].append('Test mode fault detected')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VCELL_CMP_DIAG':
                if not result_dict['SM_VCELL_CMP_DIAG1'][ic_num]['COMP']:
                    safety_results[metric]['Error Messages'].append('COMP bit not set')
                if result_dict['SM_VCELL_CMP_DIAG2'][ic_num]['COMP']:
                    safety_results[metric]['Error Messages'].append('COMP bit set when comparison not enabled')
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VCELL_OOR':
                for cell in ADBMS6832.CELLS:
                    if result_dict['SM_VCELL_OOR'][ic_num][cell] < limits[cell]['min'] or \
                            result_dict['SM_VCELL_OOR'][ic_num][cell] > limits[cell]['max']:
                        safety_results[metric]['Error Messages'].append('%s is %s out of spec [%s, %s]' % (
                        cell, result_dict['SM_VCELL_OOR'][ic_num][cell], limits[cell]['min'], limits[cell]['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VCELL_RED':
                for i in range(len(ADBMS6832.CELLS)):
                    if result_dict['SM_VCELL_RED'][ic_num]['CS%sFLT' % str(i + 1)]:
                        safety_results[metric]['Error Messages'].append(
                            'C%s-S%s comparison is out of range' % (str(i + 1), str(i + 1)))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VGPIO_OOR':
                for gpio in ADBMS6832.GPIOS:
                    if result_dict['SM_VGPIO_OOR'][ic_num][gpio] < limits[gpio]['min'] or \
                            result_dict['SM_VGPIO_OOR'][ic_num][gpio] > limits[gpio]['max']:
                        safety_results[metric]['Error Messages'].append('%s is %s out of range [%s, %s]' % (
                        gpio, result_dict['SM_VGPIO_OOR'][ic_num][gpio], limits[gpio]['min'], limits[gpio]['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VGPIO_RED':
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G1V']) > \
                        limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[metric]['Error Messages'].append('G1V - R_G1V is %s out of spec %s' % (
                        str(abs(
                            result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V'])),
                        limits['GPIO_RED_THRESHOLD']['max']))
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G3V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V']) > \
                        limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[metric]['Error Messages'].append('G3V - R_G3V is %s out of spec %s' % (
                        str(abs(
                            result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['G3V'])),
                        limits['GPIO_RED_THRESHOLD']['max']))
                if abs(result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['G3V']) > \
                        limits['GPIO_RED_THRESHOLD']['max']:
                    safety_results[metric]['Error Messages'].append('G1V - G3V is %s out of spec %s' % (
                        str(abs(
                            result_dict['SM_VGPIO_RED'][ic_num]['G1V'] - result_dict['SM_VGPIO_RED'][ic_num]['R_G3V'])),
                        limits['GPIO_RED_THRESHOLD']['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
            elif metric == 'SM_VREF2_OOR':
                if result_dict['SM_VREF2_OOR'][ic_num]['VRES'] < limits['VRES']['min'] or \
                        result_dict['SM_VREF2_OOR'][ic_num]['VRES'] > limits['VRES']['max']:
                    safety_results[metric]['Error Messages'].append('VRES is %s out of range [%s, %s]' % (
                    result_dict['SM_VREF2_OOR'][ic_num]['VRES'], limits['VRES']['min'], limits['VRES']['max']))
                if len(safety_results[metric]['Error Messages']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS

            elif metric == 'Loop':
                # Check voltages for OV/UV
                for average_map_key in ['FILT1', 'FILT2', 'FILT3', 'FILT4', 'FILT5', 'FILT6', 'FILT7', 'FILT8', 'FILT9',
                                        'FILT10']:
                    for cell in ADBMS6832.FILTERED_CELLS:
                        if result_dict[average_map_key][ic_num][cell] > limits[cell]['max']:
                            safety_results[metric]['Error Messages'].append(
                                '%s Cell [%s] voltage [%s] is over voltage limit [%s]' % (
                                    average_map_key, cell, result_dict[average_map_key][ic_num][cell],
                                    limits[cell]['max']))
                        if result_dict[average_map_key][ic_num][cell] < limits[cell]['min']:
                            safety_results[metric]['Error Messages'].append(
                                '%s Cell [%s] voltage [%s] is under voltage limit [%s]' % (
                                    average_map_key, cell, result_dict[average_map_key][ic_num][cell],
                                    limits[cell]['min']))
            elif metric == 'Aux_Open_Wire':
                safety_results[metric]['Opens'] = []
                safety_results[metric]['Delta'] = []
                i = 0
                while i < len(ADBMS6832.GPIOS):
                    gpio = ADBMS6832.GPIOS[i]
                    # Just check for #3,5,6,7,8 error for now, will implement the rest later
                    if result_dict['AUX_OPEN_ADAX'][ic_num][gpio] >= 2.75:
                        delta = abs(
                            result_dict['AUX_OPEN_PD'][ic_num][gpio] - result_dict['AUX_OPEN_ADAX'][ic_num][gpio])
                    else:
                        delta = abs(
                            result_dict['AUX_OPEN_PU'][ic_num][gpio] - result_dict['AUX_OPEN_ADAX'][ic_num][gpio])
                    safety_results[metric]['Delta'].append(delta)
                    if delta > limits['AUX_OPEN_WIRE_THRESHOLD']['value']:
                        safety_results[metric]['Opens'].append(gpio)
                        safety_results[metric]['Error Messages'].append(
                            '[%s] delta [%s] is greater than GPIO open wire limit [%s]' % (
                                gpio, delta, limits['AUX_OPEN_WIRE_THRESHOLD']['value']))
                    elif delta < 0.03:
                        safety_results[metric]['Opens'].append(gpio)
                        safety_results[metric]['Error Messages'].append(
                            '[%s] delta [%s] is less than GPIO open wire limit [0.03] current source is stuck on/off' % (
                                gpio, delta))
                    i += 1
                if len(safety_results[metric]['Opens']) != 0:
                    safety_results[metric]['Result'] = ADBMS6832.FAIL
                    global_status = ADBMS6832.FAIL
                else:
                    safety_results[metric]['Result'] = ADBMS6832.PASS
        if len(result_dict['Safety_Results']) <= ic_num:
            result_dict['Safety_Results'].append(safety_results)
        else:
            result_dict['Safety_Results'][ic_num].update(safety_results)
        return global_status