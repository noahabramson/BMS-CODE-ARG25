# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
import math
from abc import ABC
import copy


# ===================================================== Bitfields =====================================================
class Bitfield():
    NAME = None
    DESCRIPTION = ''
    MEM_KEY = 'Miscellaneous'
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = None
    SAVE_STATE = False
    ALIASES = {}
    CRC15 = [
        0x0, 0xc599, 0xceab, 0xb32, 0xd8cf, 0x1d56, 0x1664, 0xd3fd, 0xf407, 0x319e, 0x3aac,
        0xff35, 0x2cc8, 0xe951, 0xe263, 0x27fa, 0xad97, 0x680e, 0x633c, 0xa6a5, 0x7558, 0xb0c1,
        0xbbf3, 0x7e6a, 0x5990, 0x9c09, 0x973b, 0x52a2, 0x815f, 0x44c6, 0x4ff4, 0x8a6d, 0x5b2e,
        0x9eb7, 0x9585, 0x501c, 0x83e1, 0x4678, 0x4d4a, 0x88d3, 0xaf29, 0x6ab0, 0x6182, 0xa41b,
        0x77e6, 0xb27f, 0xb94d, 0x7cd4, 0xf6b9, 0x3320, 0x3812, 0xfd8b, 0x2e76, 0xebef, 0xe0dd,
        0x2544, 0x02be, 0xc727, 0xcc15, 0x098c, 0xda71, 0x1fe8, 0x14da, 0xd143, 0xf3c5, 0x365c,
        0x3d6e, 0xf8f7, 0x2b0a, 0xee93, 0xe5a1, 0x2038, 0x07c2, 0xc25b, 0xc969, 0x0cf0, 0xdf0d,
        0x1a94, 0x11a6, 0xd43f, 0x5e52, 0x9bcb, 0x90f9, 0x5560, 0x869d, 0x4304, 0x4836, 0x8daf,
        0xaa55, 0x6fcc, 0x64fe, 0xa167, 0x729a, 0xb703, 0xbc31, 0x79a8, 0xa8eb, 0x6d72, 0x6640,
        0xa3d9, 0x7024, 0xb5bd, 0xbe8f, 0x7b16, 0x5cec, 0x9975, 0x9247, 0x57de, 0x8423, 0x41ba,
        0x4a88, 0x8f11, 0x057c, 0xc0e5, 0xcbd7, 0x0e4e, 0xddb3, 0x182a, 0x1318, 0xd681, 0xf17b,
        0x34e2, 0x3fd0, 0xfa49, 0x29b4, 0xec2d, 0xe71f, 0x2286, 0xa213, 0x678a, 0x6cb8, 0xa921,
        0x7adc, 0xbf45, 0xb477, 0x71ee, 0x5614, 0x938d, 0x98bf, 0x5d26, 0x8edb, 0x4b42, 0x4070,
        0x85e9, 0x0f84, 0xca1d, 0xc12f, 0x04b6, 0xd74b, 0x12d2, 0x19e0, 0xdc79, 0xfb83, 0x3e1a, 0x3528,
        0xf0b1, 0x234c, 0xe6d5, 0xede7, 0x287e, 0xf93d, 0x3ca4, 0x3796, 0xf20f, 0x21f2, 0xe46b, 0xef59,
        0x2ac0, 0x0d3a, 0xc8a3, 0xc391, 0x0608, 0xd5f5, 0x106c, 0x1b5e, 0xdec7, 0x54aa, 0x9133, 0x9a01,
        0x5f98, 0x8c65, 0x49fc, 0x42ce, 0x8757, 0xa0ad, 0x6534, 0x6e06, 0xab9f, 0x7862, 0xbdfb, 0xb6c9,
        0x7350, 0x51d6, 0x944f, 0x9f7d, 0x5ae4, 0x8919, 0x4c80, 0x47b2, 0x822b, 0xa5d1, 0x6048, 0x6b7a,
        0xaee3, 0x7d1e, 0xb887, 0xb3b5, 0x762c, 0xfc41, 0x39d8, 0x32ea, 0xf773, 0x248e, 0xe117, 0xea25,
        0x2fbc, 0x0846, 0xcddf, 0xc6ed, 0x0374, 0xd089, 0x1510, 0x1e22, 0xdbbb, 0x0af8, 0xcf61, 0xc453,
        0x01ca, 0xd237, 0x17ae, 0x1c9c, 0xd905, 0xfeff, 0x3b66, 0x3054, 0xf5cd, 0x2630, 0xe3a9, 0xe89b,
        0x2d02, 0xa76f, 0x62f6, 0x69c4, 0xac5d, 0x7fa0, 0xba39, 0xb10b, 0x7492, 0x5368, 0x96f1, 0x9dc3,
        0x585a, 0x8ba7, 0x4e3e, 0x450c, 0x8095
    ]
    CRC10 = [
        0x000, 0x08f, 0x11e, 0x191, 0x23c, 0x2b3, 0x322, 0x3ad, 0x0f7, 0x078, 0x1e9, 0x166, 0x2cb, 0x244, 0x3d5, 0x35a,
        0x1ee, 0x161, 0x0f0, 0x07f, 0x3d2, 0x35d, 0x2cc, 0x243, 0x119, 0x196, 0x007, 0x088, 0x325, 0x3aa, 0x23b, 0x2b4,
        0x3dc, 0x353, 0x2c2, 0x24d, 0x1e0, 0x16f, 0x0fe, 0x071, 0x32b, 0x3a4, 0x235, 0x2ba, 0x117, 0x198, 0x009, 0x086,
        0x232, 0x2bd, 0x32c, 0x3a3, 0x00e, 0x081, 0x110, 0x19f, 0x2c5, 0x24a, 0x3db, 0x354, 0x0f9, 0x076, 0x1e7, 0x168,
        0x337, 0x3b8, 0x229, 0x2a6, 0x10b, 0x184, 0x015, 0x09a, 0x3c0, 0x34f, 0x2de, 0x251, 0x1fc, 0x173, 0x0e2, 0x06d,
        0x2d9, 0x256, 0x3c7, 0x348, 0x0e5, 0x06a, 0x1fb, 0x174, 0x22e, 0x2a1, 0x330, 0x3bf, 0x012, 0x09d, 0x10c, 0x183,
        0x0eb, 0x064, 0x1f5, 0x17a, 0x2d7, 0x258, 0x3c9, 0x346, 0x01c, 0x093, 0x102, 0x18d, 0x220, 0x2af, 0x33e, 0x3b1,
        0x105, 0x18a, 0x01b, 0x094, 0x339, 0x3b6, 0x227, 0x2a8, 0x1f2, 0x17d, 0x0ec, 0x063, 0x3ce, 0x341, 0x2d0, 0x25f,
        0x2e1, 0x26e, 0x3ff, 0x370, 0x0dd, 0x052, 0x1c3, 0x14c, 0x216, 0x299, 0x308, 0x387, 0x02a, 0x0a5, 0x134, 0x1bb,
        0x30f, 0x380, 0x211, 0x29e, 0x133, 0x1bc, 0x02d, 0x0a2, 0x3f8, 0x377, 0x2e6, 0x269, 0x1c4, 0x14b, 0x0da, 0x055,
        0x13d, 0x1b2, 0x023, 0x0ac, 0x301, 0x38e, 0x21f, 0x290, 0x1ca, 0x145, 0x0d4, 0x05b, 0x3f6, 0x379, 0x2e8, 0x267,
        0x0d3, 0x05c, 0x1cd, 0x142, 0x2ef, 0x260, 0x3f1, 0x37e, 0x024, 0x0ab, 0x13a, 0x1b5, 0x218, 0x297, 0x306, 0x389,
        0x1d6, 0x159, 0x0c8, 0x047, 0x3ea, 0x365, 0x2f4, 0x27b, 0x121, 0x1ae, 0x03f, 0x0b0, 0x31d, 0x392, 0x203, 0x28c,
        0x038, 0x0b7, 0x126, 0x1a9, 0x204, 0x28b, 0x31a, 0x395, 0x0cf, 0x040, 0x1d1, 0x15e, 0x2f3, 0x27c, 0x3ed, 0x362,
        0x20a, 0x285, 0x314, 0x39b, 0x036, 0x0b9, 0x128, 0x1a7, 0x2fd, 0x272, 0x3e3, 0x36c, 0x0c1, 0x04e, 0x1df, 0x150,
        0x3e4, 0x36b, 0x2fa, 0x275, 0x1d8, 0x157, 0x0c6, 0x049, 0x313, 0x39c, 0x20d, 0x282, 0x12f, 0x1a0, 0x031, 0x0be
    ]

    def __init__(self, length, value=None, raw_value=None):
        self.readback = None
        self.length = length
        self.bit_list_index = []
        self.bit_list = []
        for i in range(length):
            self.bit_list_index.append(None)
        self.raw_val = raw_value
        self.value = value
        self.name = None
        # Conversion factors
        self.twos_complement = None
        self.crc_cal_func = None
        self.crc_size = None
        self.pec_status = None
        self.lsb = None
        self.postpend = None
        self.prepend = None

    @classmethod
    def info(cls):
        return {'name': cls.NAME, 'description': cls.DESCRIPTION, 'max': cls.MAX_VALUE, 'min': cls.MIN_VALUE, 'default': cls.DEFAULT_VALUE, 'type': cls.TYPE, 'limits': cls.LIMITS}

    def bitlist_to_raw(self, bit_list):
        val = 0
        for index in self.bit_list_index[::-1]:
            val = (val << 1) | bit_list[index]
        self.raw_val = val
        return val

    def convert_to_bitlist(self, bitlist, **kwargs):
        return bitlist

    def convert_from_bitlist(self, bit_list, **kwargs):
        return None

    def convert_bool_from_bitfields(self, bitfield_list, **kwargs):
        try:
            self.bitlist_to_raw(bitfield_list)
            self.value = bool(self.raw_val)
            return self.value
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_bool_to_bitfields(self, bitlist, **kwargs):
        self.bit_list = []
        try:
            if self.value:
                self.bit_list.append(1)
            else:
                self.bit_list.append(0)
            return self.bit_list
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_int_from_bitfields(self, bitfield_list, **kwargs):
        try:
            self.bitlist_to_raw(bitfield_list)
            if not self.twos_complement:
                self.value = self.raw_val
                return self.raw_val
            # Determine if negative:
            if not (self.raw_val >> self.length - 1) & 0x1:
                self.value = self.raw_val
                return self.raw_val
            self.value = ((self.raw_val ^ (2**self.length)-1) + 1) * -1
            return self.value
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_int_to_bitfields(self, bitlist, use_raw=False, **kwargs):
        if use_raw:
            value = self.raw_val
        else:
            value = self.value
        self.bit_list = []
        try:
            if self.twos_complement and value < 0:
                value = (abs(value) ^ (2 ** self.length) - 1) + 1
            for i in range(self.length):
                self.bit_list.append((value >> i) & 0x1)
            return self.bit_list
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_adc_to_bitfields(self, bitlist, **kwargs):
        self.bit_list = []
        # Convert from value to integer
        try:
            value = int((self.value - self.postpend)/self.lsb - self.prepend)
            if self.twos_complement and value < 0:
                value = (abs(value) ^ (2 ** self.length) - 1) + 1
            for i in range(self.length):
                self.bit_list.append((value >> i) & 0x1)
            return self.bit_list
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_adc_from_bitfields(self, bitlist, **kwargs):
        self.convert_int_from_bitfields(bitlist, **kwargs)
        try:
            self.value = (self.value + self.prepend)*self.lsb + self.postpend
            return self.value
        except Exception as e:
            raise ValueError("Error converting bitfield %s: [%s]" % (self.name, e))

    def convert_crc_to_bitfields(self, bitlist, **kwargs):
        self.raw_val = self.crc_cal_func(bitlist)
        self.value = self.raw_val
        return self.convert_int_to_bitfields([])

    def convert_crc_from_bitfields(self, bitlist, **kwargs):
        # Get actual value
        self.convert_int_from_bitfields(bitlist, **kwargs)
        # Check for pec match
        calculated_pec = self.crc_cal_func(bitlist)
        if calculated_pec != self.value:
            self.pec_status = False
        else:
            self.pec_status = True
        return self.value

    def calc_pec15(self, bit_list):
        """
        Returns PEC calculation

        :param bit_list: list of bits
        :param start: pec calculation starting point inside the bit list
        :return: PEC
        """
        # create byte list
        bytes_list = []
        i = 0
        temp = 0
        for bit in bit_list[self.bit_list_index[-1]-self.crc_size:self.bit_list_index[-1]]:
            temp = (temp << 1) | bit
            i += 1
            if i > 7:
                bytes_list.append(temp)
                temp = 0
                i = 0
        remainder = 16
        for i in range(len(bytes_list)):
            table_address = ((remainder >> 7) ^ bytes_list[i]) & 0xFF
            remainder = (remainder << 8) ^ Bitfield.CRC15[table_address]
        remainder = remainder * 2
        remainder = remainder & 0xFFFF

        return remainder

    def calc_pec10(self, bit_list):
        """
        Returns PEC calculation

        :param bit_list: list of bits
        :return: PEC
        """
        # create byte list
        bytes_list = []
        i = 0
        temp = 0
        polynomial = 0x8F
        for bit in bit_list[self.bit_list_index[-1]-self.crc_size:self.bit_list_index[-1]]:
            temp = (temp << 1) | bit
            i += 1
            if i > 7:
                bytes_list.append(temp)
                temp = 0
                i = 0
        remainder = 16
        for i in range(len(bytes_list)):
            table_address = ((remainder >> 2) ^ bytes_list[i]) & 0xFF
            remainder = (remainder << 8) ^ Bitfield.CRC10[table_address]
        remainder ^= ((temp << 2) & 0xFC) << 2

        for i in [5, 4, 3, 2, 1, 0]:
            if (remainder & 0x200) > 0:
                remainder = remainder << 1
                remainder = remainder ^ polynomial
            else:
                remainder = remainder << 1

        remainder = remainder & 0x3FF

        return remainder


class BitfieldBool(Bitfield):
    NAME = None
    DESCRIPTION = ''
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = 'bool'

    def __init__(self, length, value=None, raw_value=None):
        super(BitfieldBool, self).__init__(length, value=value, raw_value=raw_value)

    def convert_to_bitlist(self, bitlist, **kwargs):
        self.convert_bool_to_bitfields(bitlist, **kwargs)
        try:
            for index, bitlist_index in enumerate(self.bit_list_index):
                bitlist[bitlist_index] = self.bit_list[index]
            return bitlist
        except IndexError:
            raise IndexError('Bitlist is too small for Bitfield [%s]' % self.name)

    def convert_from_bitlist(self, bitlist, **kwargs):
        return self.convert_bool_from_bitfields(bitlist, **kwargs)


class BitfieldInt(Bitfield):
    NAME = None
    DESCRIPTION = ''
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = 'int'

    def __init__(self, length, twos_complement=False, value=None, raw_value=None):
        super(BitfieldInt, self).__init__(length, value=value, raw_value=raw_value)
        self.twos_complement = twos_complement

    def convert_to_bitlist(self, bitlist, **kwargs):
        self.convert_int_to_bitfields(bitlist, **kwargs)
        try:
            for index, bitlist_index in enumerate(self.bit_list_index):
                bitlist[bitlist_index] = self.bit_list[index]
            return bitlist
        except IndexError:
            raise IndexError('Bitlist is too small for Bitfield [%s]' % self.name)

    def convert_from_bitlist(self, bitlist, **kwargs):
        return self.convert_int_from_bitfields(bitlist, **kwargs)


class BitfieldFloat(Bitfield):
    NAME = None
    DESCRIPTION = ''
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = 'float'

    def __init__(self, length, mantissa_length=None, value=None, raw_value=None):
        super(BitfieldFloat, self).__init__(length, value=value, raw_value=raw_value)
        self.mantissa_length = mantissa_length
        self.man_mask = 2**self.mantissa_length-1
        self.exp_mask = (2**(length-1-self.mantissa_length)-1)<<self.mantissa_length
        self.exp_bias = 2**(length-1-self.mantissa_length-1)-1
        self.exp_length = length-1-self.mantissa_length
        self.sign_mask = 1 << self.length-1

    def convert_to_bitlist(self, bitlist, **kwargs):
        self.convert_int_to_bitfields(bitlist, **kwargs)
        try:
            for index, bitlist_index in enumerate(self.bit_list_index):
                bitlist[bitlist_index] = self.bit_list[index]
            return bitlist
        except IndexError:
            raise IndexError('Bitlist is too small for Bitfield [%s]' % self.name)

    def convert_from_bitlist(self, bitlist, **kwargs):
        raw = self.convert_int_from_bitfields(bitlist, **kwargs)
        man = raw & self.man_mask
        sign = (raw & self.sign_mask) >> (self.length - 1)
        exp = (raw & self.exp_mask) >> (self.mantissa_length)
        if exp == 0:
            norm = 0.0
        else:
            norm = 1.0
        if exp == self.exp_mask >> self.mantissa_length and man == 0:
            if sign:
                self.value = -1*math.inf
                return self.value
            else:
                self.value = math.inf
                return self.value
        elif exp == self.exp_mask >> self.mantissa_length:
            self.value = math.nan
            return self.value
        # IEEE754
        exp = exp - self.exp_bias
        val = 0
        for i in range(self.mantissa_length):
            val += ((man>>i) & 0x01) * (2**(i-self.mantissa_length))
        if sign:
            self.value = -1.0*(norm+val)*2**exp
            return self.value
        else:
            self.value = (norm+val)*2**exp
            return self.value


class BitfieldPEC(Bitfield):
    NAME = None
    DESCRIPTION = ''
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = 'pec'

    def __init__(self, length, pec_size=0, value=None, raw_value=None):
        super(BitfieldPEC, self).__init__(length, value=value, raw_value=raw_value)
        self.crc_size = pec_size

    def convert_to_bitlist(self, bitlist, **kwargs):
        self.convert_crc_to_bitfields(bitlist, **kwargs)
        try:
            for index, bitlist_index in enumerate(self.bit_list_index):
                bitlist[bitlist_index] = self.bit_list[index]
            return bitlist
        except IndexError:
            raise IndexError('Bitlist is too small for Bitfield [%s]' % self.name)

    def convert_from_bitlist(self, bitlist, **kwargs):
        return self.convert_crc_from_bitfields(bitlist, **kwargs)


class BitfieldAdc(Bitfield):
    NAME = None
    DESCRIPTION = ''
    DEFAULT_VALUE = None
    MAX_VALUE = None
    MIN_VALUE = None
    LENGTH = None
    LIMITS = {}
    TYPE = 'adc'

    def __init__(self, length, twos_complement=False, lsb=1.0, prepend=0.0, postpend=0.0, value=None, raw_value=None):
        super(BitfieldAdc, self).__init__(length, value=value, raw_value=raw_value)
        self.twos_complement = twos_complement
        self.lsb = lsb
        self.prepend = prepend
        self.postpend = postpend

    def convert_to_bitlist(self, bitlist, **kwargs):
        self.convert_adc_to_bitfields(bitlist, **kwargs)
        try:
            for index, bitlist_index in enumerate(self.bit_list_index):
                bitlist[bitlist_index] = self.bit_list[index]
            return bitlist
        except IndexError:
            raise IndexError('Bitlist is too small for Bitfield [%s]' % self.name)

    def convert_from_bitlist(self, bitlist, **kwargs):
        return self.convert_adc_from_bitfields(bitlist, **kwargs)


class Bit0(BitfieldBool):
    NAME = '0'
    DESCRIPTION = 'Bit 0'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0
    MIN_VALUE = 0
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(Bit0, self).__init__(Bit0.LENGTH,  value=value, raw_value=raw_value)
        self.name = Bit0.NAME


class Bit1(BitfieldBool):
    NAME = '1'
    DESCRIPTION = 'Bit 1'
    DEFAULT_VALUE = 1
    MAX_VALUE = 1
    MIN_VALUE = 1
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=True, raw_value=1):
        super(Bit1, self).__init__(Bit1.LENGTH,  value=value, raw_value=raw_value)
        self.name = Bit1.NAME


class RSVD0(BitfieldBool):
    NAME = 'RSVD0'
    DESCRIPTION = 'Reserved Value: 0'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0
    MIN_VALUE = 0
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=False, raw_value=0):
        super(RSVD0, self).__init__(RSVD0.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD0.NAME


class RSVD1(BitfieldBool):
    NAME = 'RSVD1'
    DESCRIPTION = 'Reserved Value: 1'
    DEFAULT_VALUE = 1
    MAX_VALUE = 1
    MIN_VALUE = 1
    LENGTH = 1
    LIMITS = {}

    def __init__(self, value=True, raw_value=1):
        super(RSVD1, self).__init__(RSVD1.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD1.NAME


class TRASH(BitfieldInt):
    NAME = 'Garbage Data'
    DESCRIPTION = 'Garbage Data'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TRASH, self).__init__(TRASH.LENGTH,  value=value, raw_value=raw_value)
        self.name = TRASH.NAME


class RSVD_BYTE0(BitfieldInt):
    NAME = 'Reserved Byte 0'
    DESCRIPTION = 'Reserved Byte 0'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE0, self).__init__(RSVD_BYTE0.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE0.NAME


class RSVD_BYTE1(BitfieldInt):
    NAME = 'Reserved Byte 1'
    DESCRIPTION = 'Reserved Byte 1'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE1, self).__init__(RSVD_BYTE1.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE1.NAME


class RSVD_BYTE2(BitfieldInt):
    NAME = 'Reserved Byte 2'
    DESCRIPTION = 'Reserved Byte 2'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE2, self).__init__(RSVD_BYTE2.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE2.NAME


class RSVD_BYTE3(BitfieldInt):
    NAME = 'Reserved Byte 3'
    DESCRIPTION = 'Reserved Byte 3'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE3, self).__init__(RSVD_BYTE3.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE3.NAME


class RSVD_BYTE4(BitfieldInt):
    NAME = 'Reserved Byte 4'
    DESCRIPTION = 'Reserved Byte 4'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE4, self).__init__(RSVD_BYTE4.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE4.NAME


class RSVD_BYTE5(BitfieldInt):
    NAME = 'Reserved Byte 5'
    DESCRIPTION = 'Reserved Byte 5'
    MEM_KEY = 'Reserved'
    DEFAULT_VALUE = 0
    MAX_VALUE = 255
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(RSVD_BYTE5, self).__init__(RSVD_BYTE5.LENGTH,  value=value, raw_value=raw_value)
        self.name = RSVD_BYTE5.NAME


class WAKEUP_TIME(BitfieldInt):
    NAME = 'Wakeup Time'
    DESCRIPTION = 'SPI CS Wakeup Time Pulse Width'
    DEFAULT_VALUE = 400
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(WAKEUP_TIME, self).__init__(WAKEUP_TIME.LENGTH,  value=value, raw_value=raw_value)
        self.name = WAKEUP_TIME.NAME


class FREQUENCY(BitfieldInt):
    NAME = 'Frequency'
    DESCRIPTION = 'Frequency'
    DEFAULT_VALUE = 1000
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(FREQUENCY, self).__init__(FREQUENCY.LENGTH,  value=value, raw_value=raw_value)
        self.name = FREQUENCY.NAME


class NUM_BOARDS(BitfieldInt):
    NAME = 'Num Boards'
    DESCRIPTION = 'Number of Boards'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(NUM_BOARDS, self).__init__(NUM_BOARDS.LENGTH,  value=value, raw_value=raw_value)
        self.name = NUM_BOARDS.NAME


class NUM_BYTES(BitfieldInt):
    NAME = 'Num Bytes'
    DESCRIPTION = 'Number of Bytes to Send'
    DEFAULT_VALUE = 3
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(NUM_BYTES, self).__init__(NUM_BYTES.LENGTH,  value=value, raw_value=raw_value)
        self.name = NUM_BYTES.NAME


class DELAY_TIME(BitfieldInt):
    NAME = 'Delay'
    DESCRIPTION = 'Delay Time'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(DELAY_TIME, self).__init__(DELAY_TIME.LENGTH,  value=value, raw_value=raw_value)
        self.name = DELAY_TIME.NAME


class GPIO_PIN(BitfieldInt):
    NAME = 'GPIO Pin'
    DESCRIPTION = 'GPIO Pin'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(GPIO_PIN, self).__init__(GPIO_PIN.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO_PIN.NAME


class GPIO_VAL(BitfieldInt):
    NAME = 'GPIO Value'
    DESCRIPTION = 'GPIO Value'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(GPIO_VAL, self).__init__(GPIO_VAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = GPIO_VAL.NAME


class TIMER_ID(BitfieldInt):
    NAME = 'Timer'
    DESCRIPTION = 'Timer ID'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TIMER_ID, self).__init__(TIMER_ID.LENGTH,  value=value, raw_value=raw_value)
        self.name = TIMER_ID.NAME


class TIMER_VAL(BitfieldInt):
    NAME = 'Timer Value'
    DESCRIPTION = 'Timer Result Value'
    DEFAULT_VALUE = 1
    MAX_VALUE = 2**8-1
    MIN_VALUE = 0
    LENGTH = 64
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(TIMER_VAL, self).__init__(TIMER_VAL.LENGTH,  value=value, raw_value=raw_value)
        self.name = TIMER_VAL.NAME


class LOOP_NUM(BitfieldInt):
    NAME = 'Loop Number'
    DESCRIPTION = 'Number of Loops to Run'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(LOOP_NUM, self).__init__(LOOP_NUM.LENGTH,  value=value, raw_value=raw_value)
        self.name = LOOP_NUM.NAME


class LOOP_INDEX(BitfieldInt):
    NAME = 'Loop Index'
    DESCRIPTION = 'Loop Command Index'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(LOOP_INDEX, self).__init__(LOOP_INDEX.LENGTH,  value=value, raw_value=raw_value)
        self.name = LOOP_INDEX.NAME


class LOOP_COUNTER(BitfieldInt):
    NAME = 'Loop Counter'
    DESCRIPTION = 'Loop Command Counter Setting'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(LOOP_COUNTER, self).__init__(LOOP_COUNTER.LENGTH,  value=value, raw_value=raw_value)
        self.name = LOOP_COUNTER.NAME


class JUMP_INCREMENT(BitfieldInt):
    NAME = 'Jump Increment'
    DESCRIPTION = 'Number of Commands to Execute on Positive Branch Evaluation'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(JUMP_INCREMENT, self).__init__(JUMP_INCREMENT.LENGTH,  value=value, raw_value=raw_value)
        self.name = JUMP_INCREMENT.NAME


class EVAL_INDEX(BitfieldInt):
    NAME = 'Eval Index'
    DESCRIPTION = 'Index of Command to Use for Branch Execution Evaluation'
    DEFAULT_VALUE = 1
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(EVAL_INDEX, self).__init__(EVAL_INDEX.LENGTH,  value=value, raw_value=raw_value)
        self.name = EVAL_INDEX.NAME


class VARIABLE_DATA(BitfieldInt):
    NAME = 'Variable Data'
    DESCRIPTION = 'User Defined Variable Data'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFFFF
    MIN_VALUE = 0
    LENGTH = 16
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VARIABLE_DATA, self).__init__(VARIABLE_DATA.LENGTH,  value=value, raw_value=raw_value)
        self.name = VARIABLE_DATA.NAME


class VAR_MAN(BitfieldInt):
    NAME = 'Var Man'
    DESCRIPTION = 'Variable Manipulation Setting'
    DEFAULT_VALUE = 0
    MAX_VALUE = 0xFF
    MIN_VALUE = 0
    LENGTH = 8
    LIMITS = {}

    def __init__(self, value=0, raw_value=0):
        super(VAR_MAN, self).__init__(VAR_MAN.LENGTH,  value=value, raw_value=raw_value)
        self.name = VAR_MAN.NAME


# ===================================================== Registers =====================================================
class Register():
    MEM_KEY = None
    NAME = None

    def __init__(self, bitfields):
        self.__bitfields = bitfields

    def bitfields(self, **kwargs):
        return self.__bitfields


class TRASH_Register(Register):
    MEM_KEY = 'Trash Register'
    NAME = 'TRASH0-5'

    def __init__(self):
        super(TRASH_Register, self).__init__(
            [[TRASH, 7], [TRASH, 6], [TRASH, 5], [TRASH, 4], [TRASH, 3], [TRASH, 2], [TRASH, 1], [TRASH, 0]])


class RSVDR0(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 0'

    def __init__(self):
        super(RSVDR0, self).__init__(
            [[RSVD_BYTE0, 7], [RSVD_BYTE0, 6], [RSVD_BYTE0, 5], [RSVD_BYTE0, 4], [RSVD_BYTE0, 3], [RSVD_BYTE0, 2], [RSVD_BYTE0, 1], [RSVD_BYTE0, 0]])


class RSVDR1(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 1'

    def __init__(self):
        super(RSVDR1, self).__init__(
            [[RSVD_BYTE1, 7], [RSVD_BYTE1, 6], [RSVD_BYTE1, 5], [RSVD_BYTE1, 4], [RSVD_BYTE1, 3], [RSVD_BYTE1, 2], [RSVD_BYTE1, 1], [RSVD_BYTE1, 0]])


class RSVDR2(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 2'

    def __init__(self):
        super(RSVDR2, self).__init__(
            [[RSVD_BYTE2, 7], [RSVD_BYTE2, 6], [RSVD_BYTE2, 5], [RSVD_BYTE2, 4], [RSVD_BYTE2, 3], [RSVD_BYTE2, 2], [RSVD_BYTE2, 1], [RSVD_BYTE2, 0]])


class RSVDR3(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 3'

    def __init__(self):
        super(RSVDR3, self).__init__(
            [[RSVD_BYTE3, 7], [RSVD_BYTE3, 6], [RSVD_BYTE3, 5], [RSVD_BYTE3, 4], [RSVD_BYTE3, 3], [RSVD_BYTE3, 2], [RSVD_BYTE3, 1], [RSVD_BYTE3, 0]])


class RSVDR4(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 4'

    def __init__(self):
        super(RSVDR4, self).__init__(
            [[RSVD_BYTE4, 7], [RSVD_BYTE4, 6], [RSVD_BYTE4, 5], [RSVD_BYTE4, 4], [RSVD_BYTE4, 3], [RSVD_BYTE4, 2], [RSVD_BYTE4, 1], [RSVD_BYTE4, 0]])


class RSVDR5(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register 5'

    def __init__(self):
        super(RSVDR5, self).__init__(
            [[RSVD_BYTE5, 7], [RSVD_BYTE5, 6], [RSVD_BYTE5, 5], [RSVD_BYTE5, 4], [RSVD_BYTE5, 3], [RSVD_BYTE5, 2], [RSVD_BYTE5, 1], [RSVD_BYTE5, 0]])


class RSVDR(Register):
    MEM_KEY = 'Reserved Register'
    NAME = 'Reserved Register'

    def __init__(self):
        super(RSVDR, self).__init__([[RSVD1, 0], [RSVD1, 0], [RSVD1, 0], [RSVD1, 0], [RSVD1, 0], [RSVD1, 0], [RSVD1, 0], [RSVD1, 0]])


class WAKEUP_TIME_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Wakeup Time Register'

    def __init__(self):
        super(WAKEUP_TIME_REGISTER, self).__init__(
            [[WAKEUP_TIME, 15], [WAKEUP_TIME, 14], [WAKEUP_TIME, 13], [WAKEUP_TIME, 12], [WAKEUP_TIME, 11], [WAKEUP_TIME, 10], [WAKEUP_TIME, 9], [WAKEUP_TIME, 8],
             [WAKEUP_TIME, 7], [WAKEUP_TIME, 6], [WAKEUP_TIME, 5], [WAKEUP_TIME, 4], [WAKEUP_TIME, 3], [WAKEUP_TIME, 2], [WAKEUP_TIME, 1], [WAKEUP_TIME, 0]])


class FREQUENCY_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Frequency Register'

    def __init__(self):
        super(FREQUENCY_REGISTER, self).__init__(
            [[FREQUENCY, 15], [FREQUENCY, 14], [FREQUENCY, 13], [FREQUENCY, 12], [FREQUENCY, 11], [FREQUENCY, 10], [FREQUENCY, 9], [FREQUENCY, 8],
             [FREQUENCY, 7], [FREQUENCY, 6], [FREQUENCY, 5], [FREQUENCY, 4], [FREQUENCY, 3], [FREQUENCY, 2], [FREQUENCY, 1], [FREQUENCY, 0]])


class NUM_BOARDS_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Num Boards Register'

    def __init__(self):
        super(NUM_BOARDS_REGISTER, self).__init__(
            [[NUM_BOARDS, 7], [NUM_BOARDS, 6], [NUM_BOARDS, 5], [NUM_BOARDS, 4], [NUM_BOARDS, 3], [NUM_BOARDS, 2], [NUM_BOARDS, 1], [NUM_BOARDS, 0]])


class NUM_BYTES_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Num Bytes Register'

    def __init__(self):
        super(NUM_BYTES_REGISTER, self).__init__(
            [[NUM_BYTES, 7], [NUM_BYTES, 6], [NUM_BYTES, 5], [NUM_BYTES, 4], [NUM_BYTES, 3], [NUM_BYTES, 2], [NUM_BYTES, 1], [NUM_BYTES, 0]])


class DELAY_TIME_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Delay Time Register'

    def __init__(self):
        super(DELAY_TIME_REGISTER, self).__init__(
            [[DELAY_TIME, 15], [DELAY_TIME, 14], [DELAY_TIME, 13], [DELAY_TIME, 12], [DELAY_TIME, 11], [DELAY_TIME, 10], [DELAY_TIME, 9], [DELAY_TIME, 8],
             [DELAY_TIME, 7], [DELAY_TIME, 6], [DELAY_TIME, 5], [DELAY_TIME, 4], [DELAY_TIME, 3], [DELAY_TIME, 2], [DELAY_TIME, 1], [DELAY_TIME, 0]])


class EVAL_INDEX_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Evaluation Index Register'

    def __init__(self):
        super(EVAL_INDEX_REGISTER, self).__init__(
            [[EVAL_INDEX, 15], [EVAL_INDEX, 14], [EVAL_INDEX, 13], [EVAL_INDEX, 12], [EVAL_INDEX, 11], [EVAL_INDEX, 10], [EVAL_INDEX, 9], [EVAL_INDEX, 8],
             [EVAL_INDEX, 7], [EVAL_INDEX, 6], [EVAL_INDEX, 5], [EVAL_INDEX, 4], [EVAL_INDEX, 3], [EVAL_INDEX, 2], [EVAL_INDEX, 1], [EVAL_INDEX, 0]])


class VARIABLE_MANIPULATION_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Variable Manipulation Setting Register'

    def __init__(self):
        super(VARIABLE_MANIPULATION_REGISTER, self).__init__(
             [[VAR_MAN, 7], [VAR_MAN, 6], [VAR_MAN, 5], [VAR_MAN, 4], [VAR_MAN, 3], [VAR_MAN, 2], [VAR_MAN, 1], [VAR_MAN, 0]])


class VARIABLE_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Variable Register'

    def __init__(self):
        super(VARIABLE_REGISTER, self).__init__(
            [[VARIABLE_DATA, 15], [VARIABLE_DATA, 14], [VARIABLE_DATA, 13], [VARIABLE_DATA, 12], [VARIABLE_DATA, 11], [VARIABLE_DATA, 10], [VARIABLE_DATA, 9], [VARIABLE_DATA, 8],
             [VARIABLE_DATA, 7], [VARIABLE_DATA, 6], [VARIABLE_DATA, 5], [VARIABLE_DATA, 4], [VARIABLE_DATA, 3], [VARIABLE_DATA, 2], [VARIABLE_DATA, 1], [VARIABLE_DATA, 0]])


class GPIO_PIN_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'GPIO Pin Register'

    def __init__(self):
        super(GPIO_PIN_REGISTER, self).__init__(
            [[GPIO_PIN, 7], [GPIO_PIN, 6], [GPIO_PIN, 5], [GPIO_PIN, 4], [GPIO_PIN, 3], [GPIO_PIN, 2], [GPIO_PIN, 1], [GPIO_PIN, 0]])


class GPIO_VAL_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'GPIO Value Register'

    def __init__(self):
        super(GPIO_VAL_REGISTER, self).__init__(
            [[GPIO_VAL, 7], [GPIO_VAL, 6], [GPIO_VAL, 5], [GPIO_VAL, 4], [GPIO_VAL, 3], [GPIO_VAL, 2], [GPIO_VAL, 1], [GPIO_VAL, 0]])


class TIMER_ID_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Timer ID Register'

    def __init__(self):
        super(TIMER_ID_REGISTER, self).__init__(
            [[TIMER_ID, 7], [TIMER_ID, 6], [TIMER_ID, 5], [TIMER_ID, 4], [TIMER_ID, 3], [TIMER_ID, 2], [TIMER_ID, 1], [TIMER_ID, 0]])


class TIMER_VAL_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Timer Value Register'

    def __init__(self):
        super(TIMER_VAL_REGISTER, self).__init__(
            [
                [TIMER_VAL, 63], [TIMER_VAL, 62], [TIMER_VAL, 61], [TIMER_VAL, 60], [TIMER_VAL, 59], [TIMER_VAL, 58], [TIMER_VAL, 57], [TIMER_VAL, 56],
                [TIMER_VAL, 55], [TIMER_VAL, 54], [TIMER_VAL, 53], [TIMER_VAL, 52], [TIMER_VAL, 51], [TIMER_VAL, 50], [TIMER_VAL, 49], [TIMER_VAL,48],
                [TIMER_VAL, 47], [TIMER_VAL, 46], [TIMER_VAL, 45], [TIMER_VAL, 44], [TIMER_VAL, 43], [TIMER_VAL, 42], [TIMER_VAL, 41], [TIMER_VAL, 40],
                [TIMER_VAL, 39], [TIMER_VAL, 38], [TIMER_VAL, 37], [TIMER_VAL, 36], [TIMER_VAL, 35], [TIMER_VAL, 34], [TIMER_VAL, 33], [TIMER_VAL, 32],
                [TIMER_VAL, 31], [TIMER_VAL, 30], [TIMER_VAL, 29], [TIMER_VAL, 28], [TIMER_VAL, 27], [TIMER_VAL, 26], [TIMER_VAL, 25], [TIMER_VAL, 24],
                [TIMER_VAL, 23], [TIMER_VAL, 22], [TIMER_VAL, 21], [TIMER_VAL, 20], [TIMER_VAL, 19], [TIMER_VAL, 18], [TIMER_VAL, 17], [TIMER_VAL, 16],
                [TIMER_VAL, 15], [TIMER_VAL, 14], [TIMER_VAL, 13], [TIMER_VAL, 12], [TIMER_VAL, 11], [TIMER_VAL, 10], [TIMER_VAL, 9], [TIMER_VAL, 8],
                [TIMER_VAL, 7], [TIMER_VAL, 6], [TIMER_VAL, 5], [TIMER_VAL, 4], [TIMER_VAL, 3], [TIMER_VAL, 2], [TIMER_VAL, 1], [TIMER_VAL, 0]])


class LOOP_NUM_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Loop Number Register'

    def __init__(self):
        super(LOOP_NUM_REGISTER, self).__init__(
            [
                [LOOP_NUM, 15], [LOOP_NUM, 14], [LOOP_NUM, 13], [LOOP_NUM, 12], [LOOP_NUM, 11], [LOOP_NUM, 10], [LOOP_NUM, 9], [LOOP_NUM, 8],
                [LOOP_NUM, 7], [LOOP_NUM, 6], [LOOP_NUM, 5], [LOOP_NUM, 4], [LOOP_NUM, 3], [LOOP_NUM, 2], [LOOP_NUM, 1], [LOOP_NUM, 0]])


class LOOP_INDEX_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Loop Command Index Register'

    def __init__(self):
        super(LOOP_INDEX_REGISTER, self).__init__(
            [
                [LOOP_INDEX, 15], [LOOP_INDEX, 14], [LOOP_INDEX, 13], [LOOP_INDEX, 12], [LOOP_INDEX, 11], [LOOP_INDEX, 10], [LOOP_INDEX, 9], [LOOP_INDEX, 8],
                [LOOP_INDEX, 7], [LOOP_INDEX, 6], [LOOP_INDEX, 5], [LOOP_INDEX, 4], [LOOP_INDEX, 3], [LOOP_INDEX, 2], [LOOP_INDEX, 1], [LOOP_INDEX, 0]])


class LOOP_COUNTER_REGISTER(Register):
    MEM_KEY = 'Miscellaneous'
    NAME = 'Loop Counter Register'

    def __init__(self):
        super(LOOP_COUNTER_REGISTER, self).__init__([[LOOP_COUNTER, 7], [LOOP_COUNTER, 6], [LOOP_COUNTER, 5], [LOOP_COUNTER, 4], [LOOP_COUNTER, 3], [LOOP_COUNTER, 2], [LOOP_COUNTER, 1], [LOOP_COUNTER, 0]])


# ===================================================== Commands =====================================================
class Command():
    STATIC = []
    STATIC_LENGTH = None
    VARIABLE = []
    VARIABLE_LENGTH = None
    NAME = None
    DESCRIPTION = None
    HIDDEN = False

    LOOP = 'loop'
    REPEAT = 'repeat'
    TIMER_START = 'timer_start'
    TIMER_STOP = 'timer_stop'
    SPI_CLOCK_OUT = 'spi_clock_out'
    SPI_SET_FREQUENCY_KHZ = 'spi_set_frequency_khz'
    I2C_WRITE = 'i2c_write'
    I2C_READ = 'i2c_read'
    WRITE_I2C_DUT = 'write_i2c_dut'
    READ_I2C_DUT = 'read_i2c_dut'
    SPI_WRITE = 'spi_write'
    SPI_READ = 'spi_read'
    I2C_SET_FREQUENCY_KHZ = 'i2c_set_frequency_khz'
    SPI_SET_MODE = 'spi_set_mode'
    SPI_SLAVE_POLL = 'spi_slave_poll'
    SPI_SLAVE_READ = 'spi_slave_read'
    SPI_SLAVE_WRITE = 'spi_slave_write'
    UART_WRITE = 'uart_write'
    UART_READ = 'uart_read'
    UART_WAKEUP = 'uart_wakeup'
    PWM_START = 'pwm_start'
    PWM_STOP = 'pwm_stop'

    def __init__(self, map_key=None, **kwargs):
        self.static_bitfields = []
        self.variable_bitfields = []
        self.bits = []
        self.bytes = []
        self.map_key = map_key
        self.local_definitions = {}
        self.total_pec_status = None
        self.device_total_pec_status = []
        self.tx_length = 0
        self.rx_length = 0

    @classmethod
    def info(cls):
        return {'name': cls.NAME, 'description': cls.DESCRIPTION}

    @classmethod
    def __get_name(cls):
        return cls.NAME

    @classmethod
    def __get_static(cls):
        return cls.STATIC

    @classmethod
    def __get_variable(cls):
        return cls.VARIABLE

    def quick_view(self):
        statics = {}
        statics_raw = {}
        variables = []
        variables_raw = []
        for bitfield in self.static_bitfields:
            statics[bitfield.NAME] = bitfield.value
            statics_raw[bitfield.NAME] = bitfield.raw_val
        temp_variable_bitfields = self.variable_bitfields
        if hasattr(self, 'REVERSE_WRITE_BYTES'):
            if self.REVERSE_WRITE_BYTES:
                temp_variable_bitfields = self.variable_bitfields[::-1]
        for i in range(len(temp_variable_bitfields)):
            variables.append({})
            variables_raw.append({})
            for bitfield in temp_variable_bitfields[i]:
                variables[-1][bitfield.NAME] = bitfield.value
                variables_raw[-1][bitfield.NAME] = bitfield.raw_val
        return {'name': self.NAME, 'pec_status': self.total_pec_status, 'static': statics, 'variable': variables, 'static_raw': statics_raw, 'variable_raw': variables_raw}

    def build_bitfields(self, **kwargs):
        self.bits = []
        self.bytes = []
        self.tx_length = 0
        self.rx_length = 0
        # Calculate number of bits
        for bitfield in self.static_bitfields:
            if not bitfield.readback:
                self.bits += [None] * bitfield.length
                self.tx_length += bitfield.length
            else:
                self.rx_length += bitfield.length
        for device in self.variable_bitfields:
            for bitfield in device:
                if not bitfield.readback:
                    self.bits += [None] * bitfield.length
                    self.tx_length += bitfield.length
                else:
                    self.rx_length += bitfield.length
        # Static
        for bitfield in self.static_bitfields:
            if not bitfield.readback:
                self.bits = bitfield.convert_to_bitlist(self.bits)
        # Variable
        for device in self.variable_bitfields:
            for bitfield in device:
                if not bitfield.readback:
                    self.bits = bitfield.convert_to_bitlist(self.bits)
        # Create Bytes
        self.bytes = [None]*int(len(self.bits)/8)
        temp = 0
        for count, bit in enumerate(self.bits):
            if not (count % 8) and count > 0:
                self.bytes[int(count/8)-1] = temp
                temp = 0
            temp = (temp << 1) | bit
        self.bytes[-1] = temp
        return self.bits, self.bytes

    def parse_bitfields(self, bitlist, board_list, **kwargs):
        self.total_pec_status = True
        self.device_total_pec_status = []
        # Static
        for bitfield in self.static_bitfields:
            bitfield.convert_from_bitlist(bitlist, **kwargs)
            if bitfield.pec_status is not None:
                if not bitfield.pec_status:
                    self.total_pec_status = False
            if bitfield.SAVE_STATE:
                for board in board_list:
                    board[bitfield.NAME] = bitfield.value
        # Variable
        for index, device in enumerate(self.variable_bitfields):
            temp_kwargs = {}
            temp_kwargs.update(**kwargs)
            temp_kwargs.update(**board_list[index])
            self.device_total_pec_status.append(self.total_pec_status)  # Start with static pec status
            for bitfield in device:
                bitfield.convert_from_bitlist(bitlist, **temp_kwargs)
                if bitfield.pec_status is not None:
                    if not bitfield.pec_status:
                        self.total_pec_status = False
                        self.device_total_pec_status[index] = False
                if bitfield.SAVE_STATE:
                    board_list[index][bitfield.NAME] = bitfield.value
        return self.static_bitfields, self.variable_bitfields

    def compile_command(self, board_list, **kwargs):
        # Create bitfield relationship map
        bit_index = 0
        # Static
        static_bitfield_index = {}
        temp_kwargs = {}
        temp_kwargs.update(**kwargs)
        temp_kwargs.update(**board_list[0])
        temp_kwargs.update(**self.local_definitions)
        if hasattr(board_list[0]['Device'], "ADDRESS_BOOK"):
            temp_kwargs.update({'address_book': board_list[0]['Device'].ADDRESS_BOOK})
        for reg in self.__get_static():
            for bitfield in reg[0].bitfields(**temp_kwargs):
                # Check if bitfield location is overloaded
                for i in range(0, len(bitfield), 2):
                    # Create bitfield if it does not exist
                    if bitfield[i].NAME not in static_bitfield_index:
                        # Create bitfield
                        # Check for overrides
                        if bitfield[i].NAME in board_list[0]:
                            if isinstance(board_list[0][bitfield[i].NAME], Bitfield):
                                self.static_bitfields.append(copy.deepcopy(board_list[0][bitfield[i].NAME]))
                            else:
                                self.static_bitfields.append(board_list[0]['Device'].BITFIELDS[bitfield[i].NAME](value=board_list[0][bitfield[i].NAME]))
                        elif bitfield[i].NAME in kwargs:
                            if isinstance(kwargs[bitfield[i].NAME], Bitfield):
                                self.static_bitfields.append(kwargs[bitfield[i].NAME])
                            else:
                                self.static_bitfields.append(
                                    board_list[0]['Device'].BITFIELDS[bitfield[i].NAME](value=kwargs[bitfield[i].NAME]))
                        elif bitfield[i].NAME in self.local_definitions:
                            self.static_bitfields.append(self.local_definitions[bitfield[i].NAME])
                        else:
                            self.static_bitfields.append(board_list[0]['Device'].BITFIELDS[bitfield[i].NAME](value=board_list[0]['Device'].BITFIELDS[bitfield[i].NAME].DEFAULT_VALUE))
                        self.static_bitfields[-1].readback = reg[1]  # Mark bitfield as write/read
                        static_bitfield_index[bitfield[i].NAME] = len(self.static_bitfields) - 1
                    # Update bitfield index
                    self.static_bitfields[static_bitfield_index[bitfield[i].NAME]].bit_list_index[
                        bitfield[1]] = bit_index
                    # Check if bitfield is complete, to make room for duplicates
                    if None not in self.static_bitfields[static_bitfield_index[bitfield[i].NAME]].bit_list_index:
                        # Check if bitfield needs to be added to board list
                        if self.static_bitfields[static_bitfield_index[bitfield[i].NAME]].SAVE_STATE:
                            for board in board_list:
                                board[bitfield[i].NAME] = self.static_bitfields[static_bitfield_index[bitfield[i].NAME]].value
                        static_bitfield_index.pop(bitfield[i].NAME)
                bit_index += 1
        # Variable
        variable_bitfield_index = []
        if hasattr(self, 'REVERSE_WRITE_BYTES'):
            if self.REVERSE_WRITE_BYTES:
                board_list = board_list[::-1]
        for i, board in enumerate(board_list):
            temp_kwargs = {}
            temp_kwargs.update(**kwargs)
            temp_kwargs.update(**board_list[i])
            temp_kwargs.update(**self.local_definitions)
            if hasattr(board['Device'], "ADDRESS_BOOK"):
                temp_kwargs.update({'address_book': board['Device'].ADDRESS_BOOK})
            self.variable_bitfields.append([])
            variable_bitfield_index.append({})
            if self.__get_name() not in board['Device'].COMMANDS:
                raise ValueError('Device [%s] does not contain command [%s]' % (board['Device'], self.__get_name()))
            for reg in board['Device'].COMMANDS[self.__get_name()].VARIABLE:  # Pull up correct command definition
                for bitfield in reg[0].bitfields(**temp_kwargs):
                    # Check if bitfield location is overloaded
                    for j in range(0, len(bitfield), 2):
                        # Create bitfield if it does not exist
                        if bitfield[j].NAME not in variable_bitfield_index[i]:
                            # Create bitfield
                            # Check for overrides, board > kwargs > local > default
                            if bitfield[j].NAME in board:
                                if isinstance(board[bitfield[j].NAME], Bitfield):
                                    self.variable_bitfields[i].append(copy.deepcopy(board[bitfield[j].NAME]))
                                else:
                                    self.variable_bitfields[i].append(board['Device'].BITFIELDS[bitfield[j].NAME](value=board[bitfield[j].NAME]))
                            elif bitfield[j].NAME in kwargs:
                                if isinstance(kwargs[bitfield[j].NAME], Bitfield):
                                    self.variable_bitfields[i].append(copy.deepcopy(kwargs[bitfield[j].NAME]))
                                else:
                                    self.variable_bitfields[i].append(board['Device'].BITFIELDS[bitfield[j].NAME](value=kwargs[bitfield[j].NAME]))
                            elif bitfield[j].NAME in self.local_definitions:
                                self.variable_bitfields[i].append(
                                    copy.deepcopy(self.local_definitions[bitfield[j].NAME]))
                            else:
                                self.variable_bitfields[i].append(
                                    board_list[i]['Device'].BITFIELDS[bitfield[j].NAME](value=board_list[i]['Device'].BITFIELDS[bitfield[j].NAME].DEFAULT_VALUE))
                            self.variable_bitfields[i][-1].readback = reg[1]  # Mark bitfield as write/read
                            variable_bitfield_index[i][bitfield[j].NAME] = len(self.variable_bitfields[i]) - 1
                        # Update bitfield index
                        self.variable_bitfields[i][variable_bitfield_index[i][bitfield[j].NAME]].bit_list_index[
                            bitfield[j + 1]] = bit_index
                        # Check if bitfield is complete, to make room for duplicates
                        if None not in self.variable_bitfields[i][
                            variable_bitfield_index[i][bitfield[j].NAME]].bit_list_index:
                            # Check if bitfield needs to be added to board list
                            if self.variable_bitfields[i][variable_bitfield_index[i][bitfield[j].NAME]].SAVE_STATE:
                                board_list[i][bitfield[j].NAME] = self.variable_bitfields[i][variable_bitfield_index[i][bitfield[j].NAME]].value
                            variable_bitfield_index[i].pop(bitfield[j].NAME)
                    bit_index += 1
        self.build_bitfields(**temp_kwargs)
        return self


class SPICommand(Command):

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(SPICommand, self).__init__(map_key=map_key, **kwargs)
        self.spi_bus = spi_bus
        self.spi_cs = spi_cs
        self.tx_length = 0
        self.rx_length = 0


class SPIWrite(SPICommand):
    REVERSE_WRITE_BYTES = True
    TYPE = 'spi_write'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(SPIWrite, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class SPIRead(SPICommand):
    TYPE = 'spi_read'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(SPIRead, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class MATH_EVAL(SPICommand):
    NAME = '$MATH_EVAL$'
    DESCRIPTION = 'Python Code Evaluation'
    TYPE = 'math_eval'

    def __init__(self, map_key=None, result=None, function=None, **kwargs):
        super(MATH_EVAL, self).__init__(map_key=map_key, **kwargs)
        if not result or not function:
            raise ValueError('Must provide a result name and function string')
        self.result_name = result
        self.function = function

    def compile_command(self, board_list, **kwargs):
        # for i, board in enumerate(board_list):
        #     self.variable_bitfields.append([Bitfield(length=0)])
        pass

    def parse_bitfields(self, board_list, **kwargs):
        # for i in range(len(map_key_data)):
        #     try:
        #         map_key_data[i][self.result_name] = eval(self.function.format(**map_key_data[i]))
        #         self.variable_bitfields[i][0].value = map_key_data[i][self.result_name]
        #         self.variable_bitfields[i][0].raw_value = map_key_data[i][self.result_name]
        #     except:
        #         map_key_data[i][self.result_name] = None
        pass


class SPIWriteGeneric(SPICommand):
    NAME = '$SPI_Generic_Write$'
    DESCRIPTION = 'Raw SPI Write'
    TYPE = 'spi_write'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, data=None, **kwargs):
        super(SPIWriteGeneric, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, data=data, **kwargs)
        self.tx_data = data
        if data is None:
            raise ValueError("Must provide list of data to transmit")

    def compile_command(self, board_list, **kwargs):
        bit_index = 0
        for i, entry in enumerate(self.tx_data):
            new_class = type("TX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "TX_DATA%s" % i
            new_class.DESCRIPTION = 'Transmit Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class SPIReadGeneric(SPICommand):
    NAME = '$SPI_Generic_Read$'
    DESCRIPTION = 'Raw SPI Read'
    TYPE = 'spi_read'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, data=None, num_read_bytes=None, **kwargs):
        super(SPIReadGeneric, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, data=data, num_read_bytes=num_read_bytes, **kwargs)
        if data is None:
            data = []
        self.tx_data = data
        if num_read_bytes is None:
            raise ValueError("Must provide number of bytes to read")
        self.num_read_bytes = num_read_bytes

    def compile_command(self, board_list, **kwargs):
        bit_index = 0
        for i, entry in enumerate(self.tx_data):
            new_class = type("TX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "TX_DATA%s" % i
            new_class.DESCRIPTION = 'Transmit Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(self.num_read_bytes):
            new_class = type("RX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "RX_DATA%s" % i
            new_class.DESCRIPTION = 'Receive Data'
            new_class.DEFAULT_VALUE = 0
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=0, raw_value=0))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
            self.static_bitfields[-1].readback = True
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class SPIPoll(SPICommand):
    TYPE = 'poll'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(SPIPoll, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)

    def compile_command(self, board_list, **kwargs):
        super().compile_command(board_list, **kwargs)
        num_extra_clocks = int((2*len(board_list)-1)/8)+1
        self.bytes += [0xFF]*num_extra_clocks
        self.tx_length += num_extra_clocks*8



class SPIWriteOpen(SPICommand):
    TYPE = 'write_open'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(SPIWriteOpen, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class SPIWakeup(SPICommand):
    STATIC = [[WAKEUP_TIME_REGISTER(), False], [NUM_BOARDS_REGISTER(), False]]
    STATIC_LENGTH = 3
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$SPI_WAKEUP$'
    DESCRIPTION = 'Issues SPI CS Wakeup Pulse'
    TYPE = 'spi_wakeup'

    def __init__(self, map_key=None, spi_bus=None, spi_cs=None, **kwargs):
        super(SPIWakeup, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class SPIClockOut(SPICommand):
    STATIC = [[NUM_BYTES_REGISTER(), False]]
    STATIC_LENGTH = 1
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$SPI_CLOCK_OUT$'
    DESCRIPTION = 'Sends SPI clock cycles in 8 bit increments'
    TYPE = 'spi_clock_out'

    def __init__(self, map_key=None, spi_bus=None, spi_cs=None, **kwargs):
        super(SPIClockOut, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class SPISetFrequencyKHz(SPICommand):
    STATIC = [[FREQUENCY_REGISTER(), False]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$SPI_SET_FREQUENCY_kHz$'
    DESCRIPTION = 'Sets SPI Frequency in kHz'
    TYPE = 'spi_set_frequency_khz'

    def __init__(self, map_key=None, spi_bus=None, spi_cs=None, **kwargs):
        super(SPISetFrequencyKHz, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=spi_cs, **kwargs)


class I2CCommand(Command):

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(I2CCommand, self).__init__(map_key=map_key, **kwargs)
        self.spi_bus = spi_bus
        self.spi_cs = spi_cs
        self.tx_length = 0
        self.rx_length = 0


class I2CWrite(I2CCommand):
    REVERSE_WRITE_BYTES = True
    TYPE = 'write_i2c_dut'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(I2CWrite, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=0, **kwargs)


class I2CRead(I2CCommand):
    TYPE = 'read_i2c_dut'

    def __init__(self, map_key=None, spi_bus=0, spi_cs=0, **kwargs):
        super(I2CRead, self).__init__(map_key=map_key, spi_bus=spi_bus, spi_cs=0, **kwargs)


class I2CWriteGeneric(SPICommand):
    NAME = '$I2C_Generic_Write$'
    DESCRIPTION = 'Raw I2C Write'
    TYPE = 'i2c_write'

    def __init__(self, map_key=None, spi_bus=0, data=None, **kwargs):
        super(I2CWriteGeneric, self).__init__(map_key=map_key, i2c_bus=spi_bus, data=data, **kwargs)
        self.tx_data = data
        if data is None:
            raise ValueError("Must provide list of data to transmit")

    def compile_command(self, board_list, **kwargs):
        bit_index = 0
        for i, entry in enumerate(self.tx_data):
            new_class = type("TX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "TX_DATA%s" % i
            new_class.DESCRIPTION = 'Transmit Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class I2CReadGeneric(SPICommand):
    NAME = '$I2C_Generic_Read$'
    DESCRIPTION = 'Raw I2C Read'
    TYPE = 'i2c_read'

    def __init__(self, map_key=None, spi_bus=0, data=None, num_read_bytes=None, **kwargs):
        super(I2CReadGeneric, self).__init__(map_key=map_key, i2c_bus=spi_bus, data=data, num_read_bytes=num_read_bytes, **kwargs)
        if data is None:
            data = []
        self.tx_data = data
        if num_read_bytes is None:
            raise ValueError("Must provide number of bytes to read")
        self.num_read_bytes = num_read_bytes

    def compile_command(self, board_list, **kwargs):
        bit_index = 0
        for i, entry in enumerate(self.tx_data):
            new_class = type("TX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "TX_DATA%s" % i
            new_class.DESCRIPTION = 'Transmit Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(self.num_read_bytes):
            new_class = type("RX_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "RX_DATA%s" % i
            new_class.DESCRIPTION = 'Receive Data'
            new_class.DEFAULT_VALUE = 0
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=0, raw_value=0))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
            self.static_bitfields[-1].readback = True
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class I2CSetFrequencyKHz(SPICommand):
    STATIC = [[FREQUENCY_REGISTER(), False]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$I2C_SET_FREQUENCY_kHz$'
    DESCRIPTION = 'Sets I2C Frequency in kHz'
    TYPE = 'i2c_set_frequency_khz'

    def __init__(self, map_key=None, spi_bus=None, spi_cs=None, **kwargs):
        super(I2CSetFrequencyKHz, self).__init__(map_key=map_key, i2c_bus=spi_bus, **kwargs)


class DELAY_MS(Command):
    STATIC = [[DELAY_TIME_REGISTER(), False]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$DELAY_MS$'
    DESCRIPTION = 'Millisecond Delay'
    TYPE = 'delay_ms'

    def __init__(self, **kwargs):
        super(DELAY_MS, self).__init__(**kwargs)


class DELAY_US(Command):
    STATIC = [[DELAY_TIME_REGISTER(), False]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$DELAY_US$'
    DESCRIPTION = 'Microsecond Delay'
    TYPE = 'delay_us'

    def __init__(self, **kwargs):
        super(DELAY_US, self).__init__(**kwargs)


class GPIO_WRITE(Command):
    STATIC = [[GPIO_PIN_REGISTER(), False], [GPIO_VAL_REGISTER(), False]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$GPIO_WRITE$'
    DESCRIPTION = 'MCU GPIO Write'
    TYPE = 'gpio_write'

    def __init__(self, **kwargs):
        super(GPIO_WRITE, self).__init__(**kwargs)


class GPIO_READ(Command):
    STATIC = [[GPIO_PIN_REGISTER(), False], [GPIO_VAL_REGISTER(), True]]
    STATIC_LENGTH = 2
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$GPIO_READ$'
    DESCRIPTION = 'MCU GPIO Read'
    TYPE = 'gpio_read'

    def __init__(self, **kwargs):
        super(GPIO_READ, self).__init__(**kwargs)


class START_TIMER(Command):
    STATIC = [[TIMER_ID_REGISTER(), False]]
    STATIC_LENGTH = 1
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$START_TIMER$'
    DESCRIPTION = 'Start MCU Timer'
    TYPE = 'timer_start'

    def __init__(self, **kwargs):
        super(START_TIMER, self).__init__(**kwargs)


class STOP_TIMER(Command):
    STATIC = [[TIMER_ID_REGISTER(), False], [TIMER_VAL_REGISTER(), True]]
    STATIC_LENGTH = 9
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$STOP_TIMER$'
    DESCRIPTION = 'Stop MCU Timer'
    TYPE = 'timer_stop'

    def __init__(self, **kwargs):
        super(STOP_TIMER, self).__init__(**kwargs)


class REPEAT(Command):
    STATIC = [[LOOP_NUM_REGISTER(), False], [LOOP_INDEX_REGISTER(), False]]
    STATIC_LENGTH = 4
    VARIABLE = []
    VARIABLE_LENGTH = 0
    NAME = '$REPEAT$'
    DESCRIPTION = 'Repeats All Commands From Specified Index By Number of Loops Provided'
    TYPE = 'repeat'

    def __init__(self, **kwargs):
        super(REPEAT, self).__init__(**kwargs)


class VARIABLE(Command):
    STATIC = [[EVAL_INDEX_REGISTER(), False], [VARIABLE_MANIPULATION_REGISTER(), False]]
    STATIC_LENGTH = 3
    VARIABLE = [[VARIABLE_REGISTER(), False]]
    VARIABLE_LENGTH = 2
    NAME = '$VARIABLE$'
    DESCRIPTION = 'Holds/Manipulates a 16 bit variable'
    TYPE = 'variable'

    def __init__(self, **kwargs):
        super(VARIABLE, self).__init__(**kwargs)


class LOOP_CMD(Command):
    NAME = '$LOOP_CMD$'
    DESCRIPTION = 'Loops Over Previous Command Until Mask Matches or Mask Changes (Counter = 1)'
    TYPE = 'loop'

    def __init__(self, map_key=None, loop_num=None, mask=None, counter=False, **kwargs):
        super(LOOP_CMD, self).__init__(map_key=map_key, loop_num=loop_num, mask=mask, counter=counter, **kwargs)
        self.tx_data = mask
        self.counter = counter
        self.loop_num = loop_num
        if mask is None:
            raise ValueError("Must provide a loop mask")
        if loop_num is None:
            raise ValueError("Must provide number of loops")

    def compile_command(self, board_list, **kwargs):
        temp_kwargs = copy.deepcopy(kwargs)
        temp_kwargs.update({'Loop Number': self.loop_num})
        temp_kwargs.update({'Loop Counter': self.counter})
        bit_index = 0
        self.static_bitfields.append(LOOP_NUM(value=self.loop_num))
        for j in range(15, -1, -1):
            self.static_bitfields[-1].bit_list_index[j] = bit_index
            bit_index += 1
        self.static_bitfields.append(LOOP_COUNTER(value=self.counter))
        for j in range(7, -1, -1):
            self.static_bitfields[-1].bit_list_index[j] = bit_index
            bit_index += 1
        if self.counter:
            self.rx_length = len(self.tx_data)
        for i, entry in enumerate(self.tx_data):
            new_class = type("MASK_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "MASK_DATA%s" % i
            new_class.DESCRIPTION = 'Mask Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class BRANCH_CMD(Command):
    NAME = '$BRANCH_CMD$'
    DESCRIPTION = 'Branches Command Execution Depending On Mask Match'
    TYPE = 'branch'
    HIDDEN = True

    def __init__(self, map_key=None, jump_increment=None, eval_index=None, mask=None, **kwargs):
        super(BRANCH_CMD, self).__init__(map_key=map_key, jump_increment=jump_increment, eval_index=eval_index, mask=mask, **kwargs)
        self.tx_data = mask
        self.jump_increment = jump_increment
        self.eval_index = eval_index
        if mask is None:
            raise ValueError("Must provide a evaluation mask")
        if jump_increment is None:
            raise ValueError("Must provide a jump increment value")
        if eval_index is None:
            raise ValueError("Must provide an index of a command to use for branch evaluation")

    def compile_command(self, board_list, **kwargs):
        temp_kwargs = copy.deepcopy(kwargs)
        temp_kwargs.update({'Jump Increment': self.jump_increment})
        temp_kwargs.update({'Eval Index': self.eval_index})
        bit_index = 0
        self.static_bitfields.append(EVAL_INDEX(value=self.eval_index))
        for j in range(15, -1, -1):
            self.static_bitfields[-1].bit_list_index[j] = bit_index
            bit_index += 1
        self.static_bitfields.append(JUMP_INCREMENT(value=self.jump_increment))
        for j in range(15, -1, -1):
            self.static_bitfields[-1].bit_list_index[j] = bit_index
            bit_index += 1
        for i, entry in enumerate(self.tx_data):
            new_class = type("MASK_DATA%s" % i, (BitfieldInt,), {})
            new_class.NAME = "MASK_DATA%s" % i
            new_class.DESCRIPTION = 'Mask Data'
            new_class.DEFAULT_VALUE = entry
            new_class.MAX_VALUE = 0xFF
            new_class.MIN_VALUE = 0
            new_class.LENGTH = 8
            self.static_bitfields.append(new_class(length=8, value=entry, raw_value=entry))
            for j in range(7, -1, -1):
                self.static_bitfields[-1].bit_list_index[j] = bit_index
                bit_index += 1
        for i in range(len(board_list)):
            self.variable_bitfields.append([])
        self.build_bitfields(**kwargs)


class BMS_Config(ABC):
    PASS = 'Pass'
    FAIL = 'Fail'
    NAME = 'BMS_DUT'
    MEMORY_MAP = {
        TRASH_Register.NAME: TRASH_Register,
        RSVDR0.NAME: RSVDR0,
        RSVDR1.NAME: RSVDR1,
        RSVDR2.NAME: RSVDR2,
        RSVDR3.NAME: RSVDR3,
        RSVDR4.NAME: RSVDR4,
        RSVDR5.NAME: RSVDR5,
        RSVDR.NAME: RSVDR,
        WAKEUP_TIME_REGISTER.NAME: WAKEUP_TIME_REGISTER,
        FREQUENCY_REGISTER.NAME: FREQUENCY_REGISTER,
        NUM_BOARDS_REGISTER.NAME: NUM_BOARDS_REGISTER,
        NUM_BYTES_REGISTER.NAME: NUM_BYTES_REGISTER,
        DELAY_TIME_REGISTER.NAME: DELAY_TIME_REGISTER,
        GPIO_PIN_REGISTER.NAME: GPIO_PIN_REGISTER,
        GPIO_VAL_REGISTER.NAME: GPIO_VAL_REGISTER,
        TIMER_VAL_REGISTER.NAME: TIMER_VAL_REGISTER,
        TIMER_ID_REGISTER.NAME: TIMER_ID_REGISTER,
        LOOP_NUM_REGISTER.NAME: LOOP_NUM_REGISTER,
        LOOP_INDEX_REGISTER.NAME: LOOP_INDEX_REGISTER
    }
    BITFIELDS = {
        Bit0.NAME: Bit0,
        Bit1.NAME: Bit1,
        RSVD0.NAME: RSVD0,
        RSVD1.NAME: RSVD1,
        TRASH.NAME: TRASH,
        RSVD_BYTE0.NAME: RSVD_BYTE0,
        RSVD_BYTE1.NAME: RSVD_BYTE1,
        RSVD_BYTE2.NAME: RSVD_BYTE2,
        RSVD_BYTE3.NAME: RSVD_BYTE3,
        RSVD_BYTE4.NAME: RSVD_BYTE4,
        RSVD_BYTE5.NAME: RSVD_BYTE5,
        WAKEUP_TIME.NAME: WAKEUP_TIME,
        FREQUENCY.NAME: FREQUENCY,
        NUM_BOARDS.NAME: NUM_BOARDS,
        NUM_BYTES.NAME: NUM_BYTES,
        DELAY_TIME.NAME: DELAY_TIME,
        GPIO_PIN.NAME: GPIO_PIN,
        GPIO_VAL.NAME: GPIO_VAL,
        TIMER_VAL.NAME: TIMER_VAL,
        TIMER_ID.NAME: TIMER_ID,
        LOOP_NUM.NAME: LOOP_NUM,
        LOOP_INDEX.NAME: LOOP_INDEX,
        JUMP_INCREMENT.NAME: JUMP_INCREMENT,
        EVAL_INDEX.NAME: EVAL_INDEX
    }
    COMMANDS = {
        MATH_EVAL.NAME: MATH_EVAL,
        SPIWakeup.NAME: SPIWakeup,
        SPISetFrequencyKHz.NAME: SPISetFrequencyKHz,
        SPIClockOut.NAME: SPIClockOut,
        DELAY_MS.NAME: DELAY_MS,
        DELAY_US.NAME: DELAY_US,
        GPIO_WRITE.NAME: GPIO_WRITE,
        GPIO_READ.NAME: GPIO_READ,
        SPIWriteGeneric.NAME: SPIWriteGeneric,
        SPIReadGeneric.NAME: SPIReadGeneric,
        I2CReadGeneric.NAME: I2CReadGeneric,
        I2CWriteGeneric.NAME: I2CWriteGeneric,
        I2CSetFrequencyKHz.NAME: I2CSetFrequencyKHz,
        START_TIMER.NAME: START_TIMER,
        STOP_TIMER.NAME: STOP_TIMER,
        REPEAT.NAME: REPEAT,
        LOOP_CMD.NAME: LOOP_CMD,
        BRANCH_CMD.NAME: BRANCH_CMD
    }
    LIMITS = {}
    GUI_CFG = []
    GUI_METRICS = []
    GUI_LOOP_CMD_LIST = []