# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from abc import ABC, abstractmethod

class Connection(ABC):
    """
    This is the base class for a connection in PyBMS. It defines some standard values and also some re-accuring modules.
    It is derived as a sub-class of ABC to prevent loading the Connection class directly.
    :class: Base class of connection
    """
    _instance = None
    def __init__(self):
        self.ERRORS = {
            40: 'COMMAND NOT FORMATTED CORRECTLY',
            41: 'NOT_ENOUGH_INPUT_BUFFER_SPACE_ERROR',
            42: 'COMMAND_INPUT_BUFFER_FULL',
            43: 'MALLOC_FAILURE',
            44: 'INVALID_COMMAND_TYPE_ERROR',
            45: 'UNKNOWN_CMD_ERROR',
            46: 'RAM_ACCESS_ERROR'
        }
        self.COMMAND_TYPES = {
            'math_eval': 0,
            'write': 0x01,
            'write_open': 0x13,
            'read': 0x02,
            'poll': 0x03,
            'delay_us': 0x04,
            'delay_ms': 0x05,
            'gpio_write': 0x06,
            'gpio_read': 0x07,
            'spi_wakeup': 0x08,
            'loop': 0x09,
            'repeat': 0x0A,
            'timer_start': 0x0B,
            'timer_stop': 0x0C,
            'spi_clock_out': 0x0D,
            'spi_set_frequency_khz': 0x0E,
            'i2c_write': 0x0F,
            'i2c_read': 0x10,
            'write_i2c_dut': 0x0F,
            'read_i2c_dut': 0x10,
            'spi_write': 0x01,
            'spi_read': 0x02,
            'i2c_set_frequency_khz': 0x11,
            'spi_set_mode': 0x12,
            'spi_slave_poll': 21,
            'spi_slave_read': 22,
            'spi_slave_write': 23,
            'uart_write': 24,
            'uart_read': 25,
            'uart_wakeup': 26,
            'pwm_start': 27,
            'pwm_stop': 28,
            'branch': 30
        }

    def __new__(cls, *args, **kwargs):
        """
        Singleton, Prevents opening of two Interfaces
        :module: Singleton of Connection Class

        :return: One instance of the Connection Class
        """
        # Singleton class
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def prepare_add_command_to_buffer(self,command):
        """
        This module translates the SPI command bytes to bytes for the SDP-K1 or the virtual interface
        :module: prepare_add_command_to_buffer translates for example `[3 96 244 108]` to `[0, 12, 0, 1, 0, 4, 0, 0, 0, 0, 3, 96, 244, 108]`

        :param command: The list with the command `[3 96 244 108]`
        :type command: required, list
        :return output: The list with bytes for SDK-K1 or Virtual Interface
        :return type: list for SDP-K1
        """
        if command.TYPE == 'math_eval':
            return []
        try:
            spi_bus = command.spi_bus
            spi_cs = command.spi_cs
        except:
            spi_bus = 0
            spi_cs = 0
        tx_len = int(command.tx_length / 8)
        rx_len = int(command.rx_length / 8)
        command_length = 8 + tx_len
        command_list = [command_length >> 8, command_length & 0xFF, 0, self.COMMAND_TYPES[command.TYPE],
                        tx_len >> 8, tx_len & 0xFF, rx_len >> 8,
                        rx_len & 0xFF, spi_bus, spi_cs]
        command_list += command.bytes[:tx_len]
        return command_list

    def prepare_replace_command_in_buffer(self, command, index):
        """
        This module replaces the SPI commands in the buffer for the SDP-K1
        :module: prepare_replace_command_in_buffer translates for example `[3 96 244 108]` to `[0, 12, 0, 1, 0, 4, 0, 0, 0, 0, 3, 96, 244, 108]`

        :param command:
        :type command: required, list
        :param index: place where you want to replace commands
        :type index: required, int
        :return output: The list with bytes for SDK-K1 or Virtual Interface
        :return type: list for SDP-K1
        """

        try:
            spi_bus = command.spi_bus
            spi_cs = command.spi_cs
        except:
            spi_bus = 0
            spi_cs = 0
        tx_len = int(command.tx_length / 8)
        rx_len = int(command.rx_length / 8)
        command_length = 10 + tx_len
        command_list = [command_length >> 8, command_length & 0xFF, 6, index >> 8, index & 0xFF,
                        self.COMMAND_TYPES[command.TYPE],
                        tx_len >> 8, tx_len & 0xFF, rx_len >> 8,
                        rx_len & 0xFF, spi_bus, spi_cs]
        command_list += command.bytes[:tx_len]
        return command_list

    @abstractmethod
    def add_command_to_buffer(self):
        """
        Force the child class to have add_command_to_buffer method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def replace_command_in_buffer(self):
        """
        Force the child class to have replace_command_to_buffer method
        :module: Replace command to buffer
        """
        pass

    @abstractmethod
    def raw_commands(self, timeout=5):
        """
        Force the child class to have raw_commands method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def run_commands_in_buffer(self, timeout=10):
        """
        Force the child class to have run_commands_in_buffer method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def clear_commands_in_buffer(self, timeout=10):
        """
        Force the child class to have clear_commands_in_buffer method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def get_commands(self, timeout=5):
        """
        Force the child class to have get_commands method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def get_firmware_version(self, timeout=5):
        """
        Force the child class to have get_commands method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def close(self):
        """
        Force the child class to have close method
        :module: Add command to buffer
        """
        pass

    @abstractmethod
    def open(self):
        """
        Force the child class to have open method
        :module: Add command to buffer
        """
        pass