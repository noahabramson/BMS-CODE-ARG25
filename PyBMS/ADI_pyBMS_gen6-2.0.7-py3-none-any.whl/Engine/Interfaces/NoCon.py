# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
from Engine.Interfaces.Connection import Connection
class NoCon(Connection):
    def __init__(self, response_string=None, debug_mode=True):
        super().__init__()
        self.response_string = response_string
        self.debug = debug_mode

    def read(self, terminator=None, include_termination=False, timeout=1):
        if self.debug:
            return self.response_string
        else:
            raise NotImplementedError("NoCon cannont proccess read commands")

    def write(self, data, add_return=True):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot process write commands")

    def open_port(self):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot open a port")

    def close_port(self):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot close a port")

    def close(self):
        self.close_port()

    def open(self):
        self.open_port()

    def add_command_to_buffer(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot add command to buffer")

    def clear_commands_in_buffer(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot clear_commands_in_buffer")

    def get_commands(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("get_commands")

    def get_firmware_version(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot get_firmware_version")

    def raw_commands(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot raw_commands")

    def replace_command_in_buffer(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot replace_command_in_buffer")

    def run_commands_in_buffer(self, command):
        if self.debug:
            return
        else:
            raise NotImplementedError("NoCon cannot run_commands_in_buffer")

