# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import serial
from multiprocessing import Queue, Process
import time
import logging


class SCon:
    """
    Class that provides a serial connection to a device

    :param port: device port name string
    :param baudrate: device operational baudrate
    :param console_logger: optional logger for all serial transactions
    :param log_folder: optional folder to save log file under
    :param logger: optional top level logging, config must be taken care of by higher level module
    :param stdout: optional flag to prent all data to console
    :param make_killable: optional flag to sacrifice performance to make reader thread killable
    """

    def __init__(self, port, baudrate, log_folder=None, logger=None, console_logger=None, stdout=False,
                 make_killable=False, log_writes=True, limit_usb_polling=False):
        self.baudrate = baudrate
        self.port = port
        self.input = Queue()
        self.output = Queue()
        self.control = Queue()
        self.control_response = Queue()
        self.proc = Process(target=self.worker, args=(port, baudrate, self.input, self.output, self.control, self.control_response), kwargs={"log_folder": log_folder, "logger": logger, "stdout": stdout, "console_logger": console_logger, "log_writes": log_writes, "limit_usb_polling": limit_usb_polling})
        self.proc.start()
        # Get confirmation port was captured
        active = self.control_response.get(block=True, timeout=5)
        if active != 'OK':
            raise IOError("Could not open port %s" % active)

    @staticmethod
    def worker(port, baudrate,  input_queue, output, control, control_response, log_folder=None, logger=None, console_logger=None, stdout=False, log_writes=True, limit_usb_polling=False):
        kill = False
        try:
            ser = serial.Serial(port, baudrate)
            ser.flushInput()
            ser.flushOutput()
            control_response.put('OK')
        except Exception as e:
            control_response.put(e)
            # End process
            return
        read_data = []
        packet = []
        packet_data = []
        while not kill:
            while not control.empty():
                inst = control.get()
                if inst['cmd'] == 'close':
                    kill = True
                    control_response.put('OK')
                    # try:
                    #     ser.flushInput()
                    #     ser.flushOutput()
                    #     read_data = []
                    #     packet = []
                    #     packet_data = []
                    #     while not output.empty():
                    #         output.get()
                    #     while not input_queue.empty():
                    #         input_queue.get()
                    #     control_response.put('OK')
                    # except Exception as e:
                    #     control_response.put(e)
                    break
                elif inst['cmd'] == 'clear':
                    try:
                        while not input_queue.empty():
                            input_queue.get()
                        while not output.empty:
                            output.get()
                        ser.flushInput()
                        ser.flushOutput()
                        read_data = []
                        packet = []
                        packet_data = []
                        control_response.put('OK')
                    except Exception as e:
                        control_response.put(e)
            if kill:
                break
            try:
                while not input_queue.empty():
                    write_data = input_queue.get()
                    ser.write(bytearray(write_data))
                if ser.in_waiting:
                    read_data = ser.read(ser.in_waiting)
                    packet += read_data
                elif limit_usb_polling:
                    time.sleep(0.01)  # Don't burn cpu cycles
                if len(packet) >= 5:
                    if packet[:4] == [0, 0, 0, 0]:  # No data to return, just command status
                        data_length = 5
                        packet_data = packet[:data_length]
                        packet = packet[data_length:]
                    elif len(packet) >= (packet[0] << 24) | (packet[1] << 16) | (packet[2] << 8) | (packet[3] & 0xFF):
                        data_length = (packet[0] << 24) | (packet[1] << 16) | (packet[2] << 8) | (packet[3] & 0xFF)
                        packet_data = packet[:data_length]
                        packet = packet[data_length:]
                if packet_data:
                    output.put({'timestamp': time.time(), 'data': packet_data})
                    packet_data = []
            except Exception as e:
                try:
                    ser.close()
                    time.sleep(1)
                    ser.open()
                except:
                    pass
        ser.close()
        control_response.put('OK')

    def open(self):
        """
        Attempts to open a serial connection to the device

        :return: True if the connection is open, False if the connection could not be opened
        """
        return True

    def close(self):
        """Stops all threads and closes serial port"""
        self.control.put({'cmd': 'close'})
        active = self.control_response.get(block=True, timeout=5)
        if active != 'OK':
            self.proc.terminate()
            raise IOError("Could not close port %s" % active)
        # flush queues
        while not self.output.empty():
            self.output.get()
        while not self.input.empty():
            self.input.get()
        while not self.control.empty():
            self.control.get()
        while not self.control_response.empty():
            self.control_response.get()
        self.proc.join()


    def clear(self):
        """Flush queue and any data"""
        self.control.put({'cmd': 'clear'})
        active = self.control_response.get(block=True, timeout=5)
        if active != 'OK':
            self.proc.terminate()
            raise IOError("Could not clear port %s" % active)

    def read(self, terminator=True, include_termination=False, timeout=5, suppress_timeout=False, timestamp=False):
        start_time = time.time()
        while True:
            if not self.output.empty():
                if timestamp:
                    return self.output.get()
                else:
                    return self.output.get()['data']
            if time.time() > start_time + timeout:
                raise IOError('Communication Timeout')

    def write(self, data, add_return=True):
        """
        Writes a given string to the serial port.

        :param data: string to be written to the serial port
        :param add_return: adds a newline/carriage return to the string
        """
        self.input.put(data)