# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import serial
from Engine.Interfaces.SCon import SCon
import time


class SCon_ASCII(SCon):
    """
    Class that provides a serial connection to a device

    :param port: device port name string
    :param baudrate: device operational baudrate
    :param console_logger: optional logger for all serial transactions
    :param log_folder: optional folder to save log file under
    :param logger: optional top level logging, config must be taken care of by higher level module
    """

    def __init__(self, port, baudrate, log_folder=None, logger=None, console_logger=None, stdout=False,
                 make_killable=False, log_writes=True, limit_usb_polling=False):
        SCon.__init__(self, port, baudrate, log_folder=log_folder, logger=logger, console_logger=console_logger,
                      stdout=stdout, make_killable=make_killable, log_writes=log_writes, limit_usb_polling=limit_usb_polling)
        self.received_data = ''
        self.received_data_bytes = []

    @staticmethod
    def worker(port, baudrate, input, output, control, control_response, terminator='>>', include_termination=False, log_folder=None, logger=None,
               console_logger=None, stdout=False, log_writes=True, add_return=True, limit_usb_polling=False):
        kill = False
        try:
            ser = serial.Serial(port, baudrate)
            ser.flushInput()
            ser.flushOutput()
            control_response.put('OK')
        except Exception as e:
            control_response.put(e)
            # End process
            return
        read_data = ''
        packet = ''
        packet_data = ''
        while not kill:
            while not control.empty():
                inst = control.get()
                if inst['cmd'] == 'close':
                    kill = True
                    break
            try:
                while not input.empty():
                    write_data = input.get()
                    if add_return:
                        write_data += '\r\n'
                    ser.write(write_data.encode("UTF-8"))
                if ser.in_waiting:
                    read_data = ser.read(ser.in_waiting)
                    try:
                        read_data = read_data.decode('UTF-8')
                    except:
                        temp_data = ''
                        for item in read_data:
                            try:
                                temp_data += item.decode('UTF-8')
                            except:
                                temp_data += str(ord(item))
                        read_data = temp_data
                    packet += read_data
                elif limit_usb_polling:
                    time.sleep(0.01)  # Don't burn cpu cycles
                if terminator in packet:
                    if include_termination:
                        packet_data = packet[:packet.find(terminator)+len(terminator)]
                    else:
                        packet_data = packet[:packet.find(terminator)]
                    packet = packet[packet.find(terminator) + len(terminator):]
                if packet_data:
                    output.put({'timestamp': time.perf_counter(), 'data': packet_data})
                    packet_data = []
            except Exception as e:
                print(e)
                try:
                    ser.close()
                    time.sleep(1)
                    ser.open()
                except:
                    pass
        ser.close()
        control_response.put('OK')
