# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import serial
from Engine.Interfaces.SCon import SCon


class SCon_Bytes(SCon):
    """
    Class that provides a serial connection to a device

    :param port: device port name string
    :param baudrate: device operational baudrate
    :param console_logger: optional logger for all serial transactions
    :param log_folder: optional folder to save log file under
    :param logger: optional top level logging, config must be taken care of by higher level module
    """

    def __init__(self, port, baudrate, log_folder=None, logger=None, console_logger=None, stdout=False,
                 make_killable=False, log_writes=True, limit_usb_polling=False):
        SCon.__init__(self, port, baudrate, log_folder=log_folder, logger=logger, console_logger=console_logger,
                      stdout=stdout, make_killable=make_killable, log_writes=log_writes, limit_usb_polling=limit_usb_polling)
        self.received_data = []


