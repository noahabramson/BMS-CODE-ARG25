# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Interfaces.SCon_ASCII import SCon_ASCII
import re
import time


class USB_TO_SPI_ASCII:

    def __init__(self, port, baudrate, log_folder=None, logger=None, console_logger=None, stdout=False):
        """
        Interface used to communicate with an ASCII based USB to SPI converter

        :param port: Serial comport name
        :param baudrate: Serial comport datarate
        :param log_folder: Optional log folder to place all communication logs
        :param logger: Optional logger to record any errors
        :param console_logger: Optional logger to record all traffic from the device
        :param stdout: Optional flag to print traffic directly to console
        """
        self.con = SCon_ASCII(port, baudrate, log_folder=log_folder, logger=logger, console_logger=console_logger,
                              stdout=stdout)
        time.sleep(5)  # Give time for Linduino to boot
        self.ERRORS = {
            '40': 'NO_CMD_LENGTH_ERROR',
            '41': 'NOT_ENOUGH_INPUT_BUFFER_SPACE_ERROR',
            '42': 'COMMAND_INPUT_BUFFER_FULL',
            '43': 'MALLOC_FAILURE',
            '44': 'INVALID_COMMAND_TYPE_ERROR',
            '45': 'UNKNOWN_CMD_ERROR',
            '46': 'NO_DATA_LENGTH_ERROR',
            '47': 'NO_SPI_BUS_SPECIFIED_ERROR',
            '48': 'NO_SPI_CS_SPECIFIED_ERROR',
        }
        # Clear buffer in case commands were already present, catch any errors from pre buffered commands
        try:
            self.get_commands()
        except:
            pass

    def add_command_to_buffer(self, command):
        if 'spi' not in command:
            command['spi'] = 0
        if 'spi_cs' not in command:
            command['spi_cs'] = 0
        command_string = 'add %s %s %s %s %s %s' % (
        command['type'], str(command['tx_length']), str(command['rx_length']), str(command['spi']),
        str(command['spi_cs']), ' '.join(list(str(e) for e in command['bytes'][:command['tx_length']])))
        self.con.write(command_string)
        output = self.con.read(terminator='>>')
        match = re.search('ERROR:\s+(\d+)', output)
        if match:
            raise IOError("Error adding command: %s" % self.ERRORS[match.group(1)])
        return output

    def run_commands_in_buffer(self, timeout=10):
        self.con.write('run')
        output = self.con.read(terminator='>>', timeout=timeout)
        match = re.search('ERROR:\s+(\d+)', output)
        if match:
            raise IOError("Error running command: %s" % self.ERRORS[match.group(1)])
        return output

    def clear_commands_in_buffer(self, timeout=10):
        self.con.write('clear')
        output = self.con.read(terminator='>>', timeout=timeout)
        match = re.search('ERROR:\s+(\d+)', output)
        if match:
            raise IOError("Error clearing command: %s" % self.ERRORS[match.group(1)])
        return output

    def print_commands_in_buffer(self):
        self.con.write('print')
        output = self.con.read(terminator='>>')
        match = re.search('ERROR:\s+(\d+)', output)
        if match:
            raise IOError("Error printing commands: %s" % self.ERRORS[match.group(1)])
        return output

    def loop_commands_in_buffer(self, loops, timeout=10):
        self.con.write('loop %s %s' % (loops >> 8, loops & 0xFF))
        raw_output = self.con.read(terminator='>>', timeout=timeout).strip()
        data = []
        # loop through data
        match = re.search('ERROR:\s+(\d+)', raw_output)
        if match:
            raise IOError("Error looping commands: %s" % self.ERRORS[match.group(1)])
        output = raw_output.splitlines()
        output = output[1:-1]
        loop_size = len(output)/loops
        j = 0
        while j < len(output):
            loop_data = output[j:j+loop_size]
            temp_data = []
            for i in range(len(loop_data)):
                temp_data.append([])
                ints = loop_data[i].split(' ')
                for value in ints:
                    try:
                        temp_data[i].append(int(value))
                    except:
                        pass
            data.append(temp_data)
            j += loop_size
        return data

    def get_commands(self, timeout=5):
        self.con.write('get')
        commands = self.con.read(terminator='>>', timeout=timeout)
        match = re.search('ERROR:\s+(\d+)', commands)
        if match:
            raise IOError("Error getting command: %s" % self.ERRORS[match.group(1)])
        values = []
        for value in commands.splitlines():
            if 'get' in value or 'PASS' in value or 'ERROR' in value:
                continue
            values.append(value)
        data = []
        for i in range(len(values)):
            data.append([])
            ints = values[i].split(' ')
            for value in ints:
                try:
                    data[i].append(int(value))
                except:
                    pass
        return data

    def raw_commands(self, timeout=5):
        self.con.write('raw')
        commands = self.con.read(terminator='>>', timeout=timeout)
        match = re.search('ERROR:\s+(\d+)', commands)
        if match:
            raise IOError("Error printing raw command: %s" % self.ERRORS[match.group(1)])
        values = []
        for value in commands.splitlines():
            if 'raw' in value or 'PASS' in value or 'ERROR' in value:
                continue
            values.append(value)
        data = []
        for i in range(len(values)):
            data.append([])
            ints = values[i].split(' ')
            for value in ints:
                try:
                    data[i].append(int(value))
                except:
                    pass
        return data

    def close(self):
        self.con.close()

    def open(self):
        self.con.open()
