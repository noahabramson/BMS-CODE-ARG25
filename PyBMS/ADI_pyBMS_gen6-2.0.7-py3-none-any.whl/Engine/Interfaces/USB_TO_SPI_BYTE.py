# Copyright (c) 2021 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Interfaces.Connection import Connection
from Engine.Interfaces.SCon_Bytes import SCon_Bytes
import time


class USB_TO_SPI_BYTE(Connection):
    """
    This is the class that connects PyBMS with the SDP-K1. It prepares the data and also sends it to the SDP-K1
    :class: Base class of connection

    :param port: The comport for the SDP-K1
    :type port: required, string
    :param baudrate: baudrate for SDP-K1
    :type baudrate: required, int
    :param log_folder: Log folder for data
    :type log_folder: optional, string path
    :param console_logger: Logger
    :type console_logger: Optional
    :param stdout: Printing all the data that is send to the SDP_K1
    :type stdout: Optional, bool
    """
    def __init__(self, port, baudrate, log_folder=None, logger=None, console_logger=None, stdout=False, limit_usb_polling=False):
        super().__init__()
        self.con = SCon_Bytes(port, baudrate, log_folder=log_folder, logger=logger, console_logger=console_logger,
                              stdout=stdout)

    def add_command_to_buffer(self, command):
        command_list = self.prepare_add_command_to_buffer(command)
        if command_list:
            self.con.write(command_list)
            output = self.con.read(terminator=True)
            if output != [0, 0, 0, 0, 0]:
                try:
                    error = self.ERRORS[output[4]]
                except:
                    error = 'Unknown'
                raise IOError("Add command failed: [%s]" % error)
            return output

    def replace_command_in_buffer(self, command, index):
        command_list = self.prepare_replace_command_in_buffer(command, index)
        if command_list:
            self.con.write(command_list)
            output = self.con.read(terminator=True)
            if output != [0, 0, 0, 0, 0]:
                try:
                    error = self.ERRORS[output[4]]
                except:
                    error = 'Unknown'
                raise IOError("Replace command failed: [%s]" % error)
            return output

    def run_commands_in_buffer(self, timeout=10):
        self.con.write([0, 1, 1])  # Length of packet, RUN_CMD (0x01)
        output = self.con.read(terminator=True, timeout=timeout)
        if output != [0, 0, 0, 0, 0]:
            try:
                error = self.ERRORS[output[4]]
            except:
                error = 'Unknown'
            raise IOError("Run command failed: [%s]" % error)
        return output

    def start_freerun_mode(self):
        self.con.write([0, 1, 8])  # Length of packet, FREE_RUN_CMD (0x08)

    def stop_freerun_mode(self, clear_buffer=True):
        self.con.write([0])  # Send terminating character
        time.sleep(0.02)
        if clear_buffer:
            # self.con.clear()
            try:
                # Clear out buffer
                output = self.con.read(timeout=0.1)
                while output != [0, 0, 0, 0, 0] and output != []:
                    output = self.con.read(timeout=0.1)
            except:
                return

    def clear_commands_in_buffer(self, timeout=10):
        self.con.write([0, 1, 5])
        output = self.con.read(terminator=True, timeout=timeout)
        if output != [0, 0, 0, 0, 0]:
            try:
                error = self.ERRORS[output[4]]
            except:
                error = 'Unknown'
            raise IOError("Clear command failed: [%s]" % error)
        return output

    def loop_commands_in_buffer(self, loops, timeout=10):
        self.con.write([0, 3, 4, loops >> 8, loops & 0xFF])
        output = self.con.read(terminator=True, timeout=timeout)
        data = []
        # loop through data
        loop_size = int((len(output) - 4)/loops)
        j = 4
        while j < len(output):
            loop_data = output[j:j+loop_size]
            try:
                command_num = (loop_data[4] << 8) | loop_data[5]
                temp_data = []
                for i in range(command_num):
                    temp_data.append([])
                i = 6
                command_index = 0
                while i < len(loop_data):
                    start = i
                    cmd_length = (loop_data[start] << 8) | (loop_data[start + 1] & 0xFF)
                    end = start + cmd_length
                    temp_data[command_index] = loop_data[start + 2:end + 2]
                    i = end + 2
                    command_index += 1
            except Exception as e:
                raise IOError('Loop command failed: [%s]' % e)
            data.append(temp_data)
            j += loop_size
        return data

    def print_commands_in_buffer(self):
        pass

    def get_commands(self, timeout=5):
        self.con.write([0, 1, 2])  # Length of packet, GET_CMD (0x02)
        output = self.con.read(terminator=True, timeout=timeout)
        # Step through data and split up into different commands
        data = []
        if output == [0, 0, 0, 0, 0]:
            return data
        try:
            command_num = (output[4] << 8) | output[5]
            for i in range(command_num):
                data.append([])
            i = 6
            command_index = 0
            while i < len(output):
                start = i
                cmd_length = (output[start] << 8) | (output[start + 1] & 0xFF)
                end = start + cmd_length
                data[command_index] = output[start + 2:end + 2]
                i = end + 2
                command_index += 1
        except Exception as e:
            raise IOError('Get command failed: [%s]' % e)
        return data

    def get_firmware_version(self, timeout=5):
        self.con.write([0, 1, 7])  # Length of packet, GET_FW_VER_CMD (0x07)
        output = self.con.read(terminator=True, timeout=timeout)
        return "%s" % (output[4]/10)

    def raw_commands(self, timeout=5):
        self.con.write([0, 1, 3])  # Length of packet, RAW_CMD (0x03)
        output = self.con.read(terminator=True, timeout=timeout)
        # Step through data and split up into different commands
        data = []
        if output == [0, 0, 0, 0, 0]:
            return data
        try:
            command_num = (output[4] << 8) | output[5]
            for i in range(command_num):
                data.append([])
            i = 6
            command_index = 0
            while i < len(output):
                start = i
                cmd_length = (output[start] << 8) | (output[start + 1] & 0xFF)
                end = start + cmd_length
                data[command_index] = output[start + 2:end + 2]
                i = end + 2
                command_index += 1
        except Exception as e:
            raise IOError('Raw command failed: [%s]' % e)
        return data

    def free_run_raw_commands(self, timeout=5, return_timestamp=False):
        out = self.con.read(terminator=True, timeout=timeout, timestamp=True)
        output = out['data']
        # Step through data and split up into different commands
        data = []
        if output == [0, 0, 0, 0, 0]:
            if return_timestamp:
                return data, out['timestamp']
            else:
                return data
        try:
            command_num = (output[4] << 8) | output[5]
            for i in range(command_num):
                data.append([])
            i = 6
            command_index = 0
            while i < len(output):
                start = i
                cmd_length = (output[start] << 8) | (output[start + 1] & 0xFF)
                end = start + cmd_length
                data[command_index] = output[start + 2:end + 2]
                i = end + 2
                command_index += 1
        except Exception as e:
            raise IOError('Raw command failed: [%s]' % e)
        if return_timestamp:
            return data, out['timestamp']
        else:
            return data

    def close(self):
        self.con.close()

    def open(self):
        self.con.open()

    def force_open(self, val=2):
        try:
            self.con.open()
        except:
            print("Wait for starting IO")
            time.sleep(2)
            self.con.open()



