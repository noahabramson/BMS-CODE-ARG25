# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Interfaces.Connection import Connection

class Virtual_SPI(Connection):
    """
    This is a virtual SPI interface. It will transfer data that would normally be send to the SDP-K1 to a txt file.
    This class is compatible with USB_TO_SPI_BYTE. So it only requires to change
    `interface = USB_TO_SPI_BYTE('COM28', 115200` to `interface = Virtual_SPI("tiger_log.txt")`
    :class: Virtual_SPI is the virtual version of USB_TO_SPI_BYTE

    :param path: The path for the txt file output
    :type path: required, string
    :param kwargs: All parameters for USB_TO_SPI_BYTE can be parsed to this class, however they won't be used
    :type kwargs: optional
    """

    def __init__(self, path=None, **kwargs):
        super().__init__()
        # Path for virtual interface
        self.path = path
        self.virtual_ccnt = 0
        self.virtual_buffer = []
        # Clear commands that could be in the buffer
        try:
            self.clear_commands_in_buffer()
        except:
            pass

    def add_command_to_buffer(self, command):
        command_list = self.prepare_add_command_to_buffer(command)
        self.virtual_buffer.append(command_list)
        self.virtual_ccnt += 1
        # Return something to not break the rest
        return [0, 0, 0, 0, 0]

    def replace_command_in_buffer(self, command, index):
        command_list = self.prepare_replace_command_to_buffer(command, index)
        self.virtual_buffer.append(command_list)
        return [0, 0, 0, 0, 0]

    def run_commands_in_buffer(self, timeout=10):
        self.virtual_buffer.append([0, 1, 1])
        # Write virtual buffer to file
        if self.path:
            f = open(self.path, "w")
            for command in self.virtual_buffer:
                f.write(str(command))
                f.write("\n")
            f.close()
        else:
            print("Warning: result are not stored")
        return [0, 0, 0, 0, 0]

    def clear_commands_in_buffer(self, timeout=10):
        self.virtual_buffer.append([0, 1, 5])
        return [0, 0, 0, 0, 0]

    def loop_commands_in_buffer(self, loops, timeout=10):
        self.virtual_buffer.append([0, 3, 4, loops >> 8, loops & 0xFF])
        data = []
        for i in range(loops):
            # It's a dirty way, but in this way there are enough zeroes for sure for 13 devices and 200 commands
            cmd_data = [0] * 12 * 13
            cmds = 200
            data.append([cmd_data] * cmds)
        return data

    def print_commands_in_buffer(self):
        pass

    def get_commands(self, timeout=5):
        # self.write_to_file([0, 1, 2])  # Length of packet, GET_CMD (0x02)
        self.virtual_buffer.append([0, 1, 2])
        data = []
        # Create a list of zeros to return. Otherwise the BMS logic might crash
        # This 200 value is a very dirty fix, but at least it fixes the issue for now
        for i in range(self.virtual_ccnt):
            data.append([0]*200)

        return data

    def get_firmware_version(self, timeout=5):
        self.virtual_buffer.append([0, 1, 7])  # Length of packet, GET_FW_VER_CMD (0x07)
        return [0, 0, 0, 0]

    def raw_commands(self, timeout=5):
        # self.write_to_file([0, 1, 3])  # Length of packet, GET_CMD (0x02)
        self.virtual_buffer.append([0, 1, 2])
        print("Raw Commands not yet supported")
        return [0, 0, 0, 0, 0]

    def free_run_raw_commands(self, timeout=5):
        print("Free run raw is not yet supported")
        return [0, 0, 0, 0, 0]

    def close(self):
        print("Warning: this is a virtual interface")

    def open(self):
        print("Warning: this is a virtual interface")

