# Copyright (c) 2023 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Interfaces.NoCon import NoCon
import yaml
import csv
from Engine.BMS import BMS


class TimingCalculator:
    """
    This class calculate the spi timings like the excel sheet did in the past.
    You just give the command list, make sure the config file is correct and you'll get a csv with all the timings.
    You can also get the results as a dict in case you prefer that.

    :param config: Path the config file. Usually in the same folder as the scratchpad. This is a string. If you prefer to do it yourself, you can also send a dict with the values
    :return: a list with dicts of the values that are interesting. The time is in microseconds.
    """

    def __init__(self, config):
        # If string, interpret as a path. If not, use it as a dict with all the values
        if isinstance(config, str):
            with open(config) as file:
                config = yaml.load(file, Loader=yaml.FullLoader)

        self.t_clk = config['t_clk']
        self.t5 = config['t5']
        self.t6 = config['t6']
        self.t7 = config['t7']
        self.t_idle_between_bytes = config['t_idle_between_bytes']
        self.mcu_overhead = config['mcu_overhead']

    def calculate_timings(self, command_list, board_list, csv_file=None):
        # Create the BMS Object with NoCon
        interface = NoCon()
        bms = BMS(interface=interface)
        compiled = bms.translate_command_list_to_compiled_commands(command_list, board_list)

        # Define variables
        result_list = []
        acc_time = 0

        # Go over all commands to calculate the timing
        for index, cmd in enumerate(compiled):
            # SDP-K1 command
            if '$' == cmd.NAME[0] and '$' == cmd.NAME[-1]:
                # Extract timing data from bytes
                if cmd.NAME == '$DELAY_US$':
                    cmd_time = cmd.bytes[-1]
                    cmd_info = {
                        'cmd': f"{cmd.NAME} {cmd_time*1e6} us:",
                        'rx': 0,
                        'tx': 0,
                        'cmd_time': cmd_time,
                        'acc_time': acc_time,
                    }

                elif cmd.NAME == '$DELAY_MS$':
                # Convert ms to us and extra timing data from bytes
                    cmd_time = cmd.bytes[-1] * 1e3
                    cmd_info = {
                        'cmd': f"{cmd.NAME} {cmd_time*1e-3} ms:",
                        'rx': 0,
                        'tx': 0,
                        'cmd_time': cmd_time,
                        'acc_time': acc_time,
                    }
                # Set wake_up time in us
                elif cmd.NAME == '$SPI_WAKEUP$':
                    # Get the timing information from SPI-WAKEUP
                    cmd_time = cmd.bytes[-2]
                    cmd_info = {
                        'cmd': f"{cmd.NAME} {cmd_time} us:",
                        'rx': 0,
                        'tx': 0,
                        'cmd_time': cmd_time,
                        'acc_time': acc_time,
                    }
            else:
                # Convert bits to bytes
                rx = int(cmd.rx_length / 8)
                tx = int(cmd.tx_length / 8)
                # Calculate the total amount of bytes
                n_bytes = tx + rx
                # Give 8 clocks per byte and some overhead
                t_per_byte = 8 * self.t_clk + self.t_idle_between_bytes
                # Multiply by the amount of bytes
                t_cmd = n_bytes * t_per_byte
                # Add timings that are relevant for the timing
                cmd_time = self.t5 + self.t6 + self.t7 + self.mcu_overhead + t_cmd

                cmd_info = {
                    'cmd': cmd.NAME,
                    'rx': rx,
                    'tx': tx,
                    'cmd_time': cmd_time,
                    'acc_time': acc_time,
                }

            # Accumalated the total time
            acc_time += cmd_time
            result_list.append(cmd_info)

        # If a CSV path is mentioned, write it there. If not, do nothing.
        if csv_file:
            with open(csv_file, 'w') as f:
                w = csv.DictWriter(f, result_list[0].keys(),lineterminator='\n')
                w.writeheader()
                for row in result_list:
                    print(row)

                    w.writerow(row)

        # Return the result no matter what
        return result_list
