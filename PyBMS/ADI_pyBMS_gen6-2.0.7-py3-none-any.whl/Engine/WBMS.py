# Copyright (c) 2023 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

class WBMS:

    def __init__(self, interface):
        self.interface = interface

    def mset(self, param, value):
        self.interface.write('mset %s %s' % (param, value))
        result = self.interface.read(terminator='>')
        return result

    def mget(self, param):
        self.interface.write('mget %s' % param)
        return self.interface.read(terminator='>')

    def mseti(self, param, value):
        self.interface.write('mseti %s %s' % (param, value))
        result = self.interface.read(terminator='>')
        return result

    def mgeti(self, param):
        self.interface.write('mgeti %s' % param)
        return self.interface.read(terminator='>')

    def mxtal(self, trim=True, grade='i'):
        if not trim:
            arg = 'meas'
        else:
            arg = 'trim'
        self.interface.write('mxtal %s %s' % (arg, grade))

    def reset(self, sys='system', id=None):
        if id:
            self.interface.write('reset')
        else:
            self.interface.write('reset %s' % sys)
        return self.interface.read(terminator='>', timeout=10)
