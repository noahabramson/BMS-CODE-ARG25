# Copyright (c) 2023 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

from Engine.Devices.BMS_Config import BMS_Config, BitfieldBool, BitfieldInt, BitfieldAdc, BitfieldFloat, SPIRead, \
    SPIWrite, SPIPoll, Bit1, Bit0, RSVD0, RSVD1, BitfieldPEC, SPIWakeup, DELAY_US, DELAY_MS
from Engine.Devices.ADBMS6830 import ADBMS6830
from Engine.Devices.ADBMS6834_REVA import ADBMS6834_REVA
from Engine.Devices.ADBMS6837_REVA import ADBMS6837_REVA
from Engine.Devices.ADBMS6836 import ADBMS6836
from Engine.Devices.ADBMS6834 import ADBMS6834

num_dev = 2
define_white_space = 80
header_file = "#include <stdint.h>\n//System Defines\n#define NUM_DEV%s(%s)\n" % (
''.join([' '] * (define_white_space - 15)), num_dev)
cmc_stuct = "typedef struct CMC {\n"
defines = {}
command_codes = {}
command_parameters = {}
cmd_cls = ADBMS6834
max_payload = 0
for cmd in cmd_cls.COMMANDS:
    if cmd in BMS_Config.COMMANDS:
        continue
    if cmd_cls.COMMANDS[cmd].STATIC_LENGTH > max_payload:
        max_payload = cmd_cls.COMMANDS[cmd].STATIC_LENGTH
    if cmd_cls.COMMANDS[cmd].VARIABLE_LENGTH > max_payload:
        max_payload = cmd_cls.COMMANDS[cmd].VARIABLE_LENGTH
header_file += "#define MAX_PAYLOAD%s(%s)\n" % (''.join([' '] * (define_white_space - 19)), max_payload)
header_file += "//Utility\n#define GET_CMD_CODE(out, cmd_code)%sout[0] = cmd_code>>8; out[1] = cmd_code&0xff;\n" % (
    ''.join([' '] * (define_white_space - 35)))
# Create CMC struct
for bitfield in cmd_cls.BITFIELDS:
    isfloat = False
    if bitfield in BMS_Config.BITFIELDS:
        continue
    # Find bitfield type
    instance = cmd_cls.BITFIELDS[bitfield]()
    if isinstance(instance, BitfieldBool):
        cmc_stuct += "\tuint8_t %s;\n" % instance.__class__.__name__.lower()
    elif isinstance(instance, BitfieldInt):
        size = 8
        sizes = [8, 16, 32, 64]
        for item in sizes:
            if instance.LENGTH <= item:
                size = item
                break
        cmc_stuct += "\tuint%s_t %s;\n" % (size, instance.__class__.__name__.lower())
    elif isinstance(instance, BitfieldAdc):
        size = 8
        sizes = [8, 16, 32, 64]
        for item in sizes:
            if instance.LENGTH <= item:
                size = item
                break
        if hasattr(instance, "twos_complement"):
            if instance.twos_complement:
                cmc_stuct += "\tint%s_t %s;\n" % (size, instance.__class__.__name__.lower())
            else:
                cmc_stuct += "\tuint%s_t %s;\n" % (size, instance.__class__.__name__.lower())
        else:
            cmc_stuct += "\tuint%s_t %s;\n" % (size, instance.__class__.__name__.lower())
    elif isinstance(instance, BitfieldFloat):
        cmc_stuct += "\tfloat %s;\n" % instance.__class__.__name__.lower()
        isfloat = True
    elif isinstance(instance, BitfieldPEC):
        cmc_stuct += "\tfloat %s;\n" % instance.__class__.__name__.lower()
    else:
        print("ERROR %s Type not Found" % instance.NAME)
    mask = 2 ** instance.LENGTH - 1
    defines[instance.__class__.__name__] = {"mask": mask, "extract": {}, "insert": {}, "float": isfloat}
cmc_stuct += "\tuint8_t payload[MAX_PAYLOAD];\n\tuint8_t payload_len;\n\tuint32_t pec_error;\n\tuint8_t command_code[4];\n} CMC;"
# Step through commands, determine command type, create extract and insert defines for each bitfield
for cmd in cmd_cls.COMMANDS:
    if cmd in BMS_Config.COMMANDS:
        continue
    command = cmd_cls.COMMANDS[cmd]()
    if not command.VARIABLE_LENGTH and not isinstance(command, SPIPoll) and command.STATIC_LENGTH == 4:
        cmd_type = 'broadcast'
    elif isinstance(command, SPIWrite):
        cmd_type = 'write'
    elif isinstance(command, SPIRead):
        cmd_type = 'read'
    elif isinstance(command, SPIPoll):
        cmd_type = 'poll'
    command_codes[command.__class__.__name__] = {'code': 0, 'bitfields': {}, 'type': cmd_type, 'variable_bitfields': {}}
    # Create command code
    index = 0
    for reg in command.STATIC:
        # Step through bits, zero them out for base command code, record insert define
        temp_kwargs = {}
        if 'ADDR' in command.local_definitions:
            temp_kwargs['ADDR'] = command.local_definitions['ADDR']
        if hasattr(cmd_cls, 'ADDRESS_BOOK'):
            temp_kwargs.update({'address_book': cmd_cls.ADDRESS_BOOK})
        for bits in reg[0].bitfields(**temp_kwargs):
            if issubclass(bits[0], (Bit0, Bit1, RSVD0, RSVD1)):
                index += 1
                continue
            if bits[0].NAME not in command.local_definitions and not issubclass(bits[0], BitfieldPEC):
                if cmd_type != 'read' or index < 16:
                    command_codes[command.__class__.__name__]['bitfields'][bits[0].NAME] = 0
                else:
                    command_codes[command.__class__.__name__]['variable_bitfields'][bits[0].NAME] = 0
            # Record define
            if bits[0].NAME not in command_parameters:
                command_parameters[bits[0].NAME] = {}
            command_parameters[bits[0].NAME][command.__class__.__name__] = index
            if index < 16:
                if command.__class__.__name__ not in defines[bits[0].__name__]['insert']:
                    defines[bits[0].__name__]['insert'][command.__class__.__name__] = [None] * bits[0].LENGTH
                defines[bits[0].__name__]['insert'][command.__class__.__name__][bits[1]] = index
            if command.__class__.__name__ not in defines[bits[0].__name__]['extract']:
                defines[bits[0].__name__]['extract'][command.__class__.__name__] = [None] * bits[0].LENGTH
            defines[bits[0].__name__]['extract'][command.__class__.__name__][bits[1]] = index
            index += 1
    try:
        command.compile_command([{'Device': cmd_cls}], **command_codes[command.__class__.__name__]['bitfields'])
        command_codes[command.__class__.__name__]['code'] = command.bytes[0] << 8 | command.bytes[1] & 0xff
    except Exception as e:
        print("Could not process command %s: %s" % (command.NAME, e))
        command_codes[command.__class__.__name__]['code'] = 0x0000
    # Create write/read extractors and insertors
    if cmd_type in ['write', 'read']:
        index = 0
        temp_kwargs = {}
        if 'ADDR' in command.local_definitions:
            temp_kwargs['ADDR'] = command.local_definitions['ADDR']
        if hasattr(cmd_cls, 'ADDRESS_BOOK'):
            temp_kwargs.update({'address_book': cmd_cls.ADDRESS_BOOK})
        for reg in command.VARIABLE:
            for bits in reg[0].bitfields(**temp_kwargs):
                if issubclass(bits[0], (Bit0, Bit1, RSVD0, RSVD1)):
                    index += 1
                    continue
                if bits[0].__name__ not in defines:
                    index += 1
                    continue
                if not issubclass(bits[0], BitfieldPEC):
                    command_codes[command.__class__.__name__]['variable_bitfields'][bits[0].NAME] = 0
                # Record define
                if cmd_type == 'read':
                    if command.__class__.__name__ not in defines[bits[0].__name__]['extract']:
                        defines[bits[0].__name__]['extract'][command.__class__.__name__] = [None] * bits[0].LENGTH
                    defines[bits[0].__name__]['extract'][command.__class__.__name__][bits[1]] = index
                else:
                    if command.__class__.__name__ not in defines[bits[0].__name__]['insert']:
                        defines[bits[0].__name__]['insert'][command.__class__.__name__] = [None] * bits[0].LENGTH
                    defines[bits[0].__name__]['insert'][command.__class__.__name__][bits[1]] = index
                index += 1
header_file += "//Command Codes\n"
for code in command_codes:
    header_file += "#define %s%s(%s)\n" % (
    code.upper(), ''.join([' '] * (define_white_space - (8 + len(code)))), hex(command_codes[code]['code']))
header_file += "//Extraction and Insertion\n"
for define in defines:
    # Extractors
    for cmd in defines[define]['extract']:
        # Create masks and shifts
        masks = []
        for index, bit in enumerate(defines[define]['extract'][cmd]):
            if len(masks) == 0:
                masks.append([bit, 0x1, bit, None, index, int(bit / 8)])
                continue
            if bit != masks[-1][2] - 1 or int(bit / 8) != masks[-1][5]:
                masks.append([bit, 0x1, bit, None, index, int(bit / 8)])
                continue
            masks[-1][2] = bit
            masks[-1][1] = (masks[-1][1] << 1) | 0x01
        if masks:
            if len(masks) == 1:
                if defines[define]['float']:
                    header_file += "#define %s_%s_EXTRACT(data)%s(ieeefloat24((data[%s]>>%s)&%s))\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (23 + len(define) + len(cmd)))),
                    masks[0][5], str(((masks[0][5] + 1) * 8 - 1) - masks[0][0]), hex(masks[0][1]))
                else:
                    header_file += "#define %s_%s_EXTRACT(data)%s((data[%s]>>%s)&%s)\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (23 + len(define) + len(cmd)))),
                    masks[0][5], str(((masks[0][5] + 1) * 8 - 1) - masks[0][0]), hex(masks[0][1]))
            else:
                for mask in masks:
                    mask[3] = "(((data[%s]>>%s)&%s)<<%s)" % (
                    mask[5], str(((masks[0][5] + 1) * 8 - 1) - masks[0][0]), hex(mask[1]), mask[4])
                if defines[define]['float']:
                    header_file += "#define %s_%s_EXTRACT(data)%s(ieeefloat24(%s))\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (23 + len(define) + len(cmd)))),
                    "|".join(mask[3] for mask in masks))
                else:
                    header_file += "#define %s_%s_EXTRACT(data)%s(%s)\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (23 + len(define) + len(cmd)))),
                    "|".join(mask[3] for mask in masks))
    # Insertors
    for cmd in defines[define]['insert']:
        # Create masks and shifts
        masks = []
        for index, bit in enumerate(defines[define]['insert'][cmd]):
            if len(masks) == 0:
                masks.append([bit, 0x1, bit, None, index, int(bit / 8)])
                continue
            if bit != masks[-1][2] - 1 or int(bit / 8) != masks[-1][5]:
                masks.append([bit, 0x1, bit, None, index, int(bit / 8)])
                continue
            masks[-1][2] = bit
            masks[-1][1] = (masks[-1][1] << 1) | 0x01
        if masks:
            if len(masks) == 1:
                header_file += "#define %s_%s_INSERT(data, insert)%s(data[%s] |= (insert&%s)<<%s);\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (30 + len(define) + len(cmd)))),
                    masks[0][5], hex(masks[0][1]), str(((masks[0][5] + 1) * 8 - 1) - masks[0][0]))
            else:
                for mask in masks:
                    mask[3] = "(data[%s] |= (insert&%s)<<%s);" % (
                    mask[5], hex(mask[1]), str(((masks[0][5] + 1) * 8 - 1) - masks[0][0]))
                header_file += "#define %s_%s_INSERT(data, insert)%s%s\n" % (
                    define.upper(), cmd, ''.join([' '] * (define_white_space - (30 + len(define) + len(cmd)))),
                    " ".join(mask[3] for mask in masks))

header_file += "\n//Memory Structure\n" + cmc_stuct + "\n"
header_file += """//Function Prototypes\n
void cs_low();
void cs_high();
uint8_t spi_transaction(uint8_t data);
void wakeup_pulse(CMC cmc[]);
uint16_t pec15(uint8_t len, uint8_t *data);
uint16_t pec10(uint8_t rx_cmd, uint16_t len, uint8_t *data);
void broadcast_command(CMC cmc[]);
void poll_command(CMC cmc[]);
void write_command(CMC cmc[], uint8_t len);
void read_command(CMC cmc[], uint8_t len);
void mcu_delay_us(uint16_t delay_time);
void mcu_delay_ms(uint16_t delay_time);
void mcu_print(char* data);
float ieeefloat24(uint32_t raw);\n"""
# Create Functions
func_string = '#include "%s.h"\n#include <stdio.h>\n#include <math.h>\n\n' % (cmd_cls.__name__)
func_string += """const uint16_t Crc15Table[256] = 
{ 
  0x0000,0xc599, 0xceab, 0xb32, 0xd8cf, 0x1d56, 0x1664, 0xd3fd, 0xf407, 0x319e, 0x3aac,  
  0xff35, 0x2cc8, 0xe951, 0xe263, 0x27fa, 0xad97, 0x680e, 0x633c, 0xa6a5, 0x7558, 0xb0c1,
  0xbbf3, 0x7e6a, 0x5990, 0x9c09, 0x973b, 0x52a2, 0x815f, 0x44c6, 0x4ff4, 0x8a6d, 0x5b2e,
  0x9eb7, 0x9585, 0x501c, 0x83e1, 0x4678, 0x4d4a, 0x88d3, 0xaf29, 0x6ab0, 0x6182, 0xa41b,
  0x77e6, 0xb27f, 0xb94d, 0x7cd4, 0xf6b9, 0x3320, 0x3812, 0xfd8b, 0x2e76, 0xebef, 0xe0dd,
  0x2544, 0x2be, 0xc727, 0xcc15, 0x98c, 0xda71, 0x1fe8, 0x14da, 0xd143, 0xf3c5, 0x365c,
  0x3d6e, 0xf8f7,0x2b0a, 0xee93, 0xe5a1, 0x2038, 0x7c2, 0xc25b, 0xc969, 0xcf0, 0xdf0d,
  0x1a94, 0x11a6, 0xd43f, 0x5e52, 0x9bcb, 0x90f9, 0x5560, 0x869d, 0x4304, 0x4836, 0x8daf,
  0xaa55, 0x6fcc, 0x64fe, 0xa167, 0x729a, 0xb703, 0xbc31, 0x79a8, 0xa8eb, 0x6d72, 0x6640,
  0xa3d9, 0x7024, 0xb5bd, 0xbe8f, 0x7b16, 0x5cec, 0x9975, 0x9247, 0x57de, 0x8423, 0x41ba,
  0x4a88, 0x8f11, 0x57c, 0xc0e5, 0xcbd7, 0xe4e, 0xddb3, 0x182a, 0x1318, 0xd681, 0xf17b,
  0x34e2, 0x3fd0, 0xfa49, 0x29b4, 0xec2d, 0xe71f, 0x2286, 0xa213, 0x678a, 0x6cb8, 0xa921,
  0x7adc, 0xbf45, 0xb477, 0x71ee, 0x5614, 0x938d, 0x98bf, 0x5d26, 0x8edb, 0x4b42, 0x4070,
  0x85e9, 0xf84, 0xca1d, 0xc12f, 0x4b6, 0xd74b, 0x12d2, 0x19e0, 0xdc79, 0xfb83, 0x3e1a, 0x3528,
  0xf0b1, 0x234c, 0xe6d5, 0xede7, 0x287e, 0xf93d, 0x3ca4, 0x3796, 0xf20f, 0x21f2, 0xe46b, 0xef59,
  0x2ac0, 0xd3a, 0xc8a3, 0xc391, 0x608, 0xd5f5, 0x106c, 0x1b5e, 0xdec7, 0x54aa, 0x9133, 0x9a01,
  0x5f98, 0x8c65, 0x49fc, 0x42ce, 0x8757, 0xa0ad, 0x6534, 0x6e06, 0xab9f, 0x7862, 0xbdfb, 0xb6c9,
  0x7350, 0x51d6, 0x944f, 0x9f7d, 0x5ae4, 0x8919, 0x4c80, 0x47b2, 0x822b, 0xa5d1, 0x6048, 0x6b7a,
  0xaee3, 0x7d1e, 0xb887, 0xb3b5, 0x762c, 0xfc41, 0x39d8, 0x32ea, 0xf773, 0x248e, 0xe117, 0xea25,
  0x2fbc, 0x846, 0xcddf, 0xc6ed, 0x374, 0xd089, 0x1510, 0x1e22, 0xdbbb, 0xaf8, 0xcf61, 0xc453,
  0x1ca, 0xd237, 0x17ae, 0x1c9c, 0xd905, 0xfeff, 0x3b66, 0x3054, 0xf5cd, 0x2630, 0xe3a9, 0xe89b,
  0x2d02, 0xa76f, 0x62f6, 0x69c4, 0xac5d, 0x7fa0, 0xba39, 0xb10b, 0x7492, 0x5368, 0x96f1, 0x9dc3,
  0x585a, 0x8ba7, 0x4e3e, 0x450c, 0x8095
};
const uint16_t  Crc10Table[256] =
{
    0x000, 0x08f, 0x11e, 0x191, 0x23c, 0x2b3, 0x322, 0x3ad, 0x0f7, 0x078, 0x1e9, 0x166, 0x2cb, 0x244, 0x3d5, 0x35a,
    0x1ee, 0x161, 0x0f0, 0x07f, 0x3d2, 0x35d, 0x2cc, 0x243, 0x119, 0x196, 0x007, 0x088, 0x325, 0x3aa, 0x23b, 0x2b4,
    0x3dc, 0x353, 0x2c2, 0x24d, 0x1e0, 0x16f, 0x0fe, 0x071, 0x32b, 0x3a4, 0x235, 0x2ba, 0x117, 0x198, 0x009, 0x086,
    0x232, 0x2bd, 0x32c, 0x3a3, 0x00e, 0x081, 0x110, 0x19f, 0x2c5, 0x24a, 0x3db, 0x354, 0x0f9, 0x076, 0x1e7, 0x168,
    0x337, 0x3b8, 0x229, 0x2a6, 0x10b, 0x184, 0x015, 0x09a, 0x3c0, 0x34f, 0x2de, 0x251, 0x1fc, 0x173, 0x0e2, 0x06d,
    0x2d9, 0x256, 0x3c7, 0x348, 0x0e5, 0x06a, 0x1fb, 0x174, 0x22e, 0x2a1, 0x330, 0x3bf, 0x012, 0x09d, 0x10c, 0x183,
    0x0eb, 0x064, 0x1f5, 0x17a, 0x2d7, 0x258, 0x3c9, 0x346, 0x01c, 0x093, 0x102, 0x18d, 0x220, 0x2af, 0x33e, 0x3b1,
    0x105, 0x18a, 0x01b, 0x094, 0x339, 0x3b6, 0x227, 0x2a8, 0x1f2, 0x17d, 0x0ec, 0x063, 0x3ce, 0x341, 0x2d0, 0x25f,
    0x2e1, 0x26e, 0x3ff, 0x370, 0x0dd, 0x052, 0x1c3, 0x14c, 0x216, 0x299, 0x308, 0x387, 0x02a, 0x0a5, 0x134, 0x1bb,
    0x30f, 0x380, 0x211, 0x29e, 0x133, 0x1bc, 0x02d, 0x0a2, 0x3f8, 0x377, 0x2e6, 0x269, 0x1c4, 0x14b, 0x0da, 0x055,
    0x13d, 0x1b2, 0x023, 0x0ac, 0x301, 0x38e, 0x21f, 0x290, 0x1ca, 0x145, 0x0d4, 0x05b, 0x3f6, 0x379, 0x2e8, 0x267,
    0x0d3, 0x05c, 0x1cd, 0x142, 0x2ef, 0x260, 0x3f1, 0x37e, 0x024, 0x0ab, 0x13a, 0x1b5, 0x218, 0x297, 0x306, 0x389,
    0x1d6, 0x159, 0x0c8, 0x047, 0x3ea, 0x365, 0x2f4, 0x27b, 0x121, 0x1ae, 0x03f, 0x0b0, 0x31d, 0x392, 0x203, 0x28c,
    0x038, 0x0b7, 0x126, 0x1a9, 0x204, 0x28b, 0x31a, 0x395, 0x0cf, 0x040, 0x1d1, 0x15e, 0x2f3, 0x27c, 0x3ed, 0x362,
    0x20a, 0x285, 0x314, 0x39b, 0x036, 0x0b9, 0x128, 0x1a7, 0x2fd, 0x272, 0x3e3, 0x36c, 0x0c1, 0x04e, 0x1df, 0x150,
    0x3e4, 0x36b, 0x2fa, 0x275, 0x1d8, 0x157, 0x0c6, 0x049, 0x313, 0x39c, 0x20d, 0x282, 0x12f, 0x1a0, 0x031, 0x0be
};\n"""
for command_list in cmd_cls.C_CODE_EXPORT:
    func_string += "void %s(CMC cmc[]){\n\tuint16_t i;\n\tuint8_t j;\n" % command_list
    if 'output' in cmd_cls.C_CODE_EXPORT[command_list]:
        func_string += "\tchar out[10];\n"
    func_string += "\n"
    header_file += "void %s(CMC cmc[]);\n" % command_list
    if 'commands' in cmd_cls.C_CODE_EXPORT[command_list]:
        for cmd in cmd_cls.C_CODE_EXPORT[command_list]['commands']:
            if cmd['command'] == SPIWakeup.NAME:
                func_string += "\twakeup_pulse(cmc);\n"
            elif cmd['command'] == DELAY_MS.NAME:
                func_string += "\tmcu_delay_ms(%s);\n" % cmd['arguments']['Delay']
            elif cmd['command'] == DELAY_US.NAME:
                func_string += "\tmcu_delay_us(%s);\n" % cmd['arguments']['Delay']
            else:
                # Create Command Code
                func_string += "\tGET_CMD_CODE(cmc[0].command_code, %s);\n" % cmd['command'].upper()
                for bits in command_codes[cmd['command']]['bitfields']:
                    define_string = "%s_%s_INSERT" % (bits.upper(), cmd['command'].upper())
                    if 'arguments' in cmd:
                        if bits in cmd['arguments']:
                            func_string += "\t%s(cmc[0].command_code, %s)\n" % (
                            define_string, int(cmd['arguments'][bits]))
                    func_string += "\t%s(cmc[0].command_code, cmc[0].%s)\n" % (define_string, bits.lower())
                if command_codes[cmd['command']]['type'] == 'read':
                    if cmd_cls.COMMANDS[cmd['command']].VARIABLE_LENGTH:
                        func_string += """\tfor(i=0; i<NUM_DEV; i++){\n"""
                        func_string += """\t\tcmc[i].payload_len = %s;\n""" % cmd_cls.COMMANDS[
                            cmd['command']].VARIABLE_LENGTH
                        func_string += """\t}\n"""
                        func_string += "\tread_command(cmc, NUM_DEV);\n"
                        func_string += """\tfor(i=0; i<NUM_DEV; i++){\n"""
                        for bits in command_codes[cmd['command']]['variable_bitfields']:
                            define_string = "%s_%s_EXTRACT" % (bits.upper(), cmd['command'].upper())
                            func_string += "\t\tcmc[i].%s = %s(cmc[i].payload);\n" % (bits.lower(), define_string)
                        func_string += "\t}\n"
                    else:
                        func_string += """\tcmc[0].payload_len = %s;\n""" % str(
                            cmd_cls.COMMANDS[cmd['command']].STATIC_LENGTH - 4)
                        func_string += "\tread_command(cmc, 1);\n"
                        for bits in command_codes[cmd['command']]['variable_bitfields']:
                            define_string = "%s_%s_EXTRACT" % (bits.upper(), cmd['command'].upper())
                            func_string += "\t\tcmc[0].%s = %s(cmc[0].payload);\n" % (bits.lower(), define_string)
                elif command_codes[cmd['command']]['type'] == 'write':
                    if cmd_cls.COMMANDS[cmd['command']].VARIABLE_LENGTH:
                        func_string += """\tfor(i=0; i<NUM_DEV; i++){\n"""
                        func_string += """\t\tcmc[i].payload_len = %s;\n""" % cmd_cls.COMMANDS[
                            cmd['command']].VARIABLE_LENGTH
                        func_string += """\t\tfor(j=0; j<cmc[i].payload_len; j++){\n"""
                        func_string += "\t\t\tcmc[i].payload[j] = 0x00;"
                        func_string += "\t\t}\n"
                        for bits in command_codes[cmd['command']]['variable_bitfields']:
                            define_string = "%s_%s_INSERT" % (bits.upper(), cmd['command'].upper())
                            if 'arguments' in cmd:
                                if bits in cmd['arguments']:
                                    func_string += "\t\t%s(cmc[i].payload, %s)\n" % (
                                    define_string, int(cmd['arguments'][bits]))
                                else:
                                    func_string += "\t\t%s(cmc[i].payload, cmc[i].%s)\n" % (define_string, bits.lower())
                            else:
                                func_string += "\t\t%s(cmc[i].payload, cmc[i].%s)\n" % (define_string, bits.lower())
                        func_string += "\t}\n"
                        func_string += "\twrite_command(cmc, NUM_DEV);\n"
                    else:
                        func_string += """\t\tcmc[0].payload_len = %s;\n""" % str(
                            cmd_cls.COMMANDS[cmd['command']].STATIC_LENGTH - 4)
                        func_string += """\tfor(j=0; i<cmc[0].payload_len; j++){\n"""
                        func_string += "\t\tcmc[i].payload[j] = 0x00;"
                        func_string += "\t}"
                        for bits in command_codes[cmd['command']]['variable_bitfields']:
                            define_string = "%s_%s_INSERT" % (bits.upper(), cmd['command'].upper())
                            if 'arguments' in cmd:
                                if bits in cmd['arguments']:
                                    func_string += "\t\t%s(cmc[0].payload, %s)\n" % (
                                        define_string, int(cmd['arguments'][bits]))
                                else:
                                    func_string += "\t\t%s(cmc[0].payload, cmc[0].%s)\n" % (define_string, bits.lower())
                            else:
                                func_string += "\t\t%s(cmc[0].payload, cmc[0].%s)\n" % (define_string, bits.lower())
                        func_string += "\t}\n"
                        func_string += "\twrite_command(cmc, 1);\n"
                elif command_codes[cmd['command']]['type'] == 'poll':
                    func_string += "\tpoll_command(cmc);\n"
                elif command_codes[cmd['command']]['type'] == 'broadcast':
                    func_string += "\tbroadcast_command(cmc);\n"
    if 'output' in cmd_cls.C_CODE_EXPORT[command_list]:
        # Print Output
        func_string += '\tmcu_print("Result:\\n");\n'
        func_string += '\tfor(uint16_t i=0; i<NUM_DEV; i++){\n'
        func_string += '\t\tmcu_print("[");\n'
        for metric in cmd_cls.C_CODE_EXPORT[command_list]['output']:
            func_string += '\t\tsprintf(out, "%x, ", '
            func_string += 'cmc[i].%s);\n' % metric.lower()
            func_string += '\t\tmcu_print(out);\n'
        func_string += '\t\tmcu_print("]\\n");\n'
        func_string += "\t}\n"

    func_string += "}\n"
func_string += """void wakeup_pulse(CMC cmc[]){
  for(uint16_t i=0; i<NUM_DEV+1; i++){
    cs_low();
    mcu_delay_us(1000);
    cs_high();
  }
}
void broadcast_command(CMC cmc[]){
  uint16_t pec;

  // Build Command Code
  pec = pec15(2, cmc[0].command_code);
  cmc[0].command_code[2] = pec>>8;
  cmc[0].command_code[3] = pec&0xFF;
  // Write Data
  cs_low();
  for(uint16_t i=0; i<4; i++){
    spi_transaction(cmc[0].command_code[i]);
  }
  cs_high();
}
void poll_command(CMC cmc[]){
  uint32_t counter = 0;
  uint8_t finished = 0;
  uint8_t current_time = 0;
  uint16_t pec;

  // Build Command Code
  pec = pec15(2, cmc[0].command_code);
  cmc[0].command_code[2] = pec>>8;
  cmc[0].command_code[3] = pec&0xFF;
  // Write Data
  cs_low();
  for(uint16_t i=0; i<4; i++){
    spi_transaction(cmc[0].command_code[i]);
  }
  while ((counter<200000)&&(finished == 0))
  {
    current_time = spi_transaction(0xff);
    if (current_time>0)
    {
      finished = 1;
    }
    else
    {
      counter = counter + 1;
    }
  }
  cs_high();
}
void write_command(CMC cmc[], uint8_t len){
  uint16_t pec;
  uint16_t i;
  uint8_t j;

  // Build Command Code
  pec = pec15(2, cmc[0].command_code);
  cmc[0].command_code[2] = pec>>8;
  cmc[0].command_code[3] = pec&0xFF;
  // Build PECs
  for(i=0; i<len; i++){
    pec = pec10(0, cmc[i].payload_len-2, cmc[i].payload);
    cmc[i].payload[cmc[i].payload_len-2] = pec>>8;
    cmc[i].payload[cmc[i].payload_len-1] = pec&0xFF;
  }
  // Write Data
  cs_low();
  for(i=0; i<4; i++){
    spi_transaction(cmc[0].command_code[i]);
  }
  for(i=0; i<len; i++){
    //Reverse Write Order
    for(j=0; j<cmc[len-1-i].payload_len; j++){
        spi_transaction(cmc[len-1-i].payload[j]);
    }
  }
  cs_high();
}
void read_command(CMC cmc[], uint8_t len){
  uint16_t pec;
  uint16_t i;
  uint8_t j;

  // Build Command Code
  pec = pec15(2, cmc[0].command_code);
  cmc[0].command_code[2] = pec>>8;
  cmc[0].command_code[3] = pec&0xFF;
  // Write Data
  cs_low();
  for(i=0; i<4; i++){
    spi_transaction(cmc[0].command_code[i]);
  }
  // Read Data
  for(i=0; i<len; i++){
    for(j=0; j<cmc[i].payload_len; j++){
        cmc[i].payload[j] = spi_transaction(0xff);
    }
  }
  cs_high();
  // Evaluate PECs
  for(i=0; i<len; i++){
    pec = pec10(1, cmc[i].payload_len-2, cmc[i].payload);
    if (pec != (((uint16_t) (cmc[i].payload[cmc[i].payload_len-2] & 0x3) << 8) | (cmc[i].payload[cmc[i].payload_len-1] & 0xff))){
        cmc[i].pec_error += 1;
    }
  }
}
uint16_t pec15(uint8_t len, uint8_t *data)
{
  uint16_t remainder,addr;
  remainder = 16; /* initialize the PEC */
  for (uint8_t i = 0; i<len; i++) /* loops for each byte in data array */
  {
    addr = (((remainder>>7)^data[i])&0xff);/* calculate PEC table address */
    remainder = ((remainder<<8)^Crc15Table[addr]);
  }
  return(remainder*2);/* The CRC15 has a 0 in the LSB so the remainder must be multiplied by 2 */
}

uint16_t pec10(uint8_t rx_cmd, uint16_t len, uint8_t *data){
    uint16_t   nRemainder = 16u;/* PEC_SEED */
    /* x10 + x7 + x3 + x2 + x + 1 <- the CRC10 polynomial 100 1000 1111 */
    uint16_t   nPolynomial = 0x8Fu;
    uint8_t   nByteIndex, nBitIndex;
    uint16_t   nTableAddr;

    for (nByteIndex = 0u; nByteIndex < len; ++nByteIndex)
    {
        /* calculate PEC table address */
        nTableAddr = (uint16_t)(((uint16_t)(nRemainder >> 2) ^ (uint8_t)data[nByteIndex]) &
                (uint8_t)0xff);
        nRemainder = (uint16_t)(((uint16_t)(nRemainder << 8)) ^ Crc10Table[nTableAddr]);
    }
    /* If array is from received buffer add command counter to crc calculation */
    if (rx_cmd == 1)
    {
        nRemainder ^= (uint16_t)(((uint16_t)data[len] & (uint8_t)0xFC) << 2u);
    }
    /* Perform modulo-2 division, a bit at a time */
    for (nBitIndex = 6u; nBitIndex > 0u; --nBitIndex)
    {
        /* Try to divide the current data bit */
        if ((nRemainder & 0x200u) > 0u)
        {
            nRemainder = (uint16_t)((nRemainder << 1u));
            nRemainder = (uint16_t)(nRemainder ^ nPolynomial);
        }
        else
        {
            nRemainder = (uint16_t)((nRemainder << 1u));
        }
    }
    return ((uint16_t)(nRemainder & 0x3FFu));
}

float ieeefloat24(uint32_t raw){
    float value;
    float mantissa;
    int8_t expo;

    mantissa = (float) (raw & 0xFFFF);
    expo = (raw >> 16) & 0x7F;
    if (expo > 0){
      value = pow(2, (expo-63)) * (1 + mantissa / 0x10000);
    }
    else{
      value = pow(2, (expo-63)) * (0 + mantissa / 0x10000);
    }
    if (raw >> 23){
      return -1*value;
    }
    else {
      return value;
    }
}"""
with open("%s.h" % cmd_cls.__name__, 'w') as outfile:
    outfile.write(header_file)
with open("%s.cpp" % cmd_cls.__name__, 'w') as outfile:
    outfile.write(func_string)


