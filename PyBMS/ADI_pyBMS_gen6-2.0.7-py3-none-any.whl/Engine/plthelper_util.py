# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.
# -*- coding: utf-8 -*-
"""
Functions to support plthelper
@author: lloopik
Thanks Leon for writing this!
"""


import time
import functools
import warnings
import sys

printWrapping = False

def sleep(t):
    """
    A blocking sleep function, that still keeps the application responsive
      use plt.pause instead!
    """
    goal = time.perf_counter() + t
    warnings.warn("USING ll_util.sleep! use plt.pause instead")
    from PyQt5.Qt import QApplication
    left = t
    while (left > 0):
        QApplication.processEvents()
        if (left > 5e-3):
            time.sleep(1e-3)
        left = goal - time.perf_counter()

def wrap(oldFunc, before=None, after=None, overWrite=True, wid='ll_wrapped'):
    if(hasattr(oldFunc, wid)):
        if(overWrite):
            if(printWrapping):
                print(f"Overwritting wrapper on {oldFunc}, wid {wid}")
            oldFunc = getattr(oldFunc, wid)
        else:
            return oldFunc

    if(printWrapping):
        print(f"Wrapping {oldFunc}, wid {wid}")

    @functools.wraps(oldFunc)
    def newFunc(*args, **kwargs):
        if(before is not None):
            bret = before(*args, **kwargs)
            if(bret is not None):
                (args, kwargs) = bret

        ret = oldFunc(*args, **kwargs)

        if(after is not None):
            ret = after(ret, *args, **kwargs)
        return ret
    setattr(newFunc, wid, oldFunc)
    return newFunc

def unwrap(func, wid='ll_wrapped'):
    if(hasattr(func, wid)):
        if(printWrapping):
            print(f"Unwrapping {func}, wid {wid}")
        func = getattr(func, wid)
    return func

class Persist(dict):
    pass

try:
    persist = sys.ll_persist
except:
    #print("Creating new persist")
    persist = Persist()
    sys.ll_persist = persist