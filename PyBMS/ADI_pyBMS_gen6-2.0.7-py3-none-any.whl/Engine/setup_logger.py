# Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
# This software is proprietary to Analog Devices, Inc. and its licensors.

import logging
try:
    import tomli
except:
    pass
from pathlib import Path

def init_logger():
    """
    Creates a logger for the bms class. You can set the logging levels for stdout and logfile

    :param self.logfile: path to logfile. Standard it is None, so it wont create a file
    :param self.log_level_file: The loglevel of the file. 10 is debug (all), 50 is critical (only critical)
    :param self.log_level_stdout: The loglevel of the console output. 10 is debug (all), 50 is critical (only critical)
    :return logger object:

    # DEBUG, just for debugging
    # INFO, use for data, some message and other maybe relevant information
    # WARNING, use for warning that do not really affect the system, for example can't import a device you don't use
    # ERROR, error happened, but we are going to continue
    # CRITCAL, critical error happened and the system is severly affected. Might not even run at all

    """
    # Read log settings from pyproject.toml. If that doesn't work (on Linux for example), use pre set values
    try:
        pyproject = tomli.loads(Path("../../pyproject.toml").read_text(encoding="utf-8"))

        logfile = pyproject['logger']['logfile']
        loglevel = pyproject['logger']['loglevel']
        logname = pyproject['logger']['logname']
        write_log_level = pyproject['logger']['write_log_level']
    except:
        logfile = 'API.log'
        loglevel = 40
        logname = 'PyBMS_API'
        write_log_level = 0


    logger = logging.getLogger(logname)
    logger.setLevel(loglevel)

    # Create log format
    formatter = logging.Formatter('%(asctime)s | %(name)s | %(levelname)s | %(message)s')

    # If write log level higher then 0, write log
    if write_log_level:
        fileHandler = logging.FileHandler(logfile)
        fileHandler.setLevel(write_log_level)
        fileHandler.setFormatter(formatter)
        logger.addHandler(fileHandler)

    # Always create sdout logger
    consoleHandler = logging.StreamHandler()
    consoleHandler.setLevel(loglevel)
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)

    return logger