from Test_Equipment.VisaInstrument import VisaInstrument


class DMM(VisaInstrument):
    """
    Abstract DMM class to create a generic DMM interface.

    :param device_id: Visa device ID
    """
    INST_TYPE = ['DMM']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.gui = 'dmm.html'
        self.ON = 'ON'
        self.OFF = 'OFF'
        self.MIN_RANGE = 'MIN'
        self.MAX_RANGE = 'MAX'
        self.AUTO_RANGE = 'AUTO'
        self.DEFAULT_RANGE = 'DEF'
        self.MIN_RESOLUTION = 'MIN'
        self.MAX_RESOLUTION = 'MAX'
        self.DEFAULT_RESOLUTION = 'DEF'
        self.TEMP_FRTD = 'FRTD'
        self.TEMP_RTD = 'RTD'
        self.TEMP_THERM = 'THER'
        self.TEMP_DEFAULT = 'DEF'
        self.IMMEDIATE_TRIGGER = 'IMM'
        self.TIMER_TRIGGER = 'TIM'
        self.MANUAL_TRIGGER = 'MAN'
        self.BUS_TRIGGER = 'BUS'
        self.EXTERNAL_TRIGGER = 'EXT'
        self.RANGES = [self.MAX_RANGE, self.MIN_RANGE, self.AUTO_RANGE, self.DEFAULT_RANGE]
        self.RESOLUTIONS = [self.MAX_RESOLUTION, self.MIN_RESOLUTION, self.DEFAULT_RESOLUTION]
        self.TEMP_PROBE_TYPES = [self.TEMP_FRTD, self.TEMP_RTD, self.TEMP_THERM, self.TEMP_DEFAULT]
        self.TRIGGER_SOURCES = [self.IMMEDIATE_TRIGGER, self.TIMER_TRIGGER, self.MANUAL_TRIGGER, self.BUS_TRIGGER, self.EXTERNAL_TRIGGER]

    def open_all_chls(self):
        self.inst.write('ROUT:OPEN:ALL')

    def set_auto_range_ons(self, state):
        if state not in [self.ON, self.OFF]:
            raise ValueError('state not allowed')
        self.inst.write('VOLT:DC:RANG:AUTO %s' % state)

    def route_chls(self, chl_list=None, open_all=True):
        if not chl_list:
            raise ValueError("Must provide a channel list to route together")
        if open_all:
            self.open_all_chls()
        self.inst.write('ROUT:MULT:CLOS (@%s)' % ','.join(chl_list))

    def measure_capacitance(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CAP? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:CAP?'))

    def measure_continuity(self):
        return float(self.inst.query('MEAS:CONT?').split(',')[0]) < 5

    def measure_ac_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:AC? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:CURR:AC?'))

    def measure_dc_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:DC? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:CURR:DC?'))

    def measure_diode(self):
        return self.inst.query('MEAS:DIOD?')

    def measure_frequency(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FREQ? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:FREQ?'))

    def measure_resistance_4wire(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FRES? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:FRES?'))


    def measure_period(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:PER? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:PER?'))

    def measure_resistance(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:RES? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:RES?'))


    def measure_temperature(self, probe_type=None, resolution=None):
        if probe_type not in self.TEMP_PROBE_TYPES:
            raise ValueError('Must provide a valid temperature measurement probe type')
        if resolution:
            return float(self.inst.query('MEAS:TEMP? %s, DEF, 1, %s' % (probe_type, resolution)))
        return float(self.inst.query('MEAS:TEMP? %s, DEF, 1' % probe_type))

    def measure_ac_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:AC? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:VOLT:AC?'))

    def measure_dc_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:DC? %s, %s' % (range, resolution)))
        return float(self.inst.query('MEAS:VOLT:DC?'))

    def configure_dc_voltage(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:VOLT:DC %s, %s' % (range, resolution))

    def configure_ac_voltage(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:VOLT:AC %s, %s' % (range, resolution))

    def configure_dc_current(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:CURR:DC %s, %s' % (range, resolution))

    def configure_ac_current(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:CURR:AC %s, %s' % (range, resolution))

    def configure_resistance(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:RES %s, %s' % (range, resolution))

    def configure_4wire_resistance(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:FRES %s, %s' % (range, resolution))

    def configure_frequency(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:FREQ %s, %s' % (range, resolution))

    def configure_period(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:PER %s, %s' % (range, resolution))

    def configure_temp(self, range=None, resolution=None):
        if not range or not resolution:
            raise ValueError('Must provide range and resolution')
        self.inst.write('CONF:TEMP %s, %s' % (range, resolution))

    def trigger_source(self, source=None, query=None):
        if query:
            return self.inst.query('TRIG:SOUR?')
        if source not in self.TRIGGER_SOURCES:
            raise ValueError('Must provide a valid trigger source')
        self.inst.write('TRIG:SOUR %s' % source)

    def one_shot_measure(self, return_all=False):
        if return_all:
            return self.inst.query('READ?').split(',')
        return float(self.inst.query('READ?'))

    def trigger_timer(self, timer=None):
        self.inst.write('TRIG:TIM %s' % timer)

    def trigger_count(self, count=None):
        self.inst.write('TRIG:COUN %s' % count)

    def trigger_delay(self, delay=None):
        self.inst.write('TRIG:DEL %s' % delay)

    def trigger_delay_auto_state(self, state=None):
        self.inst.write('TRIG:DEL:AUTO %s' % state)

    def trigger_sample_count(self, count=None, query=False):
        if query:
            return self.inst.query('SAMP:COUN?')
        self.inst.write('SAMP:COUN %s' % count)

    def trigger_initiate_countinuous_state(self, state=None):
        self.inst.write('INIT:CONT %s' % state)

    def trigger_initiate(self):
        self.inst.write('INIT')

    def trace_data(self):
        return self.inst.query('TRAC:DATA?')

    def trace_data_clear(self):
        return self.inst.query('TRAC:CLE')
