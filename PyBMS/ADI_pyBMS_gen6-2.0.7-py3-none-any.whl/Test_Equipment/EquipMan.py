import pyvisa as visa
import os
import logging
import json
from importlib import import_module


__MODULE_DIR__ = os.path.dirname(__file__)


class EquipMan(object):
    """
    Class that gathers connected Visa equipment and organizes them for use by other programs.

    :param: logger: Optional logger to provide debug messages
    :param: inst_folder: Folder containing all Instrument classes
    :param: config_folder: Folder containing json config files for non Visa Instruments
    """
    INSTRUMENT_LIST = []
    MSG_GET_INSTRUMENTS = 'get'
    MSG_REBUILD_INSTRUMENTS = 'rebuild'
    MSG_CLOSE_INSTRUMENTS = 'close'

    def __init__(self, logger=None, inst_folder='Instruments', config_folder='Instruments/Non_Visa_Equipment_Config', blocklist=None, path_to_visa=None, input_queue=None, output_queue=None, msg_pipe=None):
        if logger:
            self.logger = logging.getLogger(logger)
            self.logger_name = logger
        else:
            self.logger = None
            self.logger_name = None
        self.inst_folder = inst_folder
        self.config_folder = config_folder
        if not blocklist:
            self.blocklist = []
        else:
            self.blocklist = blocklist
        if path_to_visa:
            self.rm = visa.ResourceManager(path_to_visa)
        else:
            self.rm = visa.ResourceManager()
        self.rm = visa.ResourceManager()
        self.instrument_dict = {'Oscilloscope': {}, 'Supply': {}, 'Load': {}, 'SigGen': {}, 'RFSwitch': {}, 'PA': {},
                                'RFPM': {}, 'DMM': {}, 'SMU': {}, 'BCS': {}, 'RelayBoard': {}, 'ThermalChamber': {}}
        self.instrument_dict_string = {'Oscilloscope': {}, 'Supply': {}, 'Load': {}, 'SigGen': {}, 'RFSwitch': {}, 'PA': {},
                                'RFPM': {}, 'DMM': {}, 'SMU': {}, 'BCS': {}, 'RelayBoard': {}, 'ThermalChamber': {}}
        # Create list of all defined instruments in the Instruments package
        instruments_dir = os.path.join(__MODULE_DIR__, inst_folder)
        for instrument in os.listdir(instruments_dir):
            try:
                if '__' in instrument:
                    continue
                if '.pyc' in instrument:
                    continue
                parent_module = self.__module__.rpartition('.')[0]
                instruments_module = inst_folder.replace('/', '.')
                instrument_module = instrument.split('.')[0]
                instclass = getattr(import_module("%s.%s.%s" % (parent_module, instruments_module, instrument_module)),
                                    instrument.split('.')[0])
                EquipMan.INSTRUMENT_LIST.append(instclass)
            except ImportError as ie:
                if self.logger:
                    self.logger.warning("Error importing instrument: %s: %s" % (instrument, ie))
            except AttributeError:
                pass
        self.build_instrument_dict()
        # self.input_queue = input_queue
        # self.output_queue = output_queue
        # self.msg_pipe = msg_pipe

    def build_instrument_dict(self):
        """
        Scans through all visa based instruments and creates objects out of the instruments it recognizes.
        """
        # Go through config files and create all non visa instruments before pyvisa hogs serial connections
        config_dir = os.path.join(__MODULE_DIR__, self.config_folder)
        for config_filename in os.listdir(config_dir):
            try:
                config_filepath = os.path.join(config_dir, config_filename)
                with open(config_filepath, 'r') as config_file:
                    config_json = json.load(config_file)
                # Load appropriate class from json
                for instrument_class in EquipMan.INSTRUMENT_LIST:
                    if config_json['class'] == instrument_class.__name__:
                        instclass = instrument_class
                # Create instrument using class and append to instrument dict
                kwargs = config_json['parameters'].copy()
                kwargs['logger'] = self.logger_name
                self.instrument_dict[config_json['inst_type']][config_json['identifier']] = instclass(
                    config_json['identifier'], self, **kwargs)
                self.instrument_dict_string[config_json['inst_type']][config_json['identifier']] = instclass.__name__
            except Exception as e:
                if self.logger:
                    self.logger.error('Could not create instrument [%s]: %s' % (config_filename, e))
        # Now build out visa instruments
        for resource in self.rm.list_resources():
            try:
                if 'ASRL' in resource:
                    if 'COM' + resource.split('ASRL')[1].split(':')[0] in self.blocklist:
                        continue
                inst = self.rm.get_instrument(resource)
                inst_id = inst.query('*IDN?')
                inst.close()
                brand = inst_id.split(',')[0].strip()
                model = inst_id.split(',')[1].strip()
                serial_num = inst_id.split(',')[2].replace('/', '-')
                for instrument in EquipMan.INSTRUMENT_LIST:
                    if brand in instrument.BRAND and model in instrument.MODEL_NUM:
                        for inst_type in instrument.INST_TYPE:
                            self.instrument_dict[inst_type][resource] = instrument(resource, self,
                                                                                     logger=self.logger_name)
                            self.instrument_dict_string[inst_type][resource] = instrument.__name__
            except Exception as e:
                if self.logger:
                    self.logger.error('Could not create instrument [%s]: %s' % (resource, e))
