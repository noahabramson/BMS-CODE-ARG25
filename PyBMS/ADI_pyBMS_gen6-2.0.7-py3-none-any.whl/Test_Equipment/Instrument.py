import threading
import logging
import time


class Instrument(object):
    INST_TYPE = []
    BRAND = []
    MODEL_NUM = []

    def __init__(self, device_id, em, logger=None):
        if logger:
            self.logger = logging.getLogger(logger)
        else:
            self.logger = None
        self.em = em
        self.id = device_id
        self.gui = "Instrument.html"
        self.gui_kwargs = {}

