from ..Instrument import Instrument
from Engine.Interfaces.SCon_ASCII import SCon_ASCII


class Active_Load(Instrument):
    INST_TYPE = ['ActiveLoad']

    SINE = 2
    TRIANGLE = 1
    SQUARE = 0
    RESET = 3

    def __init__(self, device_id, em, logger=None, port=None, baud=115200, chls=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        if not port:
            raise ValueError('No Comport given, cannot talk to Active Load')
        self.con = SCon_ASCII(port, baud)
        self.OUTPUT_TYPES = [Active_Load.SQUARE, Active_Load.TRIANGLE, Active_Load.SINE, Active_Load.RESET]

    def set_dc_mA(self, mA):
        self.con.write("dc %s" % mA)
        output = self.con.read(terminator=">>")
        if 'ERROR' in output:
            raise IOError(output)

    def set_ac_amplitude(self, amp):
        self.con.write("amp %s" % amp)
        output = self.con.read(terminator=">>")
        if 'ERROR' in output:
            raise IOError(output)

    def set_ac_frequency(self, freq):
        self.con.write("freq %s" % freq)
        output = self.con.read(terminator=">>")
        if 'ERROR' in output:
            raise IOError(output)

    def set_ac_output_type(self, type):
        if type not in self.OUTPUT_TYPES:
            raise ValueError("Must provide a valid output type")
        self.con.write("type %s" % type)
        output = self.con.read(terminator=">>")
        if 'ERROR' in output:
            raise IOError(output)

    def disable_load(self):
        self.con.write("stop")
        output = self.con.read(terminator=">>")
        if 'ERROR' in output:
            raise IOError(output)