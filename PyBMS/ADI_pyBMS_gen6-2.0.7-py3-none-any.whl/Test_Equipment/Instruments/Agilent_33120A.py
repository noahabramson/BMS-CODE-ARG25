from ..SignalGenerator import AgilentSignalGenerator


class Agilent_33120A(AgilentSignalGenerator):
    BRAND = ['HEWLETT-PACKARD']  # The front panel shows the Agilent name but the device reports itself as HP
    MODEL_NUM = ['33120A']

    def __init__(self, device_id, em, logger=None):
        AgilentSignalGenerator.__init__(self, device_id, em, logger=logger)
