from ..SignalGenerator import AgilentSignalGenerator


class Agilent_33220A(AgilentSignalGenerator):
    MODEL_NUM = ['33220A']

    def __init__(self, device_id, em, logger=None):
        AgilentSignalGenerator.__init__(self, device_id, em, logger=logger)
