from ..SignalGenerator import AgilentSignalGenerator


class Agilent_33250A(AgilentSignalGenerator):
    MODEL_NUM = ['33250A']

    def __init__(self, device_id, em, logger=None):
        AgilentSignalGenerator.__init__(self, device_id, em, logger=logger)
