from ..DMM import DMM


class Agilent_34410A(DMM):
    BRAND = ['Agilent Technologies', 'HEWLETT-PACKARD']
    MODEL_NUM = ['34401A']

    def __init__(self, device_id, em, logger=None):
        DMM.__init__(self, device_id, em, logger=logger)

    def measure_capacitance(self, range=None, resolution=None):
        raise ValueError('This DMM cannot measure capacitance')
