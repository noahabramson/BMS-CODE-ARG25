from ..SMU import SMU


class Agilent_B2912A(SMU):
    BRAND = ['Agilent Technologies', 'Keysight Technologies']
    MODEL_NUM = ['B2912A']

    def __init__(self, device_id, em, logger=None):
        SMU.__init__(self, device_id, em, logger=logger)
        self.chl_list = [1, 2]
