from ..Supply import Supply


class Agilent_E3634A(Supply):
    BRAND = ['Agilent Technologies']
    MODEL_NUM = ['E3634A']

    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)
        self.NORMAL_RANGE = ''
        self.VOLTAGE_MODE = ''
        self.CURRENT_MODE = ''
