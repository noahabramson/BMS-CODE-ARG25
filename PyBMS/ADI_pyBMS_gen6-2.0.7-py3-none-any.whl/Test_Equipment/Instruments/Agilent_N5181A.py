from ..SignalGenerator import SignalGenerator


class Agilent_N5181A(SignalGenerator):
    BRAND = ['Agilent Technologies']
    MODEL_NUM = ['N5181A']

    def __init__(self, device_id, em, logger=None):
        SignalGenerator.__init__(self, device_id, em, logger=logger)
