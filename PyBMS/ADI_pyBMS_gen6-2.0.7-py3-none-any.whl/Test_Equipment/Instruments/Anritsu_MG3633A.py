from ..SignalGenerator import SignalGenerator


class Anritsu_MG3633A(SignalGenerator):
    BRAND = ['Anritsu']
    MODEL_NUM = ['MG3633A']

    def __init__(self, device_id, em, logger=None):
        SignalGenerator.__init__(self, device_id, em, logger=logger)
        self.OUTPUT_ON = 'O'
        self.OUTPUT_OFF = 'F'

    def output_state(self, state=None, query=False):
        if query:
            return None
        if state not in [self.OUTPUT_ON, self.OUTPUT_OFF]:
            raise ValueError('Must provide a valid state for output')
        else:
            self.inst.write('R%s' % state)

    def sig_amplitude_dbm(self, amp=None, query=False):
        if query:
            return None
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude must be below: %s' % self.output_limits['amp_max'])
        self.inst.write('OL%sDBM,LC' % amp)

    def sig_amplitude_volt(self, amp=None, query=False):
        if query:
            return None
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude must be below: %s' % self.output_limits['amp_max'])
        self.inst.write('OL%sV,LC' % amp)

    def frequency_cw(self, cw=None, query=False):
        if query:
            return None
        if self.output_limits:
            if self.output_limits['freq_min'] > cw or cw > self.output_limits['cw_max']:
                raise ValueError('Output frequency must be between: [%s]-[%s]' % (
                    self.output_limits['cw_min'], self.output_limits['cw_max']))
        self.inst.write('FR%sMHZ' % cw)
