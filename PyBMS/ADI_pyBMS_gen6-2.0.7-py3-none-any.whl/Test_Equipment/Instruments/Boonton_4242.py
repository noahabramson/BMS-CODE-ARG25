from ..RFPowerMeter import RFPowerMeter


class Boonton_4242(RFPowerMeter):
    BRAND = ['BOONTON ELECTRONICS']
    MODEL_NUM = ['4242']

    def __init__(self, device_id, em, logger=None):
        RFPowerMeter.__init__(self, device_id, em, logger=logger)
