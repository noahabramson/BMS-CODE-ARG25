from ..Instrument import Instrument
from ..PCANBasic import *
import time


class Comemso_BCS_24(Instrument):
    def __init__(self, device_id, em, logger=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        self.pcan = PCANBasic()
        self.gui = 'bcs.html'
        self.gui_kwargs = {
            'cards': ['1', '2', '3', '4', '5', '6'],
            'channels': ['1', '2', '3', '4']
        }
        # Attempt to connect to PCAN dongle, if can't exception
        self.baudrate = PCAN_BAUD_1M
        self.hwtype = PCAN_TYPE_ISA
        self.ioport = 0x2A0
        self.interrupt = 11
        self.channel = PCAN_USBBUS1
        self.card_ids = {'1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6}
        self.chls = {'1': 0x1, '2': 0x2, '3': 0x4, '4': 0x8, 'All': 0xF}
        self.voltage_limit = {'High': 8100, 'Low': 850}
        self.current_limit = {'High': 2000, 'Low': 0}
        self.NORMAL_MODE = 1
        self.OPEN_MODE = 2
        self.SHORTCUT_MODE = 3
        self.POLARITY_CHANGE_MODE = 4
        self.CONN_U1_CS_PLUS_MODE = 5
        self.DUAL_MODE = 6
        self.QUAD_MODE = 7
        self.CURRENT_SENSOR_OFFSET_MODE = 8
        self.SENSE_DETECT_MODE = 13
        self.INTERNAL_LOAD_ONLY_MODE = 14
        self.modes = [self.NORMAL_MODE, self.OPEN_MODE, self.SHORTCUT_MODE, self.POLARITY_CHANGE_MODE,
                      self.CONN_U1_CS_PLUS_MODE, self.DUAL_MODE, self.QUAD_MODE, self.CURRENT_SENSOR_OFFSET_MODE,
                      self.SENSE_DETECT_MODE, self.INTERNAL_LOAD_ONLY_MODE]
        self.CURRENT_SENSE_AUTO = 0x00
        self.CURRENT_SENSE_MA = 0x01
        self.CURRENT_SENSE_UA = 0x02
        self.COULOMB_TYPE_INTEGRAL = 0
        self.COULOMB_TYPE_CURRENT = 1
        self.pcan_is_init = False
        try:
            self.pcan.Initialize(self.channel, self.baudrate, self.hwtype, self.ioport, self.interrupt)
            self.pcan_is_init = True
        except:
            raise ValueError('Could not connect to PCAN Dongle')
        # Uninit PCAN to prevent dll hangup if python is killed
        self.pcan_uninit()

    def set_cell_properties(self, card, chls, voltage, load, mode, sense_detection=False, micro_current_offset=False,
                             current_sensor_select=0x00, coulomb_type=0, sw_vctrol_disable=False):
        if not self.pcan_is_init:
            self.pcan_init()
        # User Input checking
        if voltage > self.voltage_limit['High'] or voltage < self.voltage_limit['Low']:
            raise ValueError('Voltage out of bounds')
        if load > self.current_limit['High'] or load < self.current_limit['Low']:
            raise ValueError('Load out of bounds')
        if card not in self.card_ids:
            raise ValueError('Card not present')
        if chls not in self.chls:
            raise ValueError('Cell does not exist')
        if mode not in self.modes:
            raise ValueError('Mode does not exist')
        if current_sensor_select not in [self.CURRENT_SENSE_AUTO, self.CURRENT_SENSE_MA, self.CURRENT_SENSE_UA]:
            raise ValueError('Incorrect current sensor selection')
        if coulomb_type not in [self.COULOMB_TYPE_CURRENT, self.COULOMB_TYPE_INTEGRAL]:
            raise ValueError('Incorrect coulomb type')
        CANMsg = TPCANMsg()
        # Configure Header 0x5<card ID> represents the message ID
        CANMsg.ID = 1280 + self.card_ids[card]
        CANMsg.LEN = 8
        CANMsg.MSGTYPE = PCAN_MESSAGE_STANDARD
        # Calculate voltage and load current values
        voltage_val = voltage * 4
        current_val = load * 100
        # Create CAN bytes
        can_bytes = []
        # Byte 0: Cell ID and set bit
        can_bytes.append((self.chls[chls] << 4) | 0x2)
        # Byte 1: LSB Voltage
        can_bytes.append(voltage_val & 0xFF)
        # Byte 2: MSB Voltage and sense detect
        byte2 = (voltage_val >> 8) & 0x7F
        if not sense_detection:
            byte2 = byte2 | 0x80
        can_bytes.append(byte2)
        # Byte 3: Load LSB
        can_bytes.append(current_val & 0xFF)
        # Byte 4: Loab MSB
        can_bytes.append((current_val >> 8) & 0x7F)
        # Byte 5: Mode, micro zero offset, current sensor select, coulomb type
        byte5 = mode
        if micro_current_offset:
            byte5 = byte5 | 0x0100
        byte5 = byte5 | (current_sensor_select << 6)
        if coulomb_type:
            byte5 = byte5 | 0x8000
        can_bytes.append(byte5)
        # Byte 6: Blank
        can_bytes.append(0x0000)
        # Byte 7: sw vctrl disable
        if sw_vctrol_disable:
            can_bytes.append(0x8000)
        else:
            can_bytes.append(0x0000)
        for i in range(CANMsg.LEN):
            CANMsg.DATA[i] = can_bytes[i]
        # Write CAN frame
        return self.pcan.Write(self.channel, CANMsg)

    def read_cell_properties(self, card, chl, repeats=3):
        if not self.pcan_is_init:
            self.pcan_init()
        data = {'Card': card, 'Channel': chl, 'Measured_Voltage': None, 'Vout_Control': None, 'Error_Fuse': None,
                'Load_Reduction': None, 'Error_Sense': None, 'Current': None, 'Current_Type': None, 'Temperature': None}
        # User input checking
        if card not in self.card_ids:
            raise ValueError('Card not present')
        if chl not in self.chls:
            raise ValueError('Cell does not exist')
        # Create dummy CANMsg
        CANMsg = TPCANMsg()
        # Configure Header 0x5<card ID> represents the message ID
        CANMsg.ID = 1280 + self.card_ids[card]
        CANMsg.LEN = 8
        CANMsg.MSGTYPE = PCAN_MESSAGE_STANDARD
        # Send msg with response bit enabled, but not save or set bit
        # Put in current measurement type bit
        can_bytes = [(self.chls[chl] << 4) | 0x1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
        for i in range(CANMsg.LEN):
            CANMsg.DATA[i] = can_bytes[i]
        while repeats > 0:
            # Write CAN frame
            self.pcan.Write(self.channel, CANMsg)
            time.sleep(0.1)
            # Read back response
            result = self.pcan.Read(self.channel)
            if result[0] == PCAN_ERROR_OK:
                break
            repeats -= 1
        if result[0] != PCAN_ERROR_OK:
            return data
        # Parse readback and return dictionary of results
        result_data = result[1]
        data['Raw'] = []
        for item in result_data.DATA:
            data['Raw'].append(item)
        # Byte 0 and Byte 1 -> Measured voltage
        data['Measured_Voltage'] = ((result_data.DATA[1] << 8) | result_data.DATA[0]) / 4
        # Byte 2 and 3 Vout control, error fuse, error load, error sense
        data['Vout_Control'] = (((result_data.DATA[3] & 0x1F) << 8) | result_data.DATA[2]) / 4
        data['Error_Fuse'] = (result_data.DATA[3] >> 5) & 0x01
        data['Load_Reduction'] = (result_data.DATA[3] >> 6) & 0x01
        data['Error_Sense'] = result_data.DATA[3] >> 7
        # Byte 4,5,6 current and current type
        data['Current'] = (((result_data.DATA[6] & 0x3F) << 16) | result_data.DATA[5] << 8 | result_data.DATA[4])
        data['Current_Type'] = result_data.DATA[6] >> 6
        # Byte 7, temperature
        data['Temperature'] = result_data.DATA[7]
        return data

    def pcan_init(self):
        if self.pcan_is_init:
            return
        try:
            self.pcan.Initialize(self.channel, self.baudrate, self.hwtype, self.ioport, self.interrupt)
            self.pcan_is_init = True
        except Exception as e:
            if self.logger:
                self.logger.error("Could not initialize pcan: %s" % e)

    def pcan_uninit(self):
        try:
            self.pcan.Uninitialize(self.channel)
            self.pcan_is_init = False
        except Exception as e:
            if self.logger:
                self.logger.error("Could not uninitialize pcan: %s" % e)

    def close(self):
        """
        Close Visa object
        """
        self.pcan_uninit()
        return True
