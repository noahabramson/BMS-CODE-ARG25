from ..ThermalChamber import ThermalChamber


class Delta_Design_9064(ThermalChamber):
    BRAND = ['Delta Design']
    MODEL_NUM = ['9064']

    def __init__(self, device_id, em, logger=None):
        ThermalChamber.__init__(self, device_id, em, logger=logger)
