from ..Supply import Supply


class Hameg_HMP4040(Supply):
    BRAND = ['HAMEG']
    MODEL_NUM = ['HMP4040']

    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)
        self.NORMAL_RANGE = ''
        self.VOLTAGE_MODE = ''
        self.CURRENT_MODE = ''
        self.chls = [1, 2, 3, 4]
        self.gui_kwargs = {'chls': self.chls}

    def voltage(self, chl=1, voltage=None, query=False):
        if not voltage:
            raise ValueError("Must provide voltage")
        if chl not in self.chls:
            raise ValueError("Must provide a valid channel")
        self.inst.write("INST:NSEL %s" % chl)
        self.inst.write("SOUR:VOLT:LEV:IMM:AMPL %s" % voltage)

    def current(self, chl=1, current=None, query=False):
        if not current:
            raise ValueError("Must provide current")
        if chl not in self.chls:
            raise ValueError("Must provide a valid channel")
        self.inst.write("INST:NSEL %s" % chl)
        self.inst.write("SOUR:CURR:LEV:IMM:AMPL %s" % current)

    def output_state(self, chl=1, state=None, query=False):
        if state not in self.OUTPUT_STATES:
            raise ValueError("Must provide an output state")
        if chl not in self.chls:
            raise ValueError("Must provide a valid channel")
        self.inst.write("INST:NSEL %s" % chl)
        self.inst.write("OUTP:STAT %s" % state)

    def range(self, chl=1, range=None, query=False):
        pass

    def mode(self, chl=1, mode=None, query=False):
        pass
