from ..Supply import Supply


class Keithley_2260B(Supply):

    BRAND = ['KEITHLEY INSTRUMENTS INC.']  # Change Brand based on *IDN? here
    MODEL_NUM = ['MODEL 2260B']  # Change Model number based on *IDN? here

    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)
        self.CV_HIGH_SPEED = 'CVHS'
        self.CC_HIGH_SPEED = 'CCHS'
        self.CV_LOW_SPEED = 'CVLS'
        self.CC_LOW_SPEED = 'CCLS'
        self.CV = 'CVHS'
        self.CC = 'CCHS'
        self.MODES = [self.CV_HIGH_SPEED, self.CV_LOW_SPEED, self.CV, self.CC_HIGH_SPEED, self.CC_LOW_SPEED, self.CC]

    def checkprotection_circuit(self):
        """
        Check all the status of protection circuit, if any protection cicuit is tripped
        :return: retrun for the query sent
        """
        set_volt_value = self.inst.query("OUTP:PROT:TRIP?")
        return set_volt_value
