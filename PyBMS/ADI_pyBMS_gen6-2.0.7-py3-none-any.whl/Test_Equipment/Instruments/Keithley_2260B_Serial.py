from ..Supply import Supply
from ..Instrument import Instrument
from Engine.Interfaces.SCon_ASCII import SCon_ASCII

class Keithley_2260B_Serial(Supply):

    BRAND = ['KEITHLEY INSTRUMENTS INC.']  # Change Brand based on *IDN? here
    MODEL_NUM = ['MODEL 2260B']  # Change Model number based on *IDN? here

    def __init__(self, device_id, em, logger=None,  port=None, baud=9600,):
        # Supply.__init__(self, device_id, em, logger=logger)
        Instrument.__init__(self, device_id, em, logger=logger)
        self.CV_HIGH_SPEED = 'CVHS'
        self.CC_HIGH_SPEED = 'CCHS'
        self.CV_LOW_SPEED = 'CVLS'
        self.CC_LOW_SPEED = 'CCLS'
        self.CV = 'CVHS'
        self.CC = 'CCHS'
        self.MODES = [self.CV_HIGH_SPEED, self.CV_LOW_SPEED, self.CV, self.CC_HIGH_SPEED, self.CC_LOW_SPEED, self.CC]
        self.con = SCon_ASCII(port, baud)

    def _get_identification(self):
        """
        Get IEEE identification
        :return: IEEE Identification of instrument
        """
        self.con.write('*IDN?')
        return self.con.read(terminator='\n')

    def _reset(self):
        """
        Send reset command to instrument
        """
        return self.con.write("*RST")

    def _indirect_query(self, query=None):
        self.con.write(query)
        return self.con.read(terminator='\n')

    def _indirect_write(self, msg=None):
        self.con.write(msg)

    # def voltage(self, chl=None, voltage=None, query=False):
    #     return self.execute_command(self.backend_output_buffer, self._voltage,
    #                                 **{'chl': chl, 'voltage': voltage, 'query': query})

    def _voltage(self, chl=None, voltage=None, query=False):
        if query:
            self.con.write('SOUR:VOLT:LEV:IMM:AMPL?')
            return self.con.read(terminator='\n')
        if not voltage:
            raise ValueError('Must provide a voltage to set')
        return self.con.write('SOUR:VOLT:LEV:IMM:AMPL %s' % voltage)

    def _current(self, chl=None, current=None, query=False):
        if query:
            self.con.write('SOUR:CURR:LEV:IMM:AMPL?')
            return self.con.read(terminator='\n')
        if not current:
            raise ValueError('Must provide a current to set')
        return self.con.write('SOUR:CURR:LEV:IMM:AMPL %s' % current)

    def _output_state(self, chl=None, state=None, query=False):
        if query:
            self.con.write('OUTP:STAT?')
            return self.con.read(terminator='\n')
        if not state:
            raise ValueError('Must provide an output state')
        return self.con.write('OUTP:STAT %s' % state)

    def _range(self, chl=None, range=None, query=False):
        pass

    def _mode(self, chl=None, mode=None, query=False):
        if query:
            self.con.write('OUTP:MODE?')
            return self.con.read(terminator='\n')
        if mode not in self.MODES:
            raise ValueError('Mode not valid')
        else:
            self.con.write('OUTP:MODE %s' % mode)

    def _checkprotection_circuit(self):
        """
        Check all the status of protection circuit, if any protection cicuit is tripped
        :return: retrun for the query sent
        """
        self.con.write("OUTP:PROT:TRIP?")
        return self.con.read(terminator='\n')

    def check_protection_circuit(self):
        """
        Check all the status of protection circuit, if any protection cicuit is tripped
        :return: retrun for the query sent
        """
        return self.execute_command(self.backend_output_buffer, self._checkprotection_circuit)


    def close(self):
        """
        Close Visa object
        """
        # self.stop_background_update()
        # self.inst.close()
        return True