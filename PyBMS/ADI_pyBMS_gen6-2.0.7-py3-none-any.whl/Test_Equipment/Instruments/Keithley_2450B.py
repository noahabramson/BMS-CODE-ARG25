from ..SMU import SMU


class Keithley_2450B(SMU):

    BRAND = ['KEITHLEY INSTRUMENTS']  # Change Brand based on *IDN? here
    MODEL_NUM = ['MODEL 2450']  # Change Model number based on *IDN? here

    def __init__(self, device_id, em, logger=None):
        SMU.__init__(self, device_id, em, logger=logger)

    def set_current_out_meas_curr(self, chl=None, current_set=None, reset=False):
        """
        Set the current out and measure the current
        :param chl:
        :param current_set: string current out setting
        :param reset: Bool if instrument needs to reset (True, False)
        :return:
        """
        if reset:
            self.inst.write("*RST")
        self.inst.write(":SOUR:FUNC CURR") #set the output function as current
        self.inst.write(":SOUR:CURR:RANGE 1")  #set the output current limit maximum to 1A with interlock
        self.inst.write("SENS:FUNC CURR") #set sense function
        self.inst.write("SENS:CURR:RANGE 1")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SOUR:CURR " + current_set)  # set the output function as current
        #read
        Function_set  = self.inst.query(":SOUR:CURR?")
        #TODO: if needed add more read functions
        return Function_set

    def set_current_out_meas_volt(self, chl=None, current_set=None, reset=False):
        """
        Set the current out and measure the current
        :param chl:
        :param current_set: string current out setting
        :param reset: Bool if instrument needs to reset (True, False)
        :return:
        """
        if reset:
            self.inst.write("*RST")

        self.inst.write(":SOUR:FUNC CURR") #set the output function as current
        # self.inst.write(":SOUR:CURR:RANGE 1")  #set the output current limit maximum to 1A with interlock
        # self.inst.write(":SOUR:CURR:VLIM .5") #voltage limit for protection

        self.a = "\"VOLT\""
        self.b = ":SENS:FUNC "
        self.inst.write(self.b + self.a) #set sense function
        self.inst.write(":SENS:VOLT:RANGE 2")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SENS:VOLT:RSEN ON")
        self.inst.write(":SOUR:CURR " + str(current_set))  # set the output function as current
        #read
        #Function_set  = self.inst.query(":SOUR:CURR?")
        #read_volt = self.inst.query(":READ?")
        #TODO: if needed add more read functions
        #return read_volt

    def set_current_out_meas_volt_microcode(self, chl=None, current_set=None, reset=False):
        """
        Set the current out and measure the current
        :param chl:
        :param current_set: string current out setting
        :param reset: Bool if instrument needs to reset (True, False)
        :return:
        """

            # self.inst.write("*RST\n")
            # self.inst.write("*CLS\n")

        self.microcode = (   "reset()"
                             "status.clear()"
                             "smu.source.func = smu.FUNC_DC_CURRENT"
                             "smu.source.vlimit.level = 2"
                             "smu.source.range = 1"
                             "smu.source.level = %f"
                             "smu.source.output = smu.ON"
                             "smu.measure.func = smu.FUNC_DC_VOLTAGE"
                             "smu.measure.terminals = smu.TERMINALS_FRONT"
                             "smu.measure.nplc = 1"
                             "smu.measure.count = 1"
                             "smu.measure.autorange = smu.ON"
                             "print(smu.measure.read())"
                             "smu.source.output = smu.OFF"
                         ) % (10e-3)

        buf = self.inst.ask(self.microcode)
        print(buf)

    def read_measurement(self):
        """
        Returns the last measured value
        :return: string last measured value
        """
        Last_measurement_value = self.inst.query("READ?")
        return Last_measurement_value

    def set_voltage_out_meas_curr(self, chl=None, voltage_set=None, voltage_range=None, reset=False):
        """
        set voltage output and measure current
        :param chl:
        :param voltage_set: string voltage to set
        :param voltage_range: string voltage range to set
        :param reset: if reset required before the settings
        :return:
        """
        if reset:
            self.inst.write("*RST")
        self.inst.write(":SOUR:FUNC \"VOLT\"")  # set the output function as volt
        self.inst.write(":SOUR:VOLT:RANGE 200")  # set the output current limit maximum to 1A with interlock
        self.inst.write("SOUR:VOLT:LEV:AMPL? MAX")  # set sense function
        self.inst.write(":SOUR:VOLT " + str(voltage_set))  # set the output function as volt
        self.inst.write(":SOUR:VOLT:ILIM 0.1")  # set the output function as volt
        self.inst.write(":FUNC \"CURR\"")  # set the output function as volt
        self.inst.write(":SENS:CURR:RANG 0.1")  # set the output function as volt
        # read
        Function_set = self.inst.query(":SOUR:VOLT?")
        # TODO: if needed add more read functions
        #TODO: Add the read
        return Function_set

    def set_voltage_out_meas_volt(self, chl=None, voltage_set=None, voltage_range=None, reset=False, ilimit=None):
        """
        Set voltage output and measure voltage
        :param chl:
        :param voltage_set: string voltage to set
        :param voltage_range: string voltage range to set
        :param reset: If reset required before the settings
        :return:
        """
        if reset:
            self.inst.write("*RST")
        self.inst.write(":SOUR:FUNC VOLT")  # set the output function as volt
        self.inst.write(":SOUR:VOLT:RANGE " + str(voltage_range))  # set the output voltage range
        self.inst.write(":SOUR:VOLT:ILIM " + str(ilimit))  # set the output voltage range
        self.inst.write("SENS:FUNC \"VOLT\"") #set sense function
        self.inst.write("SENS:VOLT:RANGE 20")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SOUR:VOLT " + voltage_set)  # set the output function as volt
        # TODO: Add the read
        return True

    def set_Sweep_cur_meas_curr(self, chl=None, current_range=None, reset=False, sweep_start=None, sweep_end=None, step_size=None, source_delay=None):
        """
        Sweep current and take the current measurement
        :param chl:
        :param current_range: range for the current output
        :param reset: if reset is required before sweep
        :param sweep_start: start point for sweep
        :param sweep_end: end point for sweep
        :param step_size: Step size for sweep
        :param source_delay: Delay in ms between each sweep
        :return:
        """
        if reset:
            self.inst.write("*RST")
        self.inst.write(":SOUR:FUNC CURR")  # set the output function as volt
        self.inst.write(":SOUR:CURR:RANGE " + str(current_range))  # set the output current limit maximum to 1A with interlock
        self.inst.write("SENS:FUNC CURR") #set sense function
        self.inst.write("SENS:CURR:RANGE 1")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SOUR:SWE:CURR:LIN:STEP " + str(sweep_start) + ", " + str(sweep_end) + ", " + str(step_size) + ", " + str(source_delay) + ', ' + "1" + "," + "FIXED")
        #Set up a linear step sweep that sweeps from sweep_Start to sweepend in septsize increments with a source delay, a sweep count of 1, and a fixed source range.
        #for ex: SOUR:SWE:CURR:LIN:STEP -1.05, 1.05, .25, 10e-3, 1,FIXED
        self.inst.write("INIT")  #Initialize the sweep
        # TODO: Add the read
        return True

    def get_average_value_from_buffer(self, buffer_name= "defbuffer1"):
        average_value= self.inst.query("TRACe:STAT:AVERage? \""+str(buffer_name)+"\"")
        return average_value

    def set_current_moving_average_config(self, chl=None, current_set=None, reset=False, No_of_readings=0):
        return self.execute_command(self.backend_output_buffer, self._set_current_moving_average_config,
                                    **{'chl': chl, 'current_set': current_set, 'reset': reset,
                                       'No_of_readings': No_of_readings})

    def _set_current_moving_average_config(self, chl=None, current_set=None, reset=False, trigger=False,
                                               No_of_readings=0):
        """
              Config the burst read mode
              :param chl:
              :param current_set: string current out setting
              :param reset: Bool if instrument needs to reset (True, False)
              :return:
              """
        if reset:
            self.inst.write("*RST")
        AVERAGE_BUFFER = "TRAC:MAKE \"averageBuffer\", "+str(No_of_readings)
        # self.inst.write(AVERAGE_BUFFER)
        self.inst.write(":SOUR:FUNC CURR")  # set the output function as current
        self.inst.write(":SOUR:CURR:RANGE 1")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SOUR:CURR:VLIM .5")  # voltage limit for protection
        self.inst.write(":SOUR:CURR " + str(current_set))  # set the output function as current

        self.inst.write(":SENS:FUNC \"VOLT\"")  # set sense function
        self.inst.write(":SENS:VOLT:RANGE 2")  # set the output current limit maximum to 1A with interlock
        self.inst.write(":SENS:VOLT:RSEN ON")
        self.inst.write(":SENS:VOLT:NPLC 10")

        self.inst.write(":SENS:AZER:ONCE")
        self.inst.write("SENS:VOLT:AZER OFF") # setting AUTO ZERO OFF and only once
        self.inst.write("SENS:VOLT:AVER:COUNT "+str(No_of_readings)) # average value count
        self.inst.write("SENS:VOLT:AVER:TCON MOV")
        self.inst.write("SENS:VOLT:AVER ON")


    def read_moving_average_data_from_buffer(self, No_of_readings=0):
        present_reading = self.inst.query("TRACe:ACT? \"averageBuffer\"")
        while int(self.inst.query("TRACe:ACT? \"averageBuffer\"")) < No_of_readings:
            status = 1
        read_buffer = self.inst.query("TRAC:DATA? 1, " + str(No_of_readings) + ", \"averageBuffer\", READ, SOUR, REL")  # reading from default buffer 1
        self.inst.write("TRAC:CLE \"averageBuffer\"")  # clear all settings and readings of default buffer 1
        return  read_buffer

    def read_moving_average_data(self,No_of_readings=0):
        """
        Returns the last measured value
        :return: string last measured value
        """
        present_reading = self.inst.query("TRACe:ACT? \"averageBuffer\"")
        Last_measurement_value = self.inst.query("READ? \"averageBuffer\", READ, SOUR, REL, FRAC, SEC")
        # Last_measurement_value = self.inst.query("TRAC:DATA? 1, " + str(No_of_readings) + ", \"averageBuffer\", READ, SOUR, REL")
        self.inst.write("TRAC:CLE \"averageBuffer\"")  # clear all settings and readings of default buffer 1
        return Last_measurement_value