from ..DMM import DMM


class Keithley_2700(DMM):
    BRAND = ['KEITHLEY INSTRUMENTS INC.']
    MODEL_NUM = ['MODEL 2700']

    def __init__(self, device_id, em, logger=None):
        DMM.__init__(self, device_id, em, logger=logger)

    def measure_capacitance(self, range=None, resolution=None):
        raise ValueError('This DMM cannot measure capacitance')

    def measure_continuity(self):
        result = self.inst.query('MEAS:CONT?').split(',')[0]
        if 'OHM' in result:
            return float(result[:-3]) < 5
        return float(result) < 5

    def measure_ac_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:AC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:CURR:AC?').split(',')[0][:-3])

    def measure_dc_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:DC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:CURR:DC?').split(',')[0][:-3])

    def measure_diode(self, range=None, resolution=None):
        raise ValueError('This DMM cannot check for diode connectivity')

    def measure_frequency(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FREQ? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:FREQ?').split(',')[0][:-2])

    def measure_resistance_4wire(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FRES? %s, %s' % (range, resolution)).split(',')[0][:-5])
        return float(self.inst.query('MEAS:FRES?').split(',')[0][:-5])

    def measure_period(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:PER? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:PER?').split(',')[0][:-3])

    def measure_resistance(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:RES? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:RES?').split(',')[0][:-3])

    def measure_ac_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:AC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:VOLT:AC?').split(',')[0][:-3])

    def measure_dc_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:DC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:VOLT:DC?').split(',')[0][:-3])

    def one_shot_measure(self, return_all=False):
        if return_all:
            return self.inst.query('READ?').split(',')
        return float(self.inst.query('READ?').split(',')[0][:-3])

    def config_immediate_trigger(self,count=0,category='FUNC', range=0.100):
        self.inst.write("*RST")
        self.inst.write("TRAC:CLE")
        self.inst.write("INIT:CONT OFF")
        self.inst.write("SENS:"+str(category)+" VOLT")
        self.inst.write("SENS:"+str(category)+":DC:RANG:AUTO OFF")
        self.inst.write("SENS:"+str(category)+":DC:RANG " + str(range))
        self.inst.write("TRIG:DEL:AUTO OFF")
        self.inst.write("SENS:"+str(category)+":DC:NPLC 5") # Highest NPLC , Slow reading , accurate measurement
        self.inst.write("SYST:AZER:STAT OFF")
        self.inst.write("SENS:"+str(category)+":DC:AVER:STAT OFF")
        self.inst.write("SAMP:COUN " + str(count))
        self.inst.write("TRIG:COUN 1")
        self.inst.write("TRIG:SOUR? IMM")
    def read_immediate_trigger_data(self):
        data = self.inst.query("TRACe:DATA?")
        self.inst.write("TRAC:CLE")
        return  data
    def initiate_immediate_trigger(self):
        self.inst.write("INIT")
    def config_DMM_accurate_meas(self,category='FUNC', range=0.100):
        self.inst.write("*RST")
        self.inst.write("TRAC:CLE")
        self.inst.write("SENS:" + str(category) + " VOLT")
        self.inst.write("SENS:" + str(category) + ":DC:RANG:AUTO OFF") # turn off auto range
        self.inst.write("SENS:" + str(category) + ":DC:RANG " + str(range)) # set range as specified
        self.inst.write("SENS:" + str(category) + ":DC:NPLC 5")  # Highest NPLC , Slow reading , accurate measurement
        self.inst.write("SYST:AZER:STAT OFF") # turn off Auto Zero
        self.inst.write("SENS:" + str(category) + ":DC:AVER:STAT OFF")
