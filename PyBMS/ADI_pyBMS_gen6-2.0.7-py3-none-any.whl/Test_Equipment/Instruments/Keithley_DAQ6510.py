from ..DMM import DMM


class Keithley_DAQ6510(DMM):
    BRAND = ['KEITHLEY INSTRUMENTS INC.', 'KEITHLEY INSTRUMENTS']
    MODEL_NUM = ['MODEL DAQ6510']

    def __init__(self, device_id, em, logger=None):
        DMM.__init__(self, device_id, em, logger=logger)

    def measure_capacitance(self, range=None, resolution=None):
        raise ValueError('This DMM cannot measure capacitance')

    def measure_continuity(self):
        result = self.inst.query('MEAS:CONT?').split(',')[0]
        if 'OHM' in result:
            return float(result[:-3]) < 5
        return float(result) < 5

    def measure_ac_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:AC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:CURR:AC?'))

    def measure_dc_current(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:CURR:DC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:CURR:DC?'))

    def measure_diode(self, range=None, resolution=None):
        raise ValueError('This DMM cannot check for diode connectivity')

    def measure_frequency(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FREQ? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:FREQ?'))

    def measure_resistance_4wire(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:FRES? %s, %s' % (range, resolution)).split(',')[0][:-5])
        return float(self.inst.query('MEAS:FRES?'))

    def measure_period(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:PER? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:PER?'))

    def measure_resistance(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:RES? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:RES?'))

    def measure_ac_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:AC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:VOLT:AC?'))

    def measure_dc_voltage(self, range=None, resolution=None):
        if range and resolution:
            return float(self.inst.query('MEAS:VOLT:DC? %s, %s' % (range, resolution)).split(',')[0][:-3])
        return float(self.inst.query('MEAS:VOLT:DC?'))

    def one_shot_measure(self, return_all=False):
        return float(self.inst.query('MEAS:VOLT:DC?'))

    def measure_channel(self, chl_list=None, nplc=1, scan_count=1):
        if not chl_list:
            raise ValueError("Must provide a channel list to measure channels")

        amount = len(chl_list) * scan_count
        self.inst.write('*RST') # Reset relay board to prevent shorts
        self.inst.write(':ROUT:SCAN:BUFF "defbuffer1"') # Send data to default buffer
        self.inst.write("FUNC  'VOLT:DC',(@%s:%s)" % (str(min(chl_list)), str(max(chl_list)))) # measure voltage
        self.inst.write('VOLT:DC:RANG:AUTO ON,(@%s:%s)' % (str(min(chl_list)), str(max(chl_list)))) # auto range
        self.inst.write('VOLT:DC:NPLC %s, (@%s:%s)' % (str(nplc), str(min(chl_list)), str(max(chl_list)))) # nplc
        self.inst.write('VOLT:DC:AZER ON, (@%s:%s)' % (str(min(chl_list)), str(max(chl_list)))) # auto zero on
        self.inst.write('ROUT:SCAN (@%s:%s)' % (str(min(chl_list)), str(max(chl_list)))) # Scan
        self.inst.write('ROUT:SCAN:COUN:SCAN %s' % scan_count) # Amount of rounds
        self.inst.write('INIT') # Init scan and send data to defbuffer1
        self.inst.write('*WAI')
        temp = self.inst.query('TRAC:DATA? 1, %s, "defbuffer1", READ, CHAN' % str(amount)).split(',') # Read buffer
        self.inst.write('*RST')
        i = 0
        data = {}
        while(i < len(temp)): # Write data with channel to data dict
            if(i % 2 == 0):
                data[int(temp[i+1].replace("\n",""))] = float(temp[i].replace("\n",""))
            i = i +1
        return data