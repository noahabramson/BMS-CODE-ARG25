from ..DMM import DMM


class Keysight_34461A(DMM):
    BRAND = ['Keysight Technologies']
    MODEL_NUM = ['34461A']

    def __init__(self, device_id, em, logger=None):
        DMM.__init__(self, device_id, em, logger=logger)

    def measure_capacitance(self, range=None, resolution=None):
        raise ValueError('This DMM cannot measure capacitance')
