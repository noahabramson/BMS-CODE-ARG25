from ..Oscilloscope import Oscilloscope


class Keysight_MSOX3024A(Oscilloscope):
    BRAND = ['AGILENT TECHNOLOGIES']
    MODEL_NUM = ['MSO-X 3024A']

    def __init__(self, device_id, em, logger=None):
        Oscilloscope.__init__(self, device_id, em, logger=logger)
