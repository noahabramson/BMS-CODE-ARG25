from ..Load import Load


class Kikusui_PLZ405(Load):
    BRAND = ['Kikusui']
    MODEL_NUM = ['PLZ405']

    def __init__(self, device_id, em, logger=None):
        Load.__init__(self, device_id, em, logger=logger)
        self.OUTPUT_ON = 'ON'
        self.OUTPUT_OFF = 'OFF'

    def output_state(self, state=None, query=False):
        if query:
            return None
        if state not in [self.OUTPUT_ON, self.OUTPUT_OFF]:
            raise ValueError('Must provide a valid state for output')
        else:
            self.inst.write(f'OUTPUT {state}')

    def set_frequency(self, frequency, query=False):
        if query:
            return None
        else:
            self.inst.write(f'CURRent:PULSe:FREQuency {round(frequency,5)}')

    def set_mode(self, mode, query=False):
        if query:
            return None
        else:
            self.inst.write(f'FUNC:MODE {mode}')

    def set_level(self, level, query=False):
        if query:
            return None
        else:
            self.inst.write(f'CURRent:PULSe:LEVel {level}')

    def set_current(self, current, query=False):
        if query:
            return None
        else:
            self.inst.write(f'CURR {current}')

    def set_state(self, state):
        self.inst.write(f'INPUT {state}')