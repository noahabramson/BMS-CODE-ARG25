from ..Supply import Supply


class Lambda_GENH600_1_3(Supply):
    BRAND = ['LAMBDA']
    MODEL_NUM = ['GENH600-1.3-IEMD']

    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)
        self.NORMAL_RANGE = ''
        self.VOLTAGE_MODE = ''
        self.CURRENT_MODE = ''
