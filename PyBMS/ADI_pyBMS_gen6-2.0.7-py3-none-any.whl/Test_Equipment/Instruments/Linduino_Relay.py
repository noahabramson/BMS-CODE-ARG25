from ..Instrument import Instrument
from Interfaces.SCon_ASCII import SCon_ASCII
import time


class Linduino_Relay(Instrument):
    INST_TYPE = ['RelayBoard']

    def __init__(self, device_id, em, logger=None, port=None, baud=115200, chls=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        if not port:
            raise ValueError('No Comport given, cannot talk to Relay Control')
        self.con = SCon_ASCII(port, baud)
        if chls:
            self.chls = chls
        else:
            self.chls = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
                         27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
        self.gui = 'relay_board.html'

    def open_relay(self, chl=None):
        if chl not in self.chls:
            raise ValueError('Relay channel does not exist')
        self.con.write('open %s' % chl)
        time.sleep(0.01)

    def close_relay(self, chl=None):
        if chl not in self.chls:
            raise ValueError('Relay channel does not exist')
        self.con.write('close %s' % chl)
        time.sleep(0.01)

    def open_all_relays(self):
        self.con.write('all open')

    def close_all_relays(self):
        self.con.write('all closed')

    def float_all_relays(self):
        for i in range(1, 21):
            self.open_relay(i)
        for i in range(21, 41):
            self.close_relay(i)

    def close_cells(self):
        for i in range(1, 21):
            self.close_relay(i)

    def close_hv(self):
        for i in range(21, 41):
            self.open_relay(i)

    def close(self):
        self.con.close()
