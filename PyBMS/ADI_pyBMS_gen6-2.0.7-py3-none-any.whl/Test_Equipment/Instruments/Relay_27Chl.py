from ..Instrument import Instrument
from Interfaces.SCon_ASCII import SCon_ASCII
import time


class Relay_27Chl(Instrument):
    INST_TYPE = ['RelayBoard']

    def __init__(self, device_id, em, logger=None, port=None, baud=115200, chls=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        if not port:
            raise ValueError('No Comport given, cannot talk to Relay Control')
        self.con = SCon_ASCII(port, baud)
        self.chls = list(range(1,82))
        self.chl_decode = [
            # Cells
            [1, 28],
            [2, 29],
            [3, 30],
            [4, 31],
            [5, 32],
            [6, 33],
            [7, 34],
            [8, 35],
            [9, 36],
            [10, 37],
            [11, 38],
            [12, 39],
            [13, 40],
            [14, 41],
            [15, 42],
            [16, 43],
            [17, 44],
            [18, 45],
            [19, 46],
            [20, 47],
            [21, 48],
            [22, 49],
            [23, 50],
            [24, 51],
            [25, 52],
            [26, 53],
            [27, 54],
            # Input 1
            [28, 8],
            [29, 7],
            [30, 6],
            [31, 5],
            [32, 4],
            [33, 3],
            [34, 2],
            [35, 1],
            [36, 9],
            [37, 10],
            [38, 11],
            [39, 12],
            [40, 13],
            [41, 14],
            [42, 15],
            [43, 16],
            [44, 24],
            [45, 23],
            [46, 22],
            [47, 21],
            [48, 20],
            [49, 19],
            [50, 18],
            [51, 17],
            [52, 25],
            [53, 26],
            [54, 27],
            # Input 2
            [55, 55],
            [56, 56],
            [57, 57],
            [58, 58],
            [59, 59],
            [60, 60],
            [61, 61],
            [62, 62],
            [63, 63],
            [64, 64],
            [65, 65],
            [66, 66],
            [67, 67],
            [68, 68],
            [69, 69],
            [70, 70],
            [71, 71],
            [72, 72],
            [73, 73],
            [74, 74],
            [75, 75],
            [76, 76],
            [77, 77],
            [78, 78],
            [79, 79],
            [80, 80],
            [81, 81],
        ]

        self.gui = 'hv_relay_board.html'
        self.init()

    def open_relay(self, chl=None):
        if chl not in self.chls:
            raise ValueError('Relay channel does not exist')
        self.con.write('open %s' % self.chl_decode[chl-1][1])
        time.sleep(0.01)

    def close_relay(self, chl=None):
        if chl not in self.chls:
            raise ValueError('Relay channel does not exist')
        self.con.write('close %s' % self.chl_decode[chl-1][1])
        time.sleep(0.01)

    def open_all_relays(self):
        self.con.write('all open')

    def close_all_relays(self):
        self.con.write('all closed')

    def float_all_relays(self):
        self.open_all_relays()

    def close_cells(self):
        for i in range(1, 28):
            self.close_relay(i)

    def close_hv(self):
        for i in range(55, 82):
            self.close_relay(i)

    def init(self):
        self.float_all_relays()
        self.con.write("init")
        time.sleep(0.5)
        self.float_all_relays()

    def close(self):
        self.con.close()
