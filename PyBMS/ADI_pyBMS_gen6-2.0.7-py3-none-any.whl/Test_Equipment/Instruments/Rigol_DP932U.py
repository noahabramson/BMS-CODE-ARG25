from ..Supply import Supply

"""
This powersupply is used as a "beuk voeding". It is not a precision power supply. Just a power supply to power boards
and ic's that happens to be remote controlled.
"""

class Rigol_DP932U(Supply):
    BRAND = ['Rigol Technologies']
    MODEL_NUM = ['DP932U']

    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)

    def measure_power(self, chl=None):
        if chl is not None:
            self._set_channel(channel=chl)

        return float(self.inst.query('MEAS:POWE?'))

    def oc_shutdown_state(self, chl=None, state=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('OUTP:OCP:STAT?')

        if not state:
            raise ValueError('Must provide an output state')
        return self.inst.write('OUTP:OCP:STAT %s' % state)

    def oc_shutdown_value(self, chl=None, val=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('OUTP:OCP:VAL?')

        if not val:
            raise ValueError('Must provide an output state')
        return self.inst.write('OUTP:OCP:VAL %d' % val)

    def get_oc_event(self, chl=None):
        if chl is not None:
            self._set_channel(channel=chl)

        return bool(self.inst.query('OUTP:OCP:ALAR?'))

    def clear_oc_event(self, chl=None):
        """
        :param chl: 1,2 or 3
        Clears the oc event and sets flag back to zero
        """
        if chl is not None:
            self._set_channel(channel=chl)

        return self.write.query('OUTP:OCP:CLE')

    def pair_channels(self, state=None, query=False):
        """
        :param state: 'PAR', 'SER' or 'OFF'. Sets channels 1 and 2 in parallel or series
        :param query: Get the state of the pairing
        :return: returns the state of the pairing
        """
        if query:
            return self.inst.query('OUTP:PAIR:?')

        if not state:
            raise ValueError('Must provide an output state of either PAR, SER or OFF')
        return self.inst.write('OUTP:PAIR %s' % state)

    def remote_lock(self, state=None, query=False):
        """
        :param state: 'ON' or 'OFF'. If on, the keys are locked on the device.
        :param query: Get the state the remote lock
        :return: returns the state of the pairing
        """
        if query:
            return self.inst.query('SYST:KLOC:STAT?')

        if not state:
            raise ValueError('Must provide an output state of either ON or OFF')
        return self.inst.write('SYST:KLOC:STAT %s' % state)