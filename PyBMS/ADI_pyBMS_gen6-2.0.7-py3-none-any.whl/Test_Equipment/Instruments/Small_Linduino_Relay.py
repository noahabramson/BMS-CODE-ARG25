from ..Instrument import Instrument
from Interfaces.SCon_ASCII import SCon_ASCII
import time


class Small_Linduino_Relay(Instrument):
    INST_TYPE = ['RelayBoard']

    def __init__(self, device_id, em, logger=None, port=None, baud=9600, chls=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        if not port:
            raise ValueError('No Comport given, cannot talk to Relay Control')
        self.con = SCon_ASCII(port, baud)
        if chls:
            self.chls = chls
        else:
            self.chls = [1, 2, 3, 4, 5, 6, 7, 8]
        self.gui = 'relay_board.html'

    def close_relay(self, chl=None):
        if chl not in self.chls:
            raise ValueError('Relay channel does not exist')
        self.con.write('%s' % chl)
        time.sleep(0.2)

    def open_all_relays(self):
        self.con.write('0')
        time.sleep(0.2)

    def close(self):
        self.con.close()
