from ..SignalGenerator import TektronixSignalGenerator


class Tektronix_AFG3101(TektronixSignalGenerator):
    MODEL_NUM = ['AFG3101']

    def __init__(self, device_id, em, logger=None):
        TektronixSignalGenerator.__init__(self, device_id, em, logger=logger)
