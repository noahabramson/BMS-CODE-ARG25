from ..Instrument import Instrument
from Interfaces.SCon import SCon


class Teseq_RF_Switch(Instrument):
    def __init__(self, device_id, em, logger=None, port=None, baud=9600, chls=None):
        Instrument.__init__(self, device_id, em, logger=logger)
        if not port:
            raise ValueError('No Comport given, cannot talk to RF switch')
        self.con = SCon(str(port), baud)
        if chls:
            self.chls = chls
        else:
            self.chls = {'A': ['1', '2', '3', '4', '5', '6'], 'B': ['0', '2'], 'C': ['0', '2'], 'D': ['0', '2']}
        for chl in self.chls:
            self.get_switch_positions_available(chl)

    def get_switch_positions_available(self, chl):
        if chl not in self.chls:
            raise ValueError('Channel does not exist')
        self.con.write('GET:POS %s\r' % chl)
        pos = self.con.read().split('to')
        return {'chls': pos[0], 'outputs': pos[1]}

    def set_switch_pos(self, chl, pos):
        if chl not in self.chls:
            raise ValueError('Channel does not exist')
        if pos not in self.chls[chl]:
            raise ValueError('Position does not exist for this channel')
        self.con.write('SET:POS %s_%s\r' % (chl, pos))
