from ..Supply import Supply


class Toellner_TOE8952(Supply):
    BRAND = ['TOELLNER']
    MODEL_NUM = ['TOE8952-60']

    def __init__(self, device_id, em, logger=None):
        super().__init__(device_id, em, logger=logger)
        self.chls = [1, 2]