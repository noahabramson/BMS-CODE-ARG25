from ..Supply import Supply


class Yokogawa_7651(Supply):
    def __init__(self, device_id, em, logger=None):
        Supply.__init__(self, device_id, em, logger=logger)
        self.VOLTAGE_MODE = 'F1'
        self.CURRENT_MODE = 'F5'
        self.MODES = [self.VOLTAGE_MODE, self.CURRENT_MODE]
        self.NORMAL_RANGE = 'R6'
        self.OUTPUT_ON = '1'
        self.OUTPUT_OFF = '0'
        self.OUTPUT_STATES = [self.OUTPUT_ON, self.OUTPUT_OFF]

    def get_identification(self):
        """
        Get IEEE identification
        :return: IEEE Identification of instrument
        """
        return None

    def reset(self):
        """
        Send reset command to instrument
        """
        return self.inst.write("RC")

    def voltage(self, chl=None, voltage=None, query=False):
        if voltage == None:
            raise ValueError("Must provide voltage")
        self.inst.write("S%s" % voltage)
        self.inst.write("E")

    def current(self, chl=None, current=None, query=False):
        if not current:
            raise ValueError("Must provide current")
        self.inst.write("S%s" % current)
        self.inst.write("E")

    def output_state(self, chl=None, state=None, query=False):
        if state not in self.OUTPUT_STATES:
            raise ValueError("Must provide an output state")
        self.inst.write('O%s' % state)
        self.inst.write('E')

    def range(self, chl=None, range=None, query=False):
        if not range:
            raise ValueError("Must provide range")
        self.inst.write(range)
        self.inst.write("E")

    def mode(self, chl=None, mode=None, query=False):
        if mode not in self.MODES:
            raise ValueError("Provided mode not available for this supply")
        self.inst.write(mode)
        self.inst.write('E')
