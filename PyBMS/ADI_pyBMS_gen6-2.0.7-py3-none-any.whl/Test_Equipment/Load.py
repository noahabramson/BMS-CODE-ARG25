from Test_Equipment.VisaInstrument import VisaInstrument


class Load(VisaInstrument):
    """
    Load instrument type

    :param device_id: Visa device identification of device.
    """
    INST_TYPE = ['Load']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
