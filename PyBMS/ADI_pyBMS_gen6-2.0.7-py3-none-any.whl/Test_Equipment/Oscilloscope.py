from Test_Equipment.VisaInstrument import VisaInstrument
import time
import numpy as np


class Oscilloscope(VisaInstrument):
    """
    Abstract Oscilloscope class to create a generic oscilloscope interface.

    :param device_id: Visa device ID
    """
    INST_TYPE = ['Oscilloscope']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.analog_chls = [1, 2, 3, 4]
        self.offset_skew = True
        self.AC_COUPLED = 'AC'
        self.DC_COUPLED = 'DC'
        self.chl_coupling_option_list = [self.AC_COUPLED, self.DC_COUPLED]
        self.DISPLAY_ON = 'ON'
        self.DISPLAY_OFF = 'OFF'
        self.chl_display_option_list = [self.DISPLAY_ON, self.DISPLAY_OFF]
        self.IMP_50 = 'FIFT'
        self.IMP_1MEG = 'ONEM'
        self.chl_impedance_option_list = [self.IMP_50, self.IMP_1MEG]
        self.ADD_OPER = 'ADD'
        self.SUBTRACT_OPER = 'SUBT'
        self.MULTIPLY_OPER = 'MULT'
        self.INTEGRATE_OPER = 'INT'
        self.DIFFERENTIATE_OPER = 'DIFF'
        self.FFT_OPER = 'FFT'
        self.SQRT_OPER = 'SQRT'
        self.function_operations = [self.ADD_OPER, self.SUBTRACT_OPER, self.MULTIPLY_OPER, self.INTEGRATE_OPER,
                                    self.DIFFERENTIATE_OPER, self.FFT_OPER, self.SQRT_OPER]
        self.TRIGGER_SWEEP_AUTO = 'AUTO'
        self.TRIGGER_SWEEP_NORMAL = 'NORM'
        self.trigger_sweep_modes = [self.TRIGGER_SWEEP_AUTO, self.TRIGGER_SWEEP_NORMAL]
        self.TRIGGER_MODE_EDGE = 'EDGE'
        self.TRIGGER_MODE_PULSE = 'GLIT'
        self.TRIGGER_MODE_PATTERN = 'PATT'
        self.TRIGGER_MODE_TV = 'TV'
        self.TRIGGER_MODE_DELAY = 'DEL'
        self.TRIGGER_MODE_EBURST = 'EBUR'
        self.TRIGGER_MODE_OR = 'OR'
        self.TRIGGER_MODE_RUNT = 'RUNT'
        self.TRIGGER_MODE_SHOLD = 'SHOL'
        self.TRIGGER_MODE_TRANSITION = 'TRAN'
        self.TRIGGER_MODE_SBUS1 = 'SBUS1'
        self.TRIGGER_MODE_SBUS2 = 'SBUS2'
        self.TRIGGER_MODE_USB = 'USB'
        self.trigger_modes = [self.TRIGGER_MODE_EDGE, self.TRIGGER_MODE_PULSE, self.TRIGGER_MODE_PATTERN,
                              self.TRIGGER_MODE_TV, self.TRIGGER_MODE_DELAY, self.TRIGGER_MODE_EBURST,
                              self.TRIGGER_MODE_OR, self.TRIGGER_MODE_RUNT, self.TRIGGER_MODE_SHOLD,
                              self.TRIGGER_MODE_TRANSITION, self.TRIGGER_MODE_SBUS1, self.TRIGGER_MODE_SBUS2,
                              self.TRIGGER_MODE_USB]
        self.ANALOG_CHL_TYPE = 'CHAN'
        self.FUNCTION_CHL_TYPE = ''
        self.DIGITAL_CHL_TYPE = 'DIG'
        self.MATH_CHL_TYPE = ''
        self.MATH_CHL = 'MATH'
        self.FUNC_CHL = 'FUNC'
        self.channel_types = [self.ANALOG_CHL_TYPE, self.FUNCTION_CHL_TYPE, self.DIGITAL_CHL_TYPE, self.MATH_CHL_TYPE]
        self.TRIGGER_PULSE_POLARITY_POSITIVE = 'POS'
        self.TRIGGER_PULSE_POLARITY_NEGATIVE = 'NEG'
        self.trigger_pulse_polarities = [self.TRIGGER_PULSE_POLARITY_POSITIVE, self.TRIGGER_PULSE_POLARITY_NEGATIVE]
        self.TRIGGER_PULSE_QUALIFIER_GREATER = 'GRE'
        self.TRIGGER_PULSE_QUALIFIER_LESS = 'LESS'
        self.TRIGGER_PULSE_QUALIFIER_RANGE = 'RANG'
        self.trigger_pulse_qualifiers = [self.TRIGGER_PULSE_QUALIFIER_GREATER, self.TRIGGER_PULSE_QUALIFIER_LESS,
                                        self.TRIGGER_PULSE_QUALIFIER_RANGE]
        # self.gui = 'oscilloscope.html'

    def time_range(self, range=None, query=False):
        if query:
            return self.inst.query('TIM:RANG?')
        self.inst.write('TIM:RANG %s' % range)

    def chl_vert_range(self, chl=None, range=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:RANG?' % chl)
        self.inst.write('CHAN%s:RANG %s' % (chl, range))

    def chl_bandwidth(self, chl=None, bandwidth=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:BAND?' % chl)
        self.inst.write('CHAN%s:BAND %s' % (chl, bandwidth))

    def chl_bandwidth_limit(self, chl=None, bandwidth=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:BWL?' % chl)
        self.inst.write('CHAN%s:BWL %s' % (chl, bandwidth))

    def chl_coupling(self, chl=None, coupling=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:COUP?' % chl)
        if coupling not in self.chl_coupling_option_list:
            raise ValueError('Coupling type not valid for this scope')
        self.inst.write('CHAN%s:COUP %s' % (chl, coupling))

    def chl_display(self, chl=None, display=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:DISP?' % chl)
        if display not in self.chl_display_option_list:
            raise ValueError('Invalid channel display option')
        self.inst.write('CHAN%s:DISP %s' % (chl, display))

    def function_display(self, display=None, query=False):
        if query:
            return self.inst.query('FUNC:DISP?')
        if display not in self.chl_display_option_list:
            raise ValueError('Invalid channel display option')
        self.inst.write('FUNC:DISP %s' % display)

    def function_source1(self, source=None, query=False):
        if query:
            return self.inst.query('FUNC:SOUR1?')
        if not source:
            raise ValueError('Must provide a scope channel')
        if source not in self.analog_chls:
            raise ValueError('Analog channel not found')
        self.inst.write('FUNC:SOUR1 CHAN%s' % source)

    def function_source2(self, source=None, query=False):
        if query:
            return self.inst.query('FUNC:SOUR2?')
        if not source:
            raise ValueError('Must provide a scope channel')
        if source not in self.analog_chls:
            raise ValueError('Analog channel not found')
        self.inst.write('FUNC:SOUR2 CHAN%s' % source)

    def function_operation(self, operation=None, query=False):
        if query:
            return self.inst.query('FUNC:OPER?')
        if operation not in self.function_operations:
            raise ValueError('Must provide a valid function operation')
        self.inst.write('FUNC:OPER %s' % operation)

    def function_scale(self, scale=None, query=False):
        if query:
            return self.inst.query('FUNC:SCAL?')
        self.inst.write('FUNC:SCAL %s' % scale)

    def chl_impedance(self, chl=None, impedance=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:IMP?' % chl)
        if impedance not in self.chl_impedance_option_list:
            raise ValueError('Invalid channel impedance option')
        self.inst.write('CHAN%s:IMP %s' % (chl, impedance))

    def chl_attenuation(self, chl=None, attenuation=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:PROB?' % chl)
        self.inst.write('CHAN%s:PROB %s' % (chl, attenuation))

    def chl_invert(self, chl=None, invert=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:INV?' % chl)
        self.inst.write('CHAN%s:INV %s' % (chl, invert))

    def chl_label(self, chl=None, label=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:LAB?' % chl)
        self.inst.write('CHAN%s:LAB "%s"' % (chl, label))

    def chl_offset(self, chl=None, offset=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:OFFS?' % chl)
        self.inst.write('CHAN%s:OFFS %s' % (chl, offset))

    def chl_probe_attenuation(self, chl=None, probe=None, query=False):
        if not chl:
            raise ValueError('Must provide a scope channel')
        if chl not in self.analog_chls:
            raise ValueError('Analog channel not found')
        if query:
            return self.inst.query('CHAN%s:PROB?' % chl)
        self.inst.write('CHAN%s:PROB %s' % (chl, probe))

    def trigger_sweep(self, sweep=None, query=False):
        if query:
            return self.inst.query('TRIG:SWE?')
        if sweep not in self.trigger_sweep_modes:
            raise ValueError("Must provide a valid sweep mode")
        self.inst.write('TRIG:SWE %s' % sweep)

    def trigger_mode(self, mode=None, query=False):
        if query:
            return self.inst.query('TRIG:MODE?')
        if mode not in self.trigger_modes:
            raise ValueError("Trigger mode not found")
        self.inst.write('TRIG:MODE %s' % mode)

    def trigger_force(self):
        self.inst.write('TRIG:FORC')

    def trigger_source(self, chl=None, chl_type=None, query=False):
        if query:
            return self.inst.query('TRIG:SOUR?')
        if not chl:
            raise ValueError('Must provide a channel')
        if chl_type not in self.channel_types:
            raise ValueError('Must provide a channel type')
        self.inst.write('TRIG:SOUR %s%s' % (chl_type, chl))

    def trigger_slope(self, slope=None, query=False):
        if query:
            return self.inst.query('TRIG:SLOP?')
        self.inst.write('TRIG:SLOP %s' % slope)

    def trigger_level(self, level=None, query=False):
        if query:
            return self.inst.query('TRIG:LEV?')
        self.inst.write('TRIG:LEV %s' % level)

    def trigger_pulse_polarity(self, polarity=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:POL?' % self.TRIGGER_MODE_PULSE)
        if polarity not in self.trigger_pulse_polarities:
            raise ValueError('Must provide a valid polarity')
        return self.inst.write('TRIG:%s:POL %s' % (self.TRIGGER_MODE_PULSE, polarity))

    def trigger_pulse_pulsewidth_greater(self, width=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:GRE?' % self.TRIGGER_MODE_PULSE)
        return self.inst.write('TRIG:%s:GRE %s' % (self.TRIGGER_MODE_PULSE, width))

    def trigger_pulse_pulsewidth_less(self, width=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:LESS?' % self.TRIGGER_MODE_PULSE)
        return self.inst.write('TRIG:%s:LESS %s' % (self.TRIGGER_MODE_PULSE, width))

    def trigger_pulse_pulsewidth_level(self, level=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:LEV?' % self.TRIGGER_MODE_PULSE)
        return self.inst.write('TRIG:%s:LEV %s' % (self.TRIGGER_MODE_PULSE, level))

    def trigger_pulse_qualifier(self, qualifier=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:QUAL?' % self.TRIGGER_MODE_PULSE)
        if qualifier not in self.trigger_pulse_qualifiers:
            raise ValueError('Must provide a valid qualifier')
        return self.inst.write('TRIG:%s:QUAL %s' % (self.TRIGGER_MODE_PULSE, qualifier))

    def trigger_pulse_pulsewidth_range(self, low=None, high=None, suffix='us', query=False):
        if query:
            return self.inst.query('TRIG:%s:RANG?' % self.TRIGGER_MODE_PULSE)
        if not low or not high:
            raise ValueError('Must provide a valid pulse width range')
        return self.inst.write('TRIG:%s:RANG %s%s,%s%s' % (self.TRIGGER_MODE_PULSE, low, suffix, high, suffix))

    def trigger_pulse_source(self, chl=None, chl_type=None, query=False):
        if query:
            return self.inst.query('TRIG:%s:SOUR?' % self.TRIGGER_MODE_PULSE)
        if chl_type not in self.channel_types:
            raise ValueError('Must provide a valid channel type')
        return self.inst.write('TRIG:%s:SOUR %s%s' % (self.TRIGGER_MODE_PULSE, chl_type, chl))

    def run(self):
        self.inst.write(':RUN')

    def stop(self):
        self.inst.write(':STOP')

    def single(self):
        self.inst.write(':SING')

    def check_trigger_status(self):
        return int(self.inst.query(':TER?').strip())

    def aquisition_mode(self, mode=None, query=False):
        if query:
            return self.inst.query('ACQ:MODE?')
        self.inst.write('ACQ:MODE %s' % mode)

    def aquisition_type(self, type=None, query=False):
        if query:
            return self.inst.query('ACQ:TYPE?')
        self.inst.write('ACQ:TYPE %s' % type)

    def aquisition_count(self, count=None, query=False):
        if query:
            return self.inst.query('ACQ:COUNT?')
        self.inst.write('ACQ:COUNT %s' % count)

    def capture_data(self, timeout=5):
        self._stop()
        time.sleep(0.1)
        # Clear trigger status
        self._check_trigger_status()
        timedout = True
        start_time = time.time()
        # Start acquisition
        self._single()
        while (time.time() - start_time) < timeout:
            if self._check_trigger_status():
                timedout = False
                break
            time.sleep(0.1)  # Avoid excessive access
        # If no trigger, force trigger
        if timedout:
            self._trigger_force()
        # Wait for screen to stop
        while self._check_run_status():
            time.sleep(0.1)
        return timedout

    def read_data(self, chl=None, chl_type=None, raw_data=True):
        if not chl:
            raise ValueError('Must provide channel to read data from')
        if chl_type not in self.channel_types:
            raise ValueError('Must provide a channel type')
        self.inst.write("WAV:SOUR %s%s" % (chl_type, chl))
        if raw_data:
            self.inst.write("WAV:POIN:MODE MAX")
        else:
            self.inst.write("WAV:POIN:MODE NORM")
        self.inst.write(":WAV:FORM BYTE")
        try:
            rawdata = self.inst.query_binary_values(":WAV:DATA?", datatype='B')
        except:
            return None
        yorigin = self.inst.query_ascii_values(":WAV:YOR?")[0]
        yreference = self.inst.query_ascii_values(":WAV:YREF?")[0]
        yincrement = self.inst.query_ascii_values(":WAV:YINC?")[0]
        xorigin = self.inst.query_ascii_values(":WAV:XOR?")[0]
        xreference = self.inst.query_ascii_values(":WAV:XREF?")[0]
        xincrement = self.inst.query_ascii_values(":WAV:XINC?")[0]
        data_value = (np.asarray(rawdata) - yorigin - yreference) * yincrement
        data_time = np.linspace(xreference, xincrement * len(data_value), len(data_value))
        if self.offset_skew:
            offset = float(self._chl_offset(chl, query=True).strip())
            data_value += offset
        return {'time': data_time, 'values': data_value}

    def measure_falltime(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:FALL? CHAN%s' % chl).strip())

    def measure_risetime(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:RIS? CHAN%s' % chl).strip())

    def measure_frequency(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:FREQ? CHAN%s' % chl).strip())

    def measure_max(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VMAX? CHAN%s' % chl).strip())

    def measure_min(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VMIN? CHAN%s' % chl).strip())

    def measure_vpp(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VPP? CHAN%s' % chl).strip())

    def measure_vtop(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VTOP? CHAN%s' % chl).strip())

    def measure_vbase(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VBAS? CHAN%s' % chl).strip())

    def measure_amplitude(self, chl=None):
        if not chl:
            raise ValueError('Must provide a channel to measure')
        return float(self.inst.query('MEAS:VAMP? CHAN%s' % chl).strip())

    def check_run_status(self):
        return (int(self.inst.query(':OPER:COND?').strip()) >> 3) & 0x01

    def wavegen_function(self, chl=None, function=None, query=False):
        if query:
            if chl:
                return self.inst.query('WGEN%s:FUNC?' % chl)
            else:
                return self.inst.query('WGEN:FUNC?')
        if chl:
            self.inst.write('WGEN%s:FUNC %s' % (chl, function))
        else:
            self.inst.write('WGEN:FUNC %s' % function)

    def wavegen_frequency(self, chl=None, frequency=None, query=False):
        if query:
            if chl:
                return self.inst.query('WGEN%s:FREQ?' % chl)
            else:
                return self.inst.query('WGEN:FREQ?')
        if chl:
            self.inst.write('WGEN%s:FREQ %s' % (chl, frequency))
        else:
            self.inst.write('WGEN:FREQ %s' % frequency)

    def wavegen_voltage(self, chl=None, voltage=None, query=False):
        if query:
            if chl:
                return self.inst.query('WGEN%s:VOLT?' % chl)
            else:
                return self.inst.query('WGEN:VOLT?')
        if chl:
            self.inst.write('WGEN%s:VOLT %s' % (chl, voltage))
        else:
            self.inst.write('WGEN:VOLT %s' % voltage)

    def wavegen_output_state(self, chl=None, state=None, query=False):
        if query:
            if chl:
                return self.inst.query('WGEN%s:OUTP?' % chl)
            else:
                return self.inst.query('WGEN:OUTP?')
        if chl:
            self.inst.write('WGEN%s:OUTP %s' % (chl, state))
        else:
            self.inst.write('WGEN:OUTP %s' % state)
