from Test_Equipment.VisaInstrument import VisaInstrument


class PowerAnalyzer(VisaInstrument):
    """
    Base Power Analyzer class for controlling visa based PAs

    :param device_id: Visa instrument ID
    """
    INST_TYPE = ['PA']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
