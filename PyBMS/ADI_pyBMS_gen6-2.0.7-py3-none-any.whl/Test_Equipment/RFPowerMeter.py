from Test_Equipment.VisaInstrument import VisaInstrument


class RFPowerMeter(VisaInstrument):
    """
    Base Power Meter class

    :param device_id: Visa instrument ID
    """
    INST_TYPE = ['RFPM']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.chl_list = [1, 2]
        self.CONT_TRIGGER_ON = 'ON'
        self.CONT_TRIGGER_OFF = 'OFF'
        # self.gui = 'rfpowermeter.html'

    def continuous_trigger(self, state=None, query=False):
        if query:
            return self.inst.query('INIT:CONT?')
        if state not in [self.CONT_TRIGGER_ON, self.CONT_TRIGGER_OFF]:
            raise ValueError('Provided state %s was invalid for continuous triggering' % state)
        else:
            self.inst.write('INIT:CONT %s' % state)

    def read_average_rf_power(self, chl):
        if chl not in self.chl_list:
            raise ValueError('Provided channel not in channel list')
        return self.inst.query('FETC%s:CW:POW?' % chl).split(',')[1].strip()
