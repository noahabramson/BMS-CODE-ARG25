from Test_Equipment.VisaInstrument import VisaInstrument


class RFSwtich(VisaInstrument):
    """
    Base RF Swtich class

    :param device_id: Visa instrument ID
    """
    INST_TYPE = ['RFSwitch']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        # self.gui = 'rfswitch.html'
