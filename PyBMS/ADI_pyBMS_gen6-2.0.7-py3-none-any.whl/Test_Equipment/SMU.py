from Test_Equipment.VisaInstrument import VisaInstrument
import time


class SMU(VisaInstrument):
    """
    Abstract SMU class to create a generic SMU interface.

    :param device_id: Visa device ID
    """
    INST_TYPE = ['SMU']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.chl_list = []
        self.output_limits = None
        self.CURRENT = "CURR"
        self.VOLTAGE = "VOLT"
        self.FIXED_MODE = "FIX"
        self.LIST_MODE = "LIST"
        self.SWEEP_MODE = "SWE"
        self.RANGE_MAX = "MAX"
        self.RANGE_MIN = "MIN"
        self.RANGE_DEFAULT = "DEF"
        self.RANGE_AUTO = "AUTO"
        self.OUTPUT_ON = "ON"
        self.OUTPUT_OFF = "OFF"
        self.REMOTE_SENSE_ON = "ON"
        self.REMOTE_SENSE_OFF = "OFF"
        self.OUTPUT_LOW_GND = "GRO"
        self.OUTPUT_LOW_FLOAT = "FLO"
        self.OUTPUT_MODE_SWEEP = 'SWE'
        self.OUTPUT_MODE_LIST = 'LIST'
        self.OUTPUT_MODE_FIXED = 'FIX'
        self.FUNCTION_SHAPE_DC = 'DC'
        self.FUNCTION_SHAPE_PULSE = 'PULS'
        # self.gui = 'smu.html'

    def voltage(self, chl=None, voltage=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:VOLT:LEV:IMM:AMPL?' % chl))
            if voltage == None:
                raise ValueError('Must provide a voltage to set')
            return self.inst.write('SOUR%s:VOLT:LEV:IMM:AMPL %s' % (chl, voltage))
        else:
            if query:
                return float(self.inst.query('SOUR:VOLT:LEV:IMM:AMPL?'))
            if voltage == None:
                raise ValueError('Must provide a voltage to set')
            return self.inst.write('SOUR:VOLT:LEV:IMM:AMPL %s' % voltage)

    def voltage_current_limit(self, chl=None, limit=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:VOLT:ILIM?' % chl))
            if limit == None:
                raise ValueError('Must provide a limit to set')
            return self.inst.write('SOUR%s:VOLT:ILIM %s' % (chl, limit))
        else:
            if query:
                return float(self.inst.query('SOUR:VOLT:ILIM?'))
            if limit == None:
                raise ValueError('Must provide a limit to set')
            return self.inst.write('SOUR:VOLT:ILIM %s' % limit)

    def enable_4_wire_sense(self, chl=None, state=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:VOLT:RSEN?' % chl))
            if state == None:
                raise ValueError('Must provide a state to set')
            return self.inst.write('SENS%s:VOLT:RSEN %s' % (chl, state))
        else:
            if query:
                return float(self.inst.query('SENS:VOLT:RSEN?'))
            if state == None:
                raise ValueError('Must provide a state to set')
            return self.inst.write('SENS:VOLT:RSEN %s' % state)

    def current(self, chl=None, current=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:CURR:LEV:IMM:AMPL?' % chl))
            if current == None:
                raise ValueError('Must provide a current to set')
            return self.inst.write('SOUR%s:CURR:LEV:IMM:AMPL %s' % (chl, current))
        else:
            if query:
                return float(self.inst.query('SOUR:CURR:LEV:IMM:AMPL?'))
            if current == None:
                raise ValueError('Must provide a current to set')
            return self.inst.write('SOUR:CURR:LEV:IMM:AMPL %s' % current)

    def current_voltage_limit(self, chl=None, limit=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:CURR:VLIM?' % chl))
            if limit == None:
                raise ValueError('Must provide a limit to set')
            return self.inst.write('SOUR%s:CURR:VLIM %s' % (chl, limit))
        else:
            if query:
                return float(self.inst.query('SOUR:CURR:VLIM?'))
            if limit == None:
                raise ValueError('Must provide a limit to set')
            return self.inst.write('SOUR:CURR:VLIM %s' % limit)

    def voltage_protection(self, chl=None, protection=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:VOLT:PROT:LEV:BOTH?' % chl))
            if protection == None:
                raise ValueError('Must provide a protection setting')
            return self.inst.write('SENS%s:VOLT:PROT:LEV:BOTH %s' % (chl, protection))
        else:
            if query:
                return float(self.inst.query('SENS:VOLT:PROT:LEV:BOTH?'))
            if protection == None:
                raise ValueError('Must provide a protection setting')
            return self.inst.write('SENS:VOLT:PROT:LEV:BOTH %s' % protection)

    def current_protection(self, chl=None, protection=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:CURR:PROT:LEV:BOTH?' % chl))
            if protection == None:
                raise ValueError('Must provide a protection setting')
            return self.inst.write('SENS%s:CURR:PROT:LEV:BOTH %s' % (chl, protection))
        else:
            if query:
                return float(self.inst.query('SENS:CURR:PROT:LEV:BOTH?'))
            if protection == None:
                raise ValueError('Must provide a protection setting')
            return self.inst.write('SENS:CURR:PROT:LEV:BOTH %s' % protection)

    def voltage_output_mode(self, chl=None, mode=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:VOLT:MODE?' % chl))
            if mode == None:
                raise ValueError('Must provide a mode to set')
            return self.inst.write('SOUR%s:VOLT:MODE %s' % (chl, mode))
        else:
            if query:
                return float(self.inst.query('SOUR:VOLT:MODE?'))
            if mode == None:
                raise ValueError('Must provide a mode to set')
            return self.inst.write('SOUR:VOLT:MODE %s' % mode)

    def current_output_mode(self, chl=None, mode=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:CURR:MODE?' % chl))
            if mode == None:
                raise ValueError('Must provide a mode to set')
            return self.inst.write('SOUR%s:CURR:MODE %s' % (chl, mode))
        else:
            if query:
                return float(self.inst.query('SOUR:CURR:MODE?'))
            if mode == None:
                raise ValueError('Must provide a mode to set')
            return self.inst.write('SOUR:CURR:MODE %s' % mode)

    def current_sweep(self, chl=None, start=None, stop=None, step=None, query=False):
        if chl:
            if query:
                return self.inst.query('SOUR%s:CURR:STAR?' % chl), self.inst.query('SOUR%s:CURR:STOP?' % chl), self.inst.query('SOUR%s:CURR:STEP?' % chl)
            if start == None or stop == None or step == None:
                raise ValueError('Must provide sweep paramenters')
            self.inst.write('SOUR%s:CURR:STAR %s' % (chl, start))
            self.inst.write('SOUR%s:CURR:STOP %s' % (chl, stop))
            return self.inst.write('SOUR%s:CURR:STEP %s' % (chl, step))
        else:
            if query:
                return self.inst.query('SOUR:CURR:STAR?'), self.inst.query('SOUR:CURR:STOP?'), self.inst.query('SOUR:CURR:STEP?')
            if start == None or stop == None or step == None:
                raise ValueError('Must provide sweep paramenters')
            self.inst.write('SOUR:CURR:STAR %s' % start)
            self.inst.write('SOUR:CURR:STOP %s' % stop)
            return self.inst.write('SOUR:CURR:STEP %s' % step)

    def voltage_sweep(self, chl=None, start=None, stop=None, step=None, query=False):
        if chl:
            if query:
                return self.inst.query('SOUR%s:VOLT:STAR?' % chl), self.inst.query('SOUR%s:VOLT:STOP?' % chl), self.inst.query('SOUR%s:VOLT:STEP?' % chl)
            if start == None or stop == None or step == None:
                raise ValueError('Must provide sweep paramenters')
            self.inst.write('SOUR%s:VOLT:STAR %s' % (chl, start))
            self.inst.write('SOUR%s:VOLT:STOP %s' % (chl, stop))
            return self.inst.write('SOUR%s:VOLT:STEP %s' % (chl, step))
        else:
            if query:
                return self.inst.query('SOUR:VOLT:STAR?'), self.inst.query('SOUR:VOLT:STOP?'), self.inst.query('SOUR:VOLT:STEP?')
            if start == None or stop == None or step == None:
                raise ValueError('Must provide sweep paramenters')
            self.inst.write('SOUR:VOLT:STAR %s' % start)
            self.inst.write('SOUR:VOLT:STOP %s' % stop)
            return self.inst.write('SOUR:VOLT:STEP %s' % step)

    def output_state(self, chl=None, state=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('OUTP%s:STAT?' % chl))
            if state == None:
                raise ValueError('Must provide an output state')
            return self.inst.write('OUTP%s:STAT %s' % (chl, state))
        else:
            if query:
                return float(self.inst.query('OUTP:STAT?'))
            if state == None:
                raise ValueError('Must provide an output state')
            return self.inst.write('OUTP:STAT %s' % state)

    def source_function_mode(self, chl=None, mode=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:FUNC:MODE?' % chl))
            if mode == None:
                raise ValueError('Must provide a function mode')
            return self.inst.write('SOUR%s:FUNC:MODE %s' % (chl, mode))
        else:
            if query:
                return float(self.inst.query('SOUR:FUNC:MODE?'))
            if mode == None:
                raise ValueError('Must provide a function mode')
            return self.inst.write('SOUR:FUNC:MODE %s' % mode)

    def source_function_shape(self, chl=None, shape=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:FUNC:SHAP?' % chl))
            if shape == None:
                raise ValueError('Must provide a function shape')
            return self.inst.write('SOUR%s:FUNC:SHAP %s' % (chl, shape))
        else:
            if query:
                return float(self.inst.query('SOUR:FUNC:SHAP?'))
            if shape == None:
                raise ValueError('Must provide a function shape')
            return self.inst.write('SOUR:FUNC:SHAP %s' % shape)


    def voltage_sweep_list(self, chl=None, list=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:LIST:VOLT?' % chl))
            if list == None:
                raise ValueError('Must provide a list of sweep values')
            list_vals = ','.join(list)
            return self.inst.write('SOUR%s:LIST:VOLT %s' % (chl, list_vals))
        else:
            if query:
                return float(self.inst.query('SOUR:LIST:VOLT?'))
            if list == None:
                raise ValueError('Must provide a list of sweep values')
            list_vals = ','.join(list)
            return self.inst.write('SOUR:LIST:VOLT %s' % list_vals)

    def current_sweep_list(self, chl=None, list=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SOUR%s:LIST:CURR?' % chl))
            if list == None:
                raise ValueError('Must provide a list of sweep values')
            list_vals = ','.join(list)
            return self.inst.write('SOUR%s:LIST:CURR %s' % (chl, list_vals))
        else:
            if query:
                return float(self.inst.query('SOUR:LIST:CURR?'))
            if list == None:
                raise ValueError('Must provide a list of sweep values')
            list_vals = ','.join(list)
            return self.inst.write('SOUR:LIST:CURR %s' % list_vals)

    def pulse_sweep(self, chl=None, width=None, delay=None, query=False):
        if chl:
            if query:
                return self.inst.query('SOUR%s:PULS:WIDT?' % chl), self.inst.query('SOUR%s:PULS:DEL?' % chl)
            if width == None or delay == None:
                raise ValueError('Must provide a pulse parameters')
            self.inst.write('SOUR%s:PULS:WIDT %s' % (chl, width))
            return self.inst.write('SOUR%s:PULS:DEL %s' % (chl, delay))
        else:
            if query:
                return self.inst.query('SOUR%s:PULS:WIDT?' % chl), self.inst.query('SOUR%s:PULS:DEL?' % chl)
            if width == None or delay == None:
                raise ValueError('Must provide a pulse parameters')
            self.inst.write('SOUR:PULS:WIDT %s' % width)
            return self.inst.write('SOUR:PULS:DEL %s' % delay)

    def enable_voltage_measurement(self, chl=None, enable=True):
        if enable:
            if chl:
                return self.inst.write('SENS%s:FUNC:ON VOLT' % chl)
            else:
                return self.inst.write('SENS:FUNC:ON VOLT')
        else:
            if chl:
                return self.inst.write('SENS%s:FUNC:OFF VOLT' % chl)
            else:
                return self.inst.write('SENS:FUNC:OFF VOLT')

    def enable_current_measurement(self, chl=None, enable=True):
        if enable:
            if chl:
                return self.inst.write('SENS%s:FUNC:ON CURR' % chl)
            else:
                return self.inst.write('SENS:FUNC:ON CURR')
        else:
            if chl:
                return self.inst.write('SENS%s:FUNC:OFF CURR' % chl)
            else:
                return self.inst.write('SENS:FUNC:OFF CURR')

    def enable_resistance_measurement(self, chl=None, enable=True):
        if enable:
            if chl:
                return self.inst.write('SENS%s:FUNC:ON RES' % chl)
            else:
                return self.inst.write('SENS:FUNC:ON RES')
        else:
            if chl:
                return self.inst.write('SENS%s:FUNC:OFF RES' % chl)
            else:
                return self.inst.write('SENS:FUNC:OFF RES')

    def voltage_measurement_range(self, chl=None, range=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:VOLT:RANG?' % chl))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS%s:VOLT:RANGE %s' % (chl, range))
        else:
            if query:
                return float(self.inst.query('SENS:VOLT:RANG?'))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS:VOLT:RANG %s' % range)

    def current_measurement_range(self, chl=None, range=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:CURR:RANG?' % chl))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS%s:CURR:RANGE %s' % (chl, range))
        else:
            if query:
                return float(self.inst.query('SENS:CURR:RANG?'))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS:CURR:RANG %s' % range)

    def resistance_measurement_range(self, chl=None, range=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:RES:RANG?' % chl))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS%s:RES:RANGE %s' % (chl, range))
        else:
            if query:
                return float(self.inst.query('SENS:RES:RANG?'))
            if range == None:
                raise ValueError('Must provide a measurement range')
            return self.inst.write('SENS:RES:RANG %s' % range)

    def current_measurement_nplc(self, chl=None, nplc=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:CURR:NPLC?' % chl))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS%s:CURR:NPLC %s' % (chl, nplc))
        else:
            if query:
                return float(self.inst.query('SENS:CURR:NPLC?'))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS:CURR:NPLC %s' % nplc)

    def voltage_measurement_nplc(self, chl=None, nplc=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:VOLT:NPLC?' % chl))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS%s:VOLT:NPLC %s' % (chl, nplc))
        else:
            if query:
                return float(self.inst.query('SENS:VOLT:NPLC?'))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS:VOLT:NPLC %s' % nplc)

    def resistance_measurement_nplc(self, chl=None, nplc=None, query=False):
        if chl:
            if query:
                return float(self.inst.query('SENS%s:RES:NPLC?' % chl))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS%s:RES:NPLC %s' % (chl, nplc))
        else:
            if query:
                return float(self.inst.query('SENS:RES:NPLC?'))
            if nplc == None:
                raise ValueError('Must provide a NPLC value')
            return self.inst.write('SENS:RES:NPLC %s' % nplc)

    def measure_voltage(self, chl=None):
        try:
            if chl:
                return float(self.inst.query('MEAS:VOLT? (@%s)' % chl))
            else:
                return float(self.inst.query('MEAS:VOLT?'))
        except:
            return None

    def measure_current(self, chl=None):
        if chl:
            return float(self.inst.query('MEAS:CURR? (@%s)' % chl))
        else:
            return float(self.inst.query('MEAS:CURR?'))

    def measure_resistance(self, chl=None):
        if chl:
            return float(self.inst.query('MEAS:RES? (@%s)' % chl))
        else:
            return float(self.inst.query('MEAS:RES?'))

    def set_voltage_measure_current(self, chl=None, voltage=None, range=None, nplc=None, protection=None, delay=None):
        self.enable_current_measurement(chl=chl)
        if range:
            self.current_measurement_range(chl=chl, range=range)
        if nplc:
            self.current_measurement_nplc(chl=chl, nplc=nplc)
        if protection:
            self.current_protection(chl=chl, protection=protection)
        self.voltage(chl=chl, voltage=voltage)
        self.output_state(chl=chl, state=self.OUTPUT_ON)
        if delay:
            time.sleep(delay)
        return self.measure_current(chl=chl)

    def set_current_measure_voltage(self, chl=None, current=None, range=None, nplc=None, protection=None, delay=None):
        self.enable_voltage_measurement(chl=chl)
        if range:
            self.voltage_measurement_range(chl=chl, range=range)
        if nplc:
            self.voltage_measurement_nplc(chl=chl, nplc=nplc)
        if protection:
            self.voltage_protection(chl=chl, protection=protection)
        self.current(chl=chl, current=current)
        self.output_state(chl=chl, state=self.OUTPUT_ON)
        if delay:
            time.sleep(delay)
        return self.measure_voltage(chl=chl)
