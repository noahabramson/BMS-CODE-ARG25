from saleae import automation
import os
import os.path
import tempfile
import csv
import numpy as np
from saleae.automation import DigitalTriggerType
import time
from pprint import pprint

class Saleae_Logic_Analyzer:

    def __init__(self, digital_channels, device_id, digital_sample_rate=50_000_000, digital_threshold=3.3, port=10430):
        """
        Function that iniates the Logic Analyzer as a measurement device. Since it's non visa, it works different then others.
        :param digital_channels: list of channels in int. Bijv: [0,1,2,3]
        :param device_id: id of logic analyzer.
        You can find this in click the three dots next to Logic Pro 16 (or whatever device you have) under serial.
        Bijv: Serial #: 62AEC19F915C0EB5
        Sample Devise is: F4241
        :param digital_sample_rate: int of sample rate. Z.b. 100000000
        :param digital_threshold: 1.2, 1.8 or 3.3
        :param port: int of port. You can find this if you have automatation enabled under automation. Standard this is 10430
        """
        self.device_id = device_id
        self.port = port
        self.temp_dir = tempfile.TemporaryDirectory()
        self.channels = digital_channels

        self.device_configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=self.channels,
            digital_sample_rate=digital_sample_rate,
            digital_threshold_volts=digital_threshold,
        )

    def capture(self, trigger_config=None, timed_config=None):
        """
        Function that captures the data. You can either use trigger_config or timed_config. If you use z.b. triggered, then you have to give this dict as a config. If you give both, it will do trigger and ignore timed
        :param trigger_config: dict with: {
            trigger_type: RISING, FALLING, PULSE_HIGH, or PULSE_LOW
            trigger_channel_index: 0 - 15
            min_pulse_width_seconds: only required with PULSE_X, in seconds
            max_pulse_width_seconds: only required with PULSE_X, in seconds
            trim_data_seconds: Seconds of data at end of capture to keep. If unspecified, all data will be kept (pre_trigger)
            after_trigger_seconds: Seconds of data to record after triggering
        }
        :param timed_config: {
            duration_seconds: Stop recording after X seconds
            trim_data_seconds: Seconds of data at end of capture to keep. If unspecified, all data will be kept.
            }
        """
        with automation.Manager.connect(port=self.port) as manager:

            # Define which mode you want to use and pass the arguments
            if trigger_config:
                # Fix trigger type and filter for non valid options
                match trigger_config['trigger_type']:
                    case 1 | 'RISING':
                        trigger_config['trigger_type'] = DigitalTriggerType(1)
                    case 2 | 'FALLING':
                        trigger_config['trigger_type'] = DigitalTriggerType(2)
                    case 3 | 'PULSE_HIGH':
                        trigger_config['trigger_type'] = DigitalTriggerType(3)
                    case 4 | 'PULSE_LOW':
                        trigger_config['trigger_type'] = DigitalTriggerType(4)
                    # case _:
                    #     raise ValueError("Not a valid trigger was given. Choose 'RISING', 'FALLING', 'PULSE_HIGH' or 'PULSE_LOW'")
                capture_mode = automation.DigitalTriggerCaptureMode(**trigger_config)
            elif timed_config:
                capture_mode = automation.TimedCaptureMode(**timed_config)
            else:
                raise ValueError("No config file was given. Either define trigger_config or timed_config")

            # Set capture configuration with the just selected config
            capture_configuration = automation.CaptureConfiguration(
                capture_mode=capture_mode
            )

            # Set the manager to the correct capture mode and start measurement
            # with manager.start_capture(
            with manager.start_capture(
                    # device_id='F4241',
                    device_id=self.device_id,
                    device_configuration=self.device_configuration,
                    capture_configuration=capture_configuration
            ) as capture:
                # Wait until measurement has finished.
                capture.wait()
                # Export raw data to temp dir
                # capture.save_capture('C:\\expirimental\\pybms-dev\\internal_scratchpads\\ADBMS6837\\EIS_Eval\\Panther_Lynx_Pack_EIS\\raw2.sal')
                capture.export_raw_data_csv(directory=self.temp_dir.name, digital_channels=self.channels)
                # capture.export_raw_data_csv(directory="C:\\expirimental\\pybms-dev\\internal_scratchpads\\ADBMS6837\\EIS_Eval\\Panther_Lynx_Pack_EIS", digital_channels=self.channels)
            return 0

    def __chllst2chllst(self,channel_list):
        chl_list = []
        for channel in channel_list:
            if isinstance(channel,str):
                chl_list.append(channel)
            else:
                chl_list.append(f"Channel {channel}")
        return chl_list


    def __read_data(self, temp_dir):
        """
        :param temp_dir: Temporary directory containing the digital.csv
        :return: list of dicts containing the data. Example:
        [{
            'Channel 0': '0',
            'Channel 1': '0',
            'Channel 2': '1',
            'Channel 3': '0',
            'Time [s]': '0.000284300'},
        ]
        """
        capture_filepath = os.path.join(temp_dir.name, 'digital.csv')
        with open(capture_filepath, 'r') as fh:
            reader = csv.reader(fh, delimiter=",")
            # Get header
            headers = next(reader)
            # Convert remaining data to dict with header as keys
            data = [{h: x for (h, x) in zip(headers, row)} for row in reader]
        return data

    def __calc_delta_t(self, data, channels, start_index, max_index):
        """
        Private Function that calculated the frequencies from data. Outliners will be removed if they are more then one STD from average.
        It will only give one frequency. This is based on Rising Edge period or Falling Edge period (see result)
        :param data: data captured by logic analyzer, the result from __read_data
        :param channels: list of channels you want to observe. Z.b. ['Channel 0', 'Channel 14']
        :return: Frequencies based on [Rising Edge, Falling Edge]
        """
        results = {}
        for channel in channels:
            time = np.array([d['Time [s]'] for d in data])
            ampli = np.array([int(d[channel]) for d in data])
            d_ampli = np.r_[[0], np.diff(ampli)]
            starts = np.where(d_ampli > 0)[0]
            ends = np.where(d_ampli < 0)[0]
            re_list = time[starts].astype(float)
            fe_list = time[ends].astype(float)
            results[channel] = [re_list, fe_list]
        return results

    def measure_freq(self, channel_list, start_index=0, max_index=None):
        """
        Function that calculated the frequencies from data. Outliners will be removed if they are more then one STD from average.
        It will only give one frequency. This is based on Rising Edge period or Falling Edge period (see result).

        It first reads the data from the temp directory. Then if will use calc_delta_t to find the delta_t. After that it will
        remove outliners and calculate the frequency based on the average frequency.
        :param channels: list of channels you want to observe. Z.b. ['Channel 0', 'Channel 14']
        :param start_index: int from which datapoint you want to start. Usually this is 0, but you can skip the first value if needed
        :param max_index: int from which you want to stop scanning for frequencies. For example 14. That means it only calcs the freqs up to the 14'th sample
        :return: Frequencies based on [Rising Edge, Falling Edge]
        """
        results = {}
        data = self.__read_data(self.temp_dir)

        if not max_index:
            max_index = len(data)

        delta_ts = self.__calc_delta_t(data, self.__chllst2chllst(channel_list), start_index, max_index)

        # Remove outliners by removing frequencies bigger then one std of the average.
        for channel in delta_ts.keys():
            freqs = []
            for edge_list in delta_ts[channel]:
                # Calculate all delta t
                delta = [j - i for i, j in zip(edge_list[:-1], edge_list[1:])]

                if len(delta) == 0:
                    freqs.append(np.NAN)
                else:
                    mean = np.mean(delta, axis=0)
                    sd = np.std(delta, axis=0)

                    final_list = [x for x in delta if (x > mean - 2 * sd)]
                    final_list = [x for x in final_list if (x < mean + 2 * sd)]

                    freqs.append(1 / np.mean(final_list))

            results[channel] = freqs

        return results

    def measure_all_freqs(self, channel_list, start_index=0, max_index=None):
        """
        Function that will show all measured frequencies instead of just showing the average. It does not filter anything. That is up to the user
        :param channels: list of channels you want to observe. Z.b. ['Channel 0', 'Channel 14']
        :param start_index: int from which datapoint you want to start. Usually this is 0, but you can skip the first value if needed
        :param max_index: int from which you want to stop scanning for frequencies. For example 14. That means it only calcs the freqs up to the 14'th sample
        :return: Frequencies based on [Rising Edge, Falling Edge]
        """
        results = {}
        data = self.__read_data(self.temp_dir)

        if not max_index:
            max_index = len(data)
        index = start_index

        delta_ts = self.__calc_delta_t(data, self.__chllst2chllst(channel_list), index, max_index)

        # Calculate all frequencies
        for channel in delta_ts.keys():
            freq_list = []
            for edge_list in delta_ts[channel]:
                freqs = []
                delta = [j - i for i, j in zip(edge_list[:-1], edge_list[1:])]
                for value in delta:
                    if value > 0:
                        freqs.append(1 / value)
                freq_list.append(freqs)
            results[channel] = freq_list

        return results
