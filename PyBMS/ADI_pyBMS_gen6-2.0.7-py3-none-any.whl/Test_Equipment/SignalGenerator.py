from Test_Equipment.VisaInstrument import VisaInstrument
from abc import ABCMeta


class SignalGenerator(VisaInstrument):
    """
    Base Signal Generator class

    :param device_id: Visa instrument ID
    """
    INST_TYPE = ['SigGen']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.output_limits = None
        self.OUTPUT_BLANKING_ON = 'ON'
        self.OUTPUT_BLANKING_OFF = 'OFF'
        self.OUTPUT_ON = 'ON'
        self.OUTPUT_OFF = 'OFF'
        self.OUTPUT_MOD_ON = 'ON'
        self.OUTPUT_MOD_OFF = 'OFF'
        self.OUTPUT_PROT_ON = 'ON'
        self.OUTPUT_PROT_OFF = 'OFF'
        self.FREQ_MODE_CW = 'CW'
        self.FREQ_MODE_FIX = 'FIX'
        self.FREQ_MODE_LIST = 'LIST'
        # self.gui = 'siggen.html'

    def output_auto_blanking(self, state=None, query=False):
        if query:
            return self.inst.query('OUTP:BLAN:AUTO?')
        if state not in [self.OUTPUT_BLANKING_ON, self.OUTPUT_BLANKING_OFF]:
            raise ValueError('Must provide a valid state for auto output blanking')
        else:
            self.inst.write('OUTP:BLAN:AUTO %s' % state)

    def output_manual_blanking(self, state=None, query=False):
        if query:
            return self.inst.query('OUTP:BLAN:STAT?')
        if state not in [self.OUTPUT_BLANKING_ON, self.OUTPUT_BLANKING_OFF]:
            raise ValueError('Must provide a valid state for output blanking')
        else:
            self.inst.write('OUTP:BLAN:STAT %s' % state)

    def output_state(self, state=None, query=False):
        if query:
            return self.inst.query('OUTP:STAT?')
        if state not in [self.OUTPUT_ON, self.OUTPUT_OFF]:
            raise ValueError('Must provide a valid state for output')
        else:
            self.inst.write('OUTP:STAT %s' % state)

    def output_modulation_state(self, state=None, query=False):
        if query:
            return self.inst.query('OUTP:MOD:STAT?')
        if state not in [self.OUTPUT_MOD_ON, self.OUTPUT_MOD_OFF]:
            raise ValueError('Must provide a valid state for output modulation')
        else:
            self.inst.write('OUTP:MOD:STAT %s' % state)

    def output_protection(self, state=None, query=False):
        if query:
            return self.inst.query('OUTP:PROT:STAT?')
        if state not in [self.OUTPUT_PROT_ON, self.OUTPUT_PROT_OFF]:
            raise ValueError('Must provide a valid state for output protection')
        else:
            self.inst.write('OUTP:PROT:STAT %s' % state)

    def set_pulse(self, voltage_high, voltage_low=0, dT=50):
        # self.inst.write(f'*RST')
        self.inst.write(f'FUNCtion:SHAPe PULSe')
        self.inst.write(f'VOLTage:LOW {voltage_low}')
        self.inst.write(f'VOLTage:HIGH {voltage_high}')
        self.inst.write(f'FUNCTION:PULSE:DCYCLE {dT}')

    def set_sine(self, voltage_high, voltage_low=0,):
        # self.inst.write(f'*RST')
        self.inst.write(f'FUNCtion:SHAPe SIN')
        self.inst.write(f'VOLTage:LOW {voltage_low}')
        self.inst.write(f'VOLTage:HIGH {voltage_high}')
        # self.inst.write(f'FUNCTION:PULSE:DCYCLE {dT}')

    def set_ramp(self, voltage_high, voltage_low=0,):
        self.inst.write(f'FUNCtion:SHAPe SQUAre')
        self.inst.write(f'VOLTage:LOW {voltage_low}')
        self.inst.write(f'VOLTage:HIGH {voltage_high}')

    def set_square(self, voltage_high, voltage_low=0, dt=50):
        self.inst.write(f'FUNCtion:SHAPe SQUARE')
        self.inst.write(f'VOLTage:LOW {voltage_low}')
        self.inst.write(f'VOLTage:HIGH {voltage_high}')
        self.inst.write(f'FUNCTION:SQUARE:DCYCLE {dt}')

    def set_frequency(self, frequency):
        self.inst.write(f'FREQUENCY {frequency}')

    def set_dT(self, dT):
        self.inst.write(f'FUNCTION:PULSE:DCYCLE {dT}')

    def sig_amplitude_dbm(self, amp=None, query=False):
        if query:
            return self.inst.query('POW:LEV:IMM:AMPL?').strip()
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude must be below: %s' % self.output_limits['amp_max'])
        self.inst.write('POW:LEV:IMM:AMPL %sDBM' % amp)

    def sig_amplitude_volt(self, amp=None, query=False):
        if query:
            return self.inst.query('VOLT?').strip()
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude must be below: %s' % self.output_limits['amp_max'])
        self.inst.write('VOLT %s' % amp)

    def sig_amplitude_volt_high(self, amp=None, query=False):
        if query:
            return self.inst.query('VOLT:HIGH?').strip()
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude high must be below: %s' % self.output_limits['amp_max'])
        self.inst.write('VOLT:HIGH %s' % amp)

    def sig_amplitude_volt_low(self, amp=None, query=False):
        if query:
            return self.inst.query('VOLT:LOW?').strip()
        if self.output_limits:
            if amp > self.output_limits['amp_max']:
                raise ValueError('Output amplitude low must be above: %s' % self.output_limits['amp_max'])
        self.inst.write('VOLT:LOW %s' % amp)

    def sig_offset_dbm(self, offset=None, query=False):
        if query:
            return self.inst.query('POW:LEV:IMM:OFFS?').strip()
        if self.output_limits:
            if self.output_limits['offset_min'] > offset or offset > self.output_limits['offset_max']:
                raise ValueError('Output offset must be between: [%s]-[%s]' % (
                self.output_limits['offset_min'], self.output_limits['offset_max']))
        self.inst.write('POW:LEV:IMM:OFFS %sDBM' % offset)

    def sig_offset_volt(self, offset=None, query=False):
        if query:
            return self.inst.query('VOLT:OFFS?').strip()
        if self.output_limits:
            if self.output_limits['offset_min'] > offset or offset > self.output_limits['offset_max']:
                raise ValueError('Output offset must be between: [%s]-[%s]' % (
                self.output_limits['offset_min'], self.output_limits['offset_max']))
        self.inst.write('VOLT:OFFS %s' % offset)

    def frequency_mode(self, mode=None, query=False):
        if query:
            return self.inst.query('FREQ:MODE?')
        if mode not in [self.FREQ_MODE_CW, self.FREQ_MODE_FIX, self.FREQ_MODE_LIST]:
            raise ValueError('Must provide a valid mode for output frequency')
        else:
            self.inst.write('FREQ:MODE %s' % mode)

    def frequency_cw(self, cw=None, query=False):
        if query:
            return self.inst.query('FREQ:CW?').strip()
        if self.output_limits:
            if self.output_limits['freq_min'] > cw or cw > self.output_limits['cw_max']:
                raise ValueError('Output frequency must be between: [%s]-[%s]' % (
                self.output_limits['cw_min'], self.output_limits['cw_max']))
        self.inst.write('FREQ:CW %sMHZ' % cw)


class AgilentSignalGenerator(SignalGenerator, metaclass=ABCMeta):
    BRAND = ['Agilent Technologies']

    def __init__(self, device_id, em, logger=None):
        SignalGenerator.__init__(self, device_id, em, logger=logger)

    def sig_amplitude_dbm(self, amp=None, query=False):
        raise ValueError('This signal generator does not use dBm units')

    def sig_offset_dbm(self, offset=None, query=False):
        raise ValueError('This signal generator does not use dBm units')


class TektronixSignalGenerator(SignalGenerator, metaclass=ABCMeta):
    BRAND = ['TEKTRONIX']

    def __init__(self, device_id, em, logger=None):
        SignalGenerator.__init__(self, device_id, em, logger=logger)
