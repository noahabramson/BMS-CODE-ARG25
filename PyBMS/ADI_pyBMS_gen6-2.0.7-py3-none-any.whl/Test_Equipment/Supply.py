from Test_Equipment.VisaInstrument import VisaInstrument


class Supply(VisaInstrument):
    """
    Base Supply class

    :param device_id: Visa instrument ID
    """
    INST_TYPE = ['Supply']

    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.MODES = []
        self.OUTPUT_ON = 'ON'
        self.OUTPUT_OFF = 'OFF'
        self.OUTPUT_STATES = [self.OUTPUT_ON, self.OUTPUT_OFF]
        self.gui = 'supply.html'
        self.chls = []
        self.gui_kwargs = {'chls': []}

    def _set_channel(self, channel: int):
        if channel in self.chls:
            self.inst.write('INST:NSEL {:d}'.format(channel))
        else:
            self.logger.warning('Power supply {:s} does not have a channel {:d}'.format(self.device_id, channel))

    def voltage(self, chl=None, voltage=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('SOUR:VOLT:LEV:IMM:AMPL?')
        if voltage is None:
            raise ValueError('Must provide a voltage to set')
        voltage = float(voltage)
        return self.inst.write('SOUR:VOLT:LEV:IMM:AMPL {:f}'.format(voltage))

    def current(self, chl=None, current=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('SOUR:CURR:LEV:IMM:AMPL?')
        if current is None:
            raise ValueError('Must provide a current to set')
        current = float(current)
        return self.inst.write('SOUR:CURR:LEV:IMM:AMPL {:f}'.format(current))

    def output_state(self, chl=None, state=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('OUTP:STAT?')

        if not state:
            raise ValueError('Must provide an output state')
        return self.inst.write('OUTP:STAT %s' % state)

    def range(self, chl=None, range=None, query=False):
        pass

    def mode(self, chl=None, mode=None, query=False):
        if chl is not None:
            self._set_channel(channel=chl)

        if query:
            return self.inst.query('OUTP:MODE?')
        if mode not in self.MODES:
            raise ValueError('Mode not valid')
        else:
            self.inst.write('OUTP:MODE %s' % mode)

    def measure_voltage(self, chl=None):
        if chl is not None:
            self._set_channel(channel=chl)

        return float(self.inst.query('MEAS:VOLT?'))

    def measure_current(self, chl=None):
        if chl is not None:
            self._set_channel(channel=chl)

        return float(self.inst.query('MEAS:CURR?'))
