from Test_Equipment.VisaInstrument import VisaInstrument


class ThermalChamber(VisaInstrument):
    """
    Instrument base class. Right now focused on visa style instruments.

    :param device_id: Visa device id
    """

    INST_TYPE = ['ThermalChamber']


    def __init__(self, device_id, em, logger=None):
        VisaInstrument.__init__(self, device_id, em, logger=logger)
        self.gui = "visa_instrument.html"
        self.ON = 'ON'
        self.OFF = 'OFF'


    def temperature(self):
        return self.inst.query('Temperature?')


    def setpoint(self, temperature=25, query=False):
        if query:
            return self.inst.query('Setpoint?')
        self.inst.write('Setpoint %s' % temperature)


    def heat_state(self, state):
        if state not in [self.ON, self.OFF]:
            raise ValueError('Not a valid state')
        self.inst.write('Heat %s' % state)


    def cool_state(self, state):
        if state not in [self.ON, self.OFF]:
            raise ValueError('Not a valid state')
        self.inst.write('Cool %s' % state)

    def indirect_write(self, msg=None):
        self.inst.write(msg)

    def indirect_query(self, query=None):
        return self.inst.query(query)
