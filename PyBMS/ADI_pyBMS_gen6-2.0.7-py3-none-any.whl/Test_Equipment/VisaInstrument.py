from Test_Equipment.Instrument import Instrument
import types


class VisaInstrument(Instrument):
    """
    Instrument base class. Right now focused on visa style instruments.

    :param device_id: Visa device id
    """

    INST_TYPE = []
    INST_TAB = None
    BRAND = []
    MODEL_NUM = []

    def __init__(self, device_id, em, logger=None, simulator=False):
        Instrument.__init__(self, device_id, em, logger=logger)
        try: # Possibility for own resource manager
            self.rm = self.em.rm
        except:
            self.rm = self.em
        self.available_resources = self.rm.list_resources()
        self.inst = None

        if simulator is True:
            self.inst = types.SimpleNamespace()     # Needed to assign arbitrary methods to empty instance
            self.inst.write = types.MethodType(self.sim_write, self.inst)   # Overrides .write with sim_write
            self.inst.query = types.MethodType(self.sim_query, self.inst)   # Overrides .query with sim_query
        else:
            self.open()

        self.gui = "visa_instrument.html"

    def simulator_write(self, dummy1, dummy2):
        return 0

    def simulator_query(self, dummy1, dummy2):
        return 'simulator is on'

    def open(self):
        """
        Create Visa object, store in self.inst
        """
        try:
            self.inst = self.rm.open_resource(self.id)
        except:
            raise ValueError("Device not found in available resources")

    def get_identification(self):
        return self.inst.query('*IDN?')

    def reset(self):
        return self.inst.write('*RST')

    def close(self):
        """
        Close Visa object
        """
        self.inst.close()
        return True

    def indirect_write(self, msg=None):
        self.inst.write(msg)

    def indirect_query(self, query=None):
        return self.inst.query(query)
